from pathlib import Path
from datetime import datetime,timezone
import json,os,subprocess,sys
from run_remaining11 import remaining_jobs,EXPECTED_SOURCE,AUTHORIZATION,save,digest

r=Path('/root/five_chains_20261117_resume');e=r/'chain_native_validation_evidence'
source=r/'chain_native_validation_staging_v11_joint_skip_load';entry=r/'document_reproduction_entry_v6_failure_reporting'
original=e/'native_full_reproduction_v11_user_skip_no_video_attempt1'
prior=e/'native_remaining11_v11_user_authorized_20261117_attempt1'
out=e/'native_remaining11_v11_user_authorized_20261117_attempt2_resume'
sys.path[:0]=[str(entry),str(source)]
from five_chains.validation_protocol import source_manifest,manifest_digest,verify_legacy_files
from five_chains.native_validation import configure,control_configuration
from reproduce_document_validation import verify_test_gate
assert manifest_digest(source_manifest(source))==EXPECTED_SOURCE
gate=json.loads((e/'test_gate_v11_joint_skip.json').read_text());assert verify_test_gate(source,gate)==EXPECTED_SOURCE
canonical=json.loads((original/'plan.json').read_text());alljobs=remaining_jobs(canonical)
priorplan=json.loads((prior/'plan.json').read_text());assert priorplan['human_authorization']==AUTHORIZATION
assert [{k:j[k] for k in ('id','stage','group','case')} for j in priorplan['jobs']]==alljobs
assert json.loads((original/'gate_a.json').read_text())['all_single_chains_passed'] is False
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();terminal=[]
receipts=[e/(prior.name+'_process.json')]+list(prior.glob('*_process.json'));assert len(receipts)==2
for p in receipts:
    v=json.loads(p.read_text());assert v['boot_id']==boot
    stat=Path('/proc')/str(v['pid'])/'stat';actual=None
    if stat.exists():
        raw=stat.read_text();f=raw[raw.rfind(')')+2:].split();actual={'start_ticks':f[19],'state':f[0]}
        assert f[19]!=str(v['start_ticks']) or f[0]=='Z'
    terminal.append({'receipt':v,'observed':actual,'same_live_process':False})
for proc in Path('/proc').iterdir():
    if not proc.name.isdigit():continue
    try:parts=(proc/'cmdline').read_bytes().split(b'\0')
    except (FileNotFoundError,PermissionError,ProcessLookupError):continue
    assert not any(x.endswith((b'/run_native_chain_episode.py',b'/run_native_chain_suite.py',
        b'/reproduce_document_validation.py',b'/run_registered_demand_v9_attempt2.py',b'/run_remaining11.py')) for x in parts),str(proc)
verify_legacy_files(source/'configs/protected_legacy.json',Path('/root/autodl-tmp/adaptive_semantics_20261031'))
outcomes=list(prior.glob('*_outcome.json'));assert len(outcomes)==1
completed=json.loads(outcomes[0].read_text());assert completed['id']==alljobs[0]['id']=='demand_00'
assert completed['case']==alljobs[0]['case'] and completed['passed'] is True
directory=Path(completed['directory']);result=json.loads((directory/'result.json').read_text())
assert result['status']=='completed' and result['step_audit_passed'] and result['source_unchanged']
assert result['audited_env_steps']==4288 and result['actual_model_calls']==2
jobs=alljobs[1:];assert len(jobs)==10
for job in jobs:configure(control_configuration(source,job['case']),job['case'])
out.mkdir(exist_ok=False);(out/'registration').mkdir();stamp=datetime.now(timezone.utc).isoformat()
plan={**priorplan,'created_utc':stamp,'jobs':[],
    'resume_scope':'Tooling-only counter repair; retain and recheck completed demand00, execute only original10 unlaunched cases. No completed native rerun.',
    'prior_attempt':str(prior),'prior_attempt_terminal_processes':terminal,
    'prior_driver_error_sha256':digest(e/(prior.name+'_driver.log')),
    'reuse_completed':[{'directory':str(directory),'outcome_path':str(outcomes[0]),
        'raw_sha256':digest(directory/'ticks.jsonl.gz'),'result_sha256':digest(directory/'result.json')}],
    'planned_total_original_cases':11,'new_cases_to_launch':10,'case_fields_changed':[]}
for job in jobs:
    reg={'schema':'native_chain_case/v1','created_utc':stamp,'case':job['case'],
        'source_manifest_sha256':EXPECTED_SOURCE,'workers':1,'wall_budget_seconds':1200,'test_gate':gate,
        'intervention_scope':'Exact remaining10 of explicitly authorized standalone11; original failedGateA unchanged; no task-rate/full31 pass claim.',
        'human_launch_authorization':AUTHORIZATION,'original_batch_gate_a_passed':False}
    p=out/'registration'/(job['id']+'.json');save(p,reg)
    plan['jobs'].append({**job,'registration':p.relative_to(out).as_posix(),'registration_sha256':digest(p)})
save(out/'plan.json',plan)
driver=Path(__file__).resolve().with_name('run_remaining11.py')
env={**os.environ,'HC_SOURCE_ROOT':str(source),'HC_LEGACY_ROOT':'/root/autodl-tmp/adaptive_semantics_20261031',
    'HC_WORK_DIR':str(e/'remaining11_v11_user_authorized_work')}
cmd=['bash',str(source/'scripts/remote_python.sh'),str(driver),'--plan',str(out/'plan.json')]
with (e/(out.name+'_driver.log')).open('x') as log:
    proc=subprocess.Popen(cmd,cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    raw=Path(f'/proc/{proc.pid}/stat').read_text()
    receipt={'pid':proc.pid,'start_ticks':raw[raw.rfind(')')+2:].split()[19],'boot_id':boot,
        'kind':'remaining11_tooling_resume_only_unlaunched10','output':str(out),'source_root':str(source),
        'source_manifest_sha256':EXPECTED_SOURCE,'command':cmd,'driver_sha256':digest(driver),
        'plan_sha256':digest(out/'plan.json'),'created_utc':stamp,'original_gate_a_passed':False,
        'planned_cases':11,'reused_completed':1,'new_cases_to_launch':10}
    save(e/(out.name+'_process.json'),receipt)
print(json.dumps(receipt),flush=True)
