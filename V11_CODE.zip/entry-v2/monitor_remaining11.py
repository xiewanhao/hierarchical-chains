"""Small SSH stdin monitor; compares exact PID/start_ticks on the same boot."""
from pathlib import Path
from datetime import datetime,timezone
import json
base=Path('/root/five_chains_20261117_resume/chain_native_validation_evidence')
name='native_remaining11_v11_user_authorized_20261117_attempt2_resume'
def read(p):return json.loads(p.read_text()) if p.exists() else None
receipt=read(base/(name+'_process.json'));out=Path(receipt['output'])
def inspect(r):
    p=Path('/proc')/str(r['pid'])/'stat';actual=None;state=None
    if p.exists():
        raw=p.read_text();fields=raw[raw.rfind(')')+2:].split();actual=fields[19];state=fields[0]
    return {'pid':r['pid'],'expected_start_ticks':r['start_ticks'],'actual_start_ticks':actual,
        'state':state,'live':str(r['start_ticks'])==actual and state!='Z'}
assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==receipt['boot_id']
records=[read(p) for p in sorted(out.glob('*_outcome.json'))]
workers=[]
for p in out.glob('*_process.json'):
    r=read(p);proof=inspect(r)
    if proof['live']:workers.append({'process':proof,'directory':r['directory'],
        'progress':read(Path(r['directory'])/'progress.json')})
print(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),'driver':inspect(receipt),
    'boot_id_matches':True,'planned_cases':11,'completed_cases':len(records),
    'passed_cases':sum(r['passed'] for r in records),'active_workers':workers,
    'completed_only_native_steps':sum(r['summary']['native_steps'] for r in records),
    'completed_only_model_calls':sum(read(Path(r['directory'])/'result.json')['actual_model_calls'] for r in records),
    'unpassed':[{'id':r['id'],'reason':r['summary']['reason']} for r in records if not r['passed']],
    'result':read(out/'remaining11_result.json'),
    'driver_log_tail':(base/(name+'_driver.log')).read_text()[-2500:]}))
