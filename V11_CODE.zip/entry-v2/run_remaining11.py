"""Explicitly authorized standalone continuation; never promotes failed Gate A."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import argparse, json, os, shutil, subprocess, sys, traceback

AUTHORIZATION='启动剩下11例检测'
EXPECTED_SOURCE='3ddc8b1f58dd64f13bd75aeaf45c71a49372218e68f6d05bb48aadd1ed57c69c'

def read(p):return json.loads(p.read_text())
def digest(p):return sha256(p.read_bytes()).hexdigest()
def save(p,v):
    with p.open('x',encoding='utf-8') as f:json.dump(v,f,ensure_ascii=False,indent=2)
def update(p,v):
    t=p.with_suffix('.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2));t.replace(p)

def remaining_jobs(original):
    jobs=original['jobs']
    if len(jobs)!=31 or any(j['stage']!='single' for j in jobs[:20]):
        raise ValueError('Original complete31 plan required')
    result=jobs[20:]
    if [j['stage'] for j in result]!=['demand']*10+['joint']:
        raise ValueError('Exact original10 demand then1 joint required')
    if len({j['id'] for j in result})!=11:raise ValueError('Duplicate case identifier')
    if result[-1]['case']!=original['joint_protocol']['case']:
        raise ValueError('Joint case no longer matches original protocol')
    return result

def integrity_ok(status,result):
    return status==0 and result.get('status')=='completed' and result.get('step_audit_passed') is True and result.get('source_unchanged') is True

def conclusion(records,demand,joint,error):
    return {'completed_cases':len(records),'planned_cases':11,'passed_cases':sum(r['passed'] for r in records),
        'standalone_remaining11_passed':bool(len(records)==11 and all(r['passed'] for r in records)
            and demand and demand['passed'] and joint and joint['passed'] and error is None),
        'original_batch_gate_a_passed':False,'original31_all_passed':False,
        'requested_whole_document_completed':False,'scope':'User-authorized separate remaining11 detection; original20 remain18pass/2unpassed.',
        'native_steps':sum(r['summary']['native_steps'] for r in records),
        'actual_model_calls':sum(r['actual_model_calls'] for r in records),
        'demand':demand,'joint':joint,'error':error,
        'skipped_requirements':['joint_button_lowload_same_tick']}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True)
    args=parser.parse_args();out=args.plan.resolve().parent;plan=read(args.plan)
    assert plan['human_authorization']==AUTHORIZATION and plan['original_batch_gate_a_passed'] is False
    source=Path(plan['source_root']);entry=Path(plan['entry_root'])
    sys.path[:0]=[str(entry),str(source)]
    from five_chains.validation_protocol import source_manifest,manifest_digest,verify_legacy_files
    from five_chains.native_validation_summary import inspect_native
    from five_chains.chain_summary import summarize,write_outputs
    from reproduce_document_validation import verify_test_gate,independent_case,audit_demand,audit_joint,collect_tables_guarded
    assert manifest_digest(source_manifest(source))==plan['source_manifest_sha256']==EXPECTED_SOURCE
    assert verify_test_gate(source,plan['test_gate'])==EXPECTED_SOURCE
    for n,h in plan['entry_manifest'].items():assert digest(entry/n)==h
    for j in plan['jobs']:assert digest(out/j['registration'])==j['registration_sha256']
    verify_legacy_files(source/'configs/protected_legacy.json',Path(os.environ['HC_LEGACY_ROOT']))
    records=[];error=None;demand=None;joint=None;tables=None;table_error=None
    try:
        for restored in plan.get('reuse_completed',[]):
            directory=Path(restored['directory'])
            assert digest(directory/'ticks.jsonl.gz')==restored['raw_sha256']
            assert digest(directory/'result.json')==restored['result_sha256']
            old=read(Path(restored['outcome_path']));result=read(directory/'result.json')
            summary=inspect_native(directory);checks=independent_case(directory,summary)
            assert summary==old['summary'] and checks==old['independent_checks']
            assert old['passed'] and all(checks.values()) and integrity_ok(old['exit_code'],result)
            old['actual_model_calls']=result['actual_model_calls']
            old['reused_completed_from_attempt1']=True
            records.append(old)
            save(out/(old['id']+'_outcome.json'),old)
        for job in plan['jobs']:
            assert manifest_digest(source_manifest(source))==EXPECTED_SOURCE
            destination=out/job['stage']/job['id'];destination.parent.mkdir(exist_ok=True)
            assert not destination.exists()
            cmd=['bash',str(source/'scripts/remote_python.sh'),str(source/'scripts/run_native_chain_episode.py'),
                 '--registration',str(out/job['registration']),'--output',str(destination)]
            with (out/(job['id']+'.log')).open('x') as log:
                worker=subprocess.Popen(cmd,cwd=source,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
                raw=Path(f'/proc/{worker.pid}/stat').read_text()
                receipt={'pid':worker.pid,'start_ticks':raw[raw.rfind(')')+2:].split()[19],
                    'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                    'directory':str(destination),'id':job['id'],'command':cmd}
                save(out/(job['id']+'_process.json'),receipt);update(out/'active_worker.json',receipt)
                status=worker.wait()
            if not (destination/'result.json').is_file():raise RuntimeError('No terminal result: '+job['id'])
            result=read(destination/'result.json');summary=inspect_native(destination)
            save(destination/'validation_summary.json',summary)
            independent=independent_case(destination,summary)
            extra=audit_joint(destination,summary,plan['joint_protocol']['protocol']) if job['stage']=='joint' else None
            table=summarize(destination/'ticks.jsonl.gz','V3_native_intervention',summary['native_steps'])
            passed=all(independent.values()) and table['trace_complete'] and (extra is None or extra['passed'])
            table['case_assertions']=summary['checks'];table['status']='PASS' if passed else 'FAIL'
            write_outputs(table,destination/'chain_table')
            record={k:job[k] for k in ('id','stage','group','case')}
            record.update(directory=str(destination),summary=summary,independent_checks=independent,
                joint_checks=extra,passed=passed,exit_code=status,actual_model_calls=result['actual_model_calls'])
            records.append(record);save(out/(job['id']+'_outcome.json'),record)
            update(out/'suite_progress.json',conclusion(records,None,None,None))
            print(json.dumps({'id':job['id'],'passed':passed,'steps':summary['native_steps'],'reason':summary['reason']}),flush=True)
            if not integrity_ok(status,result):raise RuntimeError('Runtime/integrity failure; no automatic retry: '+job['id'])
        demand=audit_demand(records)
        last=next((r for r in records if r['stage']=='joint'),None)
        if last:
            joint=last['joint_checks']
            for ext in ('json','html'):
                shutil.copyfile(Path(last['directory'])/('chain_table/timeline.'+ext),out/('joint_timeline.'+ext))
    except Exception as exc:error={'error':repr(exc),'traceback':traceback.format_exc()}
    finally:
        if records:tables,table_error=collect_tables_guarded(records,out)
        if table_error and error is None:error=table_error
        final=conclusion(records,demand,joint,error);final['table_generation']=tables
        final['finalization_error']=table_error
        final['source_unchanged']=manifest_digest(source_manifest(source))==EXPECTED_SOURCE
        verify_legacy_files(source/'configs/protected_legacy.json',Path(os.environ['HC_LEGACY_ROOT']))
        save(out/'remaining11_result.json',final)
        print(json.dumps(final),flush=True)
    if error:raise SystemExit(1)

if __name__=='__main__':main()
