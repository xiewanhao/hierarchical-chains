import copy,json,unittest
from pathlib import Path
import run_remaining11 as r

def plan():
    joint={'probe':'joint','record_video':False}
    return {'jobs':[{'stage':'single','id':str(i)} for i in range(20)]+
        [{'stage':'demand','id':'d'+str(i),'case':{'demand_layer':1}} for i in range(10)]+
        [{'stage':'joint','id':'j','case':joint}], 'joint_protocol':{'case':joint}}

class ContinuationTests(unittest.TestCase):
    def test_exact_remaining_jobs_unchanged(self):
        p=plan();before=copy.deepcopy(p);self.assertEqual(r.remaining_jobs(p),p['jobs'][20:]);self.assertEqual(p,before)
    def test_missing_case_rejected(self):
        p=plan();p['jobs'].pop(20)
        with self.assertRaises(ValueError):r.remaining_jobs(p)
    def test_changed_joint_rejected(self):
        p=plan();p['joint_protocol']['case']=dict(p['joint_protocol']['case'],record_video=True)
        with self.assertRaises(ValueError):r.remaining_jobs(p)
    def test_even_all11_pass_never_promotes_original_failed_gate(self):
        records=[{'passed':True,'actual_model_calls':1,'summary':{'native_steps':1}} for _ in range(11)]
        c=r.conclusion(records,{'passed':True},{'passed':True},None)
        self.assertTrue(c['standalone_remaining11_passed']);self.assertFalse(c['original31_all_passed']);self.assertFalse(c['original_batch_gate_a_passed'])
    def test_partial_or_unpassed_preserved(self):
        records=[{'passed':False,'actual_model_calls':1,'summary':{'native_steps':1}}]
        self.assertFalse(r.conclusion(records,{'passed':True},{'passed':True},None)['standalone_remaining11_passed'])
    def test_runtime_error_stops_but_scientific_failure_does_not_change_integrity(self):
        self.assertTrue(r.integrity_ok(0,{'status':'completed','step_audit_passed':True,'source_unchanged':True,'success':False}))
        self.assertFalse(r.integrity_ok(1,{'status':'error','step_audit_passed':True,'source_unchanged':True}))
    def test_native_summary_without_model_count_uses_actual_result_record(self):
        record={'passed':True,'actual_model_calls':2,'summary':{'native_steps':4288}}
        c=r.conclusion([record],None,None,None)
        self.assertEqual(c['actual_model_calls'],2);self.assertEqual(c['native_steps'],4288)

if __name__=='__main__':unittest.main()
