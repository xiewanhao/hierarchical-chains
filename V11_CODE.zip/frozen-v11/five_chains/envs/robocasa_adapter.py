"""RoboCasa 1.0.1 / robosuite 1.5.2 adapter, verified against installed source.

OSC uses input_type delta or absolute and input_ref_frame world or base. Delta
translations and axis-angle increments are transformed with the live controller
origin. HybridMobileBase.create_action_vector owns its extra base_mode element.
No action dimensions or slices are assumed. Frequency is env.control_freq.
Default fixed impedance cannot consume stiffness_scale; variable_kp is explicitly
requested at construction when configured. Controller metadata is saved per run.
Only this module imports robocasa / robosuite. Only Executor.execute steps env.
"""
from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose, rigid, inverse, rotation_distance
from five_chains.types import Contract, P7, SkillCall, WorldState


def make_environment(config: dict) -> Any:
    import random
    import robocasa
    import robosuite
    from robosuite.controllers import load_composite_controller_config
    envcfg = config["environment"]
    controller = load_composite_controller_config(controller=None, robot=envcfg["robot"])
    # load_composite_controller_config refactors the JSON arms nesting into parts.
    arm = controller["body_parts"][envcfg["arm"]]
    if envcfg.get("variable_stiffness", True):
        arm["impedance_mode"] = "variable_kp"
    # Some installed asset/placement utilities use process RNGs as well as env.rng.
    random.seed(envcfg["seed"])
    np.random.seed(envcfg["seed"])
    return robosuite.make(envcfg["task"], robots=envcfg["robot"], controller_configs=controller,
        has_renderer=False, has_offscreen_renderer=envcfg["render"], use_camera_obs=False,
        layout_and_style_ids=[tuple(v) for v in envcfg["layout_and_style_ids"]],
        seed=envcfg["seed"], ignore_done=False, horizon=config["control"]["max_ticks"])


class RoboCasaAdapter:
    def __init__(self, env: Any, config: dict) -> None:
        self.env = env
        self.config = config
        self.arm = config["environment"]["arm"]
        # Kitchen creates robot models lazily on its first reset.
        self._initial_obs = env.reset()
        if len(env.robots) != 1:
            raise ValueError("this adapter requires one verified mobile manipulator")
        self.robot = env.robots[0]
        self.composite = self.robot.composite_controller
        self.controller = self.composite.part_controllers[self.arm]
        self.control_freq = float(env.control_freq)
        # variable_kp reset consumes a zero action, so live kp can be zero here.
        # The nominal gains must come from the loaded part configuration.
        self.nominal_kp = np.broadcast_to(np.asarray(
            self.composite.part_controller_config[self.arm]["kp"], dtype=float), (6,)).copy()
        if np.any(self.nominal_kp <= 0):
            raise ValueError("nominal configured stiffness must be positive")
        from five_chains.envs.asset_geometry import grasp_signatures
        self.grasp_signatures=grasp_signatures(env,self.arm)
        self.posture_solver: Any = None
        self.posture_goal: np.ndarray | None = None
        self.posture_key: tuple | None = None
        self.posture_origin: np.ndarray | None = None
        self.stance_diagnostic: dict = {}
        self.posture_solution: np.ndarray | None = None
        self.posture_command: np.ndarray | None = None
        self.posture_diagnostic: dict = {}
        self._bind_posture_solver()
        self.grasp_transforms: dict[str, np.ndarray] = {}
        self.grasp_origins: dict[str, np.ndarray] = {}
        self.grasp_contact_counts: dict[str, int] = {}
        self.grasp_gap_counts: dict[str, int] = {}
        self.grasp_evidence_times: dict[str, float] = {}
        self.grasp_load_origins: dict[str,np.ndarray] = {}
        self.grasp_load_relations: dict[str,np.ndarray] = {}
        self.grasp_load_stable_counts: dict[str,int] = {}
        self.gripper_command = "open"
        self.context: tuple[Contract, P7, np.ndarray, float] | None = None
        self.context_key: tuple | None = None
        self.phase_ticks = 0
        self.context_time: float | None = None
        self.door_evidence_time: float | None = None
        self.door_closed_counts = 0
        if self.arm + "_gripper" not in self.composite._action_split_indexes:
            raise ValueError("live gripper segment is not declared by the controller")
        self.gripper_dof = int(self.robot.gripper[self.arm].dof)
        if self.controller.name != "OSC_POSE" or self.controller.input_type not in ("delta", "absolute"):
            raise ValueError("adapter supports verified OSC_POSE interfaces only")
        if self.controller.input_ref_frame not in ("world", "base"):
            raise ValueError("unsupported controller reference")

    def _bind_posture_solver(self) -> None:
        model=self.env.sim.model._model
        self.gripper_collision_ids=np.array([i for i in range(model.ngeom)
            if (self.env.sim.model.geom_id2name(i) or '').startswith('gripper0_') and
               (model.geom_contype[i] or model.geom_conaffinity[i])],dtype=int)
        self.motion_failure: str | None = None
        self.motion_scene: Any = None
        self.motion_key: tuple | None = None
        self.motion_goal: np.ndarray | None = None
        self.motion_origin: np.ndarray | None = None
        self.motion_path: tuple[np.ndarray,...] = ()
        from five_chains.envs.scene_path import MeasuredStallFeedback
        self.motion_stall_feedback=MeasuredStallFeedback()
        self.motion_index=0;self.motion_stamp=-1
        self.posture_solver=None;self.posture_goal=None;self.posture_key=None;self.posture_origin=None;self.stance_diagnostic={};self.posture_solution=None;self.posture_command=None;self.posture_diagnostic={}
        if self.config['control']['posture_ik']['enabled']:
            from five_chains.envs.pose_ik import RobotPoseIK
            self.posture_solver=RobotPoseIK(self.env.sim.model._model,int(self.robot.eef_site_id[self.arm]),
                np.asarray(self.controller.joint_index),np.asarray(self.controller.qpos_index),
                np.asarray(self.controller.initial_joint),self.config['control']['posture_ik'])

    def metadata(self) -> dict:
        import robocasa
        import robosuite
        import mujoco
        return {"robocasa": robocasa.__version__, "robosuite": robosuite.__version__, "mujoco": mujoco.__version__,
                "action_dim": self.env.action_dim, "control_freq": self.control_freq,
                "layout": dict(self.composite._action_split_indexes), "composite": self.composite.name,
                "arm": self.controller.name, "input_type": self.controller.input_type,
                "input_ref_frame": self.controller.input_ref_frame, "impedance_mode": self.controller.impedance_mode,
                "arm_input_min": self.controller.input_min.tolist(), "arm_input_max": self.controller.input_max.tolist(),
                "arm_output_min": self.controller.output_min.tolist(), "arm_output_max": self.controller.output_max.tolist(),
                "configured_nominal_kp": self.nominal_kp.tolist(), "current_kp": self.controller.kp.tolist(),
                "gripper_action_dim": self.gripper_dof,
                "posture_ik":self.posture_diagnostic, "posture_ik_enabled":self.config["control"]["posture_ik"]["enabled"],
                "grasp_provider":self.config["grasp"]["provider"], "grasp_signatures":self.grasp_signatures,
                "grasp_contact_mode": self.config['feedback']['grasp_contact_mode'],
                "source_protocol": "simulator_ground_truth_development"}

    def initial_signature(self) -> dict:
        import hashlib,json
        metadata=json.dumps(self.env.get_ep_meta(),sort_keys=True,default=str).encode()
        return {'ep_meta_sha256':hashlib.sha256(metadata).hexdigest(),
                'qpos_sha256':hashlib.sha256(np.asarray(self.env.sim.data.qpos).tobytes()).hexdigest(),
                'qvel_sha256':hashlib.sha256(np.asarray(self.env.sim.data.qvel).tobytes()).hexdigest(),
                'python_hash_seed':__import__('os').environ.get('PYTHONHASHSEED'),'seed':self.config['environment']['seed'],'rngs_seeded':['python.random','numpy.random','environment.rng']}

    def reset(self, env: Any) -> dict:
        self.grasp_transforms.clear()
        self.grasp_acquisition_relations: dict[str,np.ndarray] = {}
        self.release_support_evidence: dict[tuple,dict] = {}
        self.grasp_origins.clear()
        self.grasp_contact_counts.clear()
        self.grasp_gap_counts.clear()
        self.grasp_evidence_times.clear()
        self.grasp_load_origins.clear();self.grasp_load_relations.clear();self.grasp_load_stable_counts.clear()
        self.gripper_command = "open"
        self.context = None
        self.context_key = None
        self.context_time = None
        self.door_evidence_time = None
        self.door_closed_counts = 0
        self.phase_ticks = 0
        if self._initial_obs is not None:
            obs = self._initial_obs
            self._initial_obs = None
        else:
            obs = env.reset()
        self.robot = env.robots[0]
        self.composite = env.robots[0].composite_controller
        self.controller = self.composite.part_controllers[self.arm]
        from five_chains.envs.asset_geometry import grasp_signatures
        self.grasp_signatures=grasp_signatures(env,self.arm)
        self._bind_posture_solver()
        return self.observe(obs)

    def current_pose(self) -> np.ndarray:
        self.controller.update(force=True)
        return pose(self.controller.ref_pos, self.controller.ref_ori_mat)

    def current_base_pose(self) -> np.ndarray:
        obs=self.env._get_observations(force_update=True)
        return pose(obs['robot0_base_pos'],Rotation.from_quat(obs['robot0_base_quat']).as_matrix())

    def receptacle_egress_clear(self, target: str, entities: dict, cavities: tuple[str, ...],
                               eef: np.ndarray, reached: bool) -> bool:
        """Additional clearance for a receptacle still inside an observed cavity.

        Object distance alone can be satisfied by the hand above the bowl while
        the hand remains inside the appliance. Preserve the existing native
        placement/contact checks and require the prepared retreat to finish.
        """
        containing = []
        for name in cavities:
            if name not in entities:
                continue
            cavity = entities[name]
            local = inverse(cavity['pose_world']) @ entities[target]['pose_world']
            if np.all(np.abs(local[:3, 3]) <= np.asarray(cavity['extent'])):
                containing.append((float(np.prod(cavity['extent'])), name))
        if not containing:
            return True
        cavity = entities[min(containing)[1]]
        local_eef = inverse(cavity['pose_world']) @ eef
        return bool(reached and local_eef[1, 3] < -cavity['extent'][1]
                    - self.config['grasp']['cavity_exit_clearance_m'])

    def native_motion_diagnostics(self) -> dict:
        import mujoco
        from five_chains.envs.contact_telemetry import sample_contacts
        model = self.env.sim.model
        if not hasattr(self, '_contact_diag_names'):
            self._contact_diag_names = tuple(model.geom_id2name(i) or ('unnamed_' + str(i))
                                            for i in range(model._model.ngeom))
            prefixes = (self.robot.robot_model.naming_prefix, self.robot.gripper[self.arm].naming_prefix)
            self._contact_diag_robot = frozenset(i for i, name in enumerate(self._contact_diag_names)
                                                if name.startswith(prefixes))
        selected = self.context[0].call.bindings.get('object') if self.context else None
        payload = (frozenset(int(model.geom_name2id(name)) for name in self.env.objects[selected].contact_geoms)
                   if selected in self.env.objects else frozenset())
        record = sample_contacts(model._model, self.env.sim.data._data, self._contact_diag_robot,
                                 payload, self._contact_diag_names, mujoco.mj_contactForce)
        record['selected_object'] = selected
        if self.context and 'handle' in self.context[0].call.bindings:
            appliance = getattr(self.env, self.context[0].call.bindings.get('appliance', ''), None)
            if appliance is not None and hasattr(appliance, 'handle_name'):
                from five_chains.envs.contact_telemetry import contact_separation
                target_ids = frozenset([int(model.geom_name2id(appliance.handle_name))])
                direction = contact_separation(record['contacts'], target_ids,
                                               frozenset(map(int, self.gripper_collision_ids)))
                if direction is not None:
                    direction['target_entity'] = self.context[0].call.bindings['handle']
                    record['handle_contact_egress'] = direction
        if self.config['reflex']['bounds'].get('gripper_load_band_n') is not None and selected in self.env.objects:
            gripper=self.robot.gripper[self.arm]
            if type(gripper).__name__!='PandaGripper' or self.gripper_dof!=1 or not np.isclose(gripper.speed,.2):
                raise ValueError('native reference feedback only verified for PandaGripper')
            actuator_ids=[int(model.actuator_name2id(name)) for name in gripper.actuators]
            ranges=model._model.actuator_ctrlrange[actuator_ids]
            if ranges.shape!=(2,2) or not np.allclose(ranges,[[0.,.04],[-.04,0.]]):
                raise ValueError('unverified native Panda position actuator mapping')
            groups=[set(gripper.important_geoms[key]) for key in ('left_fingerpad','right_fingerpad')]
            loads=np.zeros(2)
            for contact in record['contacts']:
                if not contact['touches_payload']:continue
                names=set(contact['geom_names'])
                for side,group in enumerate(groups):
                    if names & group:loads[side]+=max(0.,float(contact['solver_wrench_contact_frame'][0]))
            reference=np.asarray(self.env.sim.data.ctrl)[actuator_ids]
            record['gripper_reference_feedback']={
                'source':'native_simulator_contact_solver','scope':'experimental simulator feedback, not independent tactile sensing',
                'selected_object':selected,'closing_intent':self.gripper_command=='close',
                'bilateral_native_pads':bool(self.env._check_grasp(gripper,self.env.objects[selected].contact_geoms)),
                'actuator_kp_n_m':model._model.actuator_gainprm[actuator_ids,0].copy(),
                'joint_frictionloss_n':model._model.dof_frictionloss[[model._model.jnt_dofadr[model.joint_name2id(n)] for n in gripper.joints]].copy(),
                'pad_normal_loads_n':loads,'reference_width_m':float(np.sum(np.abs(reference))),
                'measured_width_m':float(sum(abs(self.env.sim.data.qpos[model._model.jnt_qposadr[model.joint_name2id(n)]]) for n in gripper.joints)),
                'open_step_width_m':float(gripper.speed*np.sum((ranges[:,1]-ranges[:,0])/2.))}
        record['osc'] = {name: (np.asarray(getattr(self.controller, name)).copy()
                               if getattr(self.controller, name, None) is not None else None)
                         for name in ('goal_pos', 'goal_ori', 'origin_pos', 'origin_ori')}
        record['osc']['input_ref_frame'] = self.controller.input_ref_frame
        record['osc']['goal_update_mode'] = getattr(self.controller, '_goal_update_mode', None)
        if self.config['environment']['joint_dynamics_telemetry'] and self.posture_solver is not None:
            from five_chains.envs.contact_telemetry import sample_joint_dynamics
            record['joint_dynamics']=sample_joint_dynamics(model._model,self.env.sim.data._data,
                                                          self.posture_solver.joints,self.controller)
        return record

    def _estimate_grasp(self, name: str, item: Any, eef: np.ndarray) -> tuple[bool, dict]:
        """Contact acquisition and bounded retention, independently checked by lift motion.

        A contact-acquisition event is not a claim of verified lift retention.
        Native pad evidence remains separately logged for comparison.
        """
        gripper=self.robot.gripper[self.arm]
        native=bool(self.env._check_grasp(gripper,item.contact_geoms))
        left=bool(self.env.check_contact(gripper.important_geoms['left_finger'],item.contact_geoms))
        right=bool(self.env.check_contact(gripper.important_geoms['right_finger'],item.contact_geoms))
        cfg=self.config['feedback']
        contact=native if cfg['grasp_contact_mode']=='native_pads' else left and right
        closing=self.gripper_command=='close'
        now=float(self.env.sim.data.time)
        fresh=name not in self.grasp_evidence_times or abs(now-self.grasp_evidence_times[name])>1e-12
        if fresh:
            self.grasp_contact_counts[name]=self.grasp_contact_counts.get(name,0)+1 if contact and closing else 0
            self.grasp_gap_counts[name]=0 if left or right else self.grasp_gap_counts.get(name,0)+1
            self.grasp_evidence_times[name]=now
        body=pose(self.env.sim.data.get_body_xpos(item.root_body),self.env.sim.data.get_body_xmat(item.root_body))
        relation=inverse(eef)@body
        prior=self.grasp_transforms.get(name)
        if not hasattr(self,'grasp_acquisition_relations'):self.grasp_acquisition_relations={}
        acquisition=self.grasp_acquisition_relations.get(name)
        cumulative_translation=float(np.linalg.norm(relation[:3,3]-acquisition[:3,3])) if acquisition is not None else None
        cumulative_rotation=rotation_distance(relation[:3,:3],acquisition[:3,:3]) if acquisition is not None else None
        translation_error=float(np.linalg.norm(relation[:3,3]-prior[:3,3])) if prior is not None else None
        rotation_error=rotation_distance(relation[:3,:3],prior[:3,:3]) if prior is not None else None
        load=self.config['grasp']['loaded_acquisition'];load_height=0.;load_stable=0;support_clear=False;load_ready=not load['enabled']
        if load['enabled'] and prior is None:
            active=bool(self.context and self.context[1].phase_name=='grasp'
                and self.context[0].call.bindings.get('object')==name and closing)
            if active:
                assert self.context is not None
                if name not in self.grasp_load_origins:self.grasp_load_origins[name]=body[:3,3].copy()
                load_height=float(body[2,3]-self.grasp_load_origins[name][2])
                support_clear=not any(self.env.check_contact(item,support) for support in
                    (getattr(self.env,'counter',None),getattr(self.env,'sink',None)) if support is not None)
                if fresh:
                    previous=self.grasp_load_relations.get(name)
                    stable=bool(contact and support_clear and load_height>=load['min_object_lift_m'] and previous is not None
                        and np.linalg.norm(relation[:3,3]-previous[:3,3])<=load['stable_translation_m']
                        and rotation_distance(relation[:3,:3],previous[:3,:3])<=load['stable_rotation_rad'])
                    self.grasp_load_stable_counts[name]=self.grasp_load_stable_counts.get(name,0)+1 if stable else 0
                    self.grasp_load_relations[name]=relation.copy()
                load_stable=self.grasp_load_stable_counts.get(name,0)
                load_ready=load_height>=load['min_object_lift_m'] and support_clear and load_stable>=load['stable_frames']
                if 'tilt_limit' in self.context[0].fields:
                    limit=max(abs(v) for v in self.context[0].fields['tilt_limit'].default)
                    load_ready=load_ready and float(np.arccos(np.clip(body[2,2],-1,1)))<=limit
            elif fresh:
                self.grasp_load_origins.pop(name,None);self.grasp_load_relations.pop(name,None);self.grasp_load_stable_counts.pop(name,None)
        if prior is None:
            # Establish the measurement at the actual settled-grasp event, not
            # at first contact while the fingers/object are still closing.
            settled=bool(self.context and self.context[1].phase_name=='grasp'
                         and self.phase_ticks>=self.config['grasp']['close_settle_ticks'])
            held=fresh and closing and settled and load_ready and self.grasp_contact_counts.get(name,0)>=cfg['grasp_confirm_steps']
            if held:
                self.grasp_transforms[name]=relation.copy()
                self.grasp_acquisition_relations[name]=relation.copy()
                self.grasp_origins[name]=body[:3,3].copy()
        else:
            assert translation_error is not None and rotation_error is not None
            held=bool(closing and translation_error<=cfg['grasp_retention_translation_m']
                and rotation_error<=cfg['grasp_retention_rotation_rad']
                and self.grasp_gap_counts[name]<=cfg['grasp_contact_grace_steps'])
            # Continuous bilateral native-pad evidence permits measuring compliant
            # drift. The original acquisition relation remains immutable diagnostic
            # evidence. No contact means no rebase; abrupt slip still fails above.
            if held and fresh and native:self.grasp_transforms[name]=relation.copy()
        if not held:
            self.grasp_transforms.pop(name,None)
            self.grasp_origins.pop(name,None)
            self.grasp_acquisition_relations.pop(name,None)
        return held,{'native_bilateral_grasp':native,'left_finger_contact':left,'right_finger_contact':right,
                     'retention_estimate':held,'contact_mode':cfg['grasp_contact_mode'],
                     'loaded_acquisition_enabled':load['enabled'],'load_height_m':load_height,
                     'load_stable_frames':load_stable,'support_clear':support_clear,
                     'eef_object_distance_m':float(np.linalg.norm(relation[:3,3])),
                     'relation_translation_error_m':translation_error,'relation_rotation_error_rad':rotation_error,
                     'cumulative_translation_since_acquisition_m':cumulative_translation,
                     'cumulative_rotation_since_acquisition_rad':cumulative_rotation,
                     'live_relation_updated':bool(prior is not None and held and fresh and native)}

    def _release_ready(self, obj: str, held: list[str], raw_obs: dict, placement_ready: bool = False) -> bool:
        def reject() -> bool:
            for key in list(getattr(self,'release_support_evidence',{})):
                if key[2]==obj:self.release_support_evidence.pop(key,None)
            return False
        if obj in held or self.phase_ticks<25:return reject()
        width=float(np.sum(np.abs(raw_obs['robot0_gripper_qpos'])))
        if width<.075:return reject()
        item=self.env.objects[obj]
        touching=bool(self.env.check_contact(self.robot.gripper[self.arm],item.contact_geoms))
        if not touching:return True
        # A released object can rest against one fully open finger. Permit
        # geometric egress only after native placement, fixture support and
        # ten distinct stable physical frames; this is not contact-free holding.
        if not placement_ready or self.context is None:return reject()
        contract,phase,_,_=self.context;target=contract.call.bindings.get('target')
        fixture=getattr(self,'region_fixtures',{}).get(target)
        if fixture is None and target is not None:
            fixture=self.env.objects.get(target,getattr(self.env,target.removesuffix('_interior'),None))
        if fixture is None or not self.env.check_contact(item,fixture):return reject()
        if not hasattr(self,'release_support_evidence'):self.release_support_evidence={}
        key=(contract.contract_id,phase.phase_index,obj);data=self.env.sim.data;now=float(data.time)
        body=pose(data.get_body_xpos(item.root_body),data.get_body_xmat(item.root_body))
        previous=self.release_support_evidence.get(key)
        if previous is not None and now<=previous['time']+1e-12:return previous['stable_frames']>=10
        stable=bool(previous is not None and np.linalg.norm(body[:3,3]-previous['pose'][:3,3])<=.0005
                    and rotation_distance(body[:3,:3],previous['pose'][:3,:3])<=.005)
        count=previous['stable_frames']+1 if stable and previous is not None else 0
        self.release_support_evidence[key]={'time':now,'pose':body.copy(),'stable_frames':count,
            'condition':'fully open, native placed, supported, stable; residual finger contact, egress still required'}
        return count>=10

    def _update_phase_clock(self, now: float) -> None:
        if self.context is None:return
        contract,phase,_,_=self.context
        key=(contract.contract_id,phase.phase_index)
        if key!=self.context_key:
            self.phase_ticks=0;self.context_key=key;self.context_time=now
        elif self.context_time is None or now>self.context_time+1e-12:
            self.phase_ticks+=1;self.context_time=now

    def _door_settled(self, now: float, closed: bool, velocity: float) -> bool:
        active=bool(self.context and self.context[1].phase_name=='settle_door')
        valid=bool(active and closed and abs(velocity)<=self.config['grasp']['door_closed_max_velocity_rad_s'])
        if self.door_evidence_time is None or abs(now-self.door_evidence_time)>1e-12:
            self.door_closed_counts=self.door_closed_counts+1 if valid else 0
            self.door_evidence_time=now
        return bool(valid and self.door_closed_counts>=self.config['grasp']['door_closed_settle_ticks'])

    def observe(self, raw_obs: dict) -> dict:
        from robocasa.utils import object_utils as OU
        env = self.env
        sim = env.sim
        self._update_phase_clock(float(sim.data.time))
        eef = self.current_pose()
        entities: dict[str, dict[str, Any]] = {}
        predicates: dict[str, bool] = {}
        held = []
        previously_held = set(self.grasp_transforms)
        grasp_modes = {}
        top_offsets = {}
        bottom_offsets = {}
        grasp_diagnostics = {}
        gripper = self.robot.gripper[self.arm]
        for name, item in env.objects.items():
            transform = pose(sim.data.get_body_xpos(item.root_body), sim.data.get_body_xmat(item.root_body))
            # RoboCasa horizontal_radius is the xy half-box diagonal, not either half-size.
            extent = np.asarray(item.size,dtype=float) / 2.
            entities[name] = dict(pose_world=transform, extent=extent, joints={})
            top_offsets[name] = np.asarray(item.top_offset).copy()
            bottom_offsets[name] = np.asarray(item.bottom_offset).copy()
            if env.get_obj_lang(name).lower() == "bowl":
                grasp_modes[name] = "rim"
            grasp,grasp_diagnostics[name] = self._estimate_grasp(name,item,eef)
            if grasp:
                held.append(name)
        fixture = env.microwave
        body = fixture.root_body
        t = pose(sim.data.get_body_xpos(body), sim.data.get_body_xmat(body))
        angle = float(sim.data.get_joint_qpos(fixture.door_joint_names[0]))
        hinge_id = sim.model.joint_name2id(fixture.door_joint_names[0])
        hinge_velocity=float(sim.data.get_joint_qvel(fixture.door_joint_names[0]))
        hinge = dict(angle=angle, velocity_rad_s=hinge_velocity, axis_world=sim.data.xaxis[hinge_id].copy(), anchor_world=sim.data.xanchor[hinge_id].copy())
        entities["microwave"] = dict(pose_world=t, extent=np.asarray(fixture.size) / 2, joints={"door": angle})
        # get_int_sites returns region -> [p0,px,py,pz], not site -> position.
        sites = fixture.get_int_sites(relative=False)
        region = fixture.get_reset_region_names()[0]
        p0, px, py, pz = np.asarray(sites[region], float)
        axes = np.column_stack([px-p0, py-p0, pz-p0])
        center = p0 + np.sum(axes, axis=1) / 2
        extent = np.linalg.norm(axes, axis=0) / 2
        entities["microwave_interior"] = dict(pose_world=pose(center, t[:3, :3]), extent=extent, joints={})
        import mujoco
        panel=sim.model.geom_name2id(fixture.door_name+'_main')
        if int(sim.model.geom_type[panel])!=int(mujoco.mjtGeom.mjGEOM_BOX):
            raise ValueError('door preview requires the verified native box collision descriptor')
        entities['microwave_door']=dict(pose_world=pose(sim.data.geom_xpos[panel],sim.data.geom_xmat[panel].reshape(3,3)),
            extent=np.asarray(sim.model.geom_size[panel]).copy(),joints={})
        support_frames: dict[str,str]={}
        support_entities=[]
        for role in ('counter','sink'):
            support=getattr(env,role,None)
            if support is None:continue
            support_pose=pose(sim.data.get_body_xpos(support.root_body),sim.data.get_body_xmat(support.root_body))
            entities[role]=dict(pose_world=support_pose,extent=np.asarray(support.size)/2.,joints={})
            support_entities.append(role)
            for name,item in env.objects.items():
                if env.check_contact(item,support):support_frames[name]=role
        normals = {}
        for entity, geom in (("handle", fixture.handle_name), ("start", fixture.name + "_start_button")):
            i = sim.model.geom_name2id(geom)
            entities[entity] = dict(pose_world=pose(sim.data.geom_xpos[i], sim.data.geom_xmat[i].reshape(3, 3)),
                                    extent=sim.model.geom_size[i].copy(), joints={})
            normal = -t[:3, 1]
            if entity == "handle":
                normal = Rotation.from_rotvec(angle * hinge["axis_world"]).as_matrix() @ normal
            normals[entity] = normal
        predicates.update(vegetable_in_bowl=bool(OU.check_obj_in_receptacle(env, "vegetable", "bowl")),
                          bowl_in_microwave=bool(OU.obj_inside_of(env, "bowl", fixture)),
                          door_closed=bool(fixture.is_closed(env)), button_pressed=bool(fixture.get_state()["turned_on"]))
        predicates['door_closed_settled']=self._door_settled(float(sim.data.time),predicates['door_closed'],hinge_velocity)
        distance = 0.0
        continuous = {"eef_track_err": 0.0, "tilt_dev": 0.0}
        if self.context:
            contract, phase, target, track = self.context
            obj = contract.call.bindings.get("object")
            if "tilt_limit" in contract.fields:
                obj = contract.fields["tilt_limit"].arguments.get("entity", obj)
            predicates["grasp_established"] = bool(obj in held and
                (phase.phase_name != "grasp" or self.phase_ticks >= self.config['grasp']['close_settle_ticks']))
            actuator=contract.fields[contract.phases[phase.phase_index].target_field].arguments.get('actuator','arm')
            base_phase = actuator == 'base'
            torso_phase = actuator == 'torso' 
            measured = (pose(raw_obs["robot0_base_pos"], Rotation.from_quat(raw_obs["robot0_base_quat"]).as_matrix())
                        if base_phase else eef)
            distance = 0. if torso_phase else float(np.linalg.norm(measured[:3, 3] - target[:3, 3]))
            orientation_error = 0. if torso_phase else rotation_distance(measured[:3, :3], target[:3, :3])
            limits = self.config["base"] if base_phase else self.config["control"]
            position_limit = (self.config['grasp']['reached_m'] if not base_phase and (grasp_modes.get(obj) == 'rim' or self.config['grasp'].get('precise_acquisition',False)) and phase.phase_name in ('descend','grasp')
                              else (self.config['base']['stance_reached_m'] if base_phase and contract.fields[contract.phases[phase.phase_index].target_field].recipe == 'base_stance' else limits['reached_m']))
            target_name=contract.call.bindings.get('target')
            if phase.phase_name == 'carry' and target_name is not None and grasp_modes.get(target_name) == 'rim':
                # Drop above a receptacle has a region tolerance; actual placement
                # and later clearance are still checked by the native predicates.
                position_limit=min(self.config['grasp']['container_drop_reached_m'],float(np.min(entities[target_name]['extent'][:2]))/4.)
            if torso_phase:
                part=self.composite.part_controllers['torso']
                distance=abs(float(sim.data.qpos[part.qpos_index[0]])-float(target))
                orientation_error=0.;position_limit=self.config['torso']['reached_m']
            reached = (distance <= position_limit and orientation_error <= limits["reached_rad"]
                       and self.hinge_approach_branch_ready(contract,phase,np.asarray(sim.data.qpos)))
            predicates["reached"] = bool(reached and self.phase_ticks >= self.config["control"]["phase_dwell_ticks"])
            predicates['door_closed_and_retreated']=bool(predicates['door_closed'] and predicates['reached'] and phase.phase_name=='release_contact' and contract.call.skill=='close_hinged_door')
            predicates['activated_and_retreated']=bool(predicates['button_pressed'] and predicates['reached'] and phase.phase_name=='release_contact' and contract.call.skill=='activate_control')
            predicates["base_reached"] = predicates["reached"] and base_phase
            predicates['torso_reached'] = predicates['reached'] and torso_phase
            origin=self.grasp_origins.get(obj) if obj is not None else None
            predicates['lift_complete']=bool(obj is not None and obj in held and origin is not None and predicates['reached']
                and phase.phase_name=='lift' and entities[obj]['pose_world'][2,3]-origin[2]>=self.config['feedback']['lift_retention_min_m'])
            predicates["released"] = bool(obj not in held and self.phase_ticks >= self.config["control"]["phase_dwell_ticks"])
            predicates["placed"] = predicates["vegetable_in_bowl"] if obj == "vegetable" else predicates["bowl_in_microwave"]
            if phase.phase_name=='release' and obj is not None and obj in env.objects:
                predicates['released']=self._release_ready(obj,held,raw_obs,predicates['placed'])
            target_entity = contract.call.bindings.get("target")
            clear = False
            if target_entity == "microwave_interior":
                cavity = entities[target_entity]
                local_eef = inverse(cavity["pose_world"]) @ eef
                clear = bool(local_eef[1,3] < -cavity["extent"][1]-self.config["grasp"]["cavity_exit_clearance_m"])
            elif target_entity is not None and target_entity in env.objects:
                receiving = env.objects[target_entity]
                center = entities[target_entity]["pose_world"][:3,3]
                clear = (np.linalg.norm(eef[:3,3]-center) >= self.config["grasp"]["retreat_clearance_m"]
                         and not env.check_contact(gripper,receiving.contact_geoms))
            if clear and target_entity is not None and target_entity in env.objects:
                clear = self.receptacle_egress_clear(target_entity, entities, ('microwave_interior',),
                                                    eef, predicates['reached'])
            predicates["placed_and_retreated"] = bool(predicates["placed"] and clear and phase.phase_name == "retreat")
            predicates["unexpected_grasp_lost"] = bool(obj in previously_held and obj not in held
                and contract.phases[phase.phase_index].gripper == "close")
            predicates["object_at_entrance"] = predicates["reached"] and phase.phase_name == "carry"
            predicates["local_complete"] = predicates["reached"]
            continuous["eef_track_err"] = 0.0 if base_phase else float(track)
            if base_phase:
                continuous["base_track_err"] = float(track)
            from five_chains.observation_projection import tilt_deviation
            continuous["tilt_dev"] = tilt_deviation(contract,
                {name: entity['pose_world'][:3, 2] for name, entity in entities.items()})
        predicates.setdefault("grasp_established", bool(held))
        base = pose(raw_obs["robot0_base_pos"], Rotation.from_quat(raw_obs["robot0_base_quat"]).as_matrix())
        finger_joint = sim.model.joint_name2id(gripper.joints[0])
        opening_axis = eef[:3,:3].T @ np.asarray(sim.data.xaxis[finger_joint])
        state: dict[str, Any] = dict(entities=entities, eef_pose_world=eef, base_pose_world=base,
                     gripper_width=float(np.sum(np.abs(raw_obs["robot0_gripper_qpos"]))),
                     signals={"predicates": predicates, "continuous": continuous,
                              "grasp_transforms": deepcopy(self.grasp_transforms), "target_distance_m": distance,
                              "microwave_hinge": hinge, "surface_normals": normals})
        torso=self.composite.part_controllers['torso']
        origin,_=self.composite.get_controller_base_pose(self.arm)
        state['signals']['torso']={'position_m':float(sim.data.qpos[torso.qpos_index[0]]),
            'origin_world':np.asarray(origin).copy(),'command_target_m':getattr(self,'torso_command_target',None),'range_m':sim.model._model.jnt_range[torso.joint_index[0]].copy()}
        state['signals']['base_hold_target']=deepcopy(getattr(self,'base_hold_command_target',None))
        state['signals']['stance_ik']=deepcopy(self.stance_diagnostic)
        from five_chains.envs.asset_geometry import collision_boxes_world
        if self.posture_solver is not None:
            state['signals']['arm_joint_state']=self.arm_joint_state()
        state['signals']['gripper_collision_points_world']=collision_boxes_world(sim.model._model,sim.data,self.gripper_collision_ids)
        state["signals"].update(loaded_grasp_enabled=self.config["grasp"]["loaded_acquisition"]["enabled"],grasp_modes=grasp_modes, object_top_offsets=top_offsets,
                                object_bottom_offsets=bottom_offsets, cavity_entities=("microwave_interior",),
                                cavity_obstacles={"microwave_interior":("microwave_door","handle")},
                                fixture_front_entities=("microwave_interior",*support_entities), object_support_frames=support_frames, grasp_signatures=self.grasp_signatures,
                                robot_kinematic_qpos=np.asarray(sim.data.qpos).copy(),posture_ik=deepcopy(self.posture_diagnostic),
                                gripper_opening_axis_eef=opening_axis, grasp_diagnostics=grasp_diagnostics)
        state['signals']['native_motion_diagnostics'] = self.native_motion_diagnostics()
        # Force/unsafe-contact channels are absent unless independently instrumented;
        # absence is not interpreted as a measured zero force.
        return {"state": state, "raw": raw_obs}

    def set_execution_context(self, contract: Contract, p7: P7, target: np.ndarray, error: float) -> None:
        self.context = (contract, p7, target.copy(), error)

    def reference_bridge_begin(self, packet: Any, contract: Contract, p7: P7,
                               world: WorldState, override: Any) -> None:
        """Optional passive capture only; original action/reference never changed."""
        from five_chains.envs.reference_bridge import ReferenceBridge, Scope, digest
        self.reference_preview: dict[str,Any] | None=None
        if not hasattr(self,'reference_bridge'):
            self.reference_bridge=ReferenceBridge()
        self._reference_bridge_in_scope=bool(contract.call.skill=='close_hinged_door'
            and p7.phase_name in ('approach','close') and override is None
            and self.posture_solver is not None)
        if not self._reference_bridge_in_scope:
            self.reference_bridge.abort()
            return
        qpos=np.asarray(world.signals['robot_kinematic_qpos']).copy()
        appliance=getattr(self.env,contract.call.bindings['appliance'])
        model=self.env.sim.model._model
        excluded=set(int(i) for i in self.posture_solver.qpos)
        for name in appliance.door_joint_names:
            j=self.env.sim.model.joint_name2id(name)
            excluded.add(int(model.jnt_qposadr[j]))
        if len(appliance.door_joint_names)!=1:
            raise ValueError('native reference preview supports the original single microwave hinge only')
        self._reference_preview_door_qpos=int(model.jnt_qposadr[j])
        observed=[float(qpos[i]) for i in range(len(qpos)) if i not in excluded]
        parameter=packet.params['closed_handle_pose']
        target_signature=digest((parameter.kind.value,parameter.frame_entity,parameter.value))
        # Exact non-arm/non-door state binding is deliberately conservative.
        # No new scene tolerance or runtime contact permission is introduced.
        scene_signature=digest((observed,world.signals.get('grasp_transforms',{})))
        # Provenance comparison cannot renew the original exact lease.
        old_branch=self.reference_bridge.branch
        comparison: dict[str,Any]={}
        if old_branch is not None and old_branch.source_record is not None:
            try:
                from five_chains.envs.forecast_dependencies import fixed_inputs
                contact=(contract.call.bindings['appliance'],contract.call.bindings['handle'],
                    float(contract.fields['closed_handle_pose'].arguments.get('contact_preload_m',0.)))
                comparison=old_branch.source_record.compare_fixed(fixed_inputs(self,qpos,world,contact,
                    self._reference_preview_door_qpos))
            except (ValueError,TypeError,AttributeError,KeyError) as exc:
                comparison={'fixed_prerequisites_equal':False,'forecast_reuse_admitted':False,
                    'reference':None,'reason':'source_comparison_unavailable:'+str(exc)}
        self.reference_bridge.begin(Scope(contract.contract_id,p7.phase_name,world.stamp,
            target_signature,scene_signature,False))
        self.reference_bridge.source_comparison=comparison

    def reference_bridge_prepare(self, action: np.ndarray, executions: int) -> None:
        if getattr(self,'_reference_bridge_in_scope',False):
            self.reference_bridge.prepare(action,self.controller.initial_joint,
                float(self.env.sim.data.time),executions)
            if (self.config['control'].get('close_reference_native_preview_shadow',False)
                    and self.reference_bridge.scope is not None
                    and self.reference_bridge.scope.phase=='close'):
                from five_chains.envs.native_reference_preview import NativeReferencePreview
                if not hasattr(self,'native_reference_preview'):
                    self.native_reference_preview=NativeReferencePreview(self)
                self.reference_preview=self.native_reference_preview.baseline(action,self.reference_bridge.scope)
                diagnostic=self.reference_bridge.diagnostic
                diagnostic.update(native_preview_available=True,
                    native_preview_token=self.reference_preview['binding']['token'],
                    native_preview_baseline=self.reference_preview['baseline'],proposal_applied=False)
                angle=float(self.env.sim.data.qpos[self._reference_preview_door_qpos])
                branch=self.reference_bridge.branch;receipt=self.reference_bridge.receipt
                desired=None if branch is None else branch.reference(self.reference_bridge.scope,angle)
                ready=self.reference_bridge.proposal_readiness(angle)
                if (desired is not None and ready['previous_executed_close_reference_available']
                        and ready['forecast_source_capture_available'] and receipt is not None):
                    diagnostic['shadow_QP']=self.native_reference_preview.shadow_solve(self.reference_preview,
                        receipt['actual_executed_reference'],desired)
                else:diagnostic['shadow_QP_status']='no_runtime_forecast_or_executed_close_receipt'
                from five_chains.envs.candidate_qualification import inspect
                assert self.posture_solver is not None
                diagnostic['current_candidate_necessary_evidence']=inspect(self.reference_bridge,
                    self.reference_preview,diagnostic.get('shadow_QP'),self.native_reference_preview,
                    action,angle,self.env.sim.model._model.jnt_range[self.posture_solver.joints])

    def reference_bridge_before_execute(self, action: np.ndarray, executions: int) -> None:
        if getattr(self,'_reference_bridge_in_scope',False):
            self.reference_bridge.before_execute(action,self.controller.initial_joint,
                float(self.env.sim.data.time),executions)
            preview=getattr(self,'reference_preview',None)
            if preview is not None:
                assert self.reference_bridge.scope is not None
                self.native_reference_preview.verify(action,self.reference_bridge.scope,
                    preview['binding']['token'])

    def reference_bridge_after_execute(self, executions: int) -> None:
        if getattr(self,'_reference_bridge_in_scope',False):
            self.reference_bridge.after_execute(self.controller.initial_joint,
                float(self.env.sim.data.time),executions)
            self.posture_diagnostic['passive_reference_bridge']=self.reference_bridge.snapshot()

    def reference_bridge_abort(self) -> None:
        if hasattr(self,'reference_bridge'):
            self.reference_bridge.abort()

    def prepare_motion_path(self, target: np.ndarray, world: WorldState, key: tuple,
                            relation: np.ndarray | None, max_tilt: float | None,
                            contact_entity: str | None, position_only: bool = False,
                            prefer_nearby_orientation: bool = False,
                            hinge_contact: tuple[str, str, float] | None = None,
                            cost_candidates: bool = False, contact_egress_refresh: bool = False,
                            door_withdraw_tracking: bool = False,
                            grasp_approach_tracking: bool = False,
                            payload_alignment_tracking: bool = False) -> np.ndarray:
        """Plan sampled joint geometry, then expose a bounded FK waypoint to C10."""
        if self.posture_solver is None:return target.copy()
        from dataclasses import asdict
        from five_chains.envs.scene_path import StaticScene,plan_joint_path
        cfg=self.config['control']['posture_ik']['path_planning']
        # The optional cost experiment is explicitly requested only by a
        # selected button-approach phase. All other phases retain first-feasible.
        cfg={**cfg,'optimize_restarts':bool(cfg['optimize_restarts'] and cost_candidates)}
        self.motion_failure=None
        target=target.copy()
        if (prefer_nearby_orientation
                and not ((door_withdraw_tracking and cfg['strict_door_withdraw_tracking'])
                    or (grasp_approach_tracking and cfg['strict_grasp_approach_tracking'])
                    or (payload_alignment_tracking and cfg['strict_payload_alignment_tracking']))
                and np.linalg.norm(target[:3,3]-world.eef_pose_world[:3,3])<self.config['control']['reached_m']
                and (position_only or rotation_distance(target[:3,:3],world.eef_pose_world[:3,:3])<self.config['control']['reached_rad'])):
            # No free motion is needed when the original goal is already met.
            self.prepare_contact_posture(world,key)
            self.posture_diagnostic.update(path_status='already_reached',success=True,
                scope='measured pose already satisfies original goal; hold until normal feedback transition')
            return world.eef_pose_world.copy()
        if position_only and self.motion_key==key and self.motion_goal is not None:
            target[:3,:3]=self.motion_goal[:3,:3]
        if self.motion_scene is None:
            self.motion_scene=StaticScene(self.env.sim.model._model,int(self.robot.eef_site_id[self.arm]),self.posture_solver.qpos)
        qpos=np.asarray(world.signals['robot_kinematic_qpos'])
        held={n:np.asarray(t).copy() for n,t in world.signals.get('grasp_transforms',{}).items()}
        # A contained vegetable is projected with its held bowl for geometry only.
        # This is not an extra grasp assertion or a physical constraint.
        if 'bowl' in held and world.signals.get('predicates',{}).get('vegetable_in_bowl'):
            held['vegetable']=inverse(world.eef_pose_world)@world.entities['vegetable'].pose_world
        if relation is None and max_tilt is None:
            for name,transform in held.items():
                if world.signals.get('grasp_modes',{}).get(name)=='rim':
                    relation=transform
                    initial_up=(world.eef_pose_world@relation)[:3,2];final_up=(target@relation)[:3,2]
                    max_tilt=max(float(np.arccos(np.clip(initial_up[2],-1,1))),float(np.arccos(np.clip(final_up[2],-1,1))))+cfg['container_tilt_slack_rad']
                    break
        tracked=set(held)
        if contact_entity is not None:tracked.add(contact_entity)
        obstacle_changed=any(k.split('.')[0] not in tracked for k in world.changed_keys)
        changed=(self.motion_key!=key or self.motion_goal is None or self.motion_origin is None
            or np.linalg.norm(target[:3,3]-self.motion_goal[:3,3])>self.config['state']['eps_pos']
            or rotation_distance(target[:3,:3],self.motion_goal[:3,:3])>self.config['state']['eps_rot']
            or np.linalg.norm(world.base_pose_world[:3,3]-self.motion_origin[:3,3])>self.config['state']['eps_pos']
            or rotation_distance(world.base_pose_world[:3,:3],self.motion_origin[:3,:3])>self.config['state']['eps_rot']
            or (obstacle_changed and world.stamp>self.motion_stamp))
        # Refresh the same original goal after bounded measured stagnation.
        # Hinge approach still requires the original attained Cartesian point.
        # Explicitly admitted free contact egress may remain short of that point;
        # this requests a new full-scene search, never completes/skips a point.
        from five_chains.envs.scene_path import MeasuredStallFeedback
        if not hasattr(self,'motion_stall_feedback'):
            self.motion_stall_feedback=MeasuredStallFeedback()
        feedback=self.motion_stall_feedback;feedback.begin(key)
        policy=cfg['measured_stall_refresh'];stall_refresh=False
        stall_evidence: dict[str,Any]={}
        strict_withdraw=bool(door_withdraw_tracking and cfg['strict_door_withdraw_tracking']
            and hinge_contact is None and not held)
        strict_grasp=bool(grasp_approach_tracking and cfg['strict_grasp_approach_tracking']
            and hinge_contact is None and contact_entity is not None and not held)
        strict_payload=bool(payload_alignment_tracking and cfg['strict_payload_alignment_tracking']
            and hinge_contact is None and contact_entity is not None and contact_entity in held)
        grasp_refresh=bool(strict_grasp and cfg['grasp_approach_stall_refresh'])
        hinge_refresh=bool(hinge_contact is not None and cfg['hinge_continuation']['track_admitted_branch'])
        egress_refresh=bool(contact_egress_refresh and hinge_contact is None
            and contact_entity is None and relation is None and max_tilt is None
            and cfg['contact_egress_planning']['enabled']
            and cfg['contact_egress_planning']['measured_stall_refresh']
            and self.contact_egress_start_clear(world))
        if (not changed and self.motion_path and policy['enabled'] and (hinge_refresh or egress_refresh or strict_withdraw or grasp_refresh)):
            old_waypoint=self.motion_path[self.motion_index]
            old_forward=self.motion_scene.forward(old_waypoint)
            current=np.asarray(qpos[self.posture_solver.qpos])
            limits=self.env.sim.model._model.jnt_range[self.posture_solver.joints]
            telemetry=world.signals.get('arm_joint_state',{})
            speed=np.asarray(telemetry.get('velocities_rad_s',[]),dtype=float)
            physical_time=float(world.signals.get('native_motion_diagnostics',{}).get('simulation_time_s',float('nan')))
            joint_error=float(np.max(np.abs(current-old_waypoint)))
            pose_attained=bool(np.linalg.norm(world.eef_pose_world[:3,3]-old_forward[:3,3])<self.config['control']['reached_m']
                and rotation_distance(world.eef_pose_world[:3,:3],old_forward[:3,:3])<self.config['control']['reached_rad'])
            reference_settled=bool(np.max(np.abs(self.controller.initial_joint-old_waypoint))<1e-8)
            stall_refresh=feedback.observe(key,(self.motion_stamp,self.motion_index),physical_time,current,
                speed,limits[:,0],limits[:,1],joint_error,cfg['joint_reached_rad'],pose_attained,reference_settled,policy,
                require_pose_attained=not egress_refresh)
            if stall_refresh:
                stall_evidence={'simulation_time_s':physical_time,'old_path_stamp':self.motion_stamp,
                    'old_waypoint_index':self.motion_index,'joint_error_max_rad':joint_error,
                    'joint_velocity_max_rad_s':float(np.max(np.abs(speed))),
                    'distinct_frames':policy['distinct_frames'],'attempt':feedback.attempts,
                    'scope':('full_scene_contact_egress' if egress_refresh else
                        'strict_door_withdraw' if strict_withdraw else
                        'strict_grasp_approach' if grasp_refresh else 'qualified_hinge_approach'),
                    'old_waypoint_pose_attained':pose_attained,
                    'old_waypoint_position_error_m':float(np.linalg.norm(world.eef_pose_world[:3,3]-old_forward[:3,3]))}
                changed=True
        else:
            feedback.reset_window()
        if changed:
            feedback.reset_window()
            joints={n:self.env.sim.model.joint_name2id(obj.joints[0]) for n,obj in self.env.objects.items()}
            self.motion_scene.configure(qpos,held,joints,contact_entity,relation,max_tilt,cfg['penetration_epsilon_m'])
            from five_chains.envs.pose_ik import bounded_pose_targets,forward_command
            parent=self.config['control']['posture_ik']
            radius=self.config['control']['reached_rad']*cfg['orientation_search_fraction']
            targets=(target,) if position_only or not parent['orientation_projection'] else bounded_pose_targets(target,radius)
            rng=np.random.default_rng(cfg['seed']);goals=[];solutions=[]
            captured_forecasts=[]
            for candidate in targets:
                for i in range(cfg['goal_seeds']):
                    seed=qpos.copy()
                    if i:seed[self.posture_solver.qpos]=rng.uniform(self.posture_solver.lower,self.posture_solver.upper)
                    result=self.posture_solver.solve(candidate,seed,position_only=position_only)
                    solutions.append({**asdict(result),'nominal_orientation_offset_rad':rotation_distance(candidate[:3,:3],target[:3,:3])})
                    if result.success:
                        forward=self.posture_solver.forward(qpos,result.joints)
                        certified=position_only or forward_command(target,forward,parent['position_tolerance_m'],
                            self.config['control']['reached_rad'],relation,max_tilt) is not None
                        if certified and hinge_contact is not None:
                            forecast=self.hinge_contact_continuation(qpos,np.asarray(result.joints),target,
                                                                    forward,world,hinge_contact)
                            solutions[-1]['hinge_continuation']=forecast
                            certified=bool(forecast['admitted'])
                            if (certified and 'captured_knots' in forecast
                                    and getattr(self,'_reference_bridge_in_scope',False)):
                                from five_chains.envs.reference_bridge import Branch
                                assert self.reference_bridge.scope is not None
                                captured_forecasts.append(Branch.captured(self.reference_bridge.scope,
                                    len(solutions)-1,forecast['captured_knots'],result.joints,
                                    forecast.get('captured_source')))
                        if certified:goals.append(np.asarray(result.joints))
                # Button approaches can put the wrist near a joint limit after
                # door contact. Compare all already-authorized attitude samples
                # before choosing the shortest joint branch.
                if not prefer_nearby_orientation and any(self.motion_scene.valid(q) for q in goals):break
            plan=plan_joint_path(qpos[self.posture_solver.qpos],tuple(goals),self.posture_solver.lower,
                                 self.posture_solver.upper,self.motion_scene.valid,cfg,
                                 self.env.sim.model._model.jnt_range[self.posture_solver.joints,0],
                                 self.env.sim.model._model.jnt_range[self.posture_solver.joints,1])
            self.motion_path=plan.path;self.motion_index=min(1,max(0,len(plan.path)-1))
            if getattr(self,'_reference_bridge_in_scope',False) and hinge_contact is not None:
                self.reference_bridge.select(plan.path,captured_forecasts)
            self.motion_key=key;self.motion_goal=target.copy();self.motion_origin=world.base_pose_world.copy();self.motion_stamp=world.stamp
            self.posture_diagnostic={'scope':'sampled scene joint path followed by OSC FK waypoints; no continuous collision/dynamics guarantee',
                'path_status':plan.status,'initial_clear':plan.initial_clear,
                'start_margin_excess_rad':np.maximum(np.maximum(self.posture_solver.lower-qpos[self.posture_solver.qpos],qpos[self.posture_solver.qpos]-self.posture_solver.upper),0.).tolist(),'iterations':plan.iterations,'nodes':plan.nodes,
                'sample_checks':self.motion_scene.checks,'candidate_path_waypoints':list(plan.candidate_waypoints),
                'selected_path_candidate':plan.selected_candidate,'shortcut_attempts_used':plan.shortcut_attempts,
                'restart_path_optimization':cfg['optimize_restarts'],'waypoints':len(plan.path),'ik_endpoints':solutions,
                'projected_payload':list(held),'stamp':world.stamp,'key':key,'success':bool(plan.path),
                'measured_stall_refresh':stall_refresh,'stall_refresh_evidence':stall_evidence}
            if not plan.path:
                self.posture_diagnostic.update(goal_world=target.tolist(),input_qpos=qpos.tolist(),
                    held_transforms={n:t.tolist() for n,t in held.items()},
                    constraint_relation=None if relation is None else relation.tolist(),max_tilt_rad=max_tilt,
                    goal_rejections=[self.motion_scene.explain(q) for q in goals],
                    initial_constraints=self.motion_scene.explain(qpos[self.posture_solver.qpos]))
        self.posture_diagnostic.update(stall_refresh_attempts=feedback.attempts,stall_observed_frames=feedback.frames)
        if not self.motion_path:
            self.motion_failure=self.posture_diagnostic['path_status']
            self.controller.initial_joint=np.asarray(qpos[self.posture_solver.qpos]).copy()
            return world.eef_pose_world.copy()
        waypoint=self.motion_path[self.motion_index]
        forward=self.motion_scene.forward(waypoint)
        current=np.asarray(qpos[self.posture_solver.qpos])
        joint_tolerance=cfg['joint_reached_rad']
        joint_admitted=bool(np.max(np.abs(current-waypoint))<joint_tolerance)
        connection_admitted=False
        waypoint_pose_admitted=(np.linalg.norm(world.eef_pose_world[:3,3]-forward[:3,3])<self.config['control']['reached_m']
            and rotation_distance(world.eef_pose_world[:3,:3],forward[:3,:3])<self.config['control']['reached_rad'])
        hinge_tracking=bool(hinge_contact is not None and cfg['hinge_continuation']['track_admitted_branch'])
        branch_tracking=bool(hinge_tracking or strict_withdraw or strict_grasp or strict_payload)
        if not branch_tracking and not joint_admitted and waypoint_pose_admitted and self.motion_index<len(self.motion_path)-1:
            # OSC can attain a waypoint with a different redundant posture in
            # any free arm phase. Continue only after a fresh sampled connection
            # from actual joints passes the original scene/tilt/native bounds.
            # Final nominal phase completion is still checked independently.
            from five_chains.envs.scene_path import sampled_joint_connection
            connection_admitted=sampled_joint_connection(current,self.motion_path[self.motion_index+1],
                self.posture_solver.lower,self.posture_solver.upper,self.motion_scene.valid,cfg['validation_step_rad'],
                self.env.sim.model._model.jnt_range[self.posture_solver.joints,0],self.env.sim.model._model.jnt_range[self.posture_solver.joints,1])
        if self.motion_index<len(self.motion_path)-1 and waypoint_pose_admitted and (joint_admitted or connection_admitted):
            self.motion_index+=1;waypoint=self.motion_path[self.motion_index];forward=self.motion_scene.forward(waypoint)
        limit=self.config['control']['posture_ik']['max_reference_step_rad']
        self.controller.initial_joint+=np.clip(waypoint-self.controller.initial_joint,-limit,limit)
        self.posture_diagnostic['waypoint_index']=self.motion_index
        self.posture_diagnostic.update(admitted_hinge_branch_tracking=hinge_tracking,strict_door_withdraw_tracking=strict_withdraw,strict_grasp_approach_tracking=strict_grasp,strict_payload_alignment_tracking=strict_payload,attained_connection_checked=connection_admitted,joint_tracking_tolerance_rad=joint_tolerance,waypoint_joints=waypoint.tolist(),waypoint_pose_world=forward.tolist(),
            joint_error_max_rad=float(np.max(np.abs(current-waypoint))),
            waypoint_position_error_m=float(np.linalg.norm(world.eef_pose_world[:3,3]-forward[:3,3])),
            waypoint_orientation_error_rad=rotation_distance(world.eef_pose_world[:3,:3],forward[:3,:3]))
        return forward

    def contact_egress_start_clear(self, world: WorldState) -> bool:
        """Private original full-scene admission after contact; no exemption.

        Missing contact telemetry is never interpreted as separation. Recheck
        the actual full robot geometry with the original collision policy.
        """
        if self.posture_solver is None or world.signals.get('grasp_transforms'):
            return False
        from five_chains.envs.scene_path import StaticScene
        qpos=np.asarray(world.signals['robot_kinematic_qpos'])
        current=qpos[self.posture_solver.qpos]
        model=self.env.sim.model._model
        limits=model.jnt_range[self.posture_solver.joints]
        if not np.isfinite(current).all() or np.any(current<limits[:,0]) or np.any(current>limits[:,1]):
            return False
        scene=StaticScene(model,self.posture_solver.site,self.posture_solver.qpos)
        scene.configure(qpos,{}, {},None,None,None,
                        self.config['control']['posture_ik']['path_planning']['penetration_epsilon_m'])
        return bool(scene.valid(current))

    def hinge_approach_branch_ready(self, contract: Contract, phase: P7, qpos: np.ndarray) -> bool:
        """Keep explicitly selected door, grasp, or held alignment branch through handoff."""
        planner=self.config['control']['posture_ik']['path_planning']
        policy=planner['hinge_continuation']
        required=bool(planner['enabled'] and contract.call.skill=='close_hinged_door'
            and ((phase.phase_name=='approach' and policy['enabled'] and policy['track_admitted_branch'])
                 or (phase.phase_name=='withdraw' and planner['strict_door_withdraw_tracking'])))
        required=required or bool(planner['enabled'] and planner['strict_grasp_approach_tracking']
            and contract.call.skill in ('place_object_in_container','carry_container_to_region')
            and phase.phase_name=='approach'
            and contract.phases[phase.phase_index].target_field=='pregrasp_pose'
            and not getattr(self,'grasp_transforms',{}))
        required=required or bool(planner['enabled'] and planner['strict_payload_alignment_tracking']
            and contract.call.skill=='carry_container_to_region'
            and phase.phase_name=='align_payload_outside'
            and contract.phases[phase.phase_index].target_field=='payload_alignment_pose'
            and contract.call.bindings.get('object') in getattr(self,'grasp_transforms',{}))
        if not required:
            return True
        if (self.posture_solver is None or self.motion_key!=(contract.contract_id,phase.phase_index)
                or not self.motion_path or self.motion_index!=len(self.motion_path)-1):
            return False
        current=np.asarray(qpos)[self.posture_solver.qpos]
        return bool(np.isfinite(current).all() and np.max(np.abs(current-self.motion_path[-1]))
                    <self.config['control']['posture_ik']['path_planning']['joint_reached_rad'])

    def hinge_contact_continuation(self, qpos: np.ndarray, joints: np.ndarray,
                                   nominal: np.ndarray, forward: np.ndarray, world: WorldState,
                                   contact: tuple[str, str, float]) -> dict:
        """Additional endpoint gate on private robot/door states, never physics.

        Enter contact from the original approach goal, then follow the observed
        hinge to its existing closed target. Intended handle contact is excluded
        only in this extra forecast; original runtime scene checks are retained.
        """
        from five_chains.envs.scene_path import StaticScene
        from five_chains.envs.pose_ik import forward_command
        cfg=self.config['control']['posture_ik']['path_planning']
        policy=cfg['hinge_continuation'];parent=self.config['control']['posture_ik']
        appliance_name,handle_name,preload=contact
        appliance=getattr(self.env,appliance_name,None);hinge=world.signals.get('microwave_hinge')
        report: dict[str,Any]={'admitted':False,'scope':'private static hinge continuation, not dynamics or continuous safety',
                              'samples':0,'max_joint_delta_rad':0.,'failed_stage':'unavailable_geometry',
                              'local_joint_search':policy['local_joint_search']}
        if (self.posture_solver is None or appliance is None or hinge is None
                or handle_name not in world.entities or not getattr(appliance,'door_joint_names',None)):
            return report
        solver=self.posture_solver;model=self.env.sim.model._model
        door_id=self.env.sim.model.joint_name2id(appliance.door_joint_names[0])
        door_adr=int(model.jnt_qposadr[door_id]);axis=np.asarray(hinge['axis_world'],float)
        anchor=np.asarray(hinge['anchor_world'],float);angle=float(hinge['angle'])
        center=world.entities[handle_name].pose_world[:3,3]
        orientation=forward[:3,:3].copy()
        scene=StaticScene(model,solver.site,solver.qpos)
        prefix=appliance.handle_name.removesuffix('_main')
        source_definition=None
        source_status='capture_disabled'
        if self.config['control'].get('close_reference_bridge_capture',False):
            source_status='not_in_runtime_scope'
            if getattr(self,'_reference_bridge_in_scope',False):
                try:
                    from five_chains.envs.forecast_dependencies import definition
                    source_definition=definition(self,qpos,joints,nominal,forward,world,contact,
                        door_adr,self.reference_bridge.scope)
                    # Freeze all arrays now, before any private forecast calls.
                    from five_chains.envs.forecast_dependencies import canonical
                    import json
                    source_definition=json.loads(canonical(source_definition))
                    source_status='captured_original_inputs'
                except (ValueError,TypeError,AttributeError,KeyError) as exc:
                    source_status='source_capture_rejected:'+str(exc)
            report['source_capture_status']=source_status
        current=qpos.copy();current[solver.qpos]=joints;current[door_adr]=angle
        previous=joints.copy();previous_angle=angle
        contact_goal=nominal.copy();contact_goal[:3,:3]=orientation
        contact_goal[:3,3]=center+preload*orientation[:,2]
        targets=[]
        approach_count=max(1,int(np.ceil(np.linalg.norm(contact_goal[:3,3]-nominal[:3,3])/.01)))
        for fraction in np.linspace(0.,1.,approach_count+1)[1:]:
            target=contact_goal.copy();target[:3,3]=nominal[:3,3]+fraction*(contact_goal[:3,3]-nominal[:3,3])
            targets.append(('enter_contact',angle,target))
        for future_angle in np.linspace(angle,0.,policy['samples'])[1:]:
            rotation=Rotation.from_rotvec((float(future_angle)-angle)*axis).as_matrix()
            target=nominal.copy();target[:3,:3]=rotation@orientation
            target[:3,3]=anchor+rotation@(center-anchor)+preload*target[:3,2]
            targets.append(('hinge_arc',float(future_angle),target))
        captured_knots=[]
        for stage,future_angle,target in targets:
            current[solver.qpos]=previous;current[door_adr]=future_angle
            result=(solver.solve(target,current,max_joint_step_rad=policy['max_joint_step_rad'])
                    if policy['local_joint_search'] else solver.solve(target,current))
            candidate=np.asarray(result.joints)
            delta=float(np.max(np.abs(candidate-previous)))
            report.update(samples=report['samples']+1,failed_stage=stage,last_angle_rad=future_angle,
                          max_joint_delta_rad=max(report['max_joint_delta_rad'],delta))
            if not result.success or forward_command(target,solver.forward(current,candidate),
                    parent['position_tolerance_m'],self.config['control']['reached_rad']) is None:
                report['reason']='strict_ik';return report
            if delta>policy['max_joint_step_rad']:
                report['reason']='branch_discontinuity';return report
            count=max(1,int(np.ceil(delta/cfg['validation_step_rad'])))
            for fraction in np.linspace(0.,1.,count+1)[1:]:
                sample=current.copy();sample[door_adr]=previous_angle+fraction*(future_angle-previous_angle)
                scene.configure(sample,{}, {},prefix,None,None,cfg['penetration_epsilon_m'])
                if not scene.valid(previous+fraction*(candidate-previous)):
                    report['reason']='scene_collision';return report
            previous=candidate;previous_angle=future_angle
            if self.config['control'].get('close_reference_bridge_capture',False):
                captured_knots.append({'stage':stage,'angle_rad':future_angle,
                                       'joints_rad':candidate.tolist()})
        report.update(admitted=True,reason='sampled_hinge_clear',failed_stage=None)
        if self.config['control'].get('close_reference_bridge_capture',False):
            report['captured_knots']=captured_knots
            report['source_capture_status']=source_status
            if source_definition is not None:
                from five_chains.envs.forecast_dependencies import ForecastSource
                try:report['captured_source']=ForecastSource.seal(source_definition,captured_knots)
                except (ValueError,TypeError,KeyError) as exc:
                    report['source_capture_status']='source_capture_rejected:'+str(exc)
        return report

    def arm_joint_state(self) -> dict:
        """Read-only shared proprioception for both native observation adapters."""
        if self.posture_solver is None:return {}
        sim=self.env.sim;ids=self.posture_solver.joints
        return {'positions_rad':np.asarray(sim.data.qpos)[self.posture_solver.qpos].copy(),
            'velocities_rad_s':np.asarray(sim.data.qvel)[sim.model._model.jnt_dofadr[ids]].copy(),
            'native_ranges_rad':sim.model._model.jnt_range[ids].copy(),
            'nullspace_reference_rad':self.controller.initial_joint.copy(),
            'sample_timing':'observation before current C10 solve'}

    def prepare_contact_posture(self, world: WorldState, key: tuple) -> None:
        """Freeze attained arm posture for local Cartesian press or withdrawal."""
        if self.posture_solver is None:return
        if getattr(self,'contact_posture_key',None)!=key:
            self.controller.initial_joint=np.asarray(world.signals['robot_kinematic_qpos'])[self.posture_solver.qpos].copy()
            self.contact_posture_key=key
            self.posture_diagnostic={'scope':'attained joint posture frozen during local Cartesian contact motion',
                'key':key,'stamp':world.stamp,'reference_kind':'measured_contact_posture',
                'joints':self.controller.initial_joint.tolist()}

    def pose_reachable(self, target: np.ndarray, world: WorldState) -> bool:
        """Read-only robot endpoint gate for handing off coarse base assistance."""
        if self.posture_solver is None:return False
        from dataclasses import asdict
        result=self.posture_solver.solve(target,np.asarray(world.signals['robot_kinematic_qpos']))
        self.stance_diagnostic={**asdict(result),'stamp':world.stamp,
            'scope':'robot-only endpoint gate; no collision or path guarantee'}
        return bool(result.success)

    def prepare_posture(self, target: np.ndarray, world: WorldState, key: tuple,
                        relation: np.ndarray | None = None, max_tilt: float | None = None) -> np.ndarray:
        if self.posture_solver is None:return target.copy()
        from dataclasses import asdict
        origin=getattr(self,'posture_origin',None)
        origin_changed=(origin is None or np.linalg.norm(world.base_pose_world[:3,3]-origin[:3,3])>self.config['state']['eps_pos']
            or rotation_distance(world.base_pose_world[:3,:3],origin[:3,:3])>self.config['state']['eps_rot'])
        changed=(origin_changed or key!=self.posture_key or self.posture_goal is None
            or np.linalg.norm(target[:3,3]-self.posture_goal[:3,3])>self.config['state']['eps_pos']
            or rotation_distance(target[:3,:3],self.posture_goal[:3,:3])>self.config['state']['eps_rot']
            or (self.posture_solution is None and world.stamp-self.posture_diagnostic.get('stamp',0)>=self.config['control']['posture_ik']['failed_retry_ticks']))
        if changed:
            result=self.posture_solver.solve(target,np.asarray(world.signals['robot_kinematic_qpos']))
            self.posture_diagnostic={**asdict(result),'scope':'robot-only OSC nullspace reference; no collision/path guarantee','key':key,'stamp':world.stamp}
            self.posture_goal=target.copy();self.posture_key=key;self.posture_origin=world.base_pose_world.copy()
            cfg=self.config['control']['posture_ik']
            approximate=bool(cfg['allow_approximate_reference'] and result.position_error_m<=cfg['approximate_position_m']
                             and result.orientation_error_rad<=cfg['approximate_rotation_rad'])
            self.posture_solution=np.asarray(result.joints) if result.success or approximate else None
            self.posture_diagnostic['reference_kind']='exact' if result.success else 'approximate' if approximate else 'rejected'
            self.posture_command=target.copy()
            if cfg['orientation_projection'] and result.success:
                # A successful numerical IK still has a nonzero residual. OSC
                # must not chase its nominal attitude beyond the admitted joints.
                # Keep nominal position and original goal/tilt tolerances.
                from five_chains.envs.pose_ik import forward_command
                forward=self.posture_solver.forward(np.asarray(world.signals['robot_kinematic_qpos']),result.joints)
                certified=forward_command(target,forward,cfg['position_tolerance_m'],
                    self.config['control']['reached_rad'],relation,max_tilt)
                if certified is not None:
                    self.posture_command=certified
                    self.posture_diagnostic['successful_ik_forward_command']={
                        'nominal_position_retained':True,
                        'fk_position_error_m':float(np.linalg.norm(forward[:3,3]-target[:3,3])),
                        'orientation_offset_rad':rotation_distance(target[:3,:3],forward[:3,:3]),
                        'scope':'admitted FK orientation within original goal region; no dynamics/collision guarantee'}
            if cfg['orientation_projection'] and not result.success and approximate:
                from five_chains.envs.pose_ik import orientation_command
                qpos=np.asarray(world.signals['robot_kinematic_qpos'])
                forward=self.posture_solver.forward(qpos,result.joints)
                proposal=target.copy();proposal[:3,:3]=forward[:3,:3]
                allowed=orientation_command(target,proposal,self.config['control']['reached_rad'],relation,max_tilt)
                if allowed is not None:
                    seed=qpos.copy();seed[self.posture_solver.qpos]=result.joints
                    projected=self.posture_solver.solve(allowed,seed)
                    self.posture_diagnostic['projected_ik']=asdict(projected)
                    if projected.success:
                        self.posture_command=allowed;self.posture_solution=np.asarray(projected.joints)
                        self.posture_diagnostic['projection_angle_rad']=rotation_distance(target[:3,:3],allowed[:3,:3])
                    else:
                        from five_chains.envs.pose_ik import forward_command
                        final_forward=self.posture_solver.forward(qpos,projected.joints)
                        certified=forward_command(target,final_forward,cfg['position_tolerance_m'],
                            self.config['control']['reached_rad'],relation,max_tilt)
                        if certified is not None:
                            self.posture_command=certified;self.posture_solution=np.asarray(projected.joints)
                            self.posture_diagnostic['forward_validated']={
                                'position_error_m':float(np.linalg.norm(final_forward[:3,3]-target[:3,3])),
                                'nominal_orientation_error_rad':rotation_distance(target[:3,:3],final_forward[:3,:3]),
                                'scope':'strict position residual and original orientation/tilt region only; not collision proof'}
        if self.posture_solution is not None:
            limit=self.config['control']['posture_ik']['max_reference_step_rad']
            self.controller.initial_joint+=np.clip(self.posture_solution-self.controller.initial_joint,-limit,limit)
        from five_chains.envs.pose_ik import orientation_command
        command=target.copy()
        if self.posture_command is not None:command[:3,:3]=self.posture_command[:3,:3]
        allowed=orientation_command(target,command,self.config['control']['reached_rad'],relation,max_tilt)
        self.posture_diagnostic['command_projection_used']=bool(allowed is not None and rotation_distance(target[:3,:3],command[:3,:3])>1e-8)
        return allowed if allowed is not None else target.copy()

    def gripper_reference_action(self, action: np.ndarray, command: float) -> np.ndarray:
        if command not in (-1.,0.,1.):raise ValueError('invalid native gripper reference pulse')
        start,end=self.composite._action_split_indexes[self.arm+'_gripper']
        if end-start!=1:raise ValueError('unverified gripper action segment')
        result=np.asarray(action).copy();result[start:end]=command
        lower,upper=self.env.action_spec
        if result.shape!=lower.shape or not np.isfinite(result).all() or np.any(result<lower) or np.any(result>upper):
            raise ValueError('gripper feedback violates native action bounds')
        return result

    def pose_action(self, target: np.ndarray, gripper: str, stiffness: float) -> np.ndarray:
        self.gripper_command = gripper
        controller = self.controller
        current = self.current_pose()
        if controller.input_type == "delta":
            translation = target[:3, 3] - current[:3, 3]
            rotation = Rotation.from_matrix(target[:3, :3] @ current[:3, :3].T).as_rotvec()
            if controller.input_ref_frame == "base":
                _, origin = self.composite.get_controller_base_pose(self.arm)
                translation = origin.T @ translation
                rotation = origin.T @ rotation
            physical = np.r_[translation, rotation]
            low, high = np.asarray(controller.output_min), np.asarray(controller.output_max)
            ilow, ihigh = np.asarray(controller.input_min), np.asarray(controller.input_max)
            arm = (physical - (high + low) / 2) * (ihigh - ilow) / (high - low) + (ihigh + ilow) / 2
            arm = np.clip(arm, ilow, ihigh)
        else:
            local = target.copy()
            if controller.input_ref_frame == "base":
                p, r = self.composite.get_controller_base_pose(self.arm)
                local = inverse(pose(p, r)) @ target
            arm = np.r_[local[:3, 3], Rotation.from_matrix(local[:3, :3]).as_rotvec()]
        if controller.impedance_mode == "variable_kp":
            gains = np.clip(self.nominal_kp * stiffness, controller.kp_min, controller.kp_max)
            arm = np.r_[gains, arm]
        elif controller.impedance_mode != "fixed":
            raise ValueError("unverified impedance interface")
        elif not np.isclose(stiffness, 1.):
            raise ValueError("fixed impedance cannot execute stiffness updates")
        action = self.composite.create_action_vector({self.arm: arm,
            self.arm + "_gripper": np.full(self.gripper_dof,1. if gripper == "close" else -1.), "base_mode": -1})
        low, high = self.env.action_spec
        if action.shape != low.shape or not np.isfinite(action).all() or np.any(action < low) or np.any(action > high):
            raise ValueError("action violates live environment specification")
        return action

    def _torso_input(self, target: float) -> np.ndarray:
        self.torso_command_target=float(target)
        part=self.composite.part_controllers['torso'];part.update(force=True)
        if part.name!='JOINT_POSITION' or part.input_type!='delta' or part.control_dim!=1:
            raise ValueError('unsupported torso controller')
        model=self.env.sim.model._model;joint=int(part.joint_index[0]);lo,hi=model.jnt_range[joint]
        if not np.isfinite(target) or not lo<=target<=hi:raise ValueError('torso target outside native limits')
        q=float(part.joint_pos[0]);step=self.config['torso']['speed_m_s']/self.control_freq
        # The command is one period from measured state, not a hidden execution loop.
        error=float(np.clip(target-q,-step,step))
        mass=float(part.mass_matrix[0,0]);gain=float(part.kp[0])
        if mass<=0 or gain<=0:raise ValueError('invalid torso dynamics')
        friction=float(model.dof_frictionloss[int(model.jnt_dofadr[joint])])
        delta=error+np.sign(error)*friction/(mass*gain)*1.05 if abs(target-q)>self.config['torso']['reached_m']/2 else 0.
        low,high=np.asarray(part.output_min),np.asarray(part.output_max)
        ilow,ihigh=np.asarray(part.input_min),np.asarray(part.input_max)
        command=np.clip((np.array([delta])-(high+low)/2)*(ihigh-ilow)/(high-low)+(ihigh+ilow)/2,ilow,ihigh)
        return command

    def hold_torso(self, action: np.ndarray, target: float) -> np.ndarray:
        """Apply the active physical joint reference to an existing one-period action."""
        command=self._torso_input(target)
        result=np.asarray(action,dtype=float).copy()
        start,end=self.composite._action_split_indexes['torso'];result[start:end]=command
        low,high=self.env.action_spec
        if result.shape!=low.shape or not np.isfinite(result).all() or np.any(result<low) or np.any(result>high):
            raise ValueError('combined torso hold action violates native action specification')
        return result

    def torso_action(self, target: float, gripper: str, stiffness: float) -> np.ndarray:
        command=self._torso_input(target)
        hold=self.pose_action(self.current_pose(),gripper,stiffness)
        start,end=self.composite._action_split_indexes[self.arm]
        action=self.composite.create_action_vector({self.arm:hold[start:end],'torso':command,
            self.arm+'_gripper':np.full(self.gripper_dof,1. if gripper=='close' else -1.),'base_mode':1})
        low,high=self.env.action_spec
        if action.shape!=low.shape or not np.isfinite(action).all() or np.any(action<low) or np.any(action>high):
            raise ValueError('torso action violates native action specification')
        return action

    def success(self) -> bool:
        return bool(self.env._check_success())

    def _base_input(self, target: np.ndarray, speed_limit: float | None = None) -> np.ndarray:
        from robosuite.utils.transform_utils import mat2euler
        part = self.composite.part_controllers["base"]
        if part.control_dim != 3:
            raise ValueError("local base mapping requires the verified 3-axis controller")
        raw = self.env._get_observations(force_update=True)
        position = np.asarray(raw["robot0_base_pos"])
        orientation = Rotation.from_quat(raw["robot0_base_quat"]).as_matrix()
        yaw_error = float(Rotation.from_matrix(target[:3,:3] @ orientation.T).as_rotvec()[2])
        wanted = np.r_[target[:2,3]-position[:2], yaw_error] * self.config["base"]["proportional_gain"]
        from five_chains.geometry import limited
        max_speed = self.config["base"]["max_speed_m_s"] if speed_limit is None else min(speed_limit,self.config["base"]["max_speed_m_s"])
        wanted[:2] = limited(wanted[:2], max_speed)
        wanted[2] = np.clip(wanted[2], -self.config["base"]["max_yaw_rad_s"], self.config["base"]["max_yaw_rad_s"])
        model = self.env.sim.model._model
        basis = np.zeros((3,3))
        offsets = np.zeros(3)
        weights = (part.actuator_max-part.actuator_min)/2.
        point = np.r_[position[:2],0.]
        for index, joint_name in enumerate(part.joint_names):
            joint = self.env.sim.model.joint_name2id(joint_name)
            axis = np.asarray(self.env.sim.data.xaxis[joint])
            kind = int(model.jnt_type[joint])
            if kind == 2:
                basis[:2,index] = axis[:2]
            elif kind == 3:
                basis[:2,index] = np.cross(axis,point-self.env.sim.data.xanchor[joint])[:2]
                basis[2,index] = axis[2]
            else:
                raise ValueError("unsupported non-planar base joint")
            actuators = np.flatnonzero(model.actuator_trnid[:,0] == joint)
            if len(actuators) != 1:
                raise ValueError("base joint must have exactly one velocity actuator")
            actuator = int(actuators[0])
            gain = float(model.actuator_gainprm[actuator,0])
            if gain <= 0 or not np.isclose(model.actuator_biasprm[actuator,2], -gain):
                raise ValueError("unsupported base actuator dynamics")
            offsets[index] = float(model.dof_frictionloss[int(model.jnt_dofadr[joint])])/gain
        joint_velocity = np.linalg.solve(basis,wanted)
        active = np.abs(joint_velocity) > self.config["base"]["deadzone_velocity_m_s"]
        compensated = np.zeros(3)
        compensated[active] = joint_velocity[active]+np.sign(joint_velocity[active])*(offsets[active]+self.config["base"]["friction_margin_m_s"])
        _, current_base = part.get_base_pose()
        theta = float(mat2euler(current_base)[2]-mat2euler(part.init_ori)[2])
        c,s = np.cos(theta),np.sin(theta)
        transform = np.array([[c,s,0.],[-s,c,0.],[0.,0.,1.]])
        if hasattr(part,"_check_forward_joint_reversed"):
            if part._check_forward_joint_reversed():
                transform = transform @ np.array([[0.,1.,0.],[1.,0.,0.],[0.,0.,1.]])
            else:
                transform = np.array([[c,-s,0.],[s,c,0.],[0.,0.,1.]])
        command = np.linalg.solve(transform,compensated/weights)
        command = np.clip(command,part.input_min,part.input_max)
        return command

    def hold_base(self, action: np.ndarray, target: np.ndarray) -> np.ndarray:
        """Keep the achieved planar stance while the arm or torso is active."""
        self.base_hold_command_target=target.copy()
        command=self._base_input(target,self.config['base']['hold_max_speed_m_s'])
        result=np.asarray(action,dtype=float).copy()
        start,end=self.composite._action_split_indexes['base'];result[start:end]=command
        low,high=self.env.action_spec
        if result.shape!=low.shape or not np.isfinite(result).all() or np.any(result<low) or np.any(result>high):
            raise ValueError('combined base hold action violates native action specification')
        return result

    def base_pose_action(self, target: np.ndarray, gripper: str, stiffness: float, speed_limit: float | None = None) -> np.ndarray:
        """One-period local base command; no navigation loop or hidden simulation step.

        Adapts the original LocalMobileNavigator's pure actuator inversion to this
        executor. Reads native joint axes, actuator gains and friction; holds arm
        relative to the moving origin using HybridMobileBase's desired-goal mode.
        No global collision-free navigation is claimed.
        """
        command=self._base_input(target,speed_limit)
        hold = self.pose_action(self.current_pose(),gripper,stiffness)
        start,end = self.composite._action_split_indexes[self.arm]
        action = self.composite.create_action_vector({self.arm:hold[start:end],"base":command,
            self.arm+"_gripper":np.full(self.gripper_dof,1. if gripper=="close" else -1.),"base_mode":1})
        low,high = self.env.action_spec
        if action.shape != low.shape or not np.isfinite(action).all() or np.any(action<low) or np.any(action>high):
            raise ValueError("base action violates the live action specification")
        return action

    def instruction(self) -> str:
        return str(self.env.get_ep_meta()["lang"])

    def inject_test_translation(self, entity: str, translation: np.ndarray) -> dict:
        """Explicit experiment intervention, never called by runtime components."""
        item = self.env.objects[entity]
        joint = item.joints[0]
        qpos = np.asarray(self.env.sim.data.get_joint_qpos(joint)).copy()
        if qpos.shape != (7,) or np.asarray(translation).shape != (3,):
            raise ValueError("test translation requires a free-joint object")
        qpos[:3] += translation
        self.env.sim.data.set_joint_qpos(joint, qpos)
        self.env.sim.forward()
        return self.observe(self.env._get_observations(force_update=True))

    def capture_failure(self, output: Path) -> dict:
        """Read-only failure inspection; creates no control or physics step."""
        import json
        from PIL import Image
        from robosuite.utils.binding_utils import MjRenderContextOffscreen
        output.mkdir(parents=True,exist_ok=False)
        gripper=self.robot.gripper[self.arm]
        groups={name:list(values) for name,values in gripper.important_geoms.items()}
        names=set().union(*(set(values) for values in groups.values()))
        sim=self.env.sim
        positions={name:sim.data.geom_xpos[sim.model.geom_name2id(name)].tolist() for name in names}
        contacts=[]
        for index in range(sim.data.ncon):
            contact=sim.data.contact[index]
            first=sim.model.geom_id2name(contact.geom1);second=sim.model.geom_id2name(contact.geom2)
            if first in names or second in names:
                contacts.append({'first':first,'second':second,'distance_m':float(contact.dist),'position':np.asarray(contact.pos).tolist()})
        raw=self.env._get_observations(force_update=True)
        objects={name:{'pose':pose(sim.data.get_body_xpos(item.root_body),sim.data.get_body_xmat(item.root_body)).tolist(),
                       'top_offset':np.asarray(item.top_offset).tolist(),'bottom_offset':np.asarray(item.bottom_offset).tolist(),
                       'horizontal_radius':float(item.horizontal_radius),'contact_geoms':list(item.contact_geoms)}
                 for name,item in self.env.objects.items()}
        report={'gripper_groups':groups,'gripper_geometry_positions':positions,'gripper_qpos':np.asarray(raw['robot0_gripper_qpos']).tolist(),
                'eef_pose':self.current_pose().tolist(),'contacts':contacts,'objects':objects,
                'all_contacts':[{'first':sim.model.geom_id2name(sim.data.contact[i].geom1),'second':sim.model.geom_id2name(sim.data.contact[i].geom2),'distance_m':float(sim.data.contact[i].dist)} for i in range(sim.data.ncon)],
                'scope':'simulation contact diagnostic only; no perception or benchmark claim'}
        (output/'contacts.json').write_text(json.dumps(report,indent=2))
        # Frozen failure state for independent kinematic/contact diagnosis only.
        # It is never restored into an episode or counted as a successful path.
        import mujoco,hashlib,gzip,shutil
        model_path=output/'model.mjb'
        mujoco.mj_saveModel(sim.model._model,str(model_path),None)
        model_hash=hashlib.sha256(model_path.read_bytes()).hexdigest()
        packed_path=output/'model.mjb.gz'
        with model_path.open('rb') as source,gzip.open(packed_path,'wb',compresslevel=3) as packed:
            shutil.copyfileobj(source,packed,16*1024*1024)
        check=hashlib.sha256()
        with gzip.open(packed_path,'rb') as packed:
            for chunk in iter(lambda:packed.read(16*1024*1024),b''):check.update(chunk)
        if check.hexdigest()!=model_hash:raise ValueError('failure model compression mismatch')
        model_path.unlink()
        np.savez_compressed(output/'state.npz',qpos=np.asarray(sim.data.qpos),qvel=np.asarray(sim.data.qvel))
        (output/'snapshot.json').write_text(json.dumps({'scope':'read-only endpoint/contact diagnosis; no physics continuation',
            'model_sha256':model_hash,'model_file':packed_path.name,
            'site_id':int(self.robot.eef_site_id[self.arm]),'joint_ids':np.asarray(self.controller.joint_index).tolist(),
            'qpos_ids':np.asarray(self.controller.qpos_index).tolist(),'rest_joints':np.asarray(self.posture_solver.rest if self.posture_solver is not None else self.controller.initial_joint).tolist(),
            'time':float(sim.data.time)},indent=2))
        if sim._render_context_offscreen is None:
            MjRenderContextOffscreen(sim,device_id=getattr(self.env,'render_gpu_device_id',-1))
        context=sim._render_context_offscreen
        context.vopt.geomgroup[:]=0
        context.vopt.geomgroup[1]=1
        context.vopt.sitegroup[:]=0
        pixels=sim.render(width=512,height=512,camera_name=self.config['environment']['selector_camera'])[::-1].copy()
        Image.fromarray(pixels).save(output/'scene.png')
        return report

    def placement_satisfied(self, obj: str | None, target: str | None) -> bool:
        """Read the current native relation; history alone is never proof."""
        from robocasa.utils import object_utils as OU
        if obj not in self.env.objects:
            return False
        if target in self.env.objects:
            return bool(OU.check_obj_in_receptacle(self.env, obj, target))
        if target == 'microwave_interior':
            return bool(OU.obj_inside_of(self.env, obj, self.env.microwave))
        return False

    def selector_sample(self, task: str, obs: dict, history: list[SkillCall], image_path: Path) -> dict:
        from PIL import Image
        camera = self.config["environment"]["selector_camera"]
        # Actual camera name checked by MuJoCo; never synthesize a scene image.
        rgb = self.env.sim.render(width=256, height=256, camera_name=camera)[::-1].copy()
        Image.fromarray(rgb).save(image_path)
        entities = obs["state"]["entities"]
        effects = []
        for previous in history:
            if (previous.skill in ('place_object_in_container', 'carry_container_to_region')
                    and self.placement_satisfied(previous.bindings.get('object'), previous.bindings.get('target'))):
                effects.append({'bindings': dict(previous.bindings), 'effect': 'placement_satisfied',
                                'source': 'native placement predicate'})
        return {"measured_satisfied_effects": effects,
                "current_failure_feedback":obs['state']['signals'].get('failure_feedback',[]),"image": str(image_path), "instruction": task,
                "observation": {"source": "simulator_ground_truth_development", "entities": list(entities),
                    "state": obs["state"]["signals"]["predicates"],
                    "failure_feedback":obs['state']['signals'].get('failure_feedback',[])},
                "history": [{"primary": call.skill, "bindings": call.bindings, "status": "completed"} for call in history[-3:]],
                "call_context": {"decision_id": f"live_{len(history):03d}",
                    "bindings": {"appliance": "microwave", "handle": "handle", "control": "start", "reference": "microwave_interior"},
                    "binding_options": {"object": ["vegetable", "bowl"], "target": ["bowl", "microwave_interior"]},
                    "entity_types": {"bowl": ["container"], "vegetable": []}, "goal_window": []},
                "completed_goals": []}
