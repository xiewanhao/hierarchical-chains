# -*- coding: utf-8 -*-
"""Immutable input provenance, not permission to reuse or apply a forecast.

Exact fixed-input equality is only a necessary component. No scene tolerance,
geometry/IK query, reference write or execution receipt is provided here.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
from pathlib import Path
from importlib.metadata import version,PackageNotFoundError
import hashlib
import json
import numpy as np


def canonical(value: Any) -> str:
    def serial(v: Any) -> Any:
        if isinstance(v,np.ndarray):return v.tolist()
        if isinstance(v,np.generic):return v.item()
        raise ValueError('unsupported forecast dependency: '+type(v).__name__)
    return json.dumps(value,default=serial,sort_keys=True,separators=(',',':'),allow_nan=False)


def fingerprint(value: Any) -> str:
    return hashlib.sha256(canonical(value).encode()).hexdigest()


def implementation_fingerprint() -> dict[str,Any]:
    base=Path(__file__).parent
    files=['forecast_dependencies.py','robocasa_adapter.py','pose_ik.py','scene_path.py']
    try:
        return {'local_source_sha256':{n:hashlib.sha256((base/n).read_bytes()).hexdigest() for n in files},
                'library_versions':{n:version(n) for n in ['numpy','scipy','mujoco']}}
    except (OSError,PackageNotFoundError) as exc:
        raise ValueError('source/library fingerprint unavailable') from exc


def finite(value: Any,shape: tuple[int,...]) -> np.ndarray:
    result=np.asarray(value,dtype=float).copy()
    if result.shape!=shape or not np.isfinite(result).all():
        raise ValueError('invalid forecast dependency shape/value')
    return result


def model_fingerprint(model: Any) -> dict[str,Any]:
    arrays={};scalars={};nonfinite_arrays={}
    for name in dir(model):
        if name.startswith('_'):continue
        value=getattr(model,name)
        if isinstance(value,np.ndarray):
            if value.dtype.hasobject:raise ValueError('object-valued model array')
            # Model identity is byte identity, not a geometry/numerics certificate.
            # Native compiled mesh metadata can contain NaN/Inf. Preserve their
            # exact bit patterns; never sanitize, omit or numerically compare them.
            if np.issubdtype(value.dtype,np.inexact):
                count=int(np.count_nonzero(~np.isfinite(value)))
                if count:nonfinite_arrays[name]=count
            h=hashlib.sha256()
            h.update(str((value.shape,value.dtype.str)).encode());h.update(value.tobytes())
            arrays[name]=h.hexdigest()
        elif isinstance(value,(str,int,float,bool)):
            scalars[name]=value
    options={}
    opt=getattr(model,'opt',None)
    if opt is not None:
        for name in dir(opt):
            if name.startswith('_'):continue
            value=getattr(opt,name)
            if callable(value):continue
            if not isinstance(value,(str,int,float,bool,np.ndarray,np.generic)):
                raise ValueError('unsupported model option: '+name)
            options[name]=value
    if not arrays:raise ValueError('no model arrays captured')
    return {'array_count':len(arrays),'arrays_sha256':fingerprint(arrays),
            'scalars_sha256':fingerprint(scalars),'options_sha256':fingerprint(options),
            'nonfinite_array_entries':nonfinite_arrays}


def fixed_inputs(adapter: Any,qpos: Any,world: Any,contact: tuple[str,str,float],
                 door_qpos: int) -> dict[str,Any]:
    solver=adapter.posture_solver
    q=np.asarray(qpos,dtype=float)
    if q.ndim!=1 or not np.isfinite(q).all():raise ValueError('invalid source qpos')
    arm=np.asarray(solver.qpos,dtype=int)
    if (arm.shape!=(7,) or len(set(arm.tolist()))!=7 or door_qpos in arm
            or door_qpos<0 or door_qpos>=len(q) or np.any(arm<0) or np.any(arm>=len(q))):
        raise ValueError('invalid arm/door topology')
    excluded=set(arm.tolist()+[door_qpos])
    hinge=world.signals['microwave_hinge']
    appliance,handle,preload=contact
    return {'model':model_fingerprint(adapter.env.sim.model._model),
        'implementation':implementation_fingerprint(),
        'fixed_scene_qpos':[(i,float(q[i])) for i in range(len(q)) if i not in excluded],
        'grasp_transforms':world.signals.get('grasp_transforms',{}),
        'hinge_axis_world':finite(hinge['axis_world'],(3,)),
        'hinge_anchor_world':finite(hinge['anchor_world'],(3,)),
        'contact':(appliance,handle,float(preload)),
        'forecast_contact_prefix':getattr(adapter.env,appliance).handle_name.removesuffix('_main'),
        'solver':{'arm_qpos':arm,'joint_ids':np.asarray(solver.joints),
            'proprio_qpos':np.asarray(solver.proprio),'site':int(solver.site),
            'lower':finite(solver.lower,(7,)),'upper':finite(solver.upper,(7,)),
            'rest':finite(solver.rest,(7,)),'config':solver.config},
        'posture_config':adapter.config['control']['posture_ik'],
        'original_orientation_tolerance_rad':adapter.config['control']['reached_rad']}


@dataclass(frozen=True)
class ForecastSource:
    payload_json: str
    payload_sha256: str

    @classmethod
    def seal(cls,definition: dict[str,Any],knots: list[dict]) -> ForecastSource:
        if not knots:raise ValueError('missing original computed knots')
        value=canonical({'definition':definition,'knots':knots})
        result=cls(value,hashlib.sha256(value.encode()).hexdigest())
        result.read()
        return result

    def read(self) -> dict[str,Any]:
        if hashlib.sha256(self.payload_json.encode()).hexdigest()!=self.payload_sha256:
            raise ValueError('forecast source integrity mismatch')
        value=json.loads(self.payload_json)
        if set(value)!= {'definition','knots'}:raise ValueError('invalid source schema')
        d=value['definition']
        required={'schema','call','produced_tick','observed_world_tick','fixed_inputs',
            'original_qpos','original_endpoint','nominal_approach','endpoint_FK_orientation',
            'observed_handle_center','start_hinge_angle','door_qpos_index',
            'forecast_only_contact_prefix','not_captured','qualification'}
        if (set(d)!=required or d['schema']!='original_forecast_argument_closure_v1'
                or d['produced_tick']!=d['observed_world_tick']):
            raise ValueError('incomplete original source definition')
        fixed={'model','fixed_scene_qpos','grasp_transforms','hinge_axis_world','hinge_anchor_world',
               'contact','solver','posture_config','original_orientation_tolerance_rad',
               'implementation','forecast_contact_prefix'}
        if set(d['fixed_inputs'])!=fixed:raise ValueError('incomplete fixed input closure')
        if not value['knots']:raise ValueError('missing original computed knots')
        finite(d['original_endpoint'],(7,));finite(d['nominal_approach'],(4,4))
        finite(d['endpoint_FK_orientation'],(3,3));finite(d['observed_handle_center'],(3,))
        for k in value['knots']:
            finite(k['joints_rad'],(7,))
            if not np.isfinite(float(k['angle_rad'])):raise ValueError('nonfinite original knot')
        return value

    def binds(self,call: str,tick: int,endpoint: Any,knots: list[dict]) -> bool:
        data=self.read();d=data['definition']
        return bool(d['call']==call and d['produced_tick']==tick
            and canonical(d['original_endpoint'])==canonical(finite(endpoint,(7,)))
            and canonical(data['knots'])==canonical(knots))

    def compare_fixed(self,current: dict[str,Any]) -> dict[str,Any]:
        original=self.read()['definition']['fixed_inputs']
        missing=sorted(set(original)^set(current))
        changed=sorted(k for k in set(original)&set(current)
                       if canonical(original[k])!=canonical(current[k]))
        return {'source_integrity_verified':True,'fixed_prerequisites_equal':not missing and not changed,
            'missing_or_extra_components':missing,'changed_components':changed,
            'forecast_reuse_admitted':False,'reference':None,
            'reason':'fixed_input_comparison_only_not_current_geometry_or_application_certificate'}


def definition(adapter: Any,qpos: Any,joints: Any,nominal: Any,forward: Any,
               world: Any,contact: tuple[str,str,float],door_qpos: int,scope: Any) -> dict[str,Any]:
    if scope.phase!='approach' or scope.tick!=world.stamp or scope.overridden:
        raise ValueError('source capture must be current original approach')
    angle=float(world.signals['microwave_hinge']['angle'])
    if not np.isfinite(angle):raise ValueError('nonfinite source hinge angle')
    fixed=fixed_inputs(adapter,qpos,world,contact,door_qpos)
    handle=contact[1]
    return {'schema':'original_forecast_argument_closure_v1',
        'call':scope.call,'produced_tick':scope.tick,'observed_world_tick':int(world.stamp),
        'fixed_inputs':fixed,'original_qpos':np.asarray(qpos,dtype=float).copy(),
        'original_endpoint':finite(joints,(7,)),'nominal_approach':finite(nominal,(4,4)),
        'endpoint_FK_orientation':finite(forward,(4,4))[:3,:3],
        'observed_handle_center':finite(world.entities[handle].pose_world,(4,4))[:3,3],
        'start_hinge_angle':angle,'door_qpos_index':door_qpos,
        'forecast_only_contact_prefix':getattr(adapter.env,contact[0]).handle_name.removesuffix('_main'),
        'not_captured':'closed_handle_pose is not a direct input to the original forecast function',
        'qualification':'original sampled endpoint forecast only; no current connection/dynamics/application certificate'}
