# -*- coding: utf-8 -*-
"""Passive necessary-evidence checks, never a reference application permit.

Neither instantaneous geometry nor a virtual FK/clearance result is accepted
as positive-time candidate qualification. Original exact leases stay intact.
"""
from __future__ import annotations
from dataclasses import asdict
from typing import Any
import numpy as np
from five_chains.envs.reference_admission import JOINT_MARGIN,SLEW,RAD_RESIDUAL,TORQUE_RESIDUAL,KKT_RESIDUAL
from five_chains.envs.reference_bridge import digest


def array(value: Any,shape: tuple[int,...]) -> np.ndarray:
    a=np.asarray(value,dtype=float)
    if a.shape!=shape or not np.isfinite(a).all():raise ValueError('invalid candidate evidence array')
    return a


def numerical_evidence(preview: dict,proposal: dict,previous: Any,desired: Any,ranges: Any) -> dict:
    """Recheck original-unit primal/native and convex KKT evidence; no solve."""
    if proposal.get('status')!='admitted_mathematical_fixture' or proposal.get('proposal_applied') is not False:
        raise ValueError('not an unapplied mathematical proposal')
    b=preview['baseline'];n=proposal['private_native_verification'];binding=preview['binding']
    if (b.get('token')!=binding['token']
            or not np.array_equal(array(b['original_action'],binding['action'].shape),binding['action'])
            or b.get('full_qpos_qvel_unchanged') is not True
            or b.get('private_integration_state_copied') is not True):
        raise ValueError('native baseline binding mismatch')
    p=proposal['input_binding'];prev=array(previous,(7,));want=array(desired,(7,))
    if (p['native_preview_token']!=binding['token'] or p['scope']!=asdict(binding['scope'])
            or not np.array_equal(array(p['previous_executed_reference'],(7,)),prev)
            or not np.array_equal(array(p['desired_forecast_reference'],(7,)),want)):
        raise ValueError('candidate source/previous/token/scope mismatch')
    ref=array(proposal['reference'],(7,));base=array(b['reference'],(7,))
    A=array(b['A'],(7,7));tau0=array(b['torque'],(7,));native=array(n['torque'],(7,))
    jr=array(ranges,(7,2));tr=array(b['native_torque_ranges'],(7,2))
    if np.any(jr[:,0]>=jr[:,1]) or np.any(tr[:,0]>=tr[:,1]):raise ValueError('invalid native ranges')
    if (not np.array_equal(array(n['reference'],(7,)),ref)
            or not np.array_equal(array(n['A'],(7,7)),A)
            or not np.array_equal(array(n['native_torque_ranges'],(7,2)),tr)
            or not np.array_equal(array(n['original_action'],binding['action'].shape),binding['action'])
            or n['token']!=binding['token'] or n.get('full_qpos_qvel_unchanged') is not True
            or n.get('private_integration_state_copied') is not True):
        raise ValueError('native candidate binding mismatch')
    predicted=tau0+A@(ref-base)
    lower=np.maximum(jr[:,0]+JOINT_MARGIN,prev-SLEW)
    upper=np.minimum(jr[:,1]-JOINT_MARGIN,prev+SLEW)
    if np.any(lower>upper):raise ValueError('empty original joint/slew intersection')
    joint=max(0.,float(np.max(jr[:,0]+JOINT_MARGIN-ref)),float(np.max(ref-jr[:,1]+JOINT_MARGIN)))
    slew=max(0.,float(np.max(abs(ref-prev)-SLEW)))
    torque=max(0.,float(np.max(tr[:,0]-native)),float(np.max(native-tr[:,1])))
    affine=float(np.max(abs(native-predicted)))
    predicted_residual=float(np.max(abs(array(proposal['predicted_torque'],(7,))-predicted)))
    primary=float(np.max(abs(array(n['primary_and_compensation'],(7,))-array(b['primary_and_compensation'],(7,)))))
    raw_G=np.vstack((np.eye(7),-np.eye(7),A,-A))
    offset=tau0+A@(prev-base)
    raw_h=np.r_[upper-prev,prev-lower,tr[:,1]-offset,offset-tr[:,0]]
    scales=np.maximum(1.,np.linalg.norm(raw_G,axis=1));G=raw_G/scales[:,None];h=raw_h/scales
    lam=array(proposal['certificate']['normalized_inequality_multipliers'],(28,))
    x=ref-prev;delta=want-prev;slack=h-G@x
    station=float(np.max(abs(x-delta+G.T@lam)));comp=float(np.max(abs(lam*slack)))
    objective=.5*float((ref-want)@(ref-want))
    dual=float(-.5*np.dot(G.T@lam,G.T@lam)+lam@(G@delta-h));gap=objective-dual
    values=np.r_[predicted,lower,upper,raw_G.ravel(),raw_h,station,comp,objective,dual,gap]
    if (not np.isfinite(values).all() or np.min(lam)<0 or joint>RAD_RESIDUAL or slew>RAD_RESIDUAL
            or torque>TORQUE_RESIDUAL or affine>1e-8 or predicted_residual>TORQUE_RESIDUAL
            or primary>1e-8 or station>KKT_RESIDUAL or comp>KKT_RESIDUAL or abs(gap)>KKT_RESIDUAL):
        raise ValueError('independent current numerical/native evidence rejected')
    return {'verified':True,'joint_excess_rad':joint,'slew_excess_rad':slew,'native_torque_excess_nm':torque,
        'affine_residual_nm':affine,'predicted_residual_nm':predicted_residual,'primary_difference_nm':primary,
        'stationarity':station,'complementarity':comp,'dual_gap':gap}


def inspect(bridge: Any,preview: dict,proposal: dict | None,provider: Any,
            action: Any,measured_angle: float,joint_ranges: Any) -> dict[str,Any]:
    """Full token freshness failures propagate to the existing C10 failure route."""
    scope=bridge.scope
    if scope is None or preview['binding']['scope']!=scope:raise ValueError('candidate preview scope mismatch')
    provider.verify(action,scope,preview['binding']['token'])
    pending=bridge.pending
    if (pending is None or pending['scope']!=scope or pending['before_execute_verified']
            or pending['action_signature']!=digest(np.asarray(action))
            or not np.array_equal(array(pending['reference'],(7,)),array(preview['baseline']['reference'],(7,)))):
        raise ValueError('candidate is not bound to current original C10 preparation')
    ready=bridge.proposal_readiness(measured_angle);blockers=[]
    checks={'P_complete_source':False,'F_exact_fixed_inputs':False,
        'L_original_exact_lease':bool(ready['forecast_lease_valid']),
        'R_previous_executed_close_receipt':bool(ready['previous_executed_close_reference_available']),
        'N_current_candidate_numeric_native':False}
    branch=bridge.branch
    if branch is not None and branch.source_record is not None:
        try:branch.source_record.read();checks['P_complete_source']=True
        except (ValueError,TypeError,KeyError):pass
    checks['F_exact_fixed_inputs']=bridge.source_comparison.get('fixed_prerequisites_equal') is True
    numeric=None
    if proposal is not None and checks['L_original_exact_lease'] and checks['R_previous_executed_close_receipt']:
        receipt=bridge.receipt;desired=branch.reference(scope,measured_angle)
        try:
            if (pending['physical_time']!=receipt['physical_time_after']
                    or pending['expected_execution_count']!=receipt['expected_execution_count']+1):
                raise ValueError('not immediately previous physical execution')
            numeric=numerical_evidence(preview,proposal,receipt['actual_executed_reference'],desired,joint_ranges)
            checks['N_current_candidate_numeric_native']=True
        except (ValueError,TypeError,KeyError,OverflowError) as exc:
            blockers.append('invalid_current_candidate_evidence:'+str(exc))
    for key,ok in checks.items():
        if not ok:blockers.append('missing_or_invalid_'+key)
    # This module deliberately cannot produce Q or perform an application.
    blockers.extend(['no_independent_current_candidate_qualification',
                     'reference_application_transaction_not_implemented'])
    return {'schema':'current_contact_candidate_necessary_evidence_v1','scope':asdict(scope),
        'native_preview_token':preview['binding']['token'],'checks':checks,'numerical_evidence':numeric,
        'necessary_conditions_complete':all(checks.values()),'blockers':blockers,
        'current_candidate_qualification_available':False,'experimental_admitted':False,
        'proposal_applied':False,'reference':None,
        'geometry_scope':'zero-time invariance and virtual FK/clearance are not positive-time qualification; no new FK/free-path gate',
        'contract_scope':'necessary evidence only; no external-object authenticity or dynamics/safety certification'}
