"""Read-only simulator contacts, explicitly labeled when used by native gripper feedback."""
from __future__ import annotations
from typing import Any, Callable
import numpy as np


def sample_contacts(model: Any, data: Any, robot_geoms: frozenset[int],
                    payload_geoms: frozenset[int], names: tuple[str, ...],
                    force_reader: Callable) -> dict:
    records = []
    for index in range(int(data.ncon)):
        contact = data.contact[index]
        first, second = int(contact.geom1), int(contact.geom2)
        if not ({first, second} & (robot_geoms | payload_geoms)):
            continue
        wrench = np.empty(6, dtype=float)
        force_reader(model, data, index, wrench)
        if not np.isfinite(wrench).all():
            raise ValueError('non-finite native contact wrench')
        records.append({'contact_index': index, 'geom_ids': [first, second],
            'geom_names': [names[first], names[second]], 'distance_m': float(contact.dist),
            'position_world_m': np.asarray(contact.pos).copy(),
            'contact_frame_rows': np.asarray(contact.frame).reshape(3, 3).copy(),
            'solver_wrench_contact_frame': wrench.copy(),
            'friction': np.asarray(contact.friction).copy(), 'dimension': int(contact.dim),
            'touches_payload': bool({first, second} & payload_geoms)})
    return {'scope': 'MuJoCo simulator truth; last solver contact wrench, not independent force/tactile sensing',
            'sample_timing': 'observation before current C10 solve; no step/forward/state write',
            'simulation_time_s': float(data.time), 'native_contact_count': int(data.ncon),
            'recorded_contact_count': len(records), 'contacts': records,
            'full_qvel': np.asarray(data.qvel).copy()}


def contact_separation(contacts: list[dict], target_geoms: frozenset[int],
                       gripper_geoms: frozenset[int]) -> dict | None:
    """Signed MuJoCo geom1-to-geom2 normals, only the selected contact pair.

    Require a common separating half-space; opposing pinch contacts cannot
    supply a single translation. This is native geometry, not tactile sensing.
    """
    normals = []
    for contact in contacts:
        first, second = contact['geom_ids']
        if first in target_geoms and second in gripper_geoms:
            sign = 1.
        elif second in target_geoms and first in gripper_geoms:
            sign = -1.
        else:
            continue
        if contact['distance_m'] > 0 or contact['solver_wrench_contact_frame'][0] <= 0:
            continue
        normal = sign * np.asarray(contact['contact_frame_rows'][0], dtype=float)
        length = float(np.linalg.norm(normal))
        if not np.isfinite(normal).all() or length < 1e-8:
            return None
        normals.append(normal / length)
    if not normals:
        return None
    direction = np.sum(normals, axis=0)
    length = float(np.linalg.norm(direction))
    if length < 1e-8:
        return None
    direction /= length
    alignment = min(float(n @ direction) for n in normals)
    if alignment < .9:
        return None
    return {'source': 'native_simulator_contact_solver',
            'scope': 'signed current contact geometry; not independent tactile sensing or a dynamic safety certificate',
            'direction_world': direction, 'normals_world': np.asarray(normals),
            'contact_count': len(normals), 'min_normal_alignment': alignment}


def sample_joint_dynamics(model: Any, data: Any, joint_ids: np.ndarray,
                          controller: Any) -> dict:
    """Copy native force buffers without step, forward or controller update.

    Force buffers and cached OSC matrices belong to the last native integration
    substep; they are not exact forward recomputation at the reported qpos.
    """
    import mujoco
    joints=np.asarray(joint_ids,int);dofs=np.asarray(model.jnt_dofadr[joints],int)
    actuators=[]
    for joint in joints:
        ids=np.flatnonzero((model.actuator_trntype==int(mujoco.mjtTrn.mjTRN_JOINT))
                          & (model.actuator_trnid[:,0]==joint))
        if len(ids)!=1:
            raise ValueError('joint force telemetry requires one direct actuator per arm joint')
        actuators.append(int(ids[0]))
    ids=np.asarray(actuators,int)
    inertia=np.empty(model.nv);mujoco.mj_mulM(model,data,inertia,data.qacc)
    rows=[];sparse=bool(mujoco.mj_isSparse(model))
    for i in range(int(data.nefc)):
        if int(data.efc_type[i])!=int(mujoco.mjtConstraint.mjCNSTR_FRICTION_DOF):continue
        dof=int(data.efc_id[i])
        if dof not in dofs:continue
        if sparse:
            start=int(data.efc_J_rowadr[i]);count=int(data.efc_J_rownnz[i])
            cols=np.asarray(data.efc_J_colind[start:start+count]);values=np.asarray(data.efc_J[start:start+count])
        else:
            values=np.asarray(data.efc_J).reshape(int(data.nefc),model.nv)[i]
            cols=np.flatnonzero(values);values=values[cols]
        rows.append({'constraint_index':i,'dof_id':dof,'force':float(data.efc_force[i]),
                     'state':int(data.efc_state[i]),'velocity':float(data.efc_vel[i]),
                     'jacobian_columns':cols.copy(),'jacobian_values':values.copy()})
    force_names=('qfrc_actuator','qfrc_bias','qfrc_passive','qfrc_constraint','qfrc_applied')
    record={'source':'native_simulator_joint_dynamics_buffers',
            'sample_timing':'before current C10; raw last integration-substep force buffers and cached OSC matrices, not a forward recomputation or independent sensor',
            'joint_ids':joints.copy(),'dof_ids':dofs.copy(),'actuator_ids':ids.copy(),
            'native_ctrl':np.asarray(data.ctrl)[ids].copy(),
            'native_ctrl_range':np.asarray(model.actuator_ctrlrange)[ids].copy(),
            'actuator_force':np.asarray(data.actuator_force)[ids].copy(),
            'actuator_gear':np.asarray(model.actuator_gear)[ids].copy(),
            'dof_frictionloss':np.asarray(model.dof_frictionloss)[dofs].copy(),
            'native_qacc':np.asarray(data.qacc)[dofs].copy(),
            'native_mass_times_qacc':inertia[dofs].copy(),
            'friction_dof_rows':rows}
    record.update({name:np.asarray(getattr(data,name))[dofs].copy() for name in force_names})
    record['cached_osc']={name:(None if getattr(controller,name,None) is None else np.asarray(getattr(controller,name)).copy())
                          for name in ('mass_matrix','J_full','J_pos','J_ori','kp','kd','torques','joint_pos','joint_vel','initial_joint')}
    return record
