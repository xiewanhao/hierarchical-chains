# -*- coding: utf-8 -*-
"""Passive runtime plumbing. No live simulator update or reference write.

Optional fresh native preview is shadow-only; controller application unavailable.
Numerical fixtures cannot be imported as runtime forecasts by this bridge.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any
import hashlib
import json
import numpy as np
from five_chains.envs.forecast_dependencies import ForecastSource


def digest(value: Any) -> str:
    def serial(v: Any) -> Any:
        if isinstance(v, np.ndarray):
            return v.tolist()
        if isinstance(v, np.generic):
            return v.item()
        raise TypeError(type(v).__name__)
    return hashlib.sha256(json.dumps(value,default=serial,sort_keys=True,
                         separators=(',',':'),allow_nan=False).encode()).hexdigest()


def vector(value: Any) -> np.ndarray:
    a=np.asarray(value,dtype=float).copy()
    if a.shape!=(7,) or not np.isfinite(a).all():
        raise ValueError('invalid 7D reference')
    return a


@dataclass(frozen=True)
class Scope:
    call: str
    phase: str
    tick: int
    target_signature: str
    scene_signature: str
    overridden: bool


@dataclass(frozen=True)
class Branch:
    call: str
    target_signature: str
    scene_signature: str
    produced_tick: int
    query_index: int
    angles: tuple[float,...]
    joints: tuple[tuple[float,...],...]
    approach_endpoint: tuple[float,...]
    provenance: str = 'original_online_private_hinge_forecast'
    source_record: ForecastSource | None = None

    @classmethod
    def captured(cls, scope: Scope, query: int, knots: list[dict], endpoint: Any,
                 source_record: ForecastSource | None = None) -> Branch:
        if scope.phase!='approach' or scope.overridden or not knots:
            raise ValueError('capture requires original unoverridden approach')
        # Last enter-contact sample at the starting angle, never its earlier
        # approach samples. Stable last-value folding before sorted interpolation.
        folded: dict[float,tuple[float,...]]={}
        previous: float | None=None
        for k in knots:
            angle=float(k['angle_rad'])
            if (not np.isfinite(angle) or (previous is not None
                    and (abs(angle)>abs(previous) or angle*previous<0))):
                raise ValueError('nonfinite or nonclosing forecast angle sequence')
            folded[angle]=tuple(vector(k['joints_rad']))
            previous=angle
        angles=tuple(sorted(folded))
        if len(angles)<2:
            raise ValueError('forecast has no angle domain')
        if source_record is not None and not source_record.binds(scope.call,scope.tick,endpoint,knots):
            raise ValueError('forecast source does not bind actual endpoint/knots/call/tick')
        return cls(scope.call,scope.target_signature,scope.scene_signature,scope.tick,
                   query,angles,tuple(folded[x] for x in angles),tuple(vector(endpoint)),
                   source_record=source_record)

    def reference(self, scope: Scope, measured_angle: float) -> np.ndarray | None:
        if (scope.call!=self.call or scope.phase!='close' or scope.overridden
                or scope.target_signature!=self.target_signature
                or scope.scene_signature!=self.scene_signature
                or scope.tick<self.produced_tick or not np.isfinite(measured_angle)
                or not self.angles[0]<=measured_angle<=self.angles[-1]):
            return None
        q=np.asarray(self.joints)
        return np.array([np.interp(measured_angle,self.angles,q[:,j]) for j in range(7)])


def choose_branch(path: Any, choices: list[Branch]) -> Branch | None:
    """Associate actual planner endpoint, never selected_candidate restart index.

    Dense arithmetic may alter the last goal by roundoff. Matching precision
    here is for provenance only, not an IK/collision/joint admission threshold.
    Ambiguous different forecasts are rejected without doing another IK call.
    """
    if not path:
        return None
    endpoint=vector(path[-1]);matches=[]
    scale=max(1.,float(np.max(np.abs(endpoint))))
    for candidate in choices:
        if np.max(np.abs(endpoint-np.asarray(candidate.approach_endpoint)))<=64*np.finfo(float).eps*scale:
            matches.append(candidate)
    if not matches:
        return None
    signatures={digest((c.angles,c.joints,None if c.source_record is None
                        else c.source_record.payload_sha256)) for c in matches}
    return matches[0] if len(signatures)==1 else None


class ReferenceBridge:
    def __init__(self) -> None:
        self.branch: Branch | None=None
        self.scope: Scope | None=None
        self.pending: dict[str,Any] | None=None
        self.receipt: dict[str,Any] | None=None
        self.diagnostic: dict[str,Any]={}
        self.invalidation_reasons: list[str]=[]
        self.source_comparison: dict[str,Any]={}

    def begin(self, scope: Scope) -> None:
        if self.pending is not None:
            # A second solve is not an execution acknowledgement.
            self.pending=None
            self.diagnostic={'status':'abandoned_unexecuted_solve'}
        previous=self.scope
        reasons=[]
        if scope.overridden:reasons.append('reflex_override')
        if scope.phase not in ('approach','close'):reasons.append('out_of_scope_phase')
        if previous is not None:
            if scope.call!=previous.call:reasons.append('call_changed')
            if scope.target_signature!=previous.target_signature:reasons.append('target_changed')
            if scope.scene_signature!=previous.scene_signature:reasons.append('exact_scene_changed')
            if scope.call==previous.call and scope.tick<=previous.tick:
                reasons.append('nonincreasing_solve_tick')
        self.invalidation_reasons=reasons
        if reasons:
            self.branch=None
            self.receipt=None
        if previous is not None and scope.phase!=previous.phase:
            self.receipt=None
        self.scope=scope

    def select(self, path: Any, choices: list[Branch]) -> None:
        self.branch=choose_branch(path,choices)
        self.diagnostic={'status':'forecast_captured' if self.branch else 'no_unambiguous_selected_forecast',
                         'query_index':None if self.branch is None else self.branch.query_index}

    def prepare(self, action: Any, controller_reference: Any, physical_time: float,
                execution_count: int) -> None:
        if self.scope is None:
            raise ValueError('missing solve scope')
        if self.pending is not None:
            self.abort()
            raise ValueError('duplicate preparation without a new solve scope')
        if 'nonincreasing_solve_tick' in self.invalidation_reasons:
            self.abort()
            raise ValueError('nonincreasing solve tick')
        a=np.asarray(action,dtype=float)
        if not np.isfinite(a).all() or not np.isfinite(physical_time):
            raise ValueError('nonfinite execution binding')
        ref=vector(controller_reference)
        self.pending={'scope':self.scope,'action_signature':digest(a),
                      'reference':ref.tolist(),'physical_time':float(physical_time),
                      'expected_execution_count':execution_count+1,'before_execute_verified':False}
        self.diagnostic={**self.diagnostic,'status':'pending_original_action',
                         'proposal_applied':False,'native_preview_available':False}

    def before_execute(self, action: Any, controller_reference: Any,
                       physical_time: float, execution_count: int) -> None:
        p=self.pending
        if (p is None or p['before_execute_verified'] or p['scope']!=self.scope
                or digest(np.asarray(action))!=p['action_signature']
                or not np.array_equal(vector(controller_reference),p['reference'])
                or float(physical_time)!=p['physical_time']
                or execution_count+1!=p['expected_execution_count']):
            self.pending=None;self.receipt=None
            raise ValueError('stale original action/reference/time/execution binding')
        p['before_execute_verified']=True

    def after_execute(self, controller_reference: Any, physical_time: float,
                      execution_count: int) -> None:
        p=self.pending
        self.pending=None
        if (p is None or not p['before_execute_verified'] or p['scope']!=self.scope
                or not np.isfinite(physical_time)
                or physical_time<=p['physical_time']
                or execution_count!=p['expected_execution_count']
                or not np.array_equal(vector(controller_reference),p['reference'])):
            self.receipt=None
            raise ValueError('post-step reference/time/execution receipt mismatch')
        self.receipt={**p,'physical_time_after':float(physical_time),
                      'actual_executed_reference':list(p['reference'])}
        self.diagnostic={**self.diagnostic,'status':'original_reference_execution_committed',
                         'execution_count':execution_count}

    def abort(self) -> None:
        self.pending=None;self.receipt=None;self.branch=None
        self.source_comparison={}
        self.diagnostic={'status':'execution_exception_invalidated'}

    def snapshot(self) -> dict[str,Any]:
        """Detached passive telemetry for existing posture diagnostics."""
        receipt=None
        if self.receipt is not None:
            receipt={**self.receipt,'scope':asdict(self.receipt['scope'])}
        branch=None
        if self.branch is not None:
            branch={**asdict(self.branch),'knots_sha256':digest((self.branch.angles,self.branch.joints))}
        return json.loads(json.dumps({'diagnostic':self.diagnostic,'receipt':receipt,
            'branch':branch,'scope':None if self.scope is None else asdict(self.scope),
            'lifecycle_invalidation_reasons':list(self.invalidation_reasons),
            'forecast_source_comparison':self.source_comparison,
            'proposal_applied':False,'native_preview_available':bool(self.diagnostic.get('native_preview_available',False))},allow_nan=False))

    def proposal_readiness(self, measured_angle: float) -> dict[str,Any]:
        # A captured branch and executed receipt are necessary, never sufficient.
        scope=self.scope
        ref=None if scope is None or self.branch is None else self.branch.reference(scope,measured_angle)
        same_phase_receipt=bool(self.receipt is not None and scope is not None and scope.phase=='close'
                               and self.receipt['scope'].call==scope.call
                               and self.receipt['scope'].phase==scope.phase
                               and self.receipt['scope'].tick+1==scope.tick
                               and self.receipt['scope'].target_signature==scope.target_signature
                               and self.receipt['scope'].scene_signature==scope.scene_signature)
        blockers=[]
        source_complete=bool(self.branch is not None and self.branch.source_record is not None)
        if not source_complete:blockers.append('no_complete_original_forecast_source_capture')
        if ref is None:blockers.append('no_current_exact_forecast_lease')
        if not same_phase_receipt:blockers.append('no_immediately_previous_executed_close_receipt')
        if not self.diagnostic.get('native_preview_available'):blockers.append('no_current_native_preview')
        # A positive shadow result cannot certify actual reference application.
        # Runtime candidate connection/contact/dynamic qualification and the
        # full certificate/apply/rebind transaction are not implemented.
        blockers.extend(['runtime_candidate_qualification_not_implemented',
                         'reference_application_transaction_not_implemented'])
        return {'admitted':False,'reason':('shadow_preview_only_application_not_implemented'
                    if self.diagnostic.get('native_preview_available') else 'native_preview_and_application_not_implemented'),
                'forecast_lease_valid':ref is not None,
                'forecast_source_capture_available':source_complete,
                'previous_executed_close_reference_available':same_phase_receipt,
                'application_blockers':blockers,
                'lifecycle_invalidation_reasons':list(self.invalidation_reasons),
                'reference':None}
