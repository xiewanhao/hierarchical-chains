# -*- coding: utf-8 -*-
"""Deterministic numerical core used only for shadow reference admission.

Projection of a 7D forecast reference onto joint/slew/affine torque bounds.
No controller, simulator, action executor, or historical trajectory access.
Rejected results never contain an executable reference or a hold command.
"""
from dataclasses import dataclass
from typing import Any, Optional
import numpy as np
from scipy.optimize import linprog, minimize, nnls

JOINT_MARGIN = 0.015
SLEW = 0.03
# Arithmetic certificate tolerances, not native configuration changes.
RAD_RESIDUAL = 1e-12
TORQUE_RESIDUAL = 1e-9
KKT_RESIDUAL = 1e-8


def _array(value: Any, shape: tuple[int, ...]) -> np.ndarray:
    result = np.asarray(value, dtype=float).copy()
    if result.shape != shape or not np.isfinite(result).all():
        raise ValueError("invalid shape or nonfinite numerical input")
    return result


def _farkas(G: np.ndarray, h: np.ndarray) -> Optional[dict[str, Any]]:
    """Independent normalized nonnegative separating witness for Gx <= h."""
    m = len(h)
    witness = linprog(h, A_eq=np.vstack((G.T, np.ones(m))),
                      b_eq=np.r_[np.zeros(7), 1.0], bounds=(0, None),
                      method="highs-ds")
    if not witness.success:
        return None
    y = np.asarray(witness.x)
    annihilation = float(np.max(np.abs(G.T @ y)))
    gap = float(h @ y)
    if (y.min() < 0 or annihilation > 1e-10
            or abs(float(y.sum()) - 1) > 1e-10 or gap >= -1e-9):
        return None
    return dict(weights=y.tolist(), annihilation_residual=annihilation,
                separation_gap=gap, normalization=float(y.sum()))


def solve(*, base_reference: Any, previous_executed_reference: Any,
          forecast_reference: Any, A: Any, base_torque: Any,
          native_joint_ranges: Any, native_torque_ranges: Any) -> dict[str, Any]:
    """Strictly convex QP, with explicit rejection and separate certificates.

    The caller owns synchronization and provenance. This mathematical API
    cannot establish that a previous reference was actually executed or that
    a forecast is qualified for runtime. It does not mutate its inputs.
    """
    try:
        r0 = _array(base_reference, (7,))
        prev = _array(previous_executed_reference, (7,))
        desired = _array(forecast_reference, (7,))
        matrix = _array(A, (7, 7))
        tau0 = _array(base_torque, (7,))
        joints = _array(native_joint_ranges, (7, 2))
        torques = _array(native_torque_ranges, (7, 2))
        if np.any(joints[:, 0] >= joints[:, 1]) or np.any(torques[:, 0] >= torques[:, 1]):
            raise ValueError("invalid native interval")
        inner_lo, inner_hi = joints[:, 0] + JOINT_MARGIN, joints[:, 1] - JOINT_MARGIN
        if np.any(inner_lo > inner_hi):
            raise ValueError("native interval has no original internal margin")
        lo, hi = np.maximum(inner_lo, prev - SLEW), np.minimum(inner_hi, prev + SLEW)
        if np.any(lo > hi):
            return dict(status="infeasible_box", reference=None,
                        reason="joint margin and actual previous-reference slew do not intersect")
        # Optimize x = r - prev to avoid cancellation of absolute joint values.
        offset = tau0 + matrix @ (prev - r0)
        identity = np.eye(7)
        raw_G = np.vstack((identity, -identity, matrix, -matrix))
        raw_h = np.r_[hi - prev, prev - lo, torques[:, 1] - offset,
                      offset - torques[:, 0]]
        scales = np.maximum(1., np.linalg.norm(raw_G, axis=1))
        G, h = raw_G / scales[:, None], raw_h / scales
        if not np.isfinite(G).all() or not np.isfinite(h).all():
            raise ValueError("overflow in constraint construction")
        delta = desired - prev
        if not np.isfinite(delta).all():
            raise ValueError("overflow in objective construction")
        box = np.clip(desired, lo, hi) - prev
        method = "box_projection_already_torque_feasible"
        iterations = 0
        if np.max(G @ box - h) <= 0:
            x = box
        else:
            # Fixed method/order/tolerances; no random seeds or parameter scan.
            phase = linprog(np.zeros(7), A_ub=G, b_ub=h,
                            bounds=[(None, None)] * 7, method="highs-ds")
            if not phase.success:
                cert = _farkas(G, h) if phase.status == 2 else None
                return dict(status="infeasible_certified" if cert else "numerical_rejection",
                            reference=None, phase_status=int(phase.status),
                            infeasibility_certificate=cert)
            result = minimize(lambda z: .5 * float((z - delta) @ (z - delta)),
                              phase.x, jac=lambda z: z - delta,
                              constraints=[dict(type="ineq", fun=lambda z: h - G @ z,
                                                jac=lambda z: -G)],
                              method="SLSQP", options=dict(ftol=1e-13, maxiter=200))
            if not result.success:
                return dict(status="numerical_rejection", reference=None,
                            reason=str(result.message))
            x = np.asarray(result.x)
            iterations = int(result.nit)
            method = "highs_feasibility_then_SLSQP"
        reference = prev + x
        tau = tau0 + matrix @ (reference - r0)
        joint_excess = float(max(0., np.max(inner_lo - reference), np.max(reference - inner_hi)))
        slew_excess = float(max(0., np.max(np.abs(reference - prev) - SLEW)))
        torque_excess = float(max(0., np.max(torques[:, 0] - tau), np.max(tau - torques[:, 1])))
        slack = h - G @ x
        active = np.flatnonzero(slack <= 1e-8)
        multipliers = np.zeros(len(h))
        if len(active):
            multipliers[active] = nnls(G[active].T, delta - x, maxiter=1000)[0]
        stationarity = float(np.max(np.abs(x - delta + G.T @ multipliers)))
        complementarity = float(np.max(np.abs(multipliers * slack)))
        gradient = x - delta
        # Convex dual lower bound is an independent global objective certificate.
        dual = float(-.5 * np.dot(G.T @ multipliers, G.T @ multipliers)
                     + multipliers @ (G @ delta - h))
        objective = .5 * float(gradient @ gradient)
        gap = objective - dual
        if (not np.isfinite(reference).all() or not np.isfinite(tau).all()
                or not np.isfinite([objective, dual, gap, stationarity, complementarity]).all()
                or joint_excess > RAD_RESIDUAL or slew_excess > RAD_RESIDUAL
                or torque_excess > TORQUE_RESIDUAL
                or stationarity > KKT_RESIDUAL or complementarity > KKT_RESIDUAL
                or abs(gap) > KKT_RESIDUAL):
            return dict(status="numerical_rejection", reference=None,
                        reason="independent primal/KKT/dual verification failed")
        return dict(status="admitted_mathematical_fixture", reference=reference.tolist(),
                    predicted_torque=tau.tolist(), objective=objective,
                    unconstrained_box_reference=(prev + box).tolist(),
                    method=method, iterations=iterations,
                    certificate=dict(joint_excess_rad=joint_excess, slew_excess_rad=slew_excess,
                                     torque_excess_nm=torque_excess,
                                     stationarity_residual=stationarity,
                                     complementarity_residual=complementarity,
                                     dual_lower_bound=dual, primal_dual_gap=gap,
                                     normalized_inequality_multipliers=multipliers.tolist(),
                                     active_constraint_indices=active.tolist()))
    except (ValueError, TypeError, OverflowError, RuntimeError, FloatingPointError) as exc:
        return dict(status="invalid_or_numerical_rejection", reference=None, reason=str(exc))


@dataclass(frozen=True)
class Context:
    """Prospective lifecycle contract; not wired into any runtime adapter."""
    episode: str
    call: str
    contact_key: str
    target_signature: str
    scene_generation: str
    phase: str
    tick: int
    measured_angle: float


@dataclass(frozen=True)
class ForecastLease:
    episode: str
    call: str
    contact_key: str
    target_signature: str
    scene_generation: str
    produced_tick: int
    angle_low: float
    angle_high: float
    source_kind: str

    def valid(self, current: Context) -> bool:
        return bool(all(getattr(self, k) == getattr(current, k) for k in
                    ("episode", "call", "contact_key", "target_signature", "scene_generation"))
                and current.phase == "close" and self.produced_tick <= current.tick
                and self.source_kind == "online_private_forecast_from_observed_scene"
                and np.isfinite([self.angle_low, self.angle_high, current.measured_angle]).all()
                and self.angle_low <= current.measured_angle <= self.angle_high)


class ExecutedReferenceLedger:
    """Toy transaction model, no authority to certify real execution.

    Initialize from a verified executed controller reference. Proposals never
    advance it. Only the matching post-execute acknowledgement can commit;
    recovery, call/phase/target change, failed execution invalidate the ledger.
    Runtime integration must supply trusted execution receipts independently.
    """
    def __init__(self, context: Context, actual_reference: Any):
        self.context = context
        self.reference = _array(actual_reference, (7,))
        self.pending: Optional[tuple[Context, str, np.ndarray]] = None
        self.valid = True

    def propose(self, current: Context, lease: ForecastLease, token: str, **inputs: Any) -> dict[str, Any]:
        same = all(getattr(self.context, k) == getattr(current, k) for k in
                   ("episode", "call", "contact_key", "target_signature", "scene_generation", "phase"))
        if not same or not lease.valid(current):
            self.valid = False
            self.pending = None
            return dict(status="lifecycle_rejection", reference=None)
        if (not self.valid or self.pending is not None
                or current.tick <= self.context.tick or not token):
            return dict(status="lifecycle_rejection", reference=None)
        answer = solve(previous_executed_reference=self.reference, **inputs)
        if answer["reference"] is not None:
            self.pending = (current, token, _array(answer["reference"], (7,)))
        return answer

    def acknowledge(self, current: Context, token: str, actual_reference: Any,
                    execution_succeeded: bool) -> bool:
        pending = self.pending
        if pending is None or current != pending[0] or token != pending[1] or not execution_succeeded:
            self.valid = False
            self.pending = None
            return False
        try:
            observed = _array(actual_reference, (7,))
        except (ValueError, TypeError):
            self.valid = False
            self.pending = None
            return False
        if not np.array_equal(observed, pending[2]):
            self.valid = False
            self.pending = None
            return False
        self.reference = observed
        self.context = current
        self.pending = None
        return True
