# -*- coding: utf-8 -*-
"""Current-state, private original-native arm preview; never steps a plant.

Only shadow proposals are supported. No method writes a live reference/action.
The preview covers one arm controller evaluation, not policy-period dynamics,
all part torques, contact qualification, or a continuous safety certificate.
"""
from __future__ import annotations
from copy import copy,deepcopy
from dataclasses import asdict
from typing import Any
import hashlib
import numpy as np
from five_chains.envs.reference_bridge import Scope,vector


def _hash(value: Any, h: Any, references: dict[int,str] | None=None) -> None:
    if references is not None and id(value) in references:
        h.update(('bound_reference:'+references[id(value)]).encode())
    elif isinstance(value,np.ndarray):
        h.update(str((value.shape,value.dtype.str)).encode());h.update(value.tobytes())
    elif isinstance(value,np.generic):
        _hash(np.asarray(value),h,references)
    elif isinstance(value,(str,int,float,bool,type(None))):
        h.update(repr((type(value).__name__,value)).encode())
    elif isinstance(value,dict):
        for k in sorted(value,key=repr):_hash(k,h,references);_hash(value[k],h,references)
    elif isinstance(value,(tuple,list)):
        h.update(type(value).__name__.encode())
        for v in value:_hash(v,h,references)
    else:
        raise ValueError('unsupported mutable native preview state: '+type(value).__name__)


def simple_state(obj: Any, excluded: tuple[str,...]=(), references: dict[int,str] | None=None) -> dict:
    result={}
    for k,v in obj.__dict__.items():
        if k in excluded:continue
        # Composite topology and simulator/model object identities are handled
        # separately; unsupported controller state fails closed.
        _hash(v,hashlib.sha256(),references)
        result[k]=v
    return result


def clone_controller(obj: Any, private_sim: Any) -> Any:
    result=copy(obj)
    for name,value in obj.__dict__.items():
        if name=='sim':setattr(result,name,private_sim)
        elif name=='robot_model':continue
        else:
            _hash(value,hashlib.sha256(),{id(obj.sim):'native_sim'})
            setattr(result,name,deepcopy(value,{id(obj.sim):private_sim}))
    return result


class NativeReferencePreview:
    def __init__(self, adapter: Any):
        self.adapter=adapter
        self.native_evaluations=0

    def capture(self, action: Any, scope: Scope) -> dict[str,Any]:
        import mujoco
        a=self.adapter;model=a.env.sim.model._model;data=a.env.sim.data._data
        spec=mujoco.mjtState.mjSTATE_INTEGRATION
        state=np.empty(mujoco.mj_stateSize(model,spec))
        mujoco.mj_getState(model,data,state,spec)
        if not np.isfinite(state).all():raise ValueError('nonfinite integration state')
        # Include every exposed model array; no undocumented small whitelist.
        model_arrays={name:getattr(model,name) for name in dir(model)
                      if not name.startswith('_') and isinstance(getattr(model,name),np.ndarray)}
        references={id(a.env.sim):'native_sim'}
        controller_states={name:simple_state(c,('sim','robot_model'),references)
                           for name,c in a.composite.part_controllers.items()}
        composite_state=simple_state(a.composite,('sim','robot_model','part_controllers','grippers'),references)
        gripper_actions={name:np.asarray(g.current_action) for name,g in a.composite.grippers.items()
                         if hasattr(g,'current_action')}
        value=np.asarray(action,dtype=float).copy()
        lo,hi=a.env.action_spec
        if value.shape!=np.asarray(lo).shape or not np.isfinite(value).all() or np.any(value<lo) or np.any(value>hi):
            raise ValueError('preview action outside original native action specification')
        h=hashlib.sha256()
        _hash((asdict(scope),value,state,model_arrays,controller_states,composite_state,gripper_actions),h,references)
        return {'token':h.hexdigest(),'state':state.copy(),'scope':scope,'action':value,
                'model_array_count':len(model_arrays),'integration_state_size':len(state)}

    def verify(self, action: Any, scope: Scope, token: str) -> None:
        if self.capture(action,scope)['token']!=token:
            raise ValueError('stale preview fullstate/model/controller/action/scope binding')

    def _evaluate(self, binding: dict[str,Any], reference: Any) -> dict[str,Any]:
        import mujoco
        from robosuite.utils.binding_utils import MjSim
        from robosuite.utils.control_utils import opspace_matrices,nullspace_torques
        a=self.adapter;self.verify(binding['action'],binding['scope'],binding['token'])
        ref=vector(reference);model=copy(a.env.sim.model._model);private=MjSim(model)
        spec=mujoco.mjtState.mjSTATE_INTEGRATION
        mujoco.mj_setState(model,private.data._data,binding['state'],spec)
        def deny(*args: Any,**kwargs: Any) -> None:raise RuntimeError('private preview cannot integrate')
        private.step=deny
        qpos=np.asarray(private.data.qpos).copy();qvel=np.asarray(private.data.qvel).copy()
        private.forward()
        composite=copy(a.composite);composite.sim=private;composite._applied_action_dict={}
        for name,value in a.composite.__dict__.items():
            if name not in ('sim','robot_model','part_controllers','grippers'):
                _hash(value,hashlib.sha256(),{id(a.env.sim):'native_sim'})
                setattr(composite,name,deepcopy(value,{id(a.env.sim):private}))
        composite._applied_action_dict={}
        composite.part_controllers={name:clone_controller(c,private) for name,c in a.composite.part_controllers.items()}
        composite.grippers={name:deepcopy(g) for name,g in a.composite.grippers.items()}
        arm=composite.part_controllers[a.arm]
        if arm.interpolator_pos is not None or arm.interpolator_ori is not None:
            raise ValueError('interpolated controller preview not qualified')
        origin_pos=arm.origin_pos.copy();origin_ori=arm.origin_ori.copy()
        # Synchronize only the private arm buffers; never update origin early.
        arm.update(force=True)
        if not np.array_equal(arm.origin_pos,origin_pos) or not np.array_equal(arm.origin_ori,origin_ori):
            raise ValueError('private buffer update changed origin')
        arm.initial_joint=ref.copy()
        composite.set_goal(binding['action'])
        before_pos=arm.origin_pos.copy();before_ori=arm.origin_ori.copy()
        torque=composite.run_controller({a.arm:True})[a.arm].copy()
        self.native_evaluations+=1
        _,_,_,null=opspace_matrices(arm.mass_matrix,arm.J_full,arm.J_pos,arm.J_ori)
        A=10*null.T@arm.mass_matrix
        null_torque=nullspace_torques(arm.mass_matrix,null,arm.initial_joint,arm.joint_pos,arm.joint_vel)
        ids=a.robot._ref_actuators_indexes_dict[a.arm]
        bounds=np.asarray(private.model.actuator_ctrlrange)[ids].copy()
        if (not np.isfinite(torque).all() or not np.isfinite(A).all()
                or not np.array_equal(private.data.qpos,qpos)
                or not np.array_equal(private.data.qvel,qvel)):
            raise ValueError('invalid private native preview result/state mutation')
        self.verify(binding['action'],binding['scope'],binding['token'])
        return dict(reference=ref.tolist(),torque=torque.tolist(),A=A.tolist(),
            primary_and_compensation=(torque-null_torque).tolist(),native_torque_ranges=bounds.tolist(),
            origin_before_set_goal=dict(position=origin_pos.tolist(),orientation=origin_ori.tolist()),
            origin_before_composite_run=dict(position=before_pos.tolist(),orientation=before_ori.tolist()),
            origin_after_composite_run=dict(position=arm.origin_pos.tolist(),orientation=arm.origin_ori.tolist()),
            full_qpos_qvel_unchanged=True,private_integration_state_copied=True,
            original_action=binding['action'].tolist(),token=binding['token'])

    def baseline(self, action: Any, scope: Scope) -> dict[str,Any]:
        binding=self.capture(action,scope)
        result=self._evaluate(binding,self.adapter.controller.initial_joint)
        return {'binding':binding,'baseline':result}

    def verify_reference(self, preview: dict[str,Any], candidate: Any) -> dict[str,Any]:
        baseline=preview['baseline'];ref=vector(candidate)
        result=self._evaluate(preview['binding'],ref)
        predicted=np.asarray(baseline['torque'])+np.asarray(baseline['A'])@(ref-vector(baseline['reference']))
        residual=float(np.max(np.abs(predicted-np.asarray(result['torque']))))
        primary_difference=float(np.max(np.abs(np.asarray(baseline['primary_and_compensation'])-
                                                np.asarray(result['primary_and_compensation']))))
        if residual>1e-8 or primary_difference>1e-8:
            raise ValueError('candidate native affine/primary verification failed')
        result.update(affine_residual_nm=residual,primary_difference_nm=primary_difference)
        return result

    def shadow_solve(self, preview: dict[str,Any], previous_executed: Any,
                     desired_forecast: Any) -> dict[str,Any]:
        from five_chains.envs.reference_admission import solve
        a=self.adapter;base=preview['baseline']
        self.verify(preview['binding']['action'],preview['binding']['scope'],preview['binding']['token'])
        result=solve(base_reference=base['reference'],base_torque=base['torque'],A=base['A'],
            previous_executed_reference=previous_executed,forecast_reference=desired_forecast,
            native_joint_ranges=a.env.sim.model._model.jnt_range[a.posture_solver.joints],
            native_torque_ranges=base['native_torque_ranges'])
        if result['reference'] is not None:
            native=self.verify_reference(preview,result['reference'])
            bounds=np.asarray(base['native_torque_ranges']);torque=np.asarray(native['torque'])
            if np.any(torque<bounds[:,0]-1e-9) or np.any(torque>bounds[:,1]+1e-9):
                raise ValueError('candidate native torque certificate failed')
            result['private_native_verification']=native
        result['proposal_applied']=False
        result['input_binding']={'native_preview_token':preview['binding']['token'],
            'scope':asdict(preview['binding']['scope']),
            'previous_executed_reference':vector(previous_executed).tolist(),
            'desired_forecast_reference':vector(desired_forecast).tolist()}
        return result
