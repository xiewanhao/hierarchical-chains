from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any
import math
import yaml


def merge(base: dict, update: dict) -> dict:
    out = deepcopy(base)
    for key, value in update.items():
        out[key] = merge(out[key], value) if isinstance(value, dict) and isinstance(out.get(key), dict) else deepcopy(value)
    return out


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    default = Path(__file__).resolve().parents[1] / "configs/default.yaml"
    if not default.is_file():
        default = Path(__file__).resolve().parent / "data/default.yaml"
    cfg = yaml.safe_load(default.read_text())
    if path:
        cfg = merge(cfg, yaml.safe_load(Path(path).read_text()) or {})
    validate_config(cfg)
    return cfg


def validate_config(cfg: dict) -> None:
    if type(cfg['control']['close_reference_native_preview_shadow']) is not bool:raise ValueError('invalid shadow native reference preview')
    if cfg['control']['close_reference_native_preview_shadow'] and not cfg['control']['close_reference_bridge_capture']:raise ValueError('shadow preview requires passive capture')
    if type(cfg['control']['close_reference_bridge_capture']) is not bool:raise ValueError('invalid passive reference bridge capture')
    if type(cfg['control']['press_lateral_alignment']) is not bool:raise ValueError('invalid press lateral alignment')
    if type(cfg['control']['press_continuous_alignment']) is not bool:raise ValueError('invalid continuous press alignment')
    if type(cfg['environment']['joint_dynamics_telemetry']) is not bool:raise ValueError('invalid native joint dynamics telemetry')
    if not isinstance(cfg['grasp']['native_contact_egress'],bool):raise ValueError('native contact egress requires boolean')
    if not isinstance(cfg['base']['door_arc_bisector_heading'],bool):raise ValueError('door arc heading requires boolean')
    if not isinstance(cfg['grasp']['free_content_attitude_search'],bool):raise ValueError('free content attitude search requires boolean')
    reserve=cfg['reflex']['gripper_force_reserve']
    if len(reserve)!=2 or any(not math.isfinite(v) for v in reserve) or not 1<=reserve[0]<reserve[1]:raise ValueError('invalid candidate grip force reserve')
    band=cfg['reflex']['bounds'].get('gripper_load_band_n')
    if band is not None and (len(band)!=2 or any(not math.isfinite(v) for v in band) or not 0<band[0]<band[1]<=20):
        raise ValueError('invalid native gripper load band')
    margin=cfg['reflex']['bounds'].get('gripper_preload_margin_m',.002)
    if not math.isfinite(margin) or not 0<margin<.008:raise ValueError('invalid gripper reference preload margin')
    clearance = cfg['grasp']['source_transport_clearance']
    if any(not math.isfinite(clearance[k]) or not 0 < clearance[k] <= .20 for k in ('retreat_m', 'up_m')):
        raise ValueError('invalid bounded source transport clearance')
    yaws = cfg['grasp']['cavity_yaw_repair_rad']
    if (not isinstance(yaws,list) or not yaws or yaws[0] != 0.
            or any(not math.isfinite(y) or abs(y)>math.pi for y in yaws)):
        raise ValueError('invalid free-yaw cavity preparation samples')
    repair = cfg['grasp']['parameter_repair']
    if (type(repair['max_attempts']) is not int or not 0 <= repair['max_attempts'] <= 3
            or not math.isfinite(repair['min_open_width_m']) or not 0 < repair['min_open_width_m'] <= .08):
        raise ValueError('invalid grasp parameter repair budget/opening')
    if 'current_asset_contacts' in cfg['grasp'] and not isinstance(cfg['grasp']['current_asset_contacts'],bool):
        raise ValueError('current-asset contact preparation requires a boolean setting')
    for group,key in (('base','cavity_standoff_m'),('grasp','cabinet_exit_clearance_m')):
        if key in cfg[group] and (not math.isfinite(cfg[group][key]) or cfg[group][key]<=0):
            raise ValueError('invalid geometry clearance: '+key)
    if not math.isfinite(cfg['preparation']['translation_reference_m']) or cfg['preparation']['translation_reference_m']<=0:
        raise ValueError('preparation reference length must be positive')
    if any(not math.isfinite(v) or v<=0 for v in cfg['torso'].values()):
        raise ValueError('invalid torso settings')
    ik=cfg['control']['posture_ik']
    if any(not math.isfinite(v) or v<=0 for k,v in ik.items() if k not in ('enabled','allow_approximate_reference','orientation_projection','path_planning')):
        raise ValueError('invalid posture IK setting')
    refinement=cfg['grasp']['contact_refinement']
    if any(not math.isfinite(v) or v<0 for v in refinement.values()) or refinement['iterations']<1 or refinement['apertures']<3:
        raise ValueError('invalid contact refinement settings')
    if cfg['grasp']['provider'] not in ('geometric','asset_cached'):
        raise ValueError('unknown grasp provider')
    proposals=cfg['grasp']['asset_candidates']
    if (not 0<=proposals['min_confidence']<=1 or proposals['top_k']<1 or
        not 0<=proposals['min_radial_fraction']<proposals['max_radial_fraction'] or
        not 0<=proposals['max_approach_tilt_rad']<math.pi/2):
        raise ValueError('invalid asset proposal filter')
    if not math.isfinite(cfg['base']['hold_max_speed_m_s']) or cfg['base']['hold_max_speed_m_s'] <= 0:
        raise ValueError('base hold speed must be positive')
    load=cfg['grasp']['loaded_acquisition']
    for key in ('preload_height_m','min_object_lift_m','stable_translation_m','stable_rotation_rad','speed_m_s'):
        if not math.isfinite(load[key]) or load[key]<=0:raise ValueError('invalid loaded acquisition setting: '+key)
    if load['min_object_lift_m']>=load['preload_height_m'] or load['stable_frames']<1:
        raise ValueError('invalid loaded acquisition sequence')
    if not 0<=cfg['control']['constraint_tilt_margin_rad']<.05:raise ValueError('invalid tilt interior margin')
    planner=cfg['control']['posture_ik']['path_planning']
    if type(planner['strict_door_withdraw_tracking']) is not bool:raise ValueError('invalid strict door withdraw tracking')
    if type(planner['strict_grasp_approach_tracking']) is not bool:raise ValueError('invalid strict grasp approach tracking')
    if type(planner['strict_payload_alignment_tracking']) is not bool:raise ValueError('invalid strict payload alignment tracking')
    if type(planner['grasp_approach_stall_refresh']) is not bool:raise ValueError('invalid grasp approach stall refresh')
    if type(planner['door_withdraw_nearby_orientation']) is not bool:raise ValueError('invalid door withdraw orientation preference')
    refresh=planner['measured_stall_refresh']
    if (type(refresh['enabled']) is not bool or type(refresh['distinct_frames']) is not int
            or not 2<=refresh['distinct_frames']<=200 or type(refresh['max_replans']) is not int
            or not 1<=refresh['max_replans']<=2):
        raise ValueError('invalid bounded measured stall counts')
    for key in ('max_velocity_rad_s','max_motion_rad','min_error_progress_rad','max_frame_gap_s'):
        if not math.isfinite(refresh[key]) or refresh[key]<=0:
            raise ValueError('invalid measured stall scale: '+key)
    if type(planner['contact_egress_planning']['enabled']) is not bool:raise ValueError('invalid contact egress planning')
    if type(planner['contact_egress_planning']['prefer_nearby_orientation']) is not bool:raise ValueError('invalid contact egress orientation preference')
    if type(planner['contact_egress_planning']['measured_stall_refresh']) is not bool:raise ValueError('invalid contact egress stall refresh')
    continuation=planner['hinge_continuation']
    if type(continuation['local_joint_search']) is not bool:raise ValueError('invalid local hinge IK search')
    if type(continuation['track_admitted_branch']) is not bool:raise ValueError('invalid hinge branch tracking')
    if (type(continuation['enabled']) is not bool or type(continuation['samples']) is not int
            or not 2<=continuation['samples']<=129 or not math.isfinite(continuation['max_joint_step_rad'])
            or not 0<continuation['max_joint_step_rad']<=.3):
        raise ValueError('invalid hinge continuation forecast')
    if type(planner['optimize_restarts']) is not bool:raise ValueError('invalid restart optimization')
    if type(planner['restarts']) is not int or not 1<=planner['restarts']<=planner['iterations']:
        raise ValueError('invalid bounded planner restarts')
    for key in ('iterations','goal_seeds','connect_steps','shortcut_attempts'):
        if not isinstance(planner[key],int) or planner[key]<1:raise ValueError('invalid path planning count: '+key)
    for key in ('extension_rad','validation_step_rad','waypoint_step_rad','joint_reached_rad','container_tilt_slack_rad'):
        if not math.isfinite(planner[key]) or planner[key]<=0:raise ValueError('invalid path planning scale: '+key)
    if not 0<planner['orientation_search_fraction']<1:raise ValueError('attitude search must stay inside the original goal region')
    if not 0<planner['goal_bias']<1 or not 0<=planner['penetration_epsilon_m']<=1e-5:
        raise ValueError('invalid path planning geometry setting')
    if cfg["control"]["max_ticks"] <= 0:
        raise ValueError("max_ticks must be positive")
    if cfg['feedback']['grasp_contact_mode'] not in ('native_pads','bilateral_fingers'):
        raise ValueError('unknown grasp contact mode')
    if cfg['feedback']['grasp_confirm_steps'] < 1 or cfg['feedback']['grasp_contact_grace_steps'] < 0:
        raise ValueError('invalid contact evidence window')
    for key in ('grasp_retention_translation_m','grasp_retention_rotation_rad','lift_retention_min_m'):
        if not math.isfinite(cfg['feedback'][key]) or cfg['feedback'][key] <= 0:
            raise ValueError('invalid grasp retention bound: '+key)
    for key in ('reached_m','approach_speed_m_s','lift_speed_m_s','rim_depth_m','container_drop_reached_m'):
        if not math.isfinite(cfg['grasp'][key]) or cfg['grasp'][key] <= 0:
            raise ValueError('invalid grasp setting: '+key)
    if not 0 <= cfg['grasp']['asset_candidates']['max_jaw_tilt_rad'] < math.pi/2:
        raise ValueError('jaw tilt must be measured from the horizontal plane')
    if not 0 <= cfg['grasp']['rim_approach_tilt_rad'] < math.pi/2:
        raise ValueError('rim approach must point downward')
    if not isinstance(cfg['grasp']['door_closed_settle_ticks'],int) or cfg['grasp']['door_closed_settle_ticks']<1:
        raise ValueError('door settling needs positive physical frame count')
    if not math.isfinite(cfg['grasp']['door_closed_max_velocity_rad_s']) or cfg['grasp']['door_closed_max_velocity_rad_s']<=0:
        raise ValueError('invalid door settling velocity')
    if cfg['grasp']['close_settle_ticks'] < 0:
        raise ValueError('negative grasp settle time')
    for name in ("eps_pos", "eps_rot", "eps_joint"):
        if cfg["state"][name] < 0:
            raise ValueError(name + " must be nonnegative")
    if cfg["state"]["backend"] not in ("ground_truth", "noisy"):
        raise ValueError("unknown state backend")
    if cfg["state"]["noise"]["update_every"] < 1:
        raise ValueError("update_every must be positive")
    for name in ("pos_std", "rot_std"):
        value = cfg["state"]["noise"][name]
        if not math.isfinite(value) or value < 0:
            raise ValueError("invalid noise scale: " + name)
    for group, names in {"control": ("reference_speed_m_s", "reference_rotation_rad_s", "max_tracking_lead_m", "reached_m", "reached_rad"),
                         "base": ("stance_reached_m", "standoff_m", "payload_clearance_margin_m", "door_lateral_standoff_m", "door_front_standoff_m", "door_fixture_standoff_m", "door_max_lateral_shift_m", "max_speed_m_s", "max_yaw_rad_s", "proportional_gain", "reached_m", "reached_rad")}.items():
        for name in names:
            value = cfg[group][name]
            if not math.isfinite(value) or value <= 0:
                raise ValueError("invalid positive control setting: " + group + "." + name)
    if any(not math.isfinite(value) or value < 0 for value in cfg["fb_fast"]["thresholds"].values()):
        raise ValueError("invalid feedback threshold")
    for name in ("max_pos_correction_m", "max_rot_correction_rad"):
        if cfg["reflex"]["bounds"][name] < 0:
            raise ValueError("negative reflex bound")
    valid = {"c1_prep", "c2_reflex", "c3a_fb_fast", "c3b_fb_full", "c4_vision"}
    if not set(cfg["ablation"]["disable_chains"]) <= valid:
        raise ValueError("unknown disabled chain")
    if "c1_prep" in cfg["ablation"]["disable_chains"]:
        raise ValueError("preparation is required to initialize a contract")
