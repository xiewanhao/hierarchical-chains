"""Summaries preserve unknowns in old traces and distinguish fixture/native steps."""
from __future__ import annotations
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any
import csv, gzip, html, json, math, statistics


def rows(path: Path) -> Any:
    opener = gzip.open if path.suffix == '.gz' else open
    with opener(path, 'rt', encoding='utf-8') as handle:
        for line in handle:
            yield json.loads(line)


def summarize(path: Path, evidence_level: str = 'V1_natural_trace', expected_ticks: int | None = None) -> dict:
    kinds: Counter = Counter()
    triggers: Counter = Counter()
    fields: dict[str, Counter] = defaultdict(Counter)
    timing: dict[str, list] = defaultdict(list)
    conditions: dict[str, Any] = {}
    invocations: dict[str, dict] = {}
    recipe: Counter = Counter()
    decisions: Counter = Counter()
    errors = []
    summaries = []
    tick_labels = []
    perturbations: dict[str, dict] = {}
    latencies = []
    executes = []
    timeline = []
    event_ids = set()
    run_info: dict[str, Any] = {}
    writes: dict[str, Counter] = defaultdict(Counter)
    rejections: dict[str, Counter] = defaultdict(Counter)
    contexts: dict[str, Counter] = defaultdict(Counter)
    exclusive: dict[str, list] = defaultdict(list)
    for r in rows(path):
        kind = r.get('kind', '<missing>'); kinds[kind] += 1
        if r.get('event_id'):
            if r['event_id'] in event_ids:errors.append('duplicate event id')
            event_ids.add(r['event_id'])
        if kind=='run_manifest':
            run_info=r
            recorded=r.get('evidence_level','')
            if recorded.startswith('V0'):
                if not evidence_level.startswith('V0'):errors.append('fixture cannot be relabeled as native evidence')
                evidence_level=recorded
        if kind == 'summary':summaries.append(r)
        if kind == 'tick':
            tick_labels.append(r['tick']);triggers.update(r.get('triggers', []))
            timeline.append({'kind':'recorded_tick_context','source':'original_tick_row','loop_tick':r['tick'],
                'physical_step_index':len(tick_labels),'obs_stamp':None,'call_id':r.get('call_id'),'skill':None,
                'phase':r.get('phase'),'triggers':r.get('triggers',[]),'events':r.get('events',[]),
                'changed_keys':r.get('changed_keys',[]),'proposals':r.get('proposals',[]),
                'final_writes':r.get('writes',[]),'rejected':r.get('rejected',[])})
            for chain in r.get('triggers', []):
                contexts[chain].update('event:'+x for x in r.get('events', []))
                contexts[chain].update('changed:'+x for x in r.get('changed_keys', []))
            for p in r.get('writes', []):writes[p['chain']][p['name']]+=1
            for p in r.get('rejected', []):rejections[p['chain']][p['reason']]+=1
            for p in r.get('proposals', []):
                for f in p['fields']:fields[p['chain']][f] += 1
            for c, v in r.get('component_seconds', {}).items():timing[c].append(v)
        elif kind == 'invocation_start':
            invocations[r['invocation_id']] = r
            if r['component'] == 'recipe.prepare':recipe[str(r.get('owner_chain') or r.get('chain'))+'/'+r.get('field','<unknown>')] += 1
        elif kind == 'invocation_end':
            start = invocations.get(r['invocation_id'])
            if start is None:errors.append('invocation end without start')
            else:
                start['ended'] = True
                exclusive[str(start.get('owner_chain') or start.get('chain'))+'/'+r['component']].append(r['exclusive_ns'])
        elif kind == 'arbitration':decisions[(r['chain'],r['decision'])] += 1
        elif kind == 'execution':executes.append(r)
        elif kind == 'perturbation':perturbations[r['perturbation_id']] = r
        elif kind == 'case_assertion':conditions[r['name']] = r['passed']
        if kind in ('selection','contract_snapshot','arbitration','reflex_decision','phase_update','execution','reselection_requested','perturbation'):
            timeline.append(r)
        # Only an explicit causal id establishes latency. Never infer from a shared stamp.
        for cause in r.get('cause_ids', []) if kind in ('arbitration','reflex_decision','execution','action_prepared') else []:
            p = perturbations.get(cause)
            if p is not None:
                start, end = p.get('loop_tick'), r.get('loop_tick')
                latencies.append({'cause_id':cause,'event_id':r.get('event_id'),
                    'kind':kind,'decision_cycles':None if start is None or end is None else end-start,
                    'physical_response_seconds':None})
    if len(summaries)!=1:errors.append('exactly one terminal summary required')
    if summaries and summaries[-1].get('tick_rows') != kinds['tick']:errors.append('summary/tick mismatch')
    if len(set(tick_labels)) != len(tick_labels) or any(a>=b for a,b in zip(tick_labels,tick_labels[1:])):errors.append('invalid physical tick labels')
    if expected_ticks is not None and kinds['tick']!=expected_ticks:errors.append('expected tick count mismatch')
    if any(not s.get('ended') for s in invocations.values()):errors.append('incomplete invocation')
    if executes and executes[-1].get('step_after')!=kinds['tick']:errors.append('actual execution count differs from recorded ticks')
    if any(v is False for v in conditions.values()):errors.append('case assertion failed')
    calls={r['selected_call']['call_id']:r['selected_call']['skill'] for r in timeline if r['kind']=='selection'}
    calls.update({r['contract']['call']['call_id']:r['contract']['call']['skill'] for r in timeline if r['kind']=='contract_snapshot'})
    for r in timeline:
        if r['kind']=='recorded_tick_context':r['skill']=calls.get(r['call_id'])
    has_audit=bool(invocations)
    return {'evidence_level':evidence_level,'trace_complete':not errors,'integrity_errors':errors,
        'status':'FAIL' if errors else ('PASS' if conditions and all(conditions.values()) else 'NOT_OBSERVED'),
        'physical_ticks':kinds['tick'] if evidence_level in ('V1_natural_trace','V3_native','V3_native_intervention') else 0,
        'fixture_steps':kinds['tick'] if evidence_level.startswith('V0') else 0,
        'recorded_tick_rows':kinds['tick'],'record_kinds':dict(kinds),'trigger_counts':dict(triggers),
        'proposed_fields':{k:dict(v) for k,v in fields.items()},
        'final_packet_fields_legacy':{k:dict(v) for k,v in writes.items()},
        'rejection_reasons':{k:dict(v) for k,v in rejections.items()},
        'trigger_context_not_causal_proof':{k:dict(v) for k,v in contexts.items()},
        'actual_recipe_calls':dict(recipe) if has_audit else None,
        'arbitration_decisions':[{'chain':k[0],'decision':k[1],'count':v} for k,v in decisions.items()] if has_audit else None,
        'case_assertions':conditions,'explicit_causal_latencies':latencies,
        'latency_note':'Explicit IDs associate tested input with output; no physical causality/response is inferred. Null without IDs or real post-step evidence; a stamp is not a recipe call.',
        'exclusive_span_ns':{k:sum(v) for k,v in exclusive.items()},
        'run_info':run_info,
        'timing_scopes':{k:{'samples':len(v),'inclusive_sum_seconds':math.fsum(v),
            'median_seconds':statistics.median(v),'p95_seconds':sorted(v)[math.ceil(.95*len(v))-1]} for k,v in timing.items()},
        'timing_note':'Nested legacy component timers must not be added. New invocation spans provide exclusive_ns; audit overhead is included.',
        'timeline':timeline,'original_summary':summaries[-1] if summaries else None}


def write_outputs(result: dict, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=False)
    (output/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    chains=('c1_prep','c2_reflex','c3a_fb_fast','c3b_fb_full','c4_vision','c5_replan')
    with (output/'chain_validation.csv').open('x',encoding='utf-8-sig',newline='') as stream:
        w=csv.writer(stream);w.writerow(['chain','setting','evidence_level','trigger_records','trigger_context',
            'proposed_fields','final_packet_fields','rejection_reasons','actual_recipe_calls','associated_latency',
            'exclusive_span_ns','reselection_requests','status'])
        for chain in chains:
            count=result['trigger_counts'].get(chain,0)
            if chain=='c5_replan':count=result['record_kinds'].get('reselection_requested',0)
            case_chain={'preparation':'c1_prep','fast':'c3a_fb_fast','geometry':'c4_vision','relation':'c3b_fb_full',
                'reflex_stop':'c2_reflex','reflex_gripper':'c2_reflex','reselection':'c5_replan'}.get(result['run_info'].get('case'))
            recipes=None if result['actual_recipe_calls'] is None else {k:v for k,v in result['actual_recipe_calls'].items() if k.startswith(chain+'/')}
            w.writerow([chain,result['run_info'].get('setting','recorded'),result['evidence_level'],count,
                json.dumps(result['trigger_context_not_causal_proof'].get(chain,{})),json.dumps(result['proposed_fields'].get(chain,{})),
                json.dumps(result['final_packet_fields_legacy'].get(chain,{})),json.dumps(result['rejection_reasons'].get(chain,{})),
                'unknown' if recipes is None else json.dumps(recipes),json.dumps(result['explicit_causal_latencies']),
                json.dumps({k:v for k,v in result['exclusive_span_ns'].items() if k.startswith(chain+'/')}),
                result['record_kinds'].get('reselection_requested',0) if chain=='c5_replan' else '',
                'FAIL' if result['integrity_errors'] else ('PASS' if chain==case_chain and result['status']=='PASS' else ('INCONCLUSIVE' if count else 'NOT_OBSERVED'))])
    (output/'timeline.json').write_text(json.dumps(result['timeline'],ensure_ascii=False,indent=2),encoding='utf-8')
    headings=['loop_tick','physical_step_index','obs_stamp','kind','call_id','skill','phase','chain','fields']
    body='<html><meta charset="utf-8"><title>Decision timeline</title><style>body{font:14px/1.5 system-ui;margin:25px}table{border-collapse:collapse}td,th{border:1px solid #ccd;padding:6px}th{position:sticky;top:0;background:#eee}</style><h1>Decision timeline</h1><p>Unknown skill/observation stamps in old logs remain unknown. Fixture rows are not native physics. Tick observations precede the recorded execution.</p><table><tr>'
    body+=''.join('<th>'+h+'</th>' for h in headings)+'</tr>'
    for event in result['timeline']:
        row=dict(event)
        if event['kind']=='selection':
            row.update(call_id=event['selected_call']['call_id'],skill=event['selected_call']['skill'])
        if event['kind']=='contract_snapshot':
            row.update(skill=event['contract']['call']['skill'])
        row['fields']=event.get('field') or ', '.join(str(x['name']) for x in event.get('final_writes',[]))
        body+='<tr>'+''.join('<td>'+html.escape(str(row.get(h) if row.get(h) is not None else 'unknown'))+'</td>' for h in headings)+'</tr>'
    (output/'timeline.html').write_text(body+'</table></html>',encoding='utf-8')
