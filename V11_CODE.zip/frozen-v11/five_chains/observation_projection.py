"""Contract-owned projection of an observed object up vector into tilt error."""
from __future__ import annotations
from typing import Mapping
import numpy as np
from five_chains.types import Contract


def tilt_deviation(contract: Contract, observed_up: Mapping[str, np.ndarray]) -> float:
    """Keep the original adapter formula; absent attitude demand has no signal.

    Native adapters supply measured entity axes. A registered observation-fault
    experiment can supply an explicit raw axis using this same projection.
    The projector never changes the raw input or plant based on expected output.
    """
    if 'tilt_limit' not in contract.fields:
        return 0.0
    spec = contract.fields['tilt_limit']
    entity = spec.arguments.get('entity', contract.call.bindings.get('object'))
    if not isinstance(entity, str) or entity not in observed_up:
        return 0.0
    up = np.asarray(observed_up[entity], dtype=np.float64)
    if up.shape != (3,) or not np.isfinite(up).all():
        raise ValueError('object attitude observation must be one finite 3D up vector')
    tilt = float(np.arccos(np.clip(up[2], -1, 1)))
    return max(0., tilt - spec.default[1])
