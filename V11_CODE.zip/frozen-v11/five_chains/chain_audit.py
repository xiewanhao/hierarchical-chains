"""Opt-in invocation evidence. No controller arithmetic or plant writes."""
from __future__ import annotations
from contextlib import contextmanager
from hashlib import sha256
from typing import Any, Iterator, Callable, ParamSpec, TypeVar
from functools import wraps
import time
import inspect
import numpy as np
from five_chains.trace import serial
from five_chains.types import ChainId, WorldState
P = ParamSpec('P')
T = TypeVar('T')


def audit_chain(chain: str) -> Callable[[Callable[P, T]], Callable[P, T]]:
    def decorate(fn: Callable[P, T]) -> Callable[P, T]:
        names=list(inspect.signature(fn).parameters)
        key='C' if 'C' in names else 'tracer'
        index=names.index(key)
        @wraps(fn)
        def invoke(*args: P.args, **kwargs: P.kwargs) -> T:
            owner=args[index] if len(args)>index else kwargs.get(key)
            audit=getattr(owner,'chain_audit' if key=='C' else 'audit',None)
            if audit is None:return fn(*args,**kwargs)
            with audit.span('chain.'+chain,chain=chain):return fn(*args,**kwargs)
        return invoke
    return decorate


def action_digest(action: Any) -> str:
    a = np.asarray(action)
    return sha256(str(a.dtype).encode() + str(a.shape).encode() + a.tobytes()).hexdigest()


class AuditRecorder:
    def __init__(self, tracer: Any) -> None:
        self.tracer = tracer
        self.sequence = 0
        self.stack: list[dict] = []
        self.loop_tick: int | None = None
        self.obs_stamp: int | None = None
        self.physical_step = 0
        self.call_id: str | None = None
        self.phase: str | None = None
        self.last_solve: dict | None = None
        self.cause_ids: list[str] = []

    def emit(self, kind: str, **data: Any) -> None:
        self.sequence += 1
        self.tracer.write({'kind': kind, 'audit_version': 1, 'event_id': f'event_{self.sequence}',
            'loop_tick': self.loop_tick, 'obs_stamp': self.obs_stamp,
            'physical_step_index': self.physical_step, 'call_id': self.call_id,
            'phase': self.phase, 'cause_ids': list(self.cause_ids),
            'owner_chain':self.stack[-1].get('owner_chain') if self.stack else None,
            'chain': self.stack[-1].get('chain') if self.stack else None, **data})

    @contextmanager
    def span(self, component: str, **data: Any) -> Iterator[str]:
        self.sequence += 1
        sid = f'span_{self.sequence}'
        parent = self.stack[-1]['id'] if self.stack else None
        frame: dict[str, Any] = {'id': sid, 'child_ns': 0,
            'chain': data.get('chain', self.stack[-1].get('chain') if self.stack else None),
            'owner_chain':self.stack[-1].get('owner_chain') if self.stack else data.get('chain')}
        self.stack.append(frame)
        start = time.perf_counter_ns()
        self.emit('invocation_start', invocation_id=sid, parent_id=parent, component=component, **data)
        status, error = 'returned', None
        try:
            yield sid
        except BaseException as exc:
            status, error = 'raised', type(exc).__name__
            raise
        finally:
            duration = time.perf_counter_ns() - start
            self.stack.pop()
            if self.stack:
                self.stack[-1]['child_ns'] += duration
            self.emit('invocation_end', invocation_id=sid, parent_id=parent, component=component,
                status=status, error_type=error, inclusive_ns=duration,
                exclusive_ns=max(0, duration-frame['child_ns']), chain=frame['chain'],owner_chain=frame['owner_chain'])


class PermissionTap:
    def __init__(self, delegate: Any) -> None:
        self.delegate = delegate
        self.observed: list[bool] = []

    def may_write(self, *args: Any, **kwargs: Any) -> bool:
        value = self.delegate.may_write(*args, **kwargs)
        self.observed.append(bool(value))
        return value


class AuditProxy:
    def __init__(self, wrapped: Any, name: str, audit: AuditRecorder) -> None:
        object.__setattr__(self, '_wrapped', wrapped)
        object.__setattr__(self, '_name', name)
        object.__setattr__(self, '_audit', audit)

    def __setattr__(self, name: str, value: Any) -> None:
        setattr(self._wrapped, name, value)

    def __getattr__(self, name: str) -> Any:
        target = getattr(self._wrapped, name)
        if not callable(target):
            return target

        def invoke(*args: Any, **kwargs: Any) -> Any:
            original_args = args
            bound = inspect.signature(target).bind(*args, **kwargs)
            bound.apply_defaults()
            args = tuple(bound.arguments[n] for n,p in inspect.signature(target).parameters.items()
                if p.kind in (p.POSITIONAL_ONLY,p.POSITIONAL_OR_KEYWORD) and n in bound.arguments)
            audit = self._audit
            method = self._name + '.' + name
            for value in args:
                if isinstance(value, WorldState):
                    audit.obs_stamp = value.stamp
            if self._name == 'c4' and name == 'update':
                audit.obs_stamp = self._wrapped.stamp
            if self._name == 'c10' and name == 'solve':
                audit.call_id = args[1].call.call_id
                audit.phase = args[2].phase_name
            metadata: dict[str, Any] = {}
            if self._name == 'recipe' and name == 'prepare':
                metadata.update(field=args[0].name, recipe=args[0].recipe)
            if method == 'c8.fast_adjust':metadata['chain'] = 'c3a_fb_fast'
            if method == 'c7.update':metadata['chain'] = 'c3b_fb_full'
            if method == 'c9.step':metadata['chain'] = 'c2_reflex'
            if self._name in ('c6', 'c8') and name in ('prepare', 'readout'):
                contract = args[0]
                fields = args[3] if name == 'prepare' else args[4]
                chain = args[4] if name == 'prepare' else args[5]
                metadata.update(contract_id=contract.contract_id, chain=chain.value,
                    requested_fields=sorted(contract.fields if fields is None else fields))
            tap = None
            passed = original_args
            passed_kwargs = kwargs
            if self._name == 'c10' and name == 'arbitrate':
                tap = PermissionTap(args[3])
                passed = (*args[:3], tap)
                passed_kwargs = {}
            before = getattr(self._wrapped, 'executions', None) if method == 'c10.execute' else None
            sim_data = getattr(getattr(args[0], 'sim', None), 'data', None) if method == 'c10.execute' else None
            time_before = getattr(sim_data, 'time', None)
            with audit.span(method, **metadata) as sid:
                try:
                    result = target(*passed, **passed_kwargs)
                except BaseException:
                    if method == 'c10.execute':
                        audit.physical_step = self._wrapped.executions
                        audit.emit('execution', action_sha256=action_digest(args[1]),
                            step_before=before, step_after=self._wrapped.executions, status='raised',
                            simulation_time_before=time_before, simulation_time_after=getattr(sim_data,'time',None),
                            note='step may have returned before a post-step hook or observation failed')
                    raise
                if method == 'c10.arbitrate':
                    assert tap is not None
                    self._arbitration(sid, args, result, tap.observed)
                elif method == 'c10.solve':
                    audit.last_solve = {'solve_id': sid, 'action_sha256': action_digest(result),
                        'packet_version': args[0].version}
                    audit.emit('action_prepared', **audit.last_solve,
                        parameters=serial(args[0].params), failure_reason=self._wrapped.failure_reason)
                elif method == 'c10.execute':
                    audit.physical_step = self._wrapped.executions
                    audit.emit('execution', **(audit.last_solve or {}),
                        executed_action_sha256=action_digest(args[1]), step_before=before,
                        step_after=self._wrapped.executions, status='returned',
                        simulation_time_before=time_before, simulation_time_after=getattr(sim_data,'time',None))
                elif method == 'c9.step':
                    audit.emit('reflex_decision', override=serial(result), bounds=serial(args[0]),
                        nonzero_gripper_command=bool(result is not None and result.gripper_action not in (None, 0.)))
                elif method == 'c7.update':
                    audit.phase = result.phase_name
                    audit.emit('phase_update', before=serial(args[1]), after=serial(result))
                elif method == 'c11.select':
                    audit.emit('selection', selected_call=serial(result))
                elif method in ('c12.expand','c12.initialize_entry'):
                    if name=='initialize_entry':
                        audit.call_id=result.call.call_id
                        audit.phase=result.phases[0].name if result.phases else None
                    audit.emit('contract_snapshot', stage=name, contract_id=result.contract_id, contract=serial(result))
                elif method == 'c6.prepare':
                    audit.emit('preparation_result', invocation_id=sid, recipe_counter=self._wrapped.recipe_calls,
                        statuses={n: p.status for n, p in result.fields.items()})
                elif method in ('c8.readout', 'c8.fast_adjust'):
                    audit.emit('readout_result', invocation_id=sid, fields=sorted(result),
                        parameters=serial(result))
                return result
        return invoke

    def _arbitration(self, sid: str, args: tuple, result: Any, permissions: list[bool]) -> None:
        packet, proposals, contract, _ = args
        final, rejected = result
        priority = {ChainId.PREP: 0, ChainId.FB_FULL: 1, ChainId.VISION: 2, ChainId.FB_FAST: 3}
        ordinal = 0
        decisions = []
        version = packet.version if packet is not None else 0
        for i, proposal in enumerate(sorted(proposals, key=lambda p: priority[p.chain])):
            for field, parameter in proposal.updates.items():
                permitted = permissions[ordinal]
                ordinal += 1
                spec = contract.fields.get(field)
                reason = None
                if not permitted:
                    if packet is None and proposal.chain == ChainId.PREP and spec is not None and not spec.writable_by:
                        decision = 'bound_default_not_update'
                    else:
                        decision, reason = 'rejected', 'permission_denied'
                elif spec is None:
                    raise AssertionError('returned arbitration allowed a missing field')
                elif (parameter.name != field or parameter.kind != spec.kind or parameter.unit != spec.unit
                        or parameter.frame_entity != spec.frame_entity or parameter.source_chain != proposal.chain):
                    decision, reason = 'rejected', 'metadata_mismatch'
                else:
                    assert spec is not None
                    version += 1
                    decision = 'accepted_intermediate'
                decisions.append({'proposal_id': f'{sid}/proposal_{i}', 'field': field,
                    'chain': proposal.chain.value, 'permission': permitted, 'decision': decision,
                    'reason': reason, 'packet_version_after': version, 'parameter':serial(parameter)})
        assert ordinal == len(permissions), 'arbitration permission trace mismatch'
        assert version == final.version, 'arbitration version trace mismatch'
        assert collections_rejections(decisions) == [(r.name, r.chain.value, r.reason) for r in rejected]
        final_by_field = {r['field']:r for r in decisions if r['decision']=='accepted_intermediate'}
        for row in final_by_field.values():row['decision']='final_survivor'
        for row in decisions:
            if row['decision'] == 'accepted_intermediate':
                later = [d for d in decisions if d['field'] == row['field'] and d['decision'] == 'final_survivor']
                row['superseded_by'] = later[-1]['proposal_id'] if later else None
            self._audit.emit('arbitration', **row)


def collections_rejections(decisions: list[dict]) -> list[tuple]:
    return [(r['field'], r['chain'], r['reason']) for r in decisions if r['decision'] == 'rejected']


def install_audit(components: Any, tracer: Any) -> AuditRecorder:
    audit = getattr(tracer, 'audit', None) or AuditRecorder(tracer)
    components.chain_audit = audit
    components.c6.recipes = AuditProxy(components.c6.recipes, 'recipe', audit)
    for name in ('c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10', 'c11', 'c12'):
        setattr(components, name, AuditProxy(getattr(components, name), name, audit))
    tracer.audit = audit
    return audit
