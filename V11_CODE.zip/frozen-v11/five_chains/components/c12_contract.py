from __future__ import annotations
from dataclasses import replace
from pathlib import Path
from typing import Any, Literal
import yaml
import numpy as np
from five_chains.geometry import inverse
from five_chains.types import (ChainId, Contract, ContractError, ContractConflict, FieldKind,
    FieldSpec, PhaseSpec, SkillCall, TerminationSpec, FeedbackDelta, P7, WorldState)


def bind(value: Any, bindings: dict[str, str]) -> Any:
    if isinstance(value, str):
        try:
            return value.format_map(bindings)
        except KeyError as error:
            raise ContractError("missing binding: " + str(error)) from error
    if isinstance(value, list):
        return [bind(v, bindings) for v in value]
    if isinstance(value, dict):
        return {k: bind(v, bindings) for k, v in value.items()}
    return value


def predicate(name: str | None, world: WorldState, delta: FeedbackDelta) -> bool:
    return name == "always" or bool(world.signals.get("predicates", {}).get(name, False)) or name in delta.events


class ContractDispatcher:
    def __init__(self, templates: str | Path | None = None) -> None:
        self.templates = Path(templates) if templates else Path(__file__).resolve().parents[1] / "skills/templates"

    def expand(self, call: SkillCall) -> Contract:
        try:
            return self._expand(call)
        except ContractError:
            raise
        except (KeyError,TypeError,ValueError,AttributeError,yaml.YAMLError) as error:
            raise ContractError("invalid skill contract: " + str(error)) from error

    def _expand(self, call: SkillCall) -> Contract:
        if (not call.call_id or not isinstance(call.bindings, dict) or not call.skill.replace("_", "").isalnum()
                or not all(isinstance(k, str) and isinstance(v, str) and v for k, v in call.bindings.items())):
            raise ContractError("invalid call identity")
        path = self.templates / (call.skill + ".yaml")
        if not path.is_file():
            raise ContractError("unknown skill: " + call.skill)
        raw = yaml.safe_load(path.read_text())
        if raw["layer"] != call.layer:
            raise ContractError("layer mismatch")
        if not set(raw.get("roles", [])) <= call.bindings.keys():
            raise ContractError("required role is unbound")
        raw = bind(raw, call.bindings)
        fields = {}
        for name, spec in raw.get("fields", {}).items():
            if "kind" not in spec or "unit" not in spec or "writable_by" not in spec:
                raise ContractError("incomplete field specification: " + name)
            interval = tuple(spec["value_range"]) if "value_range" in spec else None
            if interval and (len(interval) != 2 or interval[0] > interval[1]):
                raise ContractError("invalid field range")
            fields[name] = FieldSpec(name, FieldKind(spec["kind"]), spec["unit"], spec.get("frame_entity"),
                frozenset(ChainId(x) for x in spec["writable_by"]), frozenset(spec.get("depends_on", [])),
                spec.get("recipe"), interval, tuple(spec.get("options", [])), spec.get("default"),
                spec.get("required", True), spec.get("prep_frame", spec.get("frame_entity")),
                tuple(spec.get("constraints", [])), spec.get("arguments", {}))
            if not fields[name].writable_by and fields[name].default is None:
                raise ContractError("immutable field requires a physical default: " + name)
        phases = tuple(PhaseSpec(p["name"], p["target_field"], p["enter_when"],
                                frozenset(p["fields"]), p.get("gripper", "keep")) for p in raw.get("phases", []))
        term = TerminationSpec(**raw["termination"])
        if term.timeout_steps <= 0:
            raise ContractError("invalid timeout")
        children = tuple(SkillCall(call.call_id + f"/child{i}", s["layer"], s["skill"],
                                  dict(s.get("bindings", call.bindings))) for i, s in enumerate(raw.get("sub_calls", [])))
        if not phases and not children and call.layer != 2:
            raise ContractError("skill has neither phases nor children")
        followup = ({"skill": call.next_call.skill, "bindings": dict(call.next_call.bindings),
                     "target": call.next_call.bindings.get("target", call.next_call.bindings.get("reference"))}
                    if call.next_call else {})
        future=followup.get('target')
        if isinstance(future,str) and future:
            for name,spec in tuple(fields.items()):
                if spec.recipe in ('pregrasp','grasp_candidates_for_followup'):
                    fields[name]=replace(spec,depends_on=spec.depends_on|frozenset((future+'.pose',future+'.extent')))
        contract = Contract(call.call_id, call, fields, phases, term, followup, children)
        for auxiliary in call.combined_with:
            addition = self.expand(auxiliary)
            for name, spec in addition.fields.items():
                if name in fields:
                    old = fields[name]
                    if old.writable_by and spec.writable_by:
                        # One canonical shared feedback scalar, declared identically
                        # by the primary and object-attitude auxiliary. No new writer.
                        shared = (name == 'stiffness_scale' and old == spec and
                            call.skill in ('place_object_in_container', 'carry_container_to_region', 'local_pose_servo') and
                            auxiliary.skill == 'maintain_container_attitude' and auxiliary.layer == 2)
                        if shared:
                            continue
                        raise ContractConflict("multiple field owners: " + name)
                    if old.writable_by or spec.writable_by:
                        target, constraint = (old, spec) if old.writable_by else (spec, old)
                        cname = name + "__constraint"
                        fields[cname] = replace(constraint, name=cname)
                        fields[name] = replace(target, constraints=target.constraints + (cname,))
                    elif old.default != spec.default:
                        raise ContractConflict("incompatible immutable constraints: " + name)
                else:
                    fields[name] = spec
        for phase in phases:
            if phase.target_field not in fields or not phase.fields <= fields.keys():
                raise ContractError("phase references an absent field")
            if (fields[phase.target_field].kind not in (FieldKind.POSE,FieldKind.POSITION)
                    and not (fields[phase.target_field].kind == FieldKind.SCALAR and fields[phase.target_field].arguments.get("actuator") == "torso")):
                raise ContractError("motion phase target must be a pose or position")
        return contract

    def may_write(self, contract: Contract, field_name: str, chain: ChainId) -> bool:
        return field_name in contract.fields and chain in contract.fields[field_name].writable_by

    def initialize_entry(self, contract: Contract, world: WorldState) -> Contract:
        # A new contract may continue an already held object. Do not reopen the
        # gripper to repeat acquisition. Initialization precedes P7 creation.
        obj = contract.call.bindings.get("object")
        if contract.call.layer == 2 and obj not in world.signals.get("grasp_transforms", {}):
            raise ContractError("standalone object-attitude control requires an established grasp")
        elevated = self._elevated_receptacle(contract, world)
        if elevated is not None:
            return self._preview_dependencies(elevated, world)
        if obj in world.signals.get("grasp_transforms", {}) and contract.call.skill in (
                "place_object_in_container", "carry_container_to_region"):
            index = next(i for i, p in enumerate(contract.phases) if p.name in ("base_to_clearance", "base_to_target", "carry"))
            return replace(contract, phases=contract.phases[index:],
                           followup={**contract.followup, "entry_variant": "already_held"})
        target=contract.call.bindings.get('target')
        if contract.call.skill=='place_object_in_container' and target in world.signals.get('cavity_entities',()):
            # The chosen L3 placement may include a high cavity. Expand its
            # physical transport stages before P7; this is not a new selection.
            schema=self.expand(SkillCall(contract.contract_id+'/cavity_schema',3,'carry_container_to_region',dict(contract.call.bindings)))
            fields=dict(contract.fields)
            for name in ('base_at_clearance','payload_alignment_pose','torso_height','entry_clearance_pose'):fields[name]=schema.fields[name]
            fields['lift_pose']=replace(fields['lift_pose'],arguments={**fields['lift_pose'].arguments,'include_target_height':False})
            assert target is not None
            for name in ('pregrasp_pose','grasp_pose'):
                fields[name]=replace(fields[name],depends_on=fields[name].depends_on|frozenset((target+'.pose',target+'.extent')))
            finish=tuple(phase for phase in contract.phases if phase.name in ('release','retreat'))
            specialized=replace(contract,fields=fields,phases=schema.phases+finish,
                followup={**contract.followup,'entry_variant':'selected_cavity_placement'})
            return self._preview_dependencies(specialized,world)
        return self._preview_dependencies(contract,world)

    def _elevated_receptacle(self, contract: Contract, world: WorldState) -> Contract | None:
        """Allocate height to target support within an already selected placement.

        A movable rim receptacle may itself lie inside an observed cavity. Its
        placement frame remains the receptacle; only transport/access frames use
        the enclosing cavity. No task name, future call or success predicate is
        used to decide this physical decomposition.
        """
        obj = contract.call.bindings.get('object')
        target = contract.call.bindings.get('target')
        if (contract.call.skill != 'place_object_in_container' or obj not in world.entities
                or target not in world.entities or target in world.signals.get('cavity_entities', ())
                or world.signals.get('grasp_modes', {}).get(target) != 'rim'
                or 'lift_pose' not in contract.fields):
            return None
        clearance = float(contract.fields['lift_pose'].arguments['clearance_m'])
        if world.entities[target].pose_world[2, 3] <= world.entities[obj].pose_world[2, 3] + clearance:
            return None
        assert obj is not None and target is not None
        containing = []
        for name in world.signals.get('cavity_entities', ()):
            cavity = world.entities[name]
            local = inverse(cavity.pose_world) @ world.entities[target].pose_world
            if np.all(np.abs(local[:3, 3]) <= cavity.extent):
                containing.append((float(np.prod(cavity.extent)), name))
        access = min(containing)[1] if containing else None
        schema = self.expand(SkillCall(contract.contract_id + '/support_schema', 3,
                                      'carry_container_to_region', dict(contract.call.bindings)))
        fields = dict(contract.fields)
        fields['lift_pose'] = replace(fields['lift_pose'], arguments={
            **fields['lift_pose'].arguments, 'include_target_height': False})
        fields['torso_height'] = schema.fields['torso_height']
        if access is not None:
            for name in ('base_at_clearance', 'payload_alignment_pose', 'entry_clearance_pose'):
                fields[name] = schema.fields[name]
            for name in ('base_at_clearance', 'base_at_target'):
                fields[name] = replace(fields[name], prep_frame=access,
                    depends_on=fields[name].depends_on | frozenset((access + '.pose', access + '.extent')))
            for name in ('payload_alignment_pose', 'entry_clearance_pose'):
                fields[name] = replace(fields[name], arguments={**fields[name].arguments, 'access_frame': access},
                    depends_on=fields[name].depends_on | frozenset((access + '.pose', access + '.extent')))
            phases = schema.phases + tuple(p for p in contract.phases if p.name in ('release', 'retreat'))
        else:
            phases_list = []
            for phase in contract.phases:
                if phase.name == 'carry':
                    phases_list.append(PhaseSpec('raise_torso', 'torso_height', 'base_reached',
                        frozenset(('torso_height', 'speed_limit', 'stiffness_scale')), 'close'))
                    phase = replace(phase, enter_when='torso_reached')
                phases_list.append(phase)
            phases = tuple(phases_list)
        # A source-side clearance motion precedes rotation/translation of the
        # mobile base. The target placement and selected call remain unchanged.
        fields['source_clearance_pose'] = replace(fields['lift_pose'], name='source_clearance_pose',
            recipe='source_transport_clearance', arguments={'held_object_goal': True})
        expanded: list[PhaseSpec] = []
        for phase in phases:
            if phase.name in ('base_to_clearance', 'base_to_target') and expanded and expanded[-1].name == 'clear_source':
                phase = replace(phase, enter_when='reached')
            expanded.append(phase)
            if phase.name == 'lift':
                expanded.append(PhaseSpec('clear_source', 'source_clearance_pose', 'lift_complete',
                    frozenset(('source_clearance_pose', 'speed_limit', 'stiffness_scale')), 'close'))
        phases = tuple(expanded)
        # Already-held re-entry still clears the source before transporting it.
        # No acquisition phase is allowed to reopen an established grasp.
        if obj in world.signals.get('grasp_transforms', {}):
            index = next(i for i, p in enumerate(phases) if p.name == 'lift')
            phases = phases[index:]
        extra = frozenset(key for name in world.signals.get('cavity_obstacles', {}).get(access, ())
                          for key in (name + '.pose', name + '.extent'))
        if extra:
            for name in ('base_at_clearance', 'payload_alignment_pose', 'entry_clearance_pose'):
                fields[name] = replace(fields[name], depends_on=fields[name].depends_on | extra)
        return replace(contract, fields=fields, phases=phases, followup={**contract.followup,
            'entry_variant': 'elevated_receptacle', 'access_frame': access,
            'local_lift_clearance_m': clearance})

    def _preview_dependencies(self, contract: Contract, world: WorldState) -> Contract:
        obj=contract.call.bindings.get('object')
        support=world.signals.get('object_support_frames',{}).get(obj)
        if (obj is not None and support in world.signals.get('enclosed_support_entities',()) and obj not in world.signals.get('grasp_transforms',{})
                and 'lift_pose' in contract.fields and any(p.name=='grasp' for p in contract.phases)):
            fields=dict(contract.fields)
            fields['extract_pose']=replace(fields['lift_pose'],name='extract_pose',frame_entity='world',prep_frame='world',
                recipe='extract_object',depends_on=frozenset((obj+'.pose',obj+'.support')),arguments={'held_object_goal':True,'source_fixture':support})
            access_phases=[]
            for phase in contract.phases:
                if phase.name=='lift':phase=replace(phase,enter_when='reached')
                access_phases.append(phase)
                if phase.name=='grasp':
                    access_phases.append(PhaseSpec('extract','extract_pose','grasp_established',frozenset(('extract_pose','speed_limit','stiffness_scale')),'close'))
            contract=replace(contract,fields=fields,phases=tuple(access_phases))
        if (world.signals.get('loaded_grasp_enabled') and obj not in world.signals.get('grasp_transforms',{})
                and 'grasp_pose' in contract.fields and any(p.name=='grasp' for p in contract.phases)):
            fields=dict(contract.fields)
            fields['preload_pose']=replace(fields['grasp_pose'],name='preload_pose',frame_entity='world',prep_frame='world',
                recipe='grasp_preload',writable_by=frozenset((ChainId.PREP,ChainId.FB_FULL)),depends_on=frozenset(),arguments={})
            phases=tuple(replace(p,target_field='preload_pose',fields=p.fields|frozenset(('preload_pose',))) if p.name=='grasp' else p for p in contract.phases)
            contract=replace(contract,fields=fields,phases=phases)
        target=contract.followup.get('target')
        if contract.call.bindings.get('target') in world.signals.get('cavity_entities',()):
            target=contract.call.bindings['target']
        if not isinstance(target,str):return contract
        keys={key for name in world.signals.get('cavity_obstacles',{}).get(target,()) for key in (name+'.pose',name+'.extent')}
        obj=contract.call.bindings.get('object')
        if obj is not None:keys.add(obj+'.support')
        dependencies=frozenset(keys)
        if not dependencies:return contract
        fields={name:replace(spec,depends_on=spec.depends_on|dependencies) if spec.recipe in ('pregrasp','grasp_candidates_for_followup') or name=='base_at_clearance' else spec for name,spec in contract.fields.items()}
        return replace(contract,fields=fields)

    def check_termination(self, contract: Contract, world: WorldState, delta: FeedbackDelta,
                          p7: P7, steps: int) -> Literal["running", "success", "failure"]:
        term = contract.termination
        if predicate(term.fail_when, world, delta):
            return "failure"
        # A generic reached signal cannot complete an earlier phase.
        if p7.phase_index == len(contract.phases) - 1 and predicate(term.success_when, world, delta):
            return "success"
        if steps >= term.timeout_steps:
            return "failure"
        if p7.steps_in_phase >= term.phase_timeouts.get(p7.phase_name,term.timeout_steps):
            return "failure"
        return "running"
