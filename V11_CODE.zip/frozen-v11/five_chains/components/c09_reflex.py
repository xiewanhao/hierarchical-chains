from __future__ import annotations
import numpy as np
from five_chains.geometry import limited
from five_chains.types import ReflexBounds, ReflexOverride


class ReflexLayer:
    def __init__(self, enabled: bool = False) -> None:
        self.enabled = enabled

    def step(self, bounds: ReflexBounds, obs: dict) -> ReflexOverride | None:
        if not self.enabled:
            return None
        signals = obs.get("state", {}).get("signals", obs)
        if bounds.stop_on_unexpected_contact and signals.get("unexpected_contact", False):
            return ReflexOverride("stop", None, "reflex_contact_stop")
        force = signals.get("force_world")
        if force is not None and bounds.max_force_n is not None:
            force = np.asarray(force, float)
            if force.shape != (3,) or not np.isfinite(force).all():
                raise ValueError("invalid force measurement")
            if np.linalg.norm(force) > bounds.max_force_n:
                t = np.eye(4)
                t[:3, 3] = limited(-force, bounds.max_pos_correction_m)
                return ReflexOverride("bounded_correction", t, "reflex_force_correction")
        native = signals.get('native_motion_diagnostics', {}).get('gripper_reference_feedback')
        band = bounds.gripper_load_band_n
        if band is not None and native is not None and native.get('closing_intent') and native.get('bilateral_native_pads'):
            if native.get('source') != 'native_simulator_contact_solver':
                raise ValueError('unverified gripper feedback source')
            loads=np.asarray(native['pad_normal_loads_n'],float)
            values=np.asarray([native['reference_width_m'],native['measured_width_m'],native['open_step_width_m']],float)
            if loads.shape!=(2,) or not np.isfinite(loads).all() or np.any(loads<0) or not np.isfinite(values).all() or values[2]<=0:
                raise ValueError('invalid native gripper feedback')
            gains=np.asarray(native['actuator_kp_n_m'],float)
            friction=np.asarray(native['joint_frictionloss_n'],float)
            if gains.shape!=(2,) or friction.shape!=(2,) or not np.isfinite(gains).all() or not np.isfinite(friction).all() or np.any(gains<=0) or np.any(friction<0):
                raise ValueError('invalid native gripper actuator parameters')
            # Reference gap guard includes native joint friction loss and the
            # requested lower load under the static position-actuator model.
            # It is not a guarantee of transient contact force.
            preload=max(bounds.gripper_preload_margin_m,float(np.sum((band[0]+friction)/gains)))
            if min(loads)<band[0]:
                command=1.  # Original native close pulse, never additional force capacity.
            elif min(loads)>band[1] and values[0]+values[2]<=values[1]-preload:
                # One native opening pulse still leaves the reference inside
                # the measured jaws by the declared total preload margin.
                command=-1.
            else:
                command=0.  # Official Panda format_action(0) keeps the reference.
            return ReflexOverride('gripper_reference',None,'native_gripper_reference_feedback',command)
        return None
