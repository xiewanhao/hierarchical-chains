from __future__ import annotations
from copy import deepcopy
from typing import Any
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import rigid, inverse, rotation_distance
from five_chains.types import EntityState, WorldState


class GroundTruthBackend:
    def read(self, obs: dict, stamp: int) -> dict:
        result = deepcopy(obs["state"])
        result["geometry_stamp"] = stamp
        return result


class NoisyBackend:
    def __init__(self, config: dict):
        self.config = config
        self.rng = np.random.default_rng(config["seed"])
        self.cached: dict | None = None
        self.sample_stamp = 0

    def read(self, obs: dict, stamp: int) -> dict:
        if self.cached is None or stamp % self.config["update_every"] == 0:
            self.cached = deepcopy(obs["state"])
            self.sample_stamp = stamp
            for entity in self.cached["entities"].values():
                t = rigid(entity["pose_world"])
                t[:3, 3] += self.rng.normal(0, self.config["pos_std"], 3)
                t[:3, :3] = Rotation.from_rotvec(self.rng.normal(0, self.config["rot_std"], 3)).as_matrix() @ t[:3, :3]
                entity["pose_world"] = t
        # Delay/noise only exteroception. Keep proprioception and event signals current.
        result = deepcopy(self.cached)
        result["geometry_stamp"] = self.sample_stamp
        for name in ("eef_pose_world", "base_pose_world", "gripper_width", "signals"):
            result[name] = deepcopy(obs["state"][name])
        return result


class StateGeometry:
    def __init__(self, config: dict):
        self.config = config
        self.backend = GroundTruthBackend() if config["backend"] == "ground_truth" else NoisyBackend(config["noise"])
        self.reported: dict[str, Any] = {}
        self.stamp = 0

    def update(self, obs: dict) -> WorldState:
        state = self.backend.read(obs, self.stamp)
        changed = set()
        entities = {}
        for name, data in state["entities"].items():
            t = rigid(data["pose_world"])
            key = name + ".pose"
            previous = self.reported.get(key)
            if previous is None or (np.linalg.norm(t[:3, 3] - previous[:3, 3]) > self.config["eps_pos"]
                                    or rotation_distance(t[:3, :3], previous[:3, :3]) > self.config["eps_rot"]):
                changed.add(key)
                self.reported[key] = t.copy()
            extent=np.asarray(data.get('extent',[0,0,0]),float)
            extent_key=name+'.extent'
            if extent_key not in self.reported or np.linalg.norm(extent-self.reported[extent_key])>self.config['eps_pos']:
                changed.add(extent_key);self.reported[extent_key]=extent.copy()
            joints = dict(data.get("joints", {}))
            for joint, angle in joints.items():
                key = name + "." + joint
                if key not in self.reported or abs(angle - self.reported[key]) > self.config["eps_joint"]:
                    changed.add(key)
                    self.reported[key] = angle
            entities[name] = EntityState(name, t, extent.copy(), joints,
                                         int(state.get("geometry_stamp", self.stamp)))
        supports=state.get('signals',{}).get('object_support_frames',{})
        previous_supports=self.reported.get('_supports',{})
        for name in set(supports)|set(previous_supports):
            parent=supports.get(name)
            if (parent!=previous_supports.get(name) or (parent is not None and
                    ({parent+'.pose',parent+'.extent'}&changed))):
                changed.add(name+'.support')
        self.reported['_supports']=deepcopy(supports)
        world = WorldState(self.stamp, entities, rigid(state["eef_pose_world"]), rigid(state["base_pose_world"]),
                           float(state["gripper_width"]), frozenset(changed), deepcopy(state.get("signals", {})))
        self.stamp += 1
        return world

    @staticmethod
    def frame(name: str | None, world: WorldState) -> np.ndarray:
        if name in (None, "world"):
            return np.eye(4)
        if name == "eef":
            return world.eef_pose_world.copy()
        if name == "base":
            return world.base_pose_world.copy()
        return world.entities[name].pose_world.copy()  # type: ignore[index]  # None returned in the first branch.

    def to_frame(self, pose_world: np.ndarray, frame_entity: str | None, world: WorldState) -> np.ndarray:
        return inverse(self.frame(frame_entity, world)) @ rigid(pose_world)

    def from_frame(self, pose_local: np.ndarray, frame_entity: str | None, world: WorldState) -> np.ndarray:
        return self.frame(frame_entity, world) @ rigid(pose_local)
