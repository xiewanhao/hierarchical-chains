from __future__ import annotations
import numpy as np
from five_chains.geometry import rigid, inverse
from five_chains.types import (ChainId, Contract, FieldKind, P6, P7, WorldState,
    PhysParam, ReadoutError, ParamPacket, FeedbackDelta, ReflexBounds)
from five_chains.components.c04_state import StateGeometry
from five_chains.preparation import decode_preparation


class ParamReadout:
    def __init__(self, geometry: StateGeometry, config: dict) -> None:
        self.geometry = geometry
        self.config = config

    def apply_constraints(self, contract: Contract, name: str, value: np.ndarray) -> np.ndarray:
        spec = contract.fields[name]
        result = np.asarray(value).copy()
        for constraint_name in spec.constraints:
            constraint = contract.fields[constraint_name]
            if constraint.writable_by or constraint.unit != spec.unit:
                raise ReadoutError("constraint must be immutable and use the target's unit")
            if spec.kind in (FieldKind.SCALAR, FieldKind.INTERVAL) and constraint.kind == FieldKind.INTERVAL:
                bounds = np.asarray(constraint.default, float)
                if bounds.shape != (2,) or bounds[0] > bounds[1]:
                    raise ReadoutError("invalid physical constraint interval")
                result = np.clip(result, bounds[0], bounds[1])
            elif spec.kind == FieldKind.SCALAR and constraint.kind == FieldKind.SCALAR:
                relation = constraint.arguments.get("relation")
                if relation == "upper_bound":
                    result = np.minimum(result, float(constraint.default))
                elif relation == "lower_bound":
                    result = np.maximum(result, float(constraint.default))
                elif relation == "equals":
                    result = np.asarray(constraint.default)
                else:
                    raise ReadoutError("scalar constraint needs an explicit bound relation")
            else:
                raise ReadoutError("unsupported same-field constraint; specify a typed solver")
        return np.asarray(result)

    def readout(self, contract: Contract, p6: P6, p7: P7, world: WorldState,
                fields: frozenset[str] | None, chain: ChainId) -> dict[str, PhysParam]:
        if contract.contract_id != p6.contract_id or contract.contract_id != p7.contract_id:
            raise ReadoutError("contract/state identity mismatch")
        result = {}
        for name in contract.fields if fields is None else fields:
            spec = contract.fields[name]
            prep = p6.fields.get(name)
            if prep is None or prep.status in ("missing", "stale"):
                if chain == ChainId.PREP and spec.required:
                    raise ReadoutError("missing required preparation: " + name)
                continue
            reference=prep.provenance.get('translation_reference_m',self.config['preparation']['translation_reference_m'])
            value = np.asarray(decode_preparation(spec,prep.value,reference))
            # A bound P6 slot carries no physical value; Contract owns the constant.
            if prep.status == "bound":
                value = np.asarray(spec.default).copy()
            elif spec.kind in (FieldKind.POSE, FieldKind.POSITION):
                local = rigid(value) if spec.kind == FieldKind.POSE else np.eye(4)
                if spec.kind == FieldKind.POSITION:
                    local[:3, 3] = value
                target = self.geometry.from_frame(local, spec.prep_frame, world)
                entity = contract.call.bindings.get("object")
                if "tilt_limit" in contract.fields:
                    entity = contract.fields["tilt_limit"].arguments.get("entity",entity)
                if spec.arguments.get("held_object_goal") or (spec.arguments.get("held_object_if_bound") and entity is not None):
                    relation = world.signals.get("grasp_transforms", {}).get(entity)
                    if relation is not None:
                        target = target @ inverse(relation)
                    elif "grasp_pose" in p6.fields and p6.fields["grasp_pose"].status in ("ready", "bound"):
                        # Predict using the candidate grasp; replace with measured T_EB at grasp event.
                        grasp = p6.fields["grasp_pose"]
                        grasp_spec=contract.fields['grasp_pose']
                        grasp_reference=grasp.provenance.get('translation_reference_m',self.config['preparation']['translation_reference_m'])
                        contact=grasp_spec.default if grasp.status=='bound' else decode_preparation(grasp_spec,grasp.value,grasp_reference)
                        target = target @ rigid(contact)
                    else:
                        if chain == ChainId.PREP and spec.required:
                            raise ReadoutError("held-object target has no established or predicted grasp")
                        continue
                target = self.geometry.to_frame(target, spec.frame_entity, world)
                value = target if spec.kind == FieldKind.POSE else target[:3, 3]
            elif spec.kind in (FieldKind.SCALAR, FieldKind.INTERVAL):
                if spec.value_range is None or np.any(value < 0) or np.any(value > 1):
                    raise ReadoutError("normalized scalar requires [0,1] and physical range")
                lo, hi = spec.value_range
                value = lo + value.astype(float) * (hi - lo)
            elif spec.kind == FieldKind.DISCRETE:
                if value.shape != () or not np.issubdtype(value.dtype, np.integer) or not 0 <= int(value) < len(spec.options):
                    raise ReadoutError("invalid discrete candidate")
                value = np.asarray(spec.options[int(value)])
            value = self.apply_constraints(contract,name,np.asarray(value))
            if spec.kind == FieldKind.DISCRETE:
                if value.shape != () or str(value.item()) not in spec.options:
                    raise ReadoutError("discrete value is outside the declared options")
            elif not np.issubdtype(value.dtype, np.number) or not np.isrealobj(value):
                raise ReadoutError("physical parameter must contain real numbers")
            if np.issubdtype(value.dtype, np.number) and not np.isfinite(value).all():
                raise ReadoutError("nonfinite physical parameter")
            if spec.kind == FieldKind.POSE:
                value = rigid(value)
            if spec.kind == FieldKind.POSITION and value.shape != (3,):
                raise ReadoutError("position must have 3 coordinates")
            if spec.kind == FieldKind.SCALAR and value.shape != ():
                raise ReadoutError("scalar must be scalar")
            if spec.kind == FieldKind.INTERVAL and (value.shape != (2,) or value[0] > value[1]):
                raise ReadoutError("invalid interval")
            result[name] = PhysParam(name, spec.kind, value.copy(), spec.unit, spec.frame_entity, chain, world.stamp)
        return result

    def fast_adjust(self, contract: Contract, packet: ParamPacket, delta: FeedbackDelta) -> dict[str, PhysParam]:
        result: dict[str, PhysParam] = {}
        excess = max((abs(delta.continuous.get(k, 0)) - th for k, th in self.config["fb_fast"]["thresholds"].items()), default=0)
        if excess <= 0:
            return result
        for name, spec in contract.fields.items():
            if spec.kind != FieldKind.SCALAR or ChainId.FB_FAST not in spec.writable_by or name not in packet.params:
                continue
            if spec.value_range is None:
                raise ReadoutError("fast feedback requires physical bounds")
            gain = self.config["fb_fast"]["gain"].get(name, 0)
            value = np.clip(packet.params[name].value + gain * excess, *spec.value_range)
            value = self.apply_constraints(contract,name,np.asarray(value))
            result[name] = PhysParam(name, spec.kind, np.asarray(value), spec.unit, spec.frame_entity, ChainId.FB_FAST, delta.stamp)
        return result

    def bounds(self, contract: Contract, p7: P7, p6: P6 | None = None) -> ReflexBounds:
        settings=dict(self.config['reflex']['bounds'])
        if settings.get('gripper_load_band_n') is not None:
            prepared=p6.fields.get('grasp_pose') if p6 is not None else None
            info=prepared.provenance.get('gravity_support') if prepared is not None and prepared.status=='ready' else None
            # Apply this experimental feedback only when C6 has a finite
            # candidate-specific load statistic; unsupported grasps keep native
            # binary closure. No assumed low-force policy for rim/handle grasps.
            settings['gripper_load_band_n']=None
            if info is not None and info.get('reduced_model_feasible'):
                load=float(info['minimum_normal_per_pad_n'])
                if not np.isfinite(load) or load<=0:raise ReadoutError('invalid C6 gravity load statistic')
                reserve=self.config['reflex']['gripper_force_reserve']
                low,high=self.config['reflex']['bounds']['gripper_load_band_n']
                band=(max(low,reserve[0]*load),max(high,reserve[1]*load))
                if band[1]<=20.:settings['gripper_load_band_n']=band
        return ReflexBounds(**settings)
