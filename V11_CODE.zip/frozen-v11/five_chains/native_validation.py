"""Explicit interventions for finite native chain experiments, never task-rate data.

Only the registered free-object translation writes plant state. All ordinary
actions still execute through C10. Private previews do not integrate time.
"""
from __future__ import annotations
from copy import deepcopy
from dataclasses import replace, asdict
from hashlib import sha256
from pathlib import Path
from typing import Any
import json
import time
import numpy as np
from five_chains.types import SkillCall, ChainId
from five_chains.components.c11_selector import ScriptedSelector
from five_chains.envs.reference_bridge import Scope, digest
from five_chains.envs.native_reference_preview import NativeReferencePreview
from five_chains.trace import serial
from five_chains.chain_audit import action_digest

PROBES = {'preparation','fast','reflex_stop','fast_stop','reflex_gripper','relation','geometry',
          'reselection','joint','demand_geometry','demand_fast','demand_tilt'}
SETTINGS = {'normal','off','full_recompute','freeze_after_prep'}


def control_configuration(root: Path, case: dict) -> dict:
    from five_chains.config import load_config
    profile = case.get('control_profile','r49_fine')
    if profile == 'r46_known_steam':
        if case['task'] != 'SteamInMicrowave':raise ValueError('known R46 profile is Steam-only')
        return load_config(root/'configs/steam_chain_validation_r46.yaml')
    if profile != 'r49_fine':raise ValueError('unknown control profile')
    return load_config(root/'configs/steam_graspgen_fine.yaml')


def configure(cfg: dict, case: dict) -> None:
    if case['probe'] not in PROBES or case['setting'] not in SETTINGS:
        raise ValueError('unknown native probe/setting')
    if cfg['control']['max_ticks'] != 6000:
        raise ValueError('native validation retains the original horizon')
    if cfg['control']['close_reference_bridge_capture'] or cfg['control']['close_reference_native_preview_shadow']:
        raise ValueError('R50 reference route must remain passive/off')
    cfg.setdefault('chain_validation', {})['audit'] = True
    probe, setting = case['probe'], case['setting']
    if 'relation_control_scope' in case and (probe!='relation' or
            case['relation_control_scope'] not in ('phase_only','whole_chain')):
        raise ValueError('relation control scope must be explicitly declared for relation only')
    if setting == 'full_recompute':
        if probe == 'preparation' or case.get('full_recompute_mode') not in ('literal_flag','shadow_cost'):
            raise ValueError('full control requires an explicit applicable computation mode')
        cfg['chain_validation']['full_recompute_mode'] = case['full_recompute_mode']
        if cfg['ablation']['vision_full_recompute']:
            raise ValueError('registered full control keeps warmup unchanged')
    if 'load_phase' in case and (probe != 'reflex_gripper' or
            case.get('load_injection') != 'qualified_observation' or case['load_phase'] != 'raise_to_entry'):
        raise ValueError('load stage must be the registered raise_to_entry observation case')
    if 'relation_phase' in case and (probe != 'relation' or case.get('task') != 'SteamInMicrowave'
            or case['relation_phase'] != 'carry' or case.get('relation_object') != 'bowl'):
        raise ValueError('relation phase override must be the registered actual held-bowl carry case')
    if setting == 'freeze_after_prep':
        if probe != 'preparation':
            raise ValueError('freeze control is preparation-only')
        cfg['ablation']['freeze_after_prep'] = True
    if setting == 'off':
        if probe == 'preparation':
            raise ValueError('preparation cannot be disabled')
        chains = {'fast':['c3a_fb_fast'],'reflex_stop':['c2_reflex'],
                  'fast_stop':['c2_reflex','c3a_fb_fast'], 'reflex_gripper':['c2_reflex'],
                  'geometry':['c4_vision'],'relation':[], 'reselection':[]}
        if probe not in chains:
            raise ValueError('off control not declared for this probe')
        if probe=='reflex_gripper' and case.get('load_injection')=='qualified_observation':
            cfg['chain_validation']['disable_c2_from_registered_input'] = True
        elif probe == 'geometry':
            cfg['chain_validation']['disable_c4_from_registered_input'] = True
        else:
            cfg['ablation']['disable_chains'] += chains[probe]
        if probe == 'relation':
            if case.get('relation_control_scope','phase_only')=='whole_chain':
                cfg['chain_validation']['disable_full_relation_from_registered_input'] = True
            else:
                cfg['chain_validation']['phase_only_from_registered_input'] = True
        if probe == 'reselection':
            cfg['replan']['max_reselections'] = 0
    if case.get('joint_scope') is not None:
        if (probe!='joint' or setting!='normal' or case['joint_scope']!='user_skip_button_lowload_v1'
                or case.get('joint_relation_object')!='bowl' or case.get('joint_target')!='microwave_interior'
                or case.get('joint_geometry_mode')!='one_frame_target_observation'
                or case.get('skipped_requirements')!=['joint_button_lowload_same_tick']
                or not case.get('human_authorization_reference')):
            raise ValueError('Unknown or incomplete explicitly amended joint protocol')
    if probe.startswith('demand_') and case.get('demand_layer') not in (1,2,3):
        raise ValueError('demand probe needs an explicit layer')
    if probe.startswith('demand_'):
        if (setting != 'normal' or case.get('target') != 'bowl' or
                case.get('input_mode') != 'identical_raw_observation' or
                case.get('post_window') != 2 or case.get('acquire_object') not in ('bowl','vegetable')):
            raise ValueError('demand needs registered identical raw inputs and a two-execution live window')
        if case['demand_layer'] == 2 and case['acquire_object'] != 'bowl':
            raise ValueError('native L2 demand requires an actually acquired container')
        if case['demand_layer'] == 1 and case.get('reference') not in ('bowl','microwave_interior'):
            raise ValueError('native L1 demand needs an explicit real reference')
        if case.get('handoff_phase') not in ('lift','carry_reached'):
            raise ValueError('demand handoff timing must be explicitly registered')


class DemandSelector:
    """Original model acquires; explicitly scripted call tests an already held state."""
    def __init__(self, original: Any) -> None:
        self.original = original
        self.pending: ScriptedSelector | None = None

    def select(self, *args: Any) -> SkillCall:
        if self.pending is not None:
            selected = self.pending.select(*args)
            self.pending = None
            return selected
        return self.original.select(*args)


def physical_signature(env: Any) -> dict:
    import mujoco
    model, data = env.sim.model._model, env.sim.data._data
    state = np.empty(mujoco.mj_stateSize(model, mujoco.mjtState.mjSTATE_INTEGRATION))
    mujoco.mj_getState(model, data, state, mujoco.mjtState.mjSTATE_INTEGRATION)
    return {'integration_sha256':sha256(state.tobytes()).hexdigest(),
            'time':float(env.sim.data.time),
            'rng':json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str)}


class PreparationSnapshotAdapter:
    """C6 sees measured poses without calling active controller.update().

    Native mesh/contact queries already copy the model. Its optional IK solver
    gets its own model/data as well. No forwarding of arbitrary live methods.
    """
    def __init__(self, adapter: Any, world: Any) -> None:
        from copy import copy
        self.env = adapter.env
        self.robot = adapter.robot
        self.arm = adapter.arm
        self.gripper_collision_ids = np.asarray(adapter.gripper_collision_ids).copy()
        self.eef = world.eef_pose_world.copy()
        self.posture_solver = None
        source = adapter.posture_solver
        if source is not None:
            from five_chains.envs.pose_ik import RobotPoseIK
            self.posture_solver = RobotPoseIK(copy(source.model),source.site,source.joints.copy(),
                source.qpos.copy(),source.rest.copy(),deepcopy(source.config))

    def current_pose(self) -> np.ndarray:
        return self.eef.copy()


class NativeInterventions:
    stop_reason = 'validation_complete'

    def __init__(self, case: dict, cfg: dict, env: Any, adapter: Any, tracer: Any,
                 output: Path, selector: DemandSelector) -> None:
        self.case, self.cfg, self.env = case, cfg, env
        self.adapter, self.tracer, self.output, self.selector = adapter, tracer, output, selector
        self.provider = NativeReferencePreview(adapter)
        self.events: list[dict] = []
        self.checked_calls: set[str] = set()
        self.preview_ticks: set[int] = set()
        self.executions_at_last_event: int | None = None
        self.injected = False
        self.handoff = False
        self.demand_call_id: str | None = None
        self.reselection_from: dict | None = None
        self.completed = False
        self.last_ctx: Any = None
        self.last_executed_action: Any = None
        self.disabled_chains: set[str] = set()
        self.relation_response_checked = False
        self.full_activation: dict | None = None
        self.full_recipe_tick_start = 0
        self.joint_restored = False
        self.post_window = int(case.get('post_window',24))
        if not 2 <= self.post_window <= 120:
            raise ValueError('finite diagnostic window must be 2..120 actual steps')

    def emit(self, tick: int, ctx: Any, name: str, target: str, magnitude: Any,
             mode: str, before: Any, after: Any) -> None:
        record = {'kind':'perturbation','event_id':f'perturb_{len(self.events)+1}',
            'perturbation_id':f'perturb_{len(self.events)+1}',
            'tick':tick,'loop_tick':tick,'physical_step_index':self.tracer.rows,
            'name':name,'target':target,'magnitude':magnitude,'mode':mode,
            'before':serial(before),'after':serial(after),
            'call_id':ctx.contract.call.call_id,'phase':ctx.p7.phase_name,
            'gripper_load_band_n_before':ctx.packet.bounds.gripper_load_band_n,
            'native_success_claim':False}
        self.events.append(record)
        self.tracer.write(record)
        if hasattr(self.tracer, 'start_recording'):
            self.tracer.start_recording()
        if getattr(self.tracer,'audit',None):
            self.tracer.audit.cause_ids.append(record['event_id'])
        self.preview_ticks.add(tick)
        self.executions_at_last_event = self.tracer.rows

    def translate(self, tick: int, obs: dict, ctx: Any, name: str, entity: str, delta: list) -> dict:
        item = self.env.objects.get(entity)
        if item is None or len(item.joints) != 1:
            raise ValueError('registered physical translation requires one real movable object')
        address = self.env.sim.model.get_joint_qpos_addr(item.joints[0])
        if not isinstance(address, tuple) or address[1]-address[0] != 7:
            raise ValueError('fixture/robot/fixed-joint displacement is prohibited')
        before = np.asarray(self.env.sim.data.qpos).copy()
        qvel = np.asarray(self.env.sim.data.qvel).copy()
        old_time = float(self.env.sim.data.time)
        np.savez_compressed(self.output/f'plant_{name}_before.npz',qpos=before,qvel=qvel)
        self.env.sim.data.qpos[address[0]:address[0]+3] += np.asarray(delta)
        self.env.sim.forward()
        after = np.asarray(self.env.sim.data.qpos).copy()
        mask = np.ones(len(before),dtype=bool);mask[address[0]:address[0]+3] = False
        if (not np.array_equal(before[mask],after[mask]) or
            not np.array_equal(qvel,np.asarray(self.env.sim.data.qvel)) or old_time != float(self.env.sim.data.time)):
            raise RuntimeError('physical intervention changed unregistered state/time')
        np.savez_compressed(self.output/f'plant_{name}_after.npz',qpos=after,qvel=qvel)
        self.emit(tick,ctx,name,entity+'.pose',delta,'physical_free_object_translation',before,after)
        return self.adapter.observe(self.env._get_observations(force_update=True))

    def control_boundary(self, tick: int, ctx: Any) -> None:
        """Apply the registered ablation only after the physical input exists."""
        if self.case['setting'] != 'off':
            return
        settings = self.cfg['chain_validation']
        phase_enabled=True
        scope='registered_existing_control'
        if self.case['probe']=='relation' and settings.get('disable_full_relation_from_registered_input'):
            chain='c3b_fb_full'
            self.disabled_chains.add(chain)
            if chain not in self.cfg['ablation']['disable_chains']:
                self.cfg['ablation']['disable_chains'].append(chain)
            settings['phase_only_no_parameter_update']=False
            phase_enabled=False;scope='whole_chain'
        elif self.case['probe'] == 'relation' and settings.get('phase_only_from_registered_input'):
            settings['phase_only_no_parameter_update'] = True
            chain = 'c3b_fb_full'
            scope='phase_only'
        elif self.case['probe'] == 'geometry' and settings.get('disable_c4_from_registered_input'):
            self.disabled_chains.add('c4_vision')
            chain = 'c4_vision'
        else:
            return
        record={'kind':'native_control_boundary','tick':tick,
            'call_id':ctx.contract.call.call_id,'chain':chain,'disabled_from_registered_input':True,
            'warmup_enabled':True,'phase_progression_enabled':phase_enabled}
        if scope=='whole_chain':
            record.update(control_scope=scope,active_disabled_chains=sorted(self.disabled_chains),
                phase_only_no_parameter_update=False)
        self.tracer.write(record)

    def activate_full(self, tick: int, ctx: Any, C: Any) -> None:
        if (self.case['setting'] != 'full_recompute' or
                self.case.get('full_recompute_mode') != 'literal_flag' or self.full_activation is not None):
            return
        self.cfg['ablation']['vision_full_recompute'] = True
        self.full_activation = {'tick':tick,'call_id':ctx.contract.call.call_id,
            'recipe_calls_before':int(C.c6.recipe_calls),'contract_fields':sorted(ctx.contract.fields)}
        self.tracer.write({'kind':'native_full_flag_activation',**self.full_activation,
            'flag':'ablation.vision_full_recompute','value':True,'warmup_value':False})

    def target_before_input(self, tick: int, ctx: Any, C: Any) -> None:
        field = ctx.contract.phases[ctx.p7.phase_index].target_field
        self.tracer.write({'kind':'native_target_before_input','tick':tick,
            'call_id':ctx.contract.call.call_id,'target_field':field,
            'parameter':ctx.packet.params[field],'previous_last_target':C.c10.last_target})

    def demand_observation(self, tick: int, obs: dict, ctx: Any, C: Any) -> dict:
        """Identical measured-input fault; owning contracts choose the projection."""
        if self.injected or ctx.contract.call.call_id != self.demand_call_id:
            return obs
        layer = self.case['demand_layer']
        phase = {3:'carry',2:'hold_attitude',1:'track'}[layer]
        signals = obs['state']['signals']
        if (ctx.p7.phase_name != phase or ctx.p7.steps_in_phase < 1 or
                ctx.executed_actuator != 'arm' or
                self.case['acquire_object'] not in signals.get('grasp_transforms',{})):
            return obs
        # A tilt-only test must not quietly attribute a real tracking response
        # to the new tilt input. Wait at a legal live decision; never erase it.
        if self.case['probe'] != 'demand_fast' and any(
                abs(signals['continuous'].get(k,0.)) > threshold
                for k,threshold in self.cfg['fb_fast']['thresholds'].items()):
            return obs
        before = physical_signature(self.env)
        obs = deepcopy(obs); signals = obs['state']['signals']
        self.target_before_input(tick,ctx,C)
        probe, entity = self.case['probe'], self.case['target']
        raw_input: dict[str, Any]
        if probe == 'demand_geometry':
            raw_input = {'schema':'demand_raw_input/v1','kind':'entity_translation_observation',
                'entity':entity,'delta_world_m':[.05,0.,0.]}
            old = np.asarray(obs['state']['entities'][entity]['pose_world']).copy()
            observed = old.copy();observed[:3,3] += np.asarray(raw_input['delta_world_m'])
            obs['state']['entities'][entity]['pose_world'] = observed
            self.emit(tick,ctx,'target_5cm',entity+'.pose',raw_input['delta_world_m'],
                'observation_entity_translation_no_physics',old,observed)
        elif probe == 'demand_fast':
            raw_input = {'schema':'demand_raw_input/v1','kind':'tracking_observation',
                'signal':'eef_track_err','value_m':.03}
            old = signals['continuous'].get('eef_track_err',0.)
            signals['continuous']['eef_track_err'] = raw_input['value_m']
            self.emit(tick,ctx,'tracking_3cm','signals.continuous.eef_track_err',.03,
                'observation_only',old,.03)
        elif probe == 'demand_tilt':
            from five_chains.observation_projection import tilt_deviation
            raw_input = {'schema':'demand_raw_input/v1','kind':'object_up_vector_observation',
                'entity':entity,'tilt_rad':.25,
                'up_world':[float(np.sin(.25)),0.,float(np.cos(.25))]}
            old = np.asarray(obs['state']['entities'][entity]['pose_world'])[:3,2].copy()
            signals['attitude_observation_input'] = deepcopy(raw_input)
            signals['continuous']['tilt_dev'] = tilt_deviation(ctx.contract,
                {entity:np.asarray(raw_input['up_world'])})
            self.emit(tick,ctx,'object_up_vector_250mrad',entity+'.observed_up_world',
                raw_input['up_world'],'raw_attitude_observation_only',old,raw_input['up_world'])
        else:
            raise ValueError('unknown demand input')
        if before != physical_signature(self.env):
            raise RuntimeError('registered demand observation changed native input/RNG')
        self.tracer.write({'kind':'native_demand_raw_input','tick':tick,
            'call_id':ctx.contract.call.call_id,'layer':layer,'input_spec':raw_input,
            'input_sha256':digest(raw_input),'active_state_preserved':True,
            'projected_continuous':deepcopy(signals['continuous']),
            'contract_declares_tilt_limit':'tilt_limit' in ctx.contract.fields,
            'current_measured_grasp':signals['grasp_transforms'][self.case['acquire_object']]})
        self.injected = True
        return obs

    def registered_joint_carry_inputs(self, tick: int, obs: dict, ctx: Any, C: Any) -> dict:
        signals=obs['state']['signals'];identity=ctx.contract.call.bindings.get('object')
        eligible=(identity==self.case['joint_relation_object'] and identity in signals.get('grasp_transforms',{})
            and ctx.executed_actuator=='arm' and ctx.p7.phase_name=='carry' and ctx.p7.steps_in_phase>=3
            and ctx.contract.phases[ctx.p7.phase_index].target_field=='place_pose'
            and ctx.contract.call.bindings.get('target')==self.case['joint_target'])
        if not eligible:return obs
        relations=[e for e in self.events if e['name']=='grasp_relation_5mm']
        if not relations:
            self.tracer.write({'kind':'native_joint_scope_amendment','tick':tick,
                'joint_scope':self.case['joint_scope'],'skipped_requirements':self.case['skipped_requirements'],
                'human_authorization_reference':self.case['human_authorization_reference'],
                'skipped_is_not_passed':True,'measured_grasp_object':identity})
            axis=np.asarray(obs['state']['eef_pose_world'])[:3,2]
            return self.translate(tick,obs,ctx,'grasp_relation_5mm',identity,(.005*axis).tolist())
        if (not self.relation_response_checked or
                C.c10.executions-relations[0]['physical_step_index']<3):return obs
        entity=self.case['joint_target']
        old=np.asarray(obs['state']['entities'][entity]['pose_world']).copy()
        if old.shape!=(4,4) or not np.isfinite(old).all():raise ValueError('Invalid current joint target observation')
        before=physical_signature(self.env);self.target_before_input(tick,ctx,C)
        result=deepcopy(obs);observed=old.copy();observed[:3,3]+=np.asarray([.05,0.,0.])
        result['state']['entities'][entity]['pose_world']=observed
        self.emit(tick,ctx,'target_5cm',entity+'.pose',[.05,0.,0.],
            'one_frame_target_observation_no_physics',old,observed)
        if before!=physical_signature(self.env):raise RuntimeError('Joint observation input changed physical state')
        self.tracer.write({'kind':'native_joint_target_observation','tick':tick,'call_id':ctx.contract.call.call_id,
            'target':entity,'active_state_preserved':True,'physical_signature':before,
            'one_frame_overlay':True,'future_observations_unmodified':True})
        return result

    def __call__(self, tick: int, obs: dict, ctx: Any, C: Any) -> dict:
        self.last_ctx = ctx
        if ctx.contract is None or ctx.p7 is None or ctx.packet is None:
            return obs
        probe = self.case['probe']; phase = ctx.p7.phase_name
        if self.case.get('full_recompute_mode')=='literal_flag':
            self.full_recipe_tick_start = int(C.c6.recipe_calls)
        signals = obs['state']['signals']
        held = ctx.contract.call.bindings.get('object') in signals.get('grasp_transforms',{})
        demand = probe.startswith('demand_')
        if demand:
            return self.demand_observation(tick,obs,ctx,C) if self.handoff else obs
        if self.injected and probe == 'joint' and self.reselection_from is None:
            if not self.joint_restored:
                return obs
            self.reselection_from = {'call_id':ctx.contract.call.call_id,'selections':ctx.selector_calls,
                'time':float(self.env.sim.data.time),'steps':C.c10.executions,
                'skill':ctx.contract.call.skill,'bindings':dict(ctx.contract.call.bindings)}
            old = ctx.contract.termination.timeout_steps
            ctx.contract = replace(ctx.contract,termination=replace(ctx.contract.termination,timeout_steps=max(1,ctx.steps)))
            self.emit(tick,ctx,'contract_timeout','active_contract.timeout_steps',ctx.steps,'contract_only',old,ctx.contract.termination.timeout_steps)
            return obs
        if self.injected:
            return obs
        arm = ctx.executed_actuator == 'arm'
        eligible = arm and ctx.p7.steps_in_phase >= 5 and phase not in ('grasp','release','settle_closed')
        if probe == 'reselection' and eligible:
            # Record a real pre-timeout clip. There must be no extra physical
            # frames after the reselection event itself.
            if hasattr(self.tracer,'start_recording'):self.tracer.start_recording()
            eligible = ctx.p7.steps_in_phase >= 29
        if probe in ('relation','geometry','joint'):
            eligible = held and phase in ('carry','align_payload_outside','raise_to_entry','track','hold_attitude') and ctx.p7.steps_in_phase >= 3
        if probe=='relation' and 'relation_phase' in self.case:
            eligible = (eligible and arm and phase==self.case['relation_phase']
                and ctx.contract.call.bindings.get('object')==self.case['relation_object'])
        if probe=='geometry':
            phase_spec = ctx.contract.phases[ctx.p7.phase_index]
            eligible = (eligible and phase == 'carry' and phase_spec.target_field == 'place_pose'
                        and ctx.contract.call.bindings.get('target') in self.env.objects)
        if (probe=='joint' and self.case.get('joint_scope')=='user_skip_button_lowload_v1'
                and not any(e['name']=='target_5cm' for e in self.events)):
            return self.registered_joint_carry_inputs(tick,obs,ctx,C)
        if probe == 'joint':
            # Relation and target events occur before button approach.
            if not any(e['name']=='grasp_relation_5mm' for e in self.events):
                if not eligible or phase != 'carry':return obs
                axis = np.asarray(obs['state']['eef_pose_world'])[:3,2]
                obs = self.translate(tick,obs,ctx,'grasp_relation_5mm',ctx.contract.call.bindings['object'],(.005*axis).tolist())
                return obs
            if not any(e['name']=='target_5cm' for e in self.events):
                if (not eligible or phase != 'carry' or
                        ctx.contract.phases[ctx.p7.phase_index].target_field != 'place_pose'):return obs
                target = ctx.contract.call.bindings.get('target')
                if target not in self.env.objects:
                    return obs
                self.target_before_input(tick,ctx,C)
                obs = self.translate(tick,obs,ctx,'target_5cm',target,[.05,0.,0.])
                return obs
            eligible = arm and ctx.contract.call.skill == 'approach_control' and ctx.p7.steps_in_phase >= 5
        if probe == 'reflex_gripper':
            native = signals.get('native_motion_diagnostics',{}).get('gripper_reference_feedback',{})
            eligible = (held and bool(native.get('closing_intent')) and bool(native.get('bilateral_native_pads'))
                        and ctx.packet.bounds.gripper_load_band_n is not None)
            if 'load_phase' in self.case:
                eligible = eligible and phase == self.case['load_phase'] and ctx.p7.steps_in_phase >= 3
            if case_mode := self.case.get('load_injection'):
                if case_mode not in ('physical_microshift','qualified_observation'):raise ValueError('unknown physical load injection')
                eligible = eligible and tuple(ctx.packet.bounds.gripper_load_band_n or ()) == (1.,3.)
                if eligible and case_mode=='qualified_observation':
                    loads=np.asarray(native['pad_normal_loads_n'],float)
                    gains=np.asarray(native['actuator_kp_n_m'],float)
                    friction=np.asarray(native['joint_frictionloss_n'],float)
                    preload=max(ctx.packet.bounds.gripper_preload_margin_m,float(np.sum((1.+friction)/gains)))
                    eligible = bool(loads.shape==(2,) and np.isfinite(loads).all() and np.all((loads>=1.)&(loads<=3.)) and
                        native['measured_width_m']-native['reference_width_m']>=preload and
                        native['reference_width_m']>=native['open_step_width_m'])
        if not eligible:
            return obs
        obs = deepcopy(obs); signals = obs['state']['signals']
        if probe in ('fast','fast_stop','joint'):
            old = signals['continuous'].get('eef_track_err',0.)
            signals['continuous']['eef_track_err'] = .03
            self.emit(tick,ctx,'tracking_3cm','signals.continuous.eef_track_err',.03,'observation_only',old,.03)
        if probe in ('reflex_stop','fast_stop','joint'):
            old = signals.get('unexpected_contact',False);signals['unexpected_contact'] = True
            self.emit(tick,ctx,'unexpected_contact','signals.unexpected_contact',True,'observation_only',old,True)
        if probe == 'reflex_gripper':
            if self.case.get('load_injection') == 'physical_microshift':
                local = np.asarray(signals['gripper_opening_axis_eef'],float)
                axis = np.asarray(obs['state']['eef_pose_world'])[:3,:3] @ local
                length = float(np.linalg.norm(axis))
                if not np.isfinite(length) or length < 1e-8:raise ValueError('invalid measured gripper opening axis')
                delta = .0005*axis/length
                raw = deepcopy(signals['native_motion_diagnostics']['gripper_reference_feedback'])
                obs = self.translate(tick,obs,ctx,'load_micro_translation_0p5mm',ctx.contract.call.bindings['object'],delta.tolist())
                self.tracer.write({'kind':'native_load_perturbation_measurement','tick':tick,
                    'before':raw,'after':obs['state']['signals']['native_motion_diagnostics'].get('gripper_reference_feedback'),
                    'force_signal_overridden':False,'original_grip_band_n':ctx.packet.bounds.gripper_load_band_n})
            else:
                if self.case['setting']=='off' and self.case.get('load_injection')=='qualified_observation':
                    self.disabled_chains.add('c2_reflex')
                native = signals['native_motion_diagnostics']['gripper_reference_feedback']
                old = deepcopy(native);native['pad_normal_loads_n'] = [.5,.5]
                self.emit(tick,ctx,'low_load_observation','native_pad_loads_n',.5,'observation_overlay_on_real_eligible_native_pads',old,native)
        if probe == 'relation':
            axis = np.asarray(obs['state']['eef_pose_world'])[:3,2]
            obs = self.translate(tick,obs,ctx,'grasp_relation_5mm',ctx.contract.call.bindings['object'],(.005*axis).tolist())
            self.control_boundary(tick,ctx)
        if probe == 'geometry':
            entity = ctx.contract.call.bindings.get('target')
            if probe == 'geometry':
                self.target_before_input(tick,ctx,C)
            obs = self.translate(tick,obs,ctx,'target_5cm',entity,[.05,0.,0.])
            self.control_boundary(tick,ctx)
        if probe == 'reselection':
            self.reselection_from = {'call_id':ctx.contract.call.call_id,'selections':ctx.selector_calls,
                'time':float(self.env.sim.data.time),'steps':C.c10.executions,
                'skill':ctx.contract.call.skill,'bindings':dict(ctx.contract.call.bindings)}
            old = ctx.contract.termination.timeout_steps
            ctx.contract = replace(ctx.contract,termination=replace(ctx.contract.termination,timeout_steps=max(1,ctx.steps)))
            self.emit(tick,ctx,'contract_timeout','active_contract.timeout_steps',ctx.steps,'contract_only',old,ctx.contract.termination.timeout_steps)
        if probe == 'preparation':
            self.emit(tick,ctx,'preparation_observation_window','phase',None,'no_injection',phase,phase)
        self.activate_full(tick,ctx,C)
        self.injected = True
        return obs

    def after_prepare(self, tick: int, obs: dict, ctx: Any, C: Any, world: Any) -> None:
        self.tracer.write({'kind':'native_preparation_gate','tick':tick,'call_id':ctx.contract.call.call_id,
            'skill':ctx.contract.call.skill,'layer':ctx.contract.call.layer,
            'statuses':{n:p.status for n,p in ctx.p6.fields.items()},'physical_step_index':C.c10.executions})
        self.tracer.write({'kind':'native_contract_fields','tick':tick,'call_id':ctx.contract.call.call_id,
            'fields':{n:{'depends_on':sorted(s.depends_on),'writable_by':sorted(c.value for c in s.writable_by),
                'kind':s.kind.value,'value_range':s.value_range} for n,s in ctx.contract.fields.items()}})

    def full_recompute(self, tick: int, contract: Any, phase: Any, world: Any,
                       action: Any, scope: Scope, token: str, stage: str) -> None:
        from five_chains.build import build_components
        start = time.perf_counter(); before = physical_signature(self.env)
        view = PreparationSnapshotAdapter(self.adapter,world)
        shadow = build_components(view,ScriptedSelector([]),self.cfg,self.tracer)
        p6 = shadow.c6.prepare(contract,world,None,None,ChainId.PREP)
        fields = shadow.c8.readout(contract,p6,phase,world,None,ChainId.PREP)
        self.provider.verify(action,scope,token)
        if before != physical_signature(self.env):raise RuntimeError('full-recompute shadow changed plant/RNG')
        self.tracer.write({'kind':'native_full_recompute_comparison','tick':tick,'stage':stage,
            'mode':'supplemental_shadow_cost','literal_flag_value':self.cfg['ablation']['vision_full_recompute'],
            'seconds':time.perf_counter()-start,'recipe_calls':shadow.c6.recipe_calls,
            'fields':sorted(fields),'parameters':fields,'phase_before':phase.phase_name,
            'phase_after':phase.phase_name,'adopted':False,'active_state_preserved':True})

    def before_recovery(self, tick: int, contract: Any, world: Any, reason: str,
                        ctx: Any, C: Any) -> None:
        if self.case['probe'] != 'reselection' or self.reselection_from is None or reason != 'contract_timeout':
            return
        if self.case['setting'] == 'full_recompute':
            if self.last_executed_action is None:raise RuntimeError('no actual previous action for read-only protection binding')
            scope = Scope(contract.call.call_id,ctx.p7.phase_name,tick,
                digest({'reason':reason,'contract':contract.contract_id}),
                digest({n:e.pose_world for n,e in world.entities.items()}),False)
            # This action only binds current state for a read-only cost probe.
            # There is no current command/OSC preview on the timeout branch.
            binding = self.provider.capture(self.last_executed_action,scope)
            self.full_recompute(tick,contract,ctx.p7,world,self.last_executed_action,
                                scope,binding['token'],'before_timeout_recovery_no_current_command')

    def after_select(self, tick: int, call: SkillCall, ctx: Any, C: Any) -> bool:
        if self.reselection_from is None or ctx.selector_calls <= self.reselection_from['selections']:
            return False
        clean = C.c10.executions == self.reselection_from['steps'] and float(self.env.sim.data.time) == self.reselection_from['time']
        different = call.call_id != self.reselection_from['call_id']
        excluded = call.skill != self.reselection_from['skill'] or call.bindings != self.reselection_from['bindings']
        self.tracer.write({'kind':'native_reselection_gate','tick':tick,'stage':'after_actual_C11_and_C12_expand_before_C1',
            'same_physical_state':clean,'different_call_identity':different,'failed_signature_excluded':excluded,
            'old':self.reselection_from,'new_call':call,'physical_steps_after':C.c10.executions,
            'simulation_time_after':float(self.env.sim.data.time),'new_C1_readiness_claimed':False})
        if not clean or not different or not excluded:raise RuntimeError('reselection transaction mismatch')
        self.completed = True
        return True

    def before_execute(self, tick: int, obs: dict, ctx: Any, C: Any, world: Any,
                       action: Any, override: Any) -> bool:
        if (self.case['probe'] in ('relation','joint') and
                any(e['name']=='grasp_relation_5mm' for e in self.events) and not self.relation_response_checked):
            affected = [name for name,p in ctx.packet.params.items() if p.source_chain==ChainId.FB_FULL and p.stamp==world.stamp
                and ctx.contract.fields[name].arguments.get('held_object_goal')
                and ctx.contract.fields[name].prep_frame!=ctx.contract.call.bindings.get('object')]
            if affected:
                self.preview_ticks.add(tick)
                self.relation_response_checked = True
        if (self.case['probe']=='joint' and self.injected and not self.joint_restored and
                override is None and self.executions_at_last_event is not None and
                C.c10.executions-self.executions_at_last_event >= 1):
            self.preview_ticks.add(tick)
        if self.reselection_from and ctx.selector_calls > self.reselection_from['selections']:
            clean = C.c10.executions == self.reselection_from['steps'] and float(self.env.sim.data.time) == self.reselection_from['time']
            different = ctx.contract.call.call_id != self.reselection_from['call_id']
            excluded = (ctx.contract.call.skill != self.reselection_from['skill'] or
                        ctx.contract.call.bindings != self.reselection_from['bindings'])
            self.tracer.write({'kind':'native_reselection_gate','tick':tick,'same_physical_state':clean,
                'different_call_identity':different,'failed_signature_excluded':excluded,'old':self.reselection_from,'new_call':ctx.contract.call,
                'physical_steps_after':C.c10.executions,'simulation_time_after':float(self.env.sim.data.time)})
            if not clean or not different or not excluded:raise RuntimeError('reselection transaction mismatch')
            self.completed = True
            return True
        call = ctx.contract.call.call_id
        if call not in self.checked_calls or tick in self.preview_ticks:
            phase_spec = ctx.contract.phases[ctx.p7.phase_index]
            self.tracer.write({'kind':'native_current_target','tick':tick,'call_id':call,
                'phase':ctx.p7.phase_name,'target_field':phase_spec.target_field,
                'parameter':ctx.packet.params[phase_spec.target_field],
                'last_target':C.c10.last_target,'packet_version':ctx.packet.version,
                'action_sha256':action_digest(action)})
            scope = Scope(call,ctx.p7.phase_name,tick,digest(C.c10.last_target),
                          digest({n:e.pose_world for n,e in world.entities.items()}),override is not None)
            start = time.perf_counter(); before = physical_signature(self.env)
            preview = self.provider.baseline(action,scope)
            self.provider.verify(action,scope,preview['binding']['token'])
            if before != physical_signature(self.env):raise RuntimeError('native current-action preview changed plant/RNG')
            self.tracer.write({'kind':'native_current_action_preview','tick':tick,'scope':asdict(scope),
                'evidence_scope':'current_complete_C10_action_only_zero_physics',
                'baseline':preview['baseline'],'token':preview['binding']['token'],
                'model_array_count':preview['binding']['model_array_count'],
                'integration_state_size':preview['binding']['integration_state_size'],
                'active_state_preserved':True,'seconds':time.perf_counter()-start,
                'all_future_candidates_qualified':False,'R50_application':False})
            if self.case['setting'] == 'full_recompute' and tick in self.preview_ticks:
                # Additional computation comparator; no shadow output becomes a command.
                # Independent recipe provider, same unchanged contract/world/phase.
                literal = self.case.get('full_recompute_mode') == 'literal_flag'
                real_c4 = (literal and bool(world.changed_keys & ctx.contract.dep_keys) and
                    any(C.c12.may_write(ctx.contract,n,ChainId.VISION) for n in ctx.contract.fields))
                if real_c4:
                    assert self.full_activation is not None
                    self.tracer.write({'kind':'native_full_recompute_comparison','tick':tick,
                        'stage':'before_execute','mode':'actual_c4_full','literal_flag_value':self.cfg['ablation']['vision_full_recompute'],
                        'recipe_calls':int(C.c6.recipe_calls)-self.full_recipe_tick_start,
                        'recipe_count_scope':'all active C6 calls in this tick; raw invocation ownership identifies actual full C4',
                        'seconds':float(self.tracer.tick_costs.get('c4_vision',0.)),
                        'fields':sorted(ctx.contract.fields),'adopted':True,
                        'adopted_fields':[n for n,p in ctx.packet.params.items() if p.source_chain==ChainId.VISION and p.stamp==world.stamp],
                        'current_action_private_preview_preserved':True})
                else:
                    self.full_recompute(tick,ctx.contract,ctx.p7,world,action,scope,
                                        preview['binding']['token'],'before_execute')
            self.checked_calls.add(call)
        return False

    def after_execute(self, tick: int, obs: dict, ctx: Any, C: Any, world: Any,
                      action: Any, override: Any) -> bool:
        self.last_executed_action = np.asarray(action).copy()
        if self.events:
            self.tracer.write({'kind':'native_probe_response','tick':tick,'physical_steps':C.c10.executions,
                'call_id':ctx.contract.call.call_id,'phase':ctx.p7.phase_name,'continuous':obs['state']['signals'].get('continuous',{}),
                'native_gripper':obs['state']['signals'].get('native_motion_diagnostics',{}).get('gripper_reference_feedback'),
                'stiffness_scale':ctx.packet.params.get('stiffness_scale'),'reflex':override})
        if self.case['probe']=='joint' and self.injected and not self.joint_restored:
            stops=[e for e in self.events if e['name']=='unexpected_contact']
            if (stops and ctx.contract.call.call_id==stops[-1]['call_id'] and override is None and
                    self.executions_at_last_event is not None and C.c10.executions-self.executions_at_last_event >= 2):
                ranges = all(s.value_range is None or np.all((np.asarray(ctx.packet.params[n].value)>=s.value_range[0]) &
                    (np.asarray(ctx.packet.params[n].value)<=s.value_range[1])) for n,s in ctx.contract.fields.items() if n in ctx.packet.params)
                self.joint_restored = bool(ranges)
                self.tracer.write({'kind':'native_joint_restored_execution','tick':tick,
                    'call_id':ctx.contract.call.call_id,'physical_steps':C.c10.executions,
                    'packet_version':ctx.packet.version,'action_sha256':action_digest(action),
                    'override':None,'declared_ranges_legal':bool(ranges)})
        if self.case['probe'].startswith('demand_') and not self.handoff:
            obj = ctx.contract.call.bindings.get('object')
            decision = (ctx.p7.phase_name == 'lift' if self.case['handoff_phase']=='lift' else
                ctx.p7.phase_name == 'carry' and obs['state']['signals']['predicates'].get('reached',False))
            if obj == self.case['acquire_object'] and obj in obs['state']['signals'].get('grasp_transforms',{}) and decision:
                layer = self.case['demand_layer']; original = ctx.contract.call
                if layer == 3:
                    call = replace(original,call_id=original.call_id+'/demand_L3',combined_with=(),next_call=None)
                elif layer == 2:
                    call = SkillCall(original.call_id+'/demand_L2',2,'maintain_container_attitude',{'object':obj})
                else:
                    bindings = {'reference':self.case['reference'],'object':obj}
                    call = SkillCall(original.call_id+'/demand_L1',1,'local_pose_servo',bindings)
                self.demand_call_id = call.call_id
                self.selector.pending = ScriptedSelector([call])
                self.tracer.write({'kind':'diagnostic_skill_handoff','tick':tick,'suspended_call':original,
                    'new_call':call,'history_success_appended':False,'physical_steps':C.c10.executions,
                    'measured_grasp':obs['state']['signals']['grasp_transforms'][obj],
                    'measured_object':obj,'history_length':len(ctx.history)})
                ctx.contract = None;ctx.packet = None;ctx.p6 = None;ctx.p7 = None;ctx.steps = 0;ctx.sub_queue.clear()
                self.handoff = True
        if self.executions_at_last_event is not None and self.injected and self.case['probe'] != 'joint':
            if C.c10.executions-self.executions_at_last_event >= self.post_window:
                self.completed = True
                return True
        return False

    def result(self) -> dict:
        return {'probe':self.case['probe'],'setting':self.case['setting'],'events':self.events,
                'full_recompute_mode':self.case.get('full_recompute_mode'),
                'literal_full_flag_final':bool(self.cfg['ablation']['vision_full_recompute']),
                'intervention_observed':self.injected,'finite_window_completed':self.completed,
                'native_preview_evaluations':self.provider.native_evaluations,
                'R50_reference_application':False,'task_rate_eligible':False}
