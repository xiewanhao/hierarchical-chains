"""Closed serial protocol; validate evidence before importing a simulator."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
from typing import Any
import json

SETTINGS = {
    'normal', 'freeze_after_prep', 'disable_c2', 'disable_c3a', 'disable_c4',
    'phase_only_no_parameter_update', 'max_reselections_0', 'shadow_full_equivalent',
}
TASKS = {'HeatMug', 'PrepareCoffee', 'SteamInMicrowave', 'ArrangeBreadBasket', 'PanTransfer'}
CASE_SETTINGS = {
    'preparation': {'normal','freeze_after_prep'}, 'fast': {'normal','disable_c3a'},
    'geometry': {'normal','disable_c4','shadow_full_equivalent'},
    'relation': {'normal','phase_only_no_parameter_update'},
    'reflex_stop': {'normal','disable_c2'}, 'reflex_gripper': {'normal','disable_c2'},
    'reselection': {'normal','max_reselections_0'}, 'joint': {'normal'}, 'demand': {'normal'},
}


def digest_file(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def source_manifest(root: Path) -> dict[str, str]:
    paths=[p for directory in ('five_chains', 'scripts', 'configs', 'protocols','data','tests')
        for p in sorted((root/directory).rglob('*')) if p.is_file() and p.suffix in ('.py', '.sh', '.yaml', '.json','.npz') and '__pycache__' not in p.parts]
    if (root/'protocol.json').is_file():paths.append(root/'protocol.json')
    return {p.relative_to(root).as_posix():digest_file(p) for p in paths}


def manifest_digest(manifest: dict) -> str:
    return sha256(json.dumps(manifest, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


def verify_legacy_files(manifest_path: Path, legacy: Path) -> None:
    expected=json.loads(manifest_path.read_text())
    for name,digest in expected.items():
        path=(legacy/name).resolve()
        if not path.is_relative_to(legacy.resolve()) or not path.is_file() or digest_file(path)!=digest:
            raise ValueError('protected original source/weights changed: '+name)


def validate_protocol(value: Any, directory: Path) -> dict:
    if not isinstance(value, dict):
        raise ValueError('protocol must be an object')
    required = {'schema_version','name','base_revision','parallel_workers','wall_budget_seconds','max_ticks','jobs'}
    if set(value) != required or value['schema_version'] != 'chain_validation/v1' or value['base_revision'] != 'R49+R50passive':
        raise ValueError('invalid protocol schema/version/keys')
    if not isinstance(value['name'], str) or not value['name']:
        raise ValueError('missing protocol name')
    if type(value['parallel_workers']) is not int or value['parallel_workers'] != 1:
        raise ValueError('only one sequential worker is supported')
    if type(value['max_ticks']) is not int or value['max_ticks'] != 6000 or type(value['wall_budget_seconds']) is not int or value['wall_budget_seconds'] != 1200:
        raise ValueError('original 6000/1200 budgets must be preserved')
    if not isinstance(value['jobs'], list) or not value['jobs']:
        raise ValueError('jobs must be nonempty')
    identifiers = set()
    for job in value['jobs']:
        if not isinstance(job, dict) or job.get('mode') not in ('trace', 'fixture', 'native'):
            raise ValueError('invalid job mode')
        jid = job.get('id')
        if not isinstance(jid, str) or not jid or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in jid) or jid in identifiers:
            raise ValueError('invalid or duplicate job id')
        identifiers.add(jid)
        if job['mode'] == 'trace':
            if set(job) != {'id','mode','trace','sha256','expected_ticks'} or type(job['expected_ticks']) is not int or job['expected_ticks'] <= 0:
                raise ValueError('invalid trace job')
            path = (directory/job['trace']).resolve()
            if not path.is_file() or digest_file(path) != job['sha256']:
                raise ValueError('trace input hash mismatch: ' + jid)
        elif job['mode'] == 'fixture':
            if set(job) != {'id','mode','case','setting'} or job['case'] not in ('preparation','fast','geometry','relation','reflex_stop','reflex_gripper','reselection','joint','demand') or job['setting'] not in SETTINGS:
                raise ValueError('invalid fixture job')
            if job['setting'] not in CASE_SETTINGS[job['case']]:
                raise ValueError('setting is not applicable to this chain')
        else:
            if not {'id','mode','task','seed','layout','style','setting','registration','preflight'} <= set(job) <= {'id','mode','task','seed','layout','style','setting','registration','preflight','record_video'}:
                raise ValueError('invalid native job fields')
            if type(job.get('record_video',False)) is not bool:raise ValueError('record_video must be boolean')
            if job['task'] not in TASKS or job['setting'] not in SETTINGS-{'shadow_full_equivalent'}:
                raise ValueError('unsupported native task/setting')
            if any(type(job[k]) is not int for k in ('seed','layout','style')):
                raise ValueError('native task identity must use integers')
            for key in ('registration','preflight'):
                if not (directory/job[key]).is_file():
                    raise ValueError('missing ' + key + ': ' + jid)
    return value


def native_evidence(job: dict, directory: Path, root: Path) -> dict:
    if job.get('task') not in TASKS or job.get('setting') not in SETTINGS-{'shadow_full_equivalent'} or any(type(job.get(k)) is not int for k in ('seed','layout','style')):
        raise ValueError('unsupported native case or setting')
    registration_path = (directory/job['registration']).resolve()
    preflight_path = (directory/job['preflight']).resolve()
    registration = json.loads(registration_path.read_text())
    preflight = json.loads(preflight_path.read_text())
    case = {k:job[k] for k in ('task','seed','layout','style','setting')}
    case['record_video']=job.get('record_video',False)
    expected = manifest_digest(source_manifest(root))
    if registration.get('case') != case or not registration.get('novelty') or registration.get('source_manifest_sha256') != expected:
        raise ValueError('registration case/source/novelty mismatch')
    if preflight.get('case') != case or preflight.get('source_manifest_sha256') != expected or preflight.get('registration_sha256') != digest_file(registration_path):
        raise ValueError('native preflight binding mismatch')
    gates = ('full_tests_passed','mypy_passed','actual_C10_all_candidate_zero_physics_passed',
        'active_state_preserved','original_selector_weights_preserved','original_native_sources_preserved')
    if any(preflight.get(g) is not True for g in gates) or type(preflight.get('physical_steps')) is not int or preflight.get('physical_steps') != 0:
        raise ValueError('required native gates not passed')
    for name, info in preflight.get('evidence_files', {}).items():
        p = (preflight_path.parent/info['path']).resolve()
        if not p.is_file() or digest_file(p) != info['sha256']:
            raise ValueError('preflight evidence changed: ' + name)
    if not {'tests','mypy','native_preflight'} <= preflight.get('evidence_files', {}).keys():
        raise ValueError('missing actual gate evidence files')
    artifacts={name:json.loads((preflight_path.parent/preflight['evidence_files'][name]['path']).read_text())
        for name in ('tests','mypy','native_preflight')}
    if any(v.get('source_manifest_sha256')!=expected or v.get('passed') is not True for v in artifacts.values()):
        raise ValueError('gate artifacts do not attest this source')
    native=artifacts['native_preflight']
    if (native.get('case')!=case or native.get('scope')!='actual_C10_all_candidate_zero_physics'
            or native.get('fixture_only') is not False or type(native.get('physical_steps')) is not int or native.get('physical_steps')!=0
            or type(native.get('candidate_count')) is not int or native['candidate_count']<1
            or native.get('all_candidates_validated') is not True or native.get('active_state_preserved') is not True):
        raise ValueError('missing actual all-candidate native preflight; fixture/refusal is insufficient')
    protected=root/'configs/protected_legacy.json'
    if preflight.get('protected_manifest_sha256')!=digest_file(protected):
        raise ValueError('native preflight protected-source binding mismatch')
    from five_chains.paths import legacy_root
    verify_legacy_files(protected,legacy_root())
    return {'registration_sha256':digest_file(registration_path),'preflight_sha256':digest_file(preflight_path),'case':case}


def apply_setting(cfg: dict, setting: str) -> None:
    if setting not in SETTINGS:
        raise ValueError('unknown setting')
    cfg.setdefault('chain_validation', {})['audit'] = True
    if setting == 'freeze_after_prep':
        cfg['ablation']['freeze_after_prep'] = True
    elif setting.startswith('disable_'):
        cfg['ablation']['disable_chains'].append({'disable_c2':'c2_reflex','disable_c3a':'c3a_fb_fast','disable_c4':'c4_vision'}[setting])
    elif setting == 'phase_only_no_parameter_update':
        cfg['chain_validation']['phase_only_no_parameter_update'] = True
    elif setting == 'max_reselections_0':
        cfg.setdefault('replan', {})['max_reselections'] = 0
    elif setting == 'shadow_full_equivalent':
        cfg['chain_validation']['shadow_full_equivalent'] = True
