"""Recompute finite native intervention verdicts from complete raw logs."""
from __future__ import annotations
from collections import Counter
from hashlib import sha256
from pathlib import Path
from typing import Any
import gzip
import json


def demand_evidence(rows: list[dict], case: dict) -> tuple[dict[str,bool], list[dict]]:
    """Reconstruct demand ownership and actual application from raw records."""
    inputs = [r for r in rows if r['kind']=='native_demand_raw_input']
    handoffs = [r for r in rows if r['kind']=='diagnostic_skill_handoff']
    checks = {'demand_one_raw_input_and_real_handoff':len(inputs)==len(handoffs)==1}
    if len(inputs)!=1 or len(handoffs)!=1:
        return checks,inputs
    entry, handoff = inputs[0],handoffs[0]
    call = handoff['new_call']; identity = call['call_id']; tick = entry['tick']
    frame = next((r for r in rows if r['kind']=='tick' and r['tick']==tick),{})
    contracts = [r for r in rows if r['kind']=='native_contract_fields' and r['call_id']==identity]
    targets = [r for r in rows if r['kind']=='native_current_target' and r['tick']==tick and r['call_id']==identity]
    prior = [r for r in rows if r['kind']=='native_target_before_input' and r['tick']==tick and r['call_id']==identity]
    executed = [r for r in rows if r['kind']=='execution' and r.get('status')=='returned' and
        r.get('call_id')==identity and r.get('loop_tick')==tick]
    raw = entry['input_spec']
    encoded = json.dumps(raw,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    checks['demand_raw_input_hash_and_state_preservation'] = (entry.get('input_sha256')==sha256(encoded).hexdigest()
        and entry.get('active_state_preserved') is True)
    checks['demand_real_acquired_object_handoff'] = (handoff.get('measured_object')==case['acquire_object']
        and bool(handoff.get('measured_grasp')) and handoff.get('history_success_appended') is False
        and call['layer']==case['demand_layer'] and entry['call_id']==identity
        and frame.get('call_id')==identity and handoff['tick']<tick
        and (case['demand_layer']!=2 or call['bindings'].get('object')=='bowl'))
    checks['demand_current_grasp_is_recorded_observation'] = (bool(entry.get('current_measured_grasp')) and
        entry.get('current_measured_grasp')==frame.get('grasp_transforms',{}).get(case['acquire_object']))
    checks['demand_input_after_actual_new_call_execution'] = any(r['kind']=='execution' and
        r.get('status')=='returned' and r.get('call_id')==identity and handoff['tick']<r.get('loop_tick',-1)<tick
        for r in rows)
    checks['demand_contract_and_action_bound'] = bool(len(contracts)==len(targets)==len(prior)==len(executed)==1)
    if not checks['demand_contract_and_action_bound']:
        return checks,inputs
    contract = contracts[0]['fields'];target=targets[0];before=prior[0];execution=executed[0]
    field = target['target_field']
    checks['demand_contract_and_action_bound'] = (target['parameter']==frame.get('parameters',{}).get(field)
        and field==before['target_field'] and target['packet_version']==execution['packet_version']
        and target['action_sha256']==execution['executed_action_sha256']==execution['action_sha256'])
    permitted = {n for n,s in contract.items() if 'c4_vision' in s['writable_by']}
    changed = set(frame.get('changed_keys',[]))
    affected = {n for n in permitted if set(contract[n]['depends_on']) & changed}
    c4 = {w['name'] for w in frame.get('writes',[]) if w['chain']=='c4_vision'}
    fast = {w['name'] for w in frame.get('writes',[]) if w['chain']=='c3a_fb_fast'}
    if case['probe']=='demand_geometry':
        checks['demand_identical_geometry_spec'] = (raw=={'schema':'demand_raw_input/v1',
            'kind':'entity_translation_observation','entity':'bowl','delta_world_m':[.05,0.,0.]})
        checks['demand_only_actual_affected_C4_fields'] = c4==affected
        input_affected = {n for n in permitted if 'bowl.pose' in contract[n]['depends_on']}
        checks['demand_reference_dependency_matches_role'] = (bool(input_affected)==
            (case['demand_layer']==3 or (case['demand_layer']==1 and call['bindings'].get('reference')=='bowl')))
        if field in input_affected:
            checks['demand_current_parameter_updated'] = (field in c4 and target['parameter']!=before['parameter']
                and target['parameter']['source_chain']=='c4_vision' and target['parameter']['stamp']==tick)
        else:
            checks['demand_unaffected_current_parameter_retained'] = target['parameter']==before['parameter']
    elif case['probe']=='demand_fast':
        checks['demand_identical_tracking_spec'] = (raw=={'schema':'demand_raw_input/v1',
            'kind':'tracking_observation','signal':'eef_track_err','value_m':.03})
        checks['demand_tracking_actual_stiffness_adopted'] = fast=={'stiffness_scale'}
    elif case['probe']=='demand_tilt':
        up=raw.get('up_world',[])
        checks['demand_identical_raw_tilt_spec'] = (raw.get('schema')=='demand_raw_input/v1' and
            raw.get('kind')=='object_up_vector_observation' and raw.get('entity')=='bowl' and
            raw.get('tilt_rad')==.25 and len(up)==3 and abs(sum(x*x for x in up)-1.)<1e-12)
        owns = 'tilt_limit' in contract
        checks['demand_tilt_projection_owned_by_actual_contract'] = (
            owns==(case['demand_layer']==2) and entry['contract_declares_tilt_limit']==owns and
            abs(entry['projected_continuous']['tilt_dev']-(.10 if owns else 0.))<1e-12)
        checks['demand_tilt_actual_stiffness_ownership'] = fast==({'stiffness_scale'} if owns else set())
        checks['demand_tilt_unrelated_tracking_below_original_threshold'] = abs(frame.get('continuous',{}).get('eef_track_err',float('inf')))<=.02
    checks['demand_phase_preserved_at_input'] = before['target_field']==field and target['phase']==frame.get('phase')
    return checks,inputs


def whole_relation_disable_evidence(rows: list[dict],case: dict) -> dict[str,bool]:
    if not (case.get('probe')=='relation' and case.get('setting')=='off' and
            case.get('relation_control_scope')=='whole_chain'):
        return {}
    boundaries=[r for r in rows if r['kind']=='native_control_boundary' and r.get('chain')=='c3b_fb_full']
    checks={'whole_relation_disable_boundary':len(boundaries)==1}
    if len(boundaries)!=1:return checks
    boundary=boundaries[0];start=boundary['tick'];identity=boundary['call_id']
    checks['whole_relation_disable_boundary']=(boundary.get('control_scope')=='whole_chain' and
        boundary.get('disabled_from_registered_input') is True and boundary.get('warmup_enabled') is True and
        boundary.get('phase_progression_enabled') is False and boundary.get('phase_only_no_parameter_update') is False and
        'c3b_fb_full' in boundary.get('active_disabled_chains',[]))
    after=rows[rows.index(boundary):]
    ticks=[r for r in after if r['kind']=='tick']
    invocations=[r for r in after if r['kind']=='invocation_start']
    executions=[r for r in after if r['kind']=='execution' and r.get('status')=='returned']
    checks['whole_relation_off_original_carry_window']=(len(ticks)==case['post_window'] and
        all(r['call_id']==identity and r['phase']=='carry' for r in ticks))
    checks['whole_relation_off_actual_execution_window']=(len(executions)==case['post_window'] and
        all(r['call_id']==identity for r in executions))
    checks['whole_relation_off_no_full_or_phase_only_trigger']=not any(
        {'c3b_fb_full','c3b_phase_only'}&set(r.get('triggers',[])) for r in ticks)
    checks['whole_relation_off_no_C7_update']=not any(r['component']=='c7.update' for r in invocations)
    checks['whole_relation_off_no_full_feedback_compute']=not any(
        (r.get('owner_chain') or r.get('chain'))=='c3b_fb_full' or r['component']=='chain.c3b_fb_full' for r in invocations)
    checks['whole_relation_off_no_full_feedback_write']=not any(
        w['chain']=='c3b_fb_full' for r in ticks for w in r.get('writes',[]))
    return checks


def inspect_native(directory: Path) -> dict[str,Any]:
    result = json.loads((directory/'result.json').read_text())
    with gzip.open(directory/'ticks.jsonl.gz','rt') as handle:
        rows = [json.loads(line) for line in handle]
    ticks = {r['tick']:r for r in rows if r['kind']=='tick'}
    events = [r for r in rows if r['kind']=='perturbation']
    previews = [r for r in rows if r['kind']=='native_current_action_preview']
    prepared = [r for r in rows if r['kind']=='native_preparation_gate']
    arbitration = [r for r in rows if r['kind']=='arbitration' and r.get('decision')=='final_survivor']
    executions = [r for r in rows if r['kind']=='execution' and r.get('status')=='returned']
    checks: dict[str,bool] = {
        'actual_native':result.get('evidence_level')=='V3_native_intervention',
        'source_unchanged':result.get('source_unchanged') is True,
        'step_equation':result.get('step_audit_passed') is True and len(ticks)==result['audited_env_steps']==len(executions),
        'native_preview':bool(previews) and all(r['active_state_preserved'] for r in previews),
        'prepared_action_executed':bool(executions) and all(r.get('action_sha256') and
            r.get('action_sha256')==r.get('executed_action_sha256') for r in executions),
        'intervention_observed':bool(events),
        'C1_ready_or_bound':bool(prepared) and all(v in ('ready','bound') for r in prepared for v in r['statuses'].values()),
        'adopted_field_permission':all(r.get('permission') is True for r in arbitration),
    }
    setting = result['case']['setting']; disabled = setting == 'off'
    fast_rows = []; stop_rows = []; geometry_rows = []; relation_rows = []; load_rows = []
    for event in events:
        row = ticks.get(event['tick'],{})
        name = event['name']; writes = row.get('writes',[])
        if name=='tracking_3cm':
            adopted = [w for w in writes if w['chain']=='c3a_fb_fast' and w['name']=='stiffness_scale']
            value = row.get('parameters',{}).get('stiffness_scale',{}).get('value')
            fast_rows.append({'tick':event['tick'],'adopted':bool(adopted),'value':value})
            checks['fast_trigger_and_adoption'] = bool(adopted) != disabled and value is not None and .5<=value<=1.5
        if name=='unexpected_contact':
            is_stop = (row.get('reflex') or {}).get('kind')=='stop'
            later = [r for t,r in ticks.items() if t>event['tick']]
            recovered = bool(later) and (later[0].get('reflex') or {}).get('kind')!='stop'
            stop_rows.append({'tick':event['tick'],'same_tick_stop':is_stop,'next_executed_tick_no_stop':recovered})
            checks['stop_this_tick_restore_next'] = (is_stop != disabled) and recovered
        if name=='target_5cm':
            c4 = [w['name'] for w in writes if w['chain']=='c4_vision']
            geometry_rows.append({'tick':event['tick'],'changed_keys':row.get('changed_keys'),
                'writes':c4,'phase_before':event['phase'],'phase_after':row.get('phase')})
            expected = not disabled
            if result['case']['probe']=='demand_geometry':
                expected = result['case']['demand_layer']!=2 and result['case'].get('reference_bound',True)
            checks['geometry_key_and_scoped_adoption'] = event['target'] in row.get('changed_keys',[]) and bool(c4)==expected
            checks['geometry_no_phase_advance'] = event['phase']==row.get('phase')
            if result['case']['probe'] in ('geometry','joint'):
                current = [r for r in rows if r['kind']=='native_current_target' and
                    r['tick']==event['tick'] and r['call_id']==event['call_id']]
                previous = [r for r in rows if r['kind']=='native_target_before_input' and
                    r['tick']==event['tick'] and r['call_id']==event['call_id']]
                executed = [r for r in executions if r.get('loop_tick')==event['tick'] and
                    r.get('call_id')==event['call_id']]
                target = current[0] if len(current)==1 else {}
                prior = previous[0] if len(previous)==1 else {}
                param = target.get('parameter',{})
                field = target.get('target_field')
                active_bound = (field=='place_pose' and field==prior.get('target_field') and
                    target.get('phase')=='carry' and param==row.get('parameters',{}).get(field) and
                    target.get('last_target') is not None and prior.get('previous_last_target') is not None and
                    len(executed)==1 and bool(target.get('action_sha256')) and
                    target.get('action_sha256')==executed[0].get('executed_action_sha256') and
                    target.get('packet_version')==executed[0].get('packet_version'))
                geometry_adopted = (field in c4 and param.get('source_chain')=='c4_vision' and
                    param.get('stamp')==event['tick'] and
                    param.get('value')!=prior.get('parameter',{}).get('value') and
                    target.get('last_target')!=prior.get('previous_last_target'))
                geometry_retained = field not in c4 and param==prior.get('parameter')
                checks['geometry_current_C10_target_bound'] = active_bound
                checks['geometry_current_target_updated_or_retained'] = geometry_retained if disabled else geometry_adopted
                geometry_rows[-1]['current_target_evidence']={'active_bound':active_bound,
                    'updated':geometry_adopted,'retained':geometry_retained,'target_field':field}
        if name=='grasp_relation_5mm':
            candidates=[r for t,r in ticks.items() if event['tick']<=t<event['tick']+result['case'].get('post_window',24) and r.get('call_id')==event['call_id'] and
                        'grasp_relation_changed' in r.get('events',[])]
            response_row=candidates[0] if candidates else {}
            full = [w['name'] for w in response_row.get('writes',[]) if w['chain']=='c3b_fb_full']
            relation_rows.append({'tick':event['tick'],'response_tick':response_row.get('tick'),
                'response_cycles':None if not response_row else response_row['tick']-event['tick'],
                'events':response_row.get('events'),'writes':full})
            checks['measured_relation_edge'] = bool(candidates)
            checks['relation_scoped_update'] = bool(full) != disabled and 'lift_pose' not in full
        if name=='low_load_observation':
            reflex = row.get('reflex') or {}
            band = event.get('gripper_load_band_n_before') or row.get('reflex_bounds',{}).get('gripper_load_band_n')
            if result['case'].get('load_injection')=='qualified_observation':
                checks['original_load_band_preserved'] = band==[1.,3.] and row.get('reflex_bounds',{}).get('gripper_load_band_n')==band
            response = [r for r in rows if r['kind']=='native_probe_response' and r['tick']>=event['tick']
                and r.get('call_id')==event['call_id']]
            actual = [r['native_gripper'].get('pad_normal_loads_n',[]) for r in response if
                (r.get('native_gripper') or {}).get('source')=='native_simulator_contact_solver' and
                r['native_gripper'].get('closing_intent') and r['native_gripper'].get('bilateral_native_pads')]
            returned = bool(band and any(len(loads)==2 and all(band[0]<=x<=band[1] for x in loads) for loads in actual))
            closed = reflex.get('kind')=='gripper_reference' and reflex.get('gripper_action')==1.
            load_rows.append({'tick':event['tick'],'close_command':closed,'native_loads_after':actual,'returned_to_band':returned})
            checks['load_branch_adopted'] = closed != disabled
            if not disabled:checks['native_load_returned_to_band'] = returned
        if name=='load_micro_translation_0p5mm':
            window=[r for t,r in ticks.items() if t>=event['tick'] and r.get('call_id')==event['call_id']]
            low=[]
            for r in window:
                native=r.get('native_motion_diagnostics',{}).get('gripper_reference_feedback') or {}
                loads=native.get('pad_normal_loads_n',[])
                if (native.get('source')=='native_simulator_contact_solver' and native.get('closing_intent') and
                    native.get('bilateral_native_pads') and len(loads)==2 and min(loads)<1. and
                    r.get('reflex_bounds',{}).get('gripper_load_band_n')==[1.,3.]):
                    ref=r.get('reflex') or {}
                    low.append({'tick':r['tick'],'native_pad_loads_n':loads,
                        'original_close_adopted':ref.get('kind')=='gripper_reference' and ref.get('gripper_action')==1.})
            first=low[0]['tick'] if low else None
            response=[r for r in rows if r['kind']=='native_probe_response' and first is not None and
                      r['tick']>=first and r.get('call_id')==event['call_id']]
            returned_samples=[]
            for r in response:
                native=r.get('native_gripper') or {};loads=native.get('pad_normal_loads_n',[])
                if (native.get('bilateral_native_pads') and native.get('closing_intent') and
                    len(loads)==2 and all(1.<=v<=3. for v in loads)):
                    returned_samples.append({'tick':r['tick'],'native_pad_loads_n':loads})
            load_rows.append({'mode':'physical_microshift_no_force_overlay','tick':event['tick'],
                'eligible_native_underloads':low,'native_returns_to_original_band':returned_samples})
            checks['actual_native_underload_observed']=bool(low)
            checks['load_branch_adopted']=bool(low) and any(r['original_close_adopted'] for r in low)!=disabled
            if not disabled:checks['native_load_returned_to_band']=bool(returned_samples)
    if result['case'].get('load_injection')=='physical_microshift':
        checks['physical_load_intervention_recorded']=any(e['name']=='load_micro_translation_0p5mm' for e in events)
    reselections = [r for r in rows if r['kind']=='native_reselection_gate']
    if any(e['name']=='contract_timeout' for e in events):
        checks['reselection_no_extra_step_and_exclusion'] = (bool(reselections) and all(
            r['same_physical_state'] and r['failed_signature_excluded'] for r in reselections)) if not disabled else (
            not reselections and result['reason']=='contract_failure:contract_timeout')
    recomputes = [r for r in rows if r['kind']=='native_full_recompute_comparison']
    if setting=='full_recompute':
        literal = result['case'].get('full_recompute_mode')=='literal_flag'
        if literal:
            activations=[r for r in rows if r['kind']=='native_full_flag_activation']
            checks['literal_full_flag_enabled_at_input'] = (len(activations)==1 and bool(events) and
                activations[0]['tick']==events[0]['tick'] and activations[0]['value'] is True and activations[0]['warmup_value'] is False and
                activations[0].get('flag')=='ablation.vision_full_recompute')
            real=[r for r in recomputes if r.get('mode')=='actual_c4_full']
            for item in real:
                matching=[r for r in rows if r['kind']=='invocation_start' and r.get('loop_tick')==item['tick'] and
                    r.get('call_id')==activations[0]['call_id'] and r.get('owner_chain')=='c4_vision'] if activations else []
                all_fields=set(item['fields'])
                prepare=[r for r in matching if r.get('component')=='c6.prepare' and set(r.get('requested_fields',[]))==all_fields]
                readout=[r for r in matching if r.get('component')=='c8.readout' and set(r.get('requested_fields',[]))==all_fields]
                item['actual_all_field_invocations_verified']=bool(prepare and readout)
            checks['actual_literal_C4_all_field_calls_verified'] = all(r.get('actual_all_field_invocations_verified') is True for r in real)
            if result['case']['probe']=='geometry':
                checks['actual_literal_C4_full_prepare_and_adoption'] = bool(real) and all(
                    r.get('literal_flag_value') is True and r.get('adopted') is True and
                    r.get('adopted_fields') and r.get('actual_all_field_invocations_verified') for r in real)
            checks['full_has_measured_registered_work'] = bool(recomputes) and all(
                r['recipe_calls']>0 and r['seconds']>0 and r.get('literal_flag_value') is True for r in recomputes)
        else:
            checks['full_shadow_has_measured_extra_work'] = bool(recomputes) and all(r['recipe_calls']>0 and not r['adopted'] for r in recomputes)
    if result['case']['probe']=='joint':
        names={e['name'] for e in events}
        checks['joint_all_registered_events']={'grasp_relation_5mm','target_5cm','tracking_3cm','unexpected_contact','contract_timeout'}<=names
        both={e['tick'] for e in events if e['name']=='tracking_3cm'} & {e['tick'] for e in events if e['name']=='unexpected_contact'}
        checks['joint_fast_and_stop_same_tick']=bool(both) and all(
            (ticks.get(t,{}).get('reflex') or {}).get('kind')=='stop' and
            any(w['chain']=='c3a_fb_fast' and w['name']=='stiffness_scale' for w in ticks.get(t,{}).get('writes',[])) for t in both)
        restores=[r for r in rows if r['kind']=='native_joint_restored_execution']
        timeouts=[e['tick'] for e in events if e['name']=='contract_timeout']
        checks['joint_actual_restore_before_timeout']=bool(restores and timeouts) and all(
            r['tick']<min(timeouts) and r['override'] is None and r['declared_ranges_legal'] and
            any(x.get('loop_tick')==r['tick'] and x.get('call_id')==r['call_id'] and
                x.get('executed_action_sha256')==r['action_sha256'] and x.get('packet_version')==r['packet_version'] for x in executions)
            for r in restores)
    if result['case'].get('joint_scope')=='user_skip_button_lowload_v1':
        relations=[e for e in events if e['name']=='grasp_relation_5mm']
        targets=[e for e in events if e['name']=='target_5cm']
        scopes=[r for r in rows if r['kind']=='native_joint_scope_amendment']
        observations=[r for r in rows if r['kind']=='native_joint_target_observation']
        checks['joint_amended_scope_explicit']=len(scopes)==1 and scopes[0]['skipped_requirements']==['joint_button_lowload_same_tick'] and scopes[0]['skipped_is_not_passed'] is True
        checks['joint_actual_bowl_carry_relation']=len(relations)==1 and relations[0]['target']=='bowl.pose' and relations[0]['phase']=='carry'
        checks['joint_current_microwave_target_observation']=len(targets)==len(observations)==1 and targets[0]['target']=='microwave_interior.pose' and targets[0]['mode']=='one_frame_target_observation_no_physics' and observations[0]['active_state_preserved'] is True
        checks['joint_relation_response_before_geometry']=bool(relation_rows and targets) and relation_rows[0]['response_tick'] is not None and relation_rows[0]['response_tick']<targets[0]['tick']
        checks['joint_lowload_skipped_not_faked']=not any(e['name']=='low_load_observation' for e in events)
    demand_inputs: list[dict] = []
    if result['case']['probe'].startswith('demand_'):
        demand_checks,demand_inputs = demand_evidence(rows,result['case'])
        checks.update(demand_checks)
    checks.update(whole_relation_disable_evidence(rows,result['case']))
    checks['finite_endpoint'] = (result['reason']=='validation_complete' and result.get('validation',{}).get('finite_window_completed')) or (
        disabled and result['case']['probe']=='reselection' and result['reason']=='contract_failure:contract_timeout')
    start=min((e['tick'] for e in events),default=None)
    window=[r for t,r in ticks.items() if start is not None and t>=start]
    warmup=[r for t,r in ticks.items() if start is None or t<start]
    return {'case':result['case'],'status':'pass' if all(checks.values()) else 'unpassed',
        'checks':checks,'reason':result['reason'],'native_success':result['success'],
        'native_steps':result['audited_env_steps'],'trigger_counts':dict(Counter(x for row in ticks.values() for x in row['triggers'])),
        'window_trigger_counts':dict(Counter(x for row in window for x in row['triggers'])),
        'warmup_trigger_counts':dict(Counter(x for row in warmup for x in row['triggers'])),
        'events':events,'fast':fast_rows,'stop':stop_rows,'geometry':geometry_rows,'relation':relation_rows,
        'gripper':load_rows,'reselections':reselections,'full_recomputes':recomputes,
        'preview_count':len(previews),'demand_inputs':demand_inputs,'task_rate_eligible':False}
