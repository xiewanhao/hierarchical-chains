"""Optional post-execute native frames; no generated or interpolated footage."""
from __future__ import annotations
from hashlib import sha256
from pathlib import Path
from typing import Any
import json, shutil, subprocess, time
import numpy as np


class FrameRecorder:
    def __init__(self, directory: Path, case: dict, source_digest: str, camera: str, evidence_level: str = 'V3_native') -> None:
        directory.mkdir(exist_ok=False)
        self.directory=directory
        self.camera=camera
        self.manifest: dict[str, Any]={'scope':'native_post_execute_frames' if evidence_level=='V3_native' else 'component_frame_fixture','case':case,
            'source_manifest_sha256':source_digest,'frames':[],'render_seconds':0.}

    def capture(self, env: Any, step_index: int) -> None:
        from PIL import Image
        before=[np.asarray(getattr(env.sim.data,n)).tobytes() for n in ('qpos','qvel','ctrl')]
        time_before=float(env.sim.data.time)
        rng=json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str)
        start=time.perf_counter()
        pixels=env.sim.render(width=768,height=768,camera_name=self.camera)[::-1].copy()
        self.manifest['render_seconds']+=time.perf_counter()-start
        after=[np.asarray(getattr(env.sim.data,n)).tobytes() for n in ('qpos','qvel','ctrl')]
        if before!=after or time_before!=float(env.sim.data.time) or rng!=json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str):
            raise RuntimeError('frame capture changed active input/RNG')
        path=self.directory/f'frame_{step_index:06d}.png'
        if path.exists():raise ValueError('frame would overwrite prior evidence')
        Image.fromarray(pixels).save(path)
        self.manifest['frames'].append({'physical_step_index':step_index,'simulation_time_s':float(env.sim.data.time),
            'path':path.name,'sha256':sha256(path.read_bytes()).hexdigest()})
        temp=self.directory/'manifest.tmp';temp.write_text(json.dumps(self.manifest,indent=2));temp.replace(self.directory/'frames.json')


def verified_frames(path: Path) -> dict:
    value=json.loads(path.read_text())
    if value.get('scope')!='native_post_execute_frames' or not value.get('frames'):
        raise ValueError('actual native post-execute frames are required')
    frames=value['frames']
    for i,frame in enumerate(frames):
        p=(path.parent/frame['path']).resolve()
        if not p.is_relative_to(path.parent.resolve()) or sha256(p.read_bytes()).hexdigest()!=frame['sha256']:
            raise ValueError('frame identity mismatch')
        if i and frame['physical_step_index']!=frames[i-1]['physical_step_index']+1:
            raise ValueError('missing executed frame')
    return value


def compare_videos(left: Path, right: Path, left_start: int, right_start: int, output: Path) -> None:
    a,b=verified_frames(left),verified_frames(right)
    identity=lambda x:{k:v for k,v in x['case'].items() if k not in ('setting','record_video')}
    if identity(a)!=identity(b):raise ValueError('different native case identities')
    for manifest,index in ((a,left_start),(b,right_start)):
        if index not in {f['physical_step_index'] for f in manifest['frames']}:raise ValueError('explicit alignment frame missing')
    deltas=[np.diff([f['simulation_time_s'] for f in x['frames']]) for x in (a,b)]
    if any(len(d)==0 for d in deltas) or not all(np.allclose(d,deltas[0][0],rtol=0,atol=1e-8) and np.all(d>0) for d in deltas):
        raise ValueError('uniform matching simulation timestamps required; no temporal interpolation')
    ffmpeg=shutil.which('ffmpeg')
    if not ffmpeg:raise RuntimeError('ffmpeg unavailable; original frames preserved')
    if output.exists() or output.with_suffix('.alignment.json').exists():raise ValueError('exclusive video output required')
    output.parent.mkdir(parents=True,exist_ok=True)
    rate=str(1./float(deltas[0][0]))
    subprocess.run([ffmpeg,'-n','-framerate',rate,'-start_number',str(left_start),'-i',str(left.parent/'frame_%06d.png'),
        '-framerate',rate,'-start_number',str(right_start),'-i',str(right.parent/'frame_%06d.png'),
        '-filter_complex','[0:v][1:v]hstack=inputs=2:shortest=1','-c:v','libx264','-pix_fmt','yuv420p',str(output)],check=True)
    output.with_suffix('.alignment.json').write_text(json.dumps({'left_manifest_sha256':sha256(left.read_bytes()).hexdigest(),
        'right_manifest_sha256':sha256(right.read_bytes()).hexdigest(),'left_start_step':left_start,'right_start_step':right_start,
        'layout':'left = first input; right = second input','no_interpolation':True,'video_sha256':sha256(output.read_bytes()).hexdigest()},indent=2))
