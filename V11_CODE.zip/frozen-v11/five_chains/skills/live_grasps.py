"""Current-asset static pad preparation on a private native MuJoCo model.

Geometric proposals and static contact checks are not pretrained predictions or
physical success. They must pass normal IK, scene planning and live grasp checks.
"""
from __future__ import annotations
from copy import copy
from typing import Any
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose,inverse
from five_chains.envs.asset_geometry import collision_boxes_world


def free_content_attitudes(goal: np.ndarray, access_frame: np.ndarray) -> tuple[np.ndarray,...]:
    """Orientation-free contents: fixed center/height, nominal first.

    Access-frame quarter turns provide side-entry options when a downward
    acquired hand would put the wrist above the cavity. No upright/tilt
    constrained payload may use this search.
    """
    result=[goal.copy()]
    for axis in (access_frame[:3,0],access_frame[:3,1]):
        for angle in (np.pi/2,-np.pi/2):
            candidate=goal.copy()
            candidate[:3,:3]=Rotation.from_rotvec(axis*angle).as_matrix()@goal[:3,:3]
            result.append(candidate)
    return tuple(result)


def gravity_support_cost(contacts: list[dict], com: np.ndarray,
                         gravity_force: np.ndarray, scale_m: float) -> float | None:
    """Minimum uniform per-pad normal load in an 8-ray point-contact model.

    Only a quasi-static ranking diagnostic. No torsional pad couple, preload,
    dynamics, finite patch pressure, or actuator-capacity certificate is implied.
    Native contact/friction inputs are not edited. None means this reduced model
    cannot balance the supplied wrench; it does not prove physical impossibility.
    """
    from scipy.optimize import linprog
    rays = []; sides = []
    if not contacts or scale_m <= 0:
        return None
    for contact in contacts:
        frame = np.asarray(contact['frame'], dtype=float)
        normal = float(contact['sign']) * frame[0]
        arm = np.asarray(contact['point'], dtype=float) - com
        for theta in np.linspace(0., 2.*np.pi, 8, endpoint=False):
            force = normal + float(contact['mu']) * (np.cos(theta)*frame[1] + np.sin(theta)*frame[2])
            rays.append(np.r_[force, np.cross(arm, force)/scale_m])
            sides.append(int(contact['side']))
    matrix = np.asarray(rays).T
    upper = np.zeros((2, len(rays)+1)); upper[:, -1] = -1.
    for index, side in enumerate(sides):
        upper[side, index] = 1.
    result = linprog(np.r_[np.zeros(len(rays)), 1.], A_ub=upper, b_ub=np.zeros(2),
                     A_eq=np.column_stack((matrix, np.zeros(6))),
                     b_eq=np.r_[-gravity_force, np.zeros(3)], bounds=(0., None), method='highs')
    return float(result.fun) if result.success else None


def transverse_grasp_candidates(candidates: list[np.ndarray], opening_local: np.ndarray,
                                limit_m: float) -> list[tuple[np.ndarray, np.ndarray]]:
    """Sample the previously omitted contact-plane direction within edit bounds."""
    result=[]
    tangent_local=np.cross([0.,0.,1.],opening_local)
    norm=float(np.linalg.norm(tangent_local))
    if norm<=1e-10:raise ValueError('opening and approach must be independent')
    tangent_local/=norm
    shifts=[0.] + [sign*distance for distance in (.0025,.005,.0075,.01,.0125)
                    if distance<=limit_m for sign in (-1.,1.)]
    for base in candidates:
        for shift in shifts:
            proposal=base.copy();proposal[:3,3]+=shift*(base[:3,:3]@tangent_local)
            result.append((proposal,base.copy()))
    return result


class CurrentAssetGrasps:
    def __init__(self, adapter: Any, config: dict, original: Any) -> None:
        self.adapter=adapter;self.config=config;self.original=original
        self.cache: dict[tuple,tuple[np.ndarray,...]]={};self.records: list[tuple[np.ndarray,dict]]=[]
        self.prepared_points: dict[tuple[str,bytes],np.ndarray]={}
        self.probes=0;self.rejected: list[dict[str,Any]]=[]
        self.inferred: list[tuple[np.ndarray,dict[str,Any]]]=[]

    def candidates(self, entity: str, world: Any) -> tuple[np.ndarray,...]:
        signatures=world.signals.get('grasp_signatures',{})
        if (world.signals.get('grasp_modes',{}).get(entity)=='rim' and
            signatures.get('objects',{}).get(entity)==getattr(self.original,'meta',{}).get('shape_sha256')):
            return self.original.candidates(entity,world)
        key=(entity,signatures.get('objects',{}).get(entity),signatures.get('gripper'),str(signatures.get('T_actual_gripper_root_TCP')))
        if key in self.cache:return self.cache[key]
        result=self._prepare(entity,world);self.cache[key]=result
        return result

    def _network_candidates(self, entity: str, world: Any) -> list[np.ndarray]:
        import hashlib,json,subprocess,fcntl
        from five_chains.paths import legacy_root, gpu_lock, work_root
        from pathlib import Path
        from five_chains.envs.asset_geometry import collision_surface
        root=Path(__file__).resolve().parents[2]
        base=Path(self.config['grasp'].get('online_cache_directory',str(work_root()/'graspgen_cache')))
        shape=world.signals['grasp_signatures']['objects'][entity];directory=base/shape
        directory.mkdir(parents=True,exist_ok=True)
        path=directory/'candidates.npz';metadata=directory/'candidates.json'
        if not metadata.exists():
            points=collision_surface(self.adapter.env,entity,4096,2710)
            tcp=world.signals['grasp_signatures']['T_actual_gripper_root_TCP']
            geometry=directory/'geometry.npz'
            np.savez_compressed(geometry,points_object_m=points,T_actual_gripper_root_TCP=np.asarray(tcp))
            asset=dict(entity=entity,shape_sha256=shape,gripper_sha256=world.signals['grasp_signatures']['gripper'],
                T_actual_gripper_root_TCP=tcp,geometry_sha256=hashlib.sha256(geometry.read_bytes()).hexdigest(),
                extent_m=world.entities[entity].extent.tolist(),scope='compiled collision mesh development input; no control steps')
            (directory/'asset.json').write_text(json.dumps(asset,indent=2))
            legacy=legacy_root(self.config['selector'])
            command=[str(legacy/'.graspgen-env/bin/python'),'-B',str(root/'scripts/infer_graspgen.py'),'--input',str(geometry),
                '--output',str(path),'--legacy-root',str(legacy),'--count','128','--seed','2711']
            lockpath=gpu_lock(self.config['selector'],base);lockpath.parent.mkdir(exist_ok=True,parents=True)
            import os
            child_env=dict(os.environ)
            child_env['PYTHONPATH']=str(legacy/'third_party/graspgen_source')+os.pathsep+str(legacy)
            for key in ('LD_PRELOAD','LD_LIBRARY_PATH','MUJOCO_GL','PYOPENGL_PLATFORM'):child_env.pop(key,None)
            with lockpath.open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX)
                with (directory/('inference_'+str(len(list(directory.glob('inference*.log'))))+'.log')).open('x') as stream:
                    subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=child_env,check=True,timeout=300)
        info=json.loads(metadata.read_text())
        if (info['shape_sha256']!=shape or info['gripper_sha256']!=world.signals['grasp_signatures']['gripper'] or
            not np.allclose(info['T_actual_gripper_root_TCP'],world.signals['grasp_signatures']['T_actual_gripper_root_TCP'],atol=1e-6) or
            info['candidate_sha256']!=hashlib.sha256(path.read_bytes()).hexdigest()):raise ValueError('regenerated proposal signature mismatch')
        support=world.signals.get('object_support_frames',{}).get(entity)
        enclosed=support in world.signals.get('enclosed_support_entities',())
        with np.load(path,allow_pickle=False) as data:poses=np.array(data['T_O_actual_TCP']);scores=np.array(data['confidence'])
        result=[]
        for index in np.argsort(-scores)[:64]:
            if scores[index]<.5:continue
            target=poses[index];approach=(world.entities[entity].pose_world@target)[:3,2]
            if enclosed:
                if approach@world.entities[support].pose_world[:3,1]<.7:continue
            elif -approach[2]<np.cos(self.config['grasp']['max_top_approach_tilt_rad']):continue
            result.append(target.copy())
            self.inferred.append((target.copy(),dict(provider=info['provider'],confidence=float(scores[index]),
                source_candidate_index=int(index),candidate_sha256=info['candidate_sha256'],input_geometry_sha256=info['geometry_sha256'],
                checkpoint_sha256=info['checkpoint_sha256'],score_scope='raw pretrained proposal score; bounded contact edits are not rescored',
                inference_metadata=str(metadata))))
        return result

    def _prepare(self, entity: str, world: Any) -> tuple[np.ndarray,...]:
        import mujoco
        adapter=self.adapter;env=adapter.env;source=env.sim.model._model
        # Native plant/model arrays are never written. Only this private copy is repositioned.
        model=copy(source)
        if np.shares_memory(model.body_pos,source.body_pos) or np.shares_memory(model.geom_contype,source.geom_contype):
            raise RuntimeError('static grasp model must own independent mutable storage')
        data=mujoco.MjData(model);initial=np.asarray(env.sim.data.qpos).copy()
        data.qpos[:]=initial;mujoco.mj_forward(model,data)
        gripper=adapter.robot.gripper[adapter.arm];obj=env.objects[entity]
        gid=lambda name:int(mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,name))
        bid=lambda name:int(mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,name))
        target_ids={gid(n) for n in obj.contact_geoms};grip_ids=set(map(int,adapter.gripper_collision_ids))
        names={i:mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_GEOM,i) or '' for i in grip_ids}
        pads=[{i for i,n in names.items() if f'finger{side}_pad_collision' in n} for side in (1,2)]
        if any(len(p)!=1 for p in pads):raise ValueError('current-asset preparation requires two native pad collision geoms')
        nonpads=grip_ids-(pads[0]|pads[1])
        keep=np.array(sorted(target_ids|grip_ids),int)
        ct=model.geom_contype[keep].copy();ca=model.geom_conaffinity[keep].copy()
        model.geom_contype[:]=0;model.geom_conaffinity[:]=0
        model.geom_contype[keep]=ct;model.geom_conaffinity[keep]=ca
        # The reduced static query measures only own-object/pad geometry;
        # fixtures and arm are still checked by the full live scene planner.
        root=bid(gripper.root_body);parent=int(model.body_parentid[root])
        parent_pose=pose(data.xpos[parent],data.xmat[parent].reshape(3,3))
        root_pose=pose(data.xpos[root],data.xmat[root].reshape(3,3))
        tcp=adapter.current_pose();root_tcp=inverse(root_pose)@tcp
        object_pose=world.entities[entity].pose_world
        joint_ids=[int(mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,n)) for n in gripper.joints]
        if len(joint_ids)!=2 or any(model.jnt_type[j]!=2 for j in joint_ids):raise ValueError('unverified gripper joints')
        indices=[int(model.jnt_qposadr[j]) for j in joint_ids]
        opened=np.array([model.jnt_range[j][np.argmax(np.abs(model.jnt_range[j]))] for j in joint_ids])
        cfg=self.config['grasp']['contact_refinement']
        object_body=bid(obj.root_body)
        descendants=[]
        for index in range(model.nbody):
            ancestor=index
            while ancestor and ancestor!=object_body:ancestor=int(model.body_parentid[ancestor])
            if ancestor==object_body:descendants.append(index)
        mass=float(sum(model.body_mass[descendants]))
        if mass<=0:raise ValueError('grasp ranking requires positive native object mass')
        com_world=sum(model.body_mass[index]*data.xipos[index] for index in descendants)/mass
        com_object=object_pose[:3,:3].T@(com_world-object_pose[:3,3])
        gravity_force_object=mass*object_pose[:3,:3].T@model.opt.gravity
        length_scale=max(float(np.max(world.entities[entity].extent)),1e-6)
        def probe(contact):
            target=object_pose@contact@inverse(root_tcp);local=inverse(parent_pose)@target
            model.body_pos[root]=local[:3,3]
            quat=Rotation.from_matrix(local[:3,:3]).as_quat();model.body_quat[root]=quat[[3,0,1,2]];model.body_sameframe[root]=0
            for fraction in np.linspace(1.,0.,int(cfg['apertures'])):
                self.probes+=1;data.qpos[:]=initial;data.qpos[indices]=opened*fraction;mujoco.mj_forward(model,data)
                sides=[[],[]];nonpad=0.;wrenches=[]
                for c in data.contact[:data.ncon]:
                    a,b=int(c.geom1),int(c.geom2)
                    if (a in nonpads and b in target_ids) or (b in nonpads and a in target_ids):nonpad=max(nonpad,-float(c.dist))
                    for side,group in enumerate(pads):
                        if a in group and b in target_ids:pad=a
                        elif b in group and a in target_ids:pad=b
                        else:continue
                        offset=data.geom_xmat[pad].reshape(3,3).T@(c.pos-data.geom_xpos[pad])
                        frame=np.asarray(c.frame).reshape(3,3)
                        wrenches.append(dict(side=side,point=(object_pose[:3,:3].T@(c.pos-object_pose[:3,3])).tolist(),
                            frame=(frame@object_pose[:3,:3]).tolist(),sign=1. if b in target_ids else -1.,mu=float(c.friction[0])))
                        sides[side].append(dict(offset=float(offset[2]),margin=float(model.geom_size[pad,2]-abs(offset[2])),penetration=max(0.,-float(c.dist))))
                if all(sides):
                    contacts=[max(s,key=lambda p:p['margin']) for s in sides]
                    return dict(contacts=contacts,nonpad_penetration_m=nonpad,opening_fraction=float(fraction),
                        opening_axis_object=object_pose[:3,:3].T@data.xaxis[joint_ids[0]],wrenches=wrenches)
            return None
        item=world.entities[entity];support=world.signals.get('object_support_frames',{}).get(entity)
        enclosed=support in world.signals.get('enclosed_support_entities',())
        opening_local=np.asarray(world.signals.get('gripper_opening_axis_eef',[1.,0.,0.]),float).copy()
        opening_local[2]=0.;opening_local/=np.linalg.norm(opening_local)
        local_basis=np.column_stack([opening_local,np.cross([0.,0.,1.],opening_local),[0.,0.,1.]])
        raw=[]
        if enclosed:
            fixture=world.entities[support];approach=fixture.pose_world[:3,1].copy();approach[2]=0.;approach/=np.linalg.norm(approach)
            opening=np.cross(approach,[0.,0.,1.]);opening/=np.linalg.norm(opening)
            for sign in (1.,-1.):
                r=np.column_stack([opening*sign,np.cross(approach,opening*sign),approach])@local_basis.T
                for depth in (-.08,-.06,-.04,-.02,0.,.02):
                    for lateral in (0.,-.02,.02):
                        for height in (0.,-.015,.015):
                            center=object_pose[:3,3]+approach*depth+opening*lateral+[0,0,height]
                            raw.append(inverse(object_pose)@pose(center,r))
        else:
            from five_chains.skills.recipes import GeometricGraspProvider
            if world.signals.get('grasp_modes',{}).get(entity)=='rim':
                from copy import deepcopy
                for tilt in (0.,.3,.5):
                    cfg2=deepcopy(self.config);cfg2['grasp']['rim_approach_tilt_rad']=tilt
                    for t in GeometricGraspProvider(cfg2).candidates(entity,world):
                        for dz in (0.,-.015,.015):
                            extra=t.copy();extra[2,3]+=dz;raw.append(extra)
            else:
                raw=list(GeometricGraspProvider(self.config).candidates(entity,world))
                for t in tuple(raw):
                    for dz in (-.015,.015):
                            extra=t.copy();extra[2,3]+=dz;raw.append(extra)
        anchors: dict[bytes,np.ndarray]={}
        if not enclosed and world.signals.get('grasp_modes',{}).get(entity)!='rim':
            expanded=transverse_grasp_candidates(raw,opening_local,cfg['max_total_shift_m'])
            raw=[candidate for candidate,_ in expanded]
            anchors={candidate.tobytes():base for candidate,base in expanded}
        if self.config['grasp'].get('online_graspgen',False):raw=self._network_candidates(entity,world)+raw
        admitted=[]
        for original in raw:
            t=original.copy();anchor=anchors.get(original.tobytes(),original);record=None;reason='iteration_limit'
            for _ in range(int(cfg['iterations'])):
                record=probe(t)
                if record is None:reason='no_bilateral_pad_geometry';break
                left,right=record['contacts'];offsets=[left['offset'],right['offset']]
                if abs(offsets[0]-offsets[1])>cfg['max_depth_disagreement_m']:reason='opposite_pad_ends';break
                imbalance=left['penetration']-right['penetration']
                if np.linalg.norm(t[:3,3]-anchor[:3,3])>cfg['max_total_shift_m']+1e-12:reason='shift_bound';break
                if (min(left['margin'],right['margin'])>=cfg['min_pad_margin_m'] and abs(imbalance)<=cfg['max_imbalance_m']
                    and max(left['penetration'],right['penetration'])<=cfg['max_penetration_m'] and record['nonpad_penetration_m']<=cfg['max_nonpad_penetration_m']):
                    normal_load=gravity_support_cost(record['wrenches'],com_object,gravity_force_object,length_scale)
                    admitted.append(t.copy())
                    points=collision_boxes_world(model,data,np.array(sorted(grip_ids),int))
                    self.prepared_points[(entity,t.tobytes())]=(points-object_pose[:3,3])@object_pose[:3,:3]
                    origin=next((meta.copy() for candidate,meta in self.inferred if np.allclose(candidate,original,atol=1e-7)),{})
                    if 'provider' in origin:origin['proposal_provider']=origin.pop('provider')
                    self.records.append((t.copy(),dict(provider='current-asset geometric proposal + private native pad check',
                        physical_success_verified=False,source_shape=world.signals['grasp_signatures']['objects'][entity],
                        contact_margins_m=[left['margin'],right['margin']],opening_fraction=record['opening_fraction'],
                        contact_edit_from_raw_m=(t[:3,3]-anchor[:3,3]).tolist(),
                        gravity_support=dict(reduced_model_feasible=normal_load is not None,
                            minimum_normal_per_pad_n=normal_load,mass_kg=mass,com_object_m=com_object.tolist(),
                            gravity_force_object_n=gravity_force_object.tolist(),contacts=record['wrenches'],
                            scope='8-ray friction point contacts at first bilateral aperture; ranking only, no holding guarantee'),
                        approach_policy='cabinet_front' if enclosed else 'top',scope='static own-object contact geometry, not scene path or holding validation',**origin)))
                    break
                depth=float(np.clip(np.mean(offsets),-cfg['max_depth_step_m'],cfg['max_depth_step_m']))
                shift=float(np.clip(imbalance/2,-cfg['max_lateral_step_m'],cfg['max_lateral_step_m']))
                t[:3,3]+=depth*t[:3,2]+shift*record['opening_axis_object']
                if np.linalg.norm(t[:3,3]-anchor[:3,3])>cfg['max_total_shift_m']:reason='shift_bound';break
            else:reason='iteration_limit'
            if not admitted or not np.allclose(admitted[-1],t,atol=1e-7):
                self.rejected.append(dict(reason=reason,contacts=None if record is None else record['contacts'],nonpad_penetration_m=None if record is None else record['nonpad_penetration_m']))
        return tuple(admitted)

    def filter_for_followup(self,entity,world,candidates,target,goal_object_world):
        keys=[(entity,t.tobytes()) for t in candidates]
        points=tuple(self.prepared_points[k] for k in keys) if all(k in self.prepared_points for k in keys) else None
        return self.original.filter_for_followup(entity,world,candidates,target,goal_object_world,candidate_points_object=points)

    def free_content_pose(self, entity: str, world: Any, goal: np.ndarray, access: str) -> np.ndarray:
        """C6 read-only whole-arm endpoint query for unconstrained contents.

        Only private MjData changes. C10 must still plan and execute the actual
        arm path under the original bounds and precision.
        """
        from five_chains.envs.scene_path import StaticScene
        from five_chains.envs.pose_ik import forward_command
        from five_chains.geometry import rigid
        goal=rigid(goal);solver=self.adapter.posture_solver
        held={n:np.asarray(t) for n,t in world.signals.get('grasp_transforms',{}).items()}
        if solver is None or entity not in held:return goal.copy()
        model=self.adapter.env.sim.model._model;qpos=np.asarray(world.signals['robot_kinematic_qpos'])
        parent=self.config['control']['posture_ik'];cfg=parent['path_planning']
        joints={n:self.adapter.env.sim.model.joint_name2id(o.joints[0]) for n,o in self.adapter.env.objects.items()}
        scene=StaticScene(model,solver.site,solver.qpos)
        scene.configure(qpos,held,joints,entity,None,None,cfg['penetration_epsilon_m'])
        records=[];chosen=None
        for index,candidate in enumerate(free_content_attitudes(goal,world.entities[access].pose_world)):
            target=candidate@inverse(held[entity]);rng=np.random.default_rng(cfg['seed']);clear=0;solved=0
            for attempt in range(cfg['goal_seeds']):
                seed=qpos.copy()
                if attempt:seed[solver.qpos]=rng.uniform(solver.lower,solver.upper)
                result=solver.solve(target,seed)
                if result.success and forward_command(target,solver.forward(qpos,result.joints),parent['position_tolerance_m'],self.config['control']['reached_rad']) is not None:
                    solved+=1
                    if scene.valid(np.asarray(result.joints)):
                        clear+=1;break
            records.append(dict(candidate_index=index,strict_ik=solved,clear_ik=clear))
            if clear:chosen=candidate;break
        self.last_free_content_diagnostic=dict(entity=entity,access_frame=access,records=records,
            admitted=chosen is not None,selected_index=None if chosen is None else records[-1]['candidate_index'],
            object_center_and_height_unchanged=True,
            scope='private whole-arm endpoint geometry only; C10 path/live native success still required')
        return goal.copy() if chosen is None else chosen.copy()

    def stability_rank(self, matrix: np.ndarray) -> tuple[int,float]:
        info=self.describe(matrix).get('gravity_support')
        # All original candidates remain available for bounded native IK/path
        # repair. Missing diagnostics preserve the original ordering.
        return (0,float(info['minimum_normal_per_pad_n'])) if info is not None and info['reduced_model_feasible'] else (1,0.)

    def describe(self, matrix):
        for candidate,record in self.records:
            if np.allclose(candidate,matrix,atol=1e-7):return record
        return self.original.describe(matrix) if hasattr(self.original,'describe') else {'provider':'geometric'}
