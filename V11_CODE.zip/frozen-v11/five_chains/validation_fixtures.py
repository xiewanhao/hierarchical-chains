"""Zero-native-physics component cases. Synthetic input is never native evidence."""
from __future__ import annotations
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
from typing import Any
import numpy as np
from five_chains.build import build_components
from five_chains.config import load_config
from five_chains.components.c11_selector import ScriptedSelector
from five_chains.envs.kinematic_testbed import KinematicTestbed
from five_chains.geometry import pose
from five_chains.types import SkillCall, ChainId, FeedbackDelta, ReflexBounds
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.c3_feedback import chain3a_fast, chain3b_full
from five_chains.chains.c4_vision import chain4_vision
from five_chains.runtime import run_episode
from five_chains.trace import Tracer, serial
from five_chains.validation_protocol import apply_setting, CASE_SETTINGS


def expected_fields(contract: Any, changed_keys: frozenset[str]) -> dict:
    return {'vision':sorted(n for n,s in contract.fields.items() if ChainId.VISION in s.writable_by and s.depends_on & changed_keys),
        'fast':sorted(n for n,s in contract.fields.items() if ChainId.FB_FAST in s.writable_by and s.kind.value=='scalar')}


def observed_fixture() -> dict:
    return {'state':{'entities':{n:{'pose_world':pose(p),'extent':[.03]*3,'joints':{}} for n,p in
        {'vegetable':[.2,0,.8],'bowl':[.4,0,.8],'microwave':[.6,.2,1.],
         'microwave_interior':[.6,.2,1.],'handle':[.5,.2,1.],'start':[.65,.2,1.]}.items()},
        'eef_pose_world':pose([.2,0,1.]),'base_pose_world':np.eye(4),'gripper_width':.08,
        'signals':{'predicates':{},'continuous':{}}}}


def geometry_comparison(cfg: dict, tracer: Any) -> dict:
    outputs=[];counts=[]
    for full in (False,True):
        env=KinematicTestbed(cfg)
        c=build_components(env,ScriptedSelector([]),deepcopy(cfg),tracer)
        world=c.c4.update(observed_fixture())
        contract,p6,p7,_=chain1_prep(SkillCall('geometry',1,'local_pose_servo',{'reference':'bowl'}),world,c)
        observation=observed_fixture();observation['state']['entities']['bowl']['pose_world'][0,3]+=.05
        moved=c.c4.update(observation)
        before=c.c6.recipe_calls
        new_p6,proposal=chain4_vision(contract,p6,p7,moved,c,full)
        assert proposal is not None
        outputs.append(proposal.updates)
        counts.append(c.c6.recipe_calls-before)
    equivalent=outputs[0].keys()==outputs[1].keys() and all(
        np.array_equal(outputs[0][n].value,outputs[1][n].value) for n in outputs[0])
    return {'equivalent':equivalent,'sparse_recipe_calls':counts[0],'full_recipe_calls':counts[1],
        'scope':'independent synthetic component instances; extra full work not committed to any runtime'}


def run_fixture(case: str, setting: str, output: Path) -> dict:
    if case not in CASE_SETTINGS or setting not in CASE_SETTINGS[case]:
        raise ValueError('fixture case/setting is not applicable')
    output.mkdir(parents=True,exist_ok=False)
    cfg=load_config();apply_setting(cfg,setting)
    trace=Tracer(output/'ticks.jsonl')
    trace.write({'kind':'run_manifest','evidence_level':'V0_component_fixture','case':case,'setting':setting,
        'native_environment_created':False,'native_physical_steps':0,'selector_mode':'synthetic_fixture_only'})
    cfg['reflex']['enabled']=True
    env=KinematicTestbed(cfg);c=build_components(env,ScriptedSelector([]),cfg,trace)
    c_audit=trace.audit
    c_audit.loop_tick=0
    assertions={}
    details: dict[str,Any]={}
    try:
        world=c.c4.update(observed_fixture())
        call=SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})
        contract,p6,p7,prep=chain1_prep(call,world,c)
        packet,_=c.c10.arbitrate(None,[prep],contract,c.c12)
        if case=='preparation':
            assertions['required_preparations_readable']=all(p6.fields[n].status in ('bound','ready') for n,s in contract.fields.items() if s.required)
        elif case=='fast':
            delta=FeedbackDelta(1,(),{'eef_track_err':.03})
            proposal=None if setting in ('disable_c3a','freeze_after_prep') else chain3a_fast(contract,packet,delta,c,cfg)
            updated=packet if proposal is None else c.c10.arbitrate(packet,[proposal],contract,c.c12)[0]
            actual=updated.params['stiffness_scale'].value
            assertions['fast_expected_write']=(proposal is not None)==(setting not in ('disable_c3a','freeze_after_prep'))
            assertions['original_physical_bounds']=bool(.5<=actual<=1.5)
            if proposal is not None:assertions['parameter_increased']=bool(actual>packet.params['stiffness_scale'].value)
        elif case=='geometry':
            moved_obs=observed_fixture();moved_obs['state']['entities']['bowl']['pose_world'][0,3]+=.05
            moved=c.c4.update(moved_obs)
            before=p7
            proposal=None if setting in ('disable_c4','freeze_after_prep') else chain4_vision(contract,p6,p7,moved,c)[1]
            assertions['phase_preserved']=p7==before
            assertions['vision_expected_fields']=proposal is None if setting in ('disable_c4','freeze_after_prep') else (proposal is not None and sorted(proposal.updates)==expected_fields(contract,moved.changed_keys)['vision'])
            if proposal is not None:c.c10.arbitrate(packet,[proposal],contract,c.c12)
            if setting=='shadow_full_equivalent':
                details['comparison']=geometry_comparison(cfg,trace)
                assertions['full_output_equivalent']=details['comparison']['equivalent']
                assertions['full_extra_work_measured']=details['comparison']['full_recipe_calls']>=details['comparison']['sparse_recipe_calls']
        elif case=='relation':
            relation=pose([.02,0,0]);held=replace(world,signals={**world.signals,'grasp_transforms':{'vegetable':relation}})
            call=SkillCall('held',3,'place_object_in_container',{'object':'vegetable','target':'bowl'})
            contract,p6,p7,prep=chain1_prep(call,held,c)
            held_packet,_=c.c10.arbitrate(None,[prep],contract,c.c12)
            index=next(i for i,p in enumerate(contract.phases) if p.name=='carry');p7=replace(p7,phase_index=index,phase_name='carry')
            original=c.c8.readout(contract,p6,p7,held,frozenset(('place_pose',)),ChainId.FB_FULL)['place_pose'].value
            moved_relation=pose([.025,0,0]);moved=replace(held,stamp=1,signals={**held.signals,'grasp_transforms':{'vegetable':moved_relation}})
            delta=FeedbackDelta(1,('grasp_relation_changed',),{})
            if setting in ('phase_only_no_parameter_update','freeze_after_prep'):
                new_p6,new_p7,proposal=p6,c.c7.update(contract,p7,moved,delta),None
                assertions['parameter_work_skipped']=proposal is None
            else:
                new_p6,new_p7,proposal=chain3b_full(contract,p6,p7,moved,delta,c)
                assertions['measured_relation_readout']=proposal is not None and np.allclose(proposal.updates['place_pose'].value@moved_relation,original@relation)
                assertions['source_lift_not_reanchored']=proposal is not None and 'lift_pose' not in proposal.updates
                if proposal is not None:
                    committed,rejected=c.c10.arbitrate(held_packet,[proposal],contract,c.c12)
                    assertions['relation_update_adopted']=not rejected and all(committed.params[n] is p for n,p in proposal.updates.items())
            assertions['destination_p6_fixed']=new_p6 is p6
            assertions['no_false_phase_advance']=new_p7.phase_index==p7.phase_index
        elif case=='reflex_stop':
            override=None if setting=='disable_c2' else c.c9.step(packet.bounds,{'state':{'signals':{'unexpected_contact':True}}})
            assertions['stop_only_when_enabled']=(override is not None and override.kind=='stop')==(setting!='disable_c2')
            if override is not None:
                action=c.c10.solve(packet,contract,p7,world,override)
                assertions['stop_routes_current_reference']=np.array_equal(action[:16].reshape(4,4),world.eef_pose_world)
        elif case=='reflex_gripper':
            bounds=ReflexBounds(.003,.03,None,True,(1.,3.),.002)
            commands: list[float | None]=[]
            for load in (.5,2.,4.):
                signals={'native_motion_diagnostics':{'gripper_reference_feedback':{
                    'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,
                    'pad_normal_loads_n':[load,load],'reference_width_m':.02,'measured_width_m':.05,
                    'open_step_width_m':.001,'actuator_kp_n_m':[10000.,10000.],'joint_frictionloss_n':[0.,0.]}}}
                override=None if setting=='disable_c2' else c.c9.step(bounds,{'state':{'signals':signals}})
                commands.append(None if override is None else override.gripper_action)
            expected_commands: list[float | None]=[None]*3 if setting=='disable_c2' else [1.,0.,-1.]
            assertions['load_branches']=commands==expected_commands
            details['commands']=commands;details['native_load_source']='synthetic fixture of the native schema, not a measured load'
        elif case=='demand':
            matrix={}
            fixture_held=replace(world,signals={**world.signals,'grasp_transforms':{'vegetable':np.eye(4)}})
            target=world.entities['bowl'].pose_world.copy();target[0,3]+=.05
            moved=replace(fixture_held,stamp=1,changed_keys=frozenset(('bowl.pose',)),
                entities={**world.entities,'bowl':replace(world.entities['bowl'],pose_world=target,stamp=1)})
            for layer,skill,bindings in [(3,'place_object_in_container',{'object':'vegetable','target':'bowl'}),
                (2,'maintain_container_attitude',{'object':'vegetable'}),(1,'local_pose_servo',{'reference':'bowl'})]:
                bound,prepared,phase,initial_proposal=chain1_prep(SkillCall('demand_'+str(layer),layer,skill,bindings),fixture_held,c)
                current,_=c.c10.arbitrate(None,[initial_proposal],bound,c.c12)
                matrix[str(layer)]=expected_fields(bound,frozenset(('bowl.pose',)))
                _,vision=chain4_vision(bound,prepared,phase,moved,c)
                fast=chain3a_fast(bound,current,FeedbackDelta(1,(),{'eef_track_err':.03}),c,cfg)
                matrix[str(layer)]['actual_vision']=sorted(vision.updates) if vision else []
                matrix[str(layer)]['actual_fast']=sorted(fast.updates) if fast else []
                assertions['layer_'+str(layer)+'_actual_matches_declared']=(matrix[str(layer)]['actual_vision']==matrix[str(layer)]['vision'] and matrix[str(layer)]['actual_fast']==matrix[str(layer)]['fast'])
                selected=[p for p in (vision,fast) if p is not None]
                if selected:
                    _,rejected=c.c10.arbitrate(current,selected,bound,c.c12)
                    assertions['layer_'+str(layer)+'_adoption_permitted']=not rejected
            assertions['l2_declares_shared_fast_stiffness']=matrix['2']['fast']==['stiffness_scale']
            assertions['l3_target_dependency']=set(matrix['3']['vision'])=={'place_pose','base_at_target'}
            assertions['l1_reference_dependency']=matrix['1']['vision']==['local_target']
            details['matrix']=matrix
        elif case in ('reselection','joint'):
            cfg['control']['max_ticks']=12;cfg['control']['posture_ik']['path_planning']['enabled']=True
            cfg.setdefault('replan', {})['max_reselections']=0 if setting=='max_reselections_0' else 1
            decisions=[]
            class Selector:
                def select(self,task: str,obs: dict,history: list) -> SkillCall:
                    decisions.append((env.executions,deepcopy(obs['state']['signals']),list(history)))
                    return SkillCall('decision_'+str(len(decisions)),1,'local_pose_servo',{'reference':'bowl'})
            def path(target: Any,world: Any,key: Any,*args: Any,**kwargs: Any) -> Any:
                setattr(env,'motion_failure','no_clear_goal' if key[0]=='decision_1' else None)
                return target
            setattr(env,'prepare_motion_path',path)
            setattr(env,'success',lambda:env.executions>=3)
            c=build_components(env,Selector(),cfg,trace)
            def observe(tick: int,obs: dict,ctx: Any,components: Any) -> dict:
                if case=='joint' and tick==2:
                    obs=deepcopy(obs)
                    obs['state']['signals']['unexpected_contact']=True
                    obs['state']['signals']['continuous']['eef_track_err']=.03
                    obs['state']['signals']['predicates']['test_event']=True
                    obs['state']['entities']['bowl']['pose_world'][0,3]+=.05
                    trace.write({'kind':'perturbation','perturbation_id':'joint_fixture','loop_tick':tick,
                        'view':'synthetic_fixture_only','name':'joint_observation','magnitude':{'tracking_m':.03,'reference_m':.05}})
                    trace.audit.cause_ids=['joint_fixture']
                return obs
            episode=run_episode(env,'synthetic_fixture',c,cfg,trace,perturb=observe)
            enabled=setting!='max_reselections_0'
            assertions['reselection_expected_calls']=len(decisions)==(2 if enabled else 1)
            assertions['no_step_during_reselection']=not enabled or decisions[1][0]==0
            assertions['failure_not_success_history']=not enabled or decisions[1][2]==[]
            details['fixture_result']=serial(episode)
            details['strict_native_joint_status']='NOT_OBSERVED'
        else:raise ValueError('unknown fixture case')
        for name,passed in assertions.items():trace.write({'kind':'case_assertion','name':name,'passed':bool(passed)})
        result={'case':case,'setting':setting,'evidence_level':'V0_component_fixture','native_physical_steps':0,
            'assertions':{k:bool(v) for k,v in assertions.items()},'details':details,
            'passed':bool(assertions) and all(bool(x) for x in assertions.values())}
    except BaseException as exc:
        trace.write({'kind':'case_assertion','name':'case_completed','passed':False})
        result={'case':case,'setting':setting,'passed':False,'native_physical_steps':0,'error':repr(exc)}
        raise
    finally:
        trace.close(locals().get('result',{'passed':False}))
    (output/'result.json').write_text(__import__('json').dumps(serial(result),indent=2))
    return result
