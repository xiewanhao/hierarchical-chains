"""Machine paths are configuration; resolving them does not create directories."""
from __future__ import annotations
import os
from copy import deepcopy
from pathlib import Path
from typing import Any


def legacy_root(config: dict | None = None) -> Path:
    value = os.environ.get('HC_LEGACY_ROOT') or (config or {}).get('legacy_root')
    if not value:
        raise ValueError('set HC_LEGACY_ROOT or selector.legacy_root before external model I/O')
    path = Path(value).expanduser().resolve()
    if not path.is_dir():
        raise ValueError('legacy root does not exist: ' + str(path))
    return path


def work_root() -> Path:
    return Path(os.environ.get('HC_WORK_DIR') or Path(__file__).resolve().parents[1] / 'work').expanduser().resolve()


def gpu_lock(config: dict, output: str | Path) -> Path:
    return Path(config.get('gpu_lock_path') or Path(output) / 'neural_gpu.lock').resolve()


def runtime_paths(config: dict[str, Any], output: str | Path) -> dict[str, Any]:
    cfg = deepcopy(config)
    destination = Path(output).resolve()
    cfg['selector']['legacy_root'] = str(legacy_root(cfg['selector']))
    cfg['selector']['gpu_lock_path'] = str(destination / 'neural_gpu.lock')
    if cfg['grasp'].get('online_graspgen', False):
        cfg['grasp']['online_cache_directory'] = str(destination / 'asset_cache')
    return cfg
