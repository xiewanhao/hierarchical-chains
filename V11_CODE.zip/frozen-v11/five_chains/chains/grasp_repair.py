"""Bounded C3 parameter repair after an observed C10 acquisition planning failure."""
from __future__ import annotations
from dataclasses import replace
from typing import Any
from five_chains.geometry import rigid
from five_chains.preparation import decode_preparation
from five_chains.types import RuntimeContext, Components, WorldState, FeedbackDelta, ReadoutError
from five_chains.chains.c3_feedback import chain3b_full


def repair_world(world: WorldState, ctx: RuntimeContext) -> WorldState:
    if ctx.contract is None or not ctx.grasp_rejections:
        return world
    return replace(world, signals={**world.signals, 'grasp_candidate_rejections': {
        'contract_id': ctx.contract.contract_id,
        'contacts_object': [t.copy() for t in ctx.grasp_rejections]}})


def retry_grasp(ctx: RuntimeContext, C: Components, world: WorldState,
                reason: str, cfg: dict, tracer: Any) -> bool:
    settings = cfg['grasp']['parameter_repair']
    if (cfg.get('chain_validation', {}).get('phase_only_no_parameter_update', False)
            or reason not in ('motion_path:no_clear_goal', 'motion_path:search_exhausted')
            or cfg['ablation']['freeze_after_prep'] or 'c3b_fb_full' in cfg['ablation']['disable_chains']
            or len(ctx.grasp_rejections) >= settings['max_attempts']):
        return False
    contract, p6, p7 = ctx.contract, ctx.p6, ctx.p7
    if contract is None or p6 is None or p7 is None or ctx.packet is None:
        return False
    phase = contract.phases[p7.phase_index]
    obj = contract.call.bindings.get('object')
    diagnostic = world.signals.get('grasp_diagnostics', {}).get(obj)
    if (phase.name not in ('approach', 'descend') or phase.gripper != 'open'
            or world.gripper_width < settings['min_open_width_m']
            or world.signals.get('grasp_transforms') or diagnostic is None
            or any(diagnostic.get(k, False) for k in
                ('native_bilateral_grasp', 'left_finger_contact', 'right_finger_contact', 'retention_estimate'))
            or 'grasp_pose' not in p6.fields or p6.fields['grasp_pose'].status != 'ready'):
        return False
    prep = p6.fields['grasp_pose']
    contact = rigid(decode_preparation(contract.fields['grasp_pose'], prep.value,
        prep.provenance['translation_reference_m']))
    ctx.grasp_rejections.append(contact.copy())
    event = FeedbackDelta(world.stamp, ('grasp_candidate_rejected',), {})
    tracer.write({'kind': 'grasp_candidate_rejected', 'contract_id': contract.contract_id,
        'phase': phase.name, 'stamp': world.stamp, 'reason': reason,
        'attempt': len(ctx.grasp_rejections), 'contact_pose_object': contact,
        'gripper_width': world.gripper_width, 'contact_diagnostic': diagnostic})
    try:
        next_p6, next_p7, proposal = chain3b_full(contract, p6, p7, repair_world(world, ctx), event, C)
    except ReadoutError as error:
        tracer.write({'kind': 'grasp_repair_exhausted', 'contract_id': contract.contract_id,
            'stamp': world.stamp, 'reason': str(error)})
        return False
    assert proposal is not None
    packet, rejected = C.c10.arbitrate(ctx.packet, [proposal], contract, C.c12)
    if rejected:
        raise ReadoutError('grasp repair proposal rejected')
    ctx.p6, ctx.p7, ctx.packet = next_p6, next_p7, packet
    C.c5.rearm_grasp_entry()
    # Invalidate command/path caches only. No physics, selector call or reset.
    C.c10.reference_key = None
    for attr, value in (('motion_key', None), ('motion_path', ()), ('posture_key', None)):
        if hasattr(C.adapter, attr):
            setattr(C.adapter, attr, value)
    tracer.write({'kind': 'grasp_parameter_repaired', 'contract_id': contract.contract_id,
        'stamp': world.stamp, 'attempt': len(ctx.grasp_rejections), 'p7': next_p7,
        'updated_fields': sorted(proposal.updates), 'p6': next_p6})
    return True
