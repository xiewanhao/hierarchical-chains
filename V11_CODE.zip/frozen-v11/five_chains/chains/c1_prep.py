from __future__ import annotations
from five_chains.chain_audit import audit_chain
from five_chains.types import ChainId, SkillCall, WorldState, Components, Contract, P6, P7, Proposal


@audit_chain('c1_prep')
def chain1_prep(call: SkillCall, world: WorldState, C: Components) -> tuple[Contract, P6, P7, Proposal]:
    contract = C.c12.expand(call)
    contract = C.c12.initialize_entry(contract, world)
    p7 = P7.initial(contract)
    p6 = C.c6.prepare(contract, world, None, None, ChainId.PREP)
    params = C.c8.readout(contract, p6, p7, world, None, ChainId.PREP)
    return contract, p6, p7, Proposal(ChainId.PREP, params, C.c8.bounds(contract, p7, p6))
