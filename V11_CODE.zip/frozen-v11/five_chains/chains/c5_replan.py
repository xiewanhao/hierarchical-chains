from __future__ import annotations
from five_chains.chain_audit import audit_chain
from typing import Any
from five_chains.types import Contract, WorldState, SkillCall


@audit_chain('c5_replan')
def chain5_replan(contract: Contract, world: WorldState, reason: str, tracer: Any) -> SkillCall | None:
    tracer.log_failure(contract.contract_id, reason)
    if hasattr(tracer, "write"):
        tracer.write({"kind": "failure_state", "contract_id": contract.contract_id, "stamp": world.stamp,
                      "reason": reason, "signals": world.signals, "eef_pose_world": world.eef_pose_world,
                      "bound_object_pose": (world.entities[contract.call.bindings["object"]].pose_world
                          if contract.call.bindings.get("object") in world.entities else None)})
    return None
