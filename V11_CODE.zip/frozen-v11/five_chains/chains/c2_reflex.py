from __future__ import annotations
from five_chains.chain_audit import audit_chain
from five_chains.types import ParamPacket, Components, ReflexOverride


@audit_chain('c2_reflex')
def chain2_reflex(packet: ParamPacket, obs: dict, C: Components) -> ReflexOverride | None:
    return C.c9.step(packet.bounds, obs)
