from __future__ import annotations
from five_chains.chain_audit import audit_chain
from five_chains.types import ChainId, Contract, P6, P7, WorldState, Components, Proposal


@audit_chain('c4_vision')
def chain4_vision(contract: Contract, p6: P6, p7: P7, world: WorldState,
                  C: Components, full_recompute: bool = False) -> tuple[P6, Proposal | None]:
    affected = frozenset(name for name, spec in contract.fields.items()
                         if C.c12.may_write(contract, name, ChainId.VISION)
                         and (full_recompute or spec.depends_on & world.changed_keys))
    if not affected:
        return p6, None
    if full_recompute:
        # Recompute all preparation/readout work as the expensive ablation, while
        # preserving write permissions and the current phase.
        p6 = C.c6.prepare(contract, world, None, None, ChainId.PREP)
        all_params = C.c8.readout(contract, p6, p7, world, None, ChainId.PREP)
        from dataclasses import replace
        updates = {n: replace(p, source_chain=ChainId.VISION) for n, p in all_params.items() if n in affected}
    else:
        p6 = C.c6.prepare(contract, world, p6, affected, ChainId.VISION)
        updates = C.c8.readout(contract, p6, p7, world, affected, ChainId.VISION)
    return p6, Proposal(ChainId.VISION, updates, C.c8.bounds(contract,p7,p6))
