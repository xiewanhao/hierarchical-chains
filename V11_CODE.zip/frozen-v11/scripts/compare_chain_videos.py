from pathlib import Path
import argparse,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.validation_media import compare_videos
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('left',type=Path);p.add_argument('right',type=Path)
    p.add_argument('--left-start',type=int,required=True);p.add_argument('--right-start',type=int,required=True)
    p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    compare_videos(a.left,a.right,a.left_start,a.right_start,a.output)
