"""One preregistered native intervention episode; separate from benchmark rates."""
from __future__ import annotations
import argparse
from dataclasses import asdict
from hashlib import sha256
import inspect
import json
from pathlib import Path
import signal
import sys
import time
import traceback
from typing import Any
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from five_chains.build import build_components
from five_chains.config import load_config
from five_chains.components.c11_selector import SubprocessSelectorAdapter
from five_chains.envs.multitask_adapter import MultiTaskAdapter
from five_chains.envs.robocasa_adapter import make_environment
from five_chains.native_validation import configure, control_configuration, DemandSelector, NativeInterventions
from five_chains.paths import runtime_paths, legacy_root
from five_chains.runtime import run_episode
from five_chains.trace import serial
from five_chains.validation_protocol import source_manifest, manifest_digest, verify_legacy_files
from five_chains.validation_media import FrameRecorder
from evaluate_episode import EvalTrace, BudgetSelector, InspectPreparer


class NativeTrace(EvalTrace):
    def start_recording(self) -> None:
        if hasattr(self,'ready_recorder'):
            self.frame_recorder = self.ready_recorder

    def log_tick(self, *args: Any, **kwargs: Any) -> None:
        super().log_tick(*args,**kwargs)
        if self.rows % 10 == 0:
            temp = self.directory/'progress.tmp'
            temp.write_text(json.dumps(self.last_tick))
            temp.replace(self.directory/'progress.json')


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--registration',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    reg = json.loads(args.registration.read_text())
    source = source_manifest(root); source_digest = manifest_digest(source)
    if reg.get('schema') != 'native_chain_case/v1' or reg.get('source_manifest_sha256') != source_digest:
        raise ValueError('registration does not match frozen source')
    if reg.get('workers') != 1 or reg.get('wall_budget_seconds') != 1200:
        raise ValueError('original serial/wall budget required')
    gate = reg['test_gate']
    if gate.get('source_manifest_sha256') != source_digest or not gate.get('pytest_passed') or not gate.get('mypy_passed'):
        raise ValueError('matching complete tests/mypy required')
    for key in ('pytest','mypy'):
        p = Path(gate[key+'_log'])
        if sha256(p.read_bytes()).hexdigest() != gate[key+'_sha256']:
            raise ValueError('test evidence hash mismatch')
    verify_legacy_files(root/'configs/protected_legacy.json',legacy_root())
    case = reg['case']; output = args.output.resolve(); output.mkdir(parents=True,exist_ok=False)
    cfg = runtime_paths(control_configuration(root,case),output)
    cfg['environment'].update(task=case['task'],seed=case['seed'],layout_and_style_ids=[[case['layout'],case['style']]],render=True)
    configure(cfg,case)
    (output/'registration.json').write_text(json.dumps(reg,indent=2))
    (output/'source_manifest.json').write_text(json.dumps(source,indent=2))
    (output/'effective_config.json').write_text(json.dumps(cfg,indent=2))
    tracer = NativeTrace(output); start = time.time(); env = None; adapter = None; C = None; hook = None; steps = 0; model = None
    result = {'success':False,'status':'initializing','reason':'not_started','case':case,
        'evidence_level':'V3_native_intervention','source_manifest_sha256':source_digest,
        'registration_sha256':sha256(args.registration.read_bytes()).hexdigest(),'task_rate_eligible':False}
    tracer.write({'kind':'run_manifest',**result,'case':case['probe'],'native_case':case,'setting':case['setting']})
    def alarm(signum: int, frame: Any) -> None:
        raise TimeoutError('original_1200s_wall_budget')
    signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,1200)
    try:
        env = make_environment(cfg); adapter = MultiTaskAdapter(env,cfg)
        initial = adapter.observe(adapter._initial_obs)
        if adapter.success():raise ValueError('initial native task already successful')
        np.savez_compressed(output/'initial_physical_state.npz',qpos=np.asarray(env.sim.data.qpos),qvel=np.asarray(env.sim.data.qvel))
        (output/'initial_metadata.json').write_text(json.dumps(serial(env.get_ep_meta()),indent=2))
        result['initial_native_success'] = False
        result['initial_signature'] = adapter.initial_signature()
        result['initial_entities'] = sorted(initial['state']['entities'])
        native_file = Path(inspect.getfile(type(env)))
        result['native_task_source_sha256'] = sha256(native_file.read_bytes()).hexdigest()
        raw_step = env.step
        def audit_step(action: Any) -> tuple:
            nonlocal steps
            caller = sys._getframe(1)
            if caller.f_code.co_name != 'execute' or caller.f_globals.get('__name__') != 'five_chains.components.c10_executor':
                raise RuntimeError('only C10.execute may step the live plant')
            value = raw_step(action);steps += 1
            return value
        env.step = audit_step
        def builder(task: str, obs: dict, history: list) -> dict:
            return adapter.selector_sample(task,obs,history,output/f'camera_{0 if model is None else model.calls:03d}.png')
        model = BudgetSelector(SubprocessSelectorAdapter(cfg['selector'],builder,output/'selector'),10)
        selector = DemandSelector(model)
        C = build_components(adapter,selector,cfg,tracer); C.c6 = InspectPreparer(C.c6,tracer)
        hook = NativeInterventions(case,cfg,env,adapter,tracer,output,selector)
        if case.get('record_video',True):
            tracer.ready_recorder = FrameRecorder(output/'frames',case,source_digest,cfg['environment']['selector_camera'])
            tracer.video_env = env
        result.update(asdict(run_episode(env,adapter.instruction(),C,cfg,tracer,hook)),status='completed')
    except Exception as error:
        result.update(status='error',reason=repr(error),traceback=traceback.format_exc())
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        result.update(audited_env_steps=steps,executions=0 if C is None else C.c10.executions,
            tick_rows=tracer.rows,actual_model_calls=0 if model is None else model.calls,
            elapsed_seconds=time.time()-start,last_tick=tracer.last_tick)
        if hook is not None:result['validation'] = hook.result()
        if adapter is not None:
            result['native_success_at_end'] = bool(adapter.success())
            np.savez_compressed(output/'terminal_physical_state.npz',qpos=np.asarray(env.sim.data.qpos),qvel=np.asarray(env.sim.data.qvel))
            result['metadata'] = adapter.metadata()
        result['step_audit_passed'] = steps == result['executions'] == tracer.rows
        result['source_unchanged'] = source == source_manifest(root)
        result['success'] = bool(result['success'] and result.get('native_success_at_end') and not result.get('initial_native_success',True))
        verify_legacy_files(root/'configs/protected_legacy.json',legacy_root())
        tracer.close(result)
        (output/'result.json').write_text(json.dumps(serial(result),indent=2))
        if env is not None:env.close()
    print(json.dumps({k:result.get(k) for k in ('status','reason','success','audited_env_steps','actual_model_calls','validation','step_audit_passed')},default=serial),flush=True)
    if result['status']=='error' or not result['step_audit_passed'] or not result['source_unchanged']:
        raise SystemExit(1)


if __name__ == '__main__':main()
