"""Compatibility entry: serial schema-aware validation, no implicit scene creation."""
from run_chain_validation import main
if __name__=="__main__":main()
