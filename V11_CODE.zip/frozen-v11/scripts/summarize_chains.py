"""Read-only single-trace entry point."""
from __future__ import annotations
import argparse
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.chain_summary import summarize, write_outputs

def main() -> None:
    p=argparse.ArgumentParser();p.add_argument('trace',type=Path);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--evidence-level',choices=['V1_natural_trace','V0_component_fixture','V3_native','V3_native_intervention'],default='V1_natural_trace')
    p.add_argument('--expected-ticks',type=int);a=p.parse_args()
    result=summarize(a.trace,a.evidence_level,a.expected_ticks);write_outputs(result,a.output)
    if not result['trace_complete']:raise SystemExit(1)

if __name__=='__main__':main()
