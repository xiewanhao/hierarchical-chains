#!/usr/bin/env bash
set -euo pipefail
: "${HC_LEGACY_ROOT:?Set HC_LEGACY_ROOT to the preserved original project}"
RUNTIME_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
export HC_WORK_DIR="${HC_WORK_DIR:-$RUNTIME_ROOT/work}"
mkdir -p "$HC_WORK_DIR/.cache" "$HC_WORK_DIR/tmp"
export XDG_CACHE_HOME="$HC_WORK_DIR/.cache"
export NUMBA_CACHE_DIR="$HC_WORK_DIR/.cache/numba"
export TMPDIR="$HC_WORK_DIR/tmp"
export MUJOCO_GL=osmesa
export PYOPENGL_PLATFORM=osmesa
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
export LD_LIBRARY_PATH="$HC_LEGACY_ROOT/.runtime/robocasa_gl:$HC_LEGACY_ROOT/.runtime/libs/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PYTHONDONTWRITEBYTECODE=1 PYTHONHASHSEED=2000 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
exec "$HC_LEGACY_ROOT/.robocasa-env/bin/python" -B "$@"
