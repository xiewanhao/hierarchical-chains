"""Version-frozen development cases; never add them to a held-out rate."""
import argparse,concurrent.futures,json,os,signal,subprocess,time
from pathlib import Path
from evaluate_episode import sources

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--case',action='append',required=True)
    a=p.parse_args();root=Path(__file__).resolve().parents[1];out=root/a.output;out.mkdir(parents=True,exist_ok=False)
    frozen=sources(root);(out/'freeze.json').write_text(json.dumps(frozen,indent=2));started=time.time()
    def run(text):
        task,layout,seed=text.split(':');name=f'{task}_L{layout}_S{seed}';d=out/name
        cmd=['bash','scripts/remote_python.sh','scripts/evaluate_episode.py','--task',task,'--layout',layout,'--seed',seed,'--output',str(d)]
        with (out/(name+'.log')).open('x') as log:
            child=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            stat=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()
            (out/(name+'.process.json')).write_text(json.dumps({'pid':child.pid,'start_ticks':stat[19],'command':cmd}))
            timeout=False
            try:child.wait(timeout=1200)
            except subprocess.TimeoutExpired:
                timeout=True;os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        if (d/'result.json').exists():r=json.loads((d/'result.json').read_text())
        else:r={'task':task,'layout':int(layout),'seed':int(seed),'success':False,'reason':'wall_budget' if timeout else 'process_error'}
        r['case_id']=name;r['development_only']=True
        return r
    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        for future in concurrent.futures.as_completed([pool.submit(run,c) for c in a.case]):
            r=future.result();results.append(r)
            (out/'results.json').write_text(json.dumps(results,indent=2))
            print(json.dumps({k:r.get(k) for k in ('case_id','success','reason','audited_env_steps','actual_model_calls')}),flush=True)
    changed=[n for n,h in frozen.items() if sources(root).get(n)!=h]
    (out/'completed.json').write_text(json.dumps({'development_only':True,'completed':len(results),'source_changed':changed,'elapsed_seconds':time.time()-started},indent=2))
    if changed:raise RuntimeError('source revision changed during development cases')

if __name__=='__main__':main()
