"""Official pretrained inference on the exported asset; no training or stepping."""
from __future__ import annotations
import argparse,hashlib,json,os,sys,time
from pathlib import Path


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p.add_argument('--legacy-root',default=__import__('os').environ.get('HC_LEGACY_ROOT'))
    p.add_argument('--count',type=int,default=128);p.add_argument('--seed',type=int,default=2701);a=p.parse_args()
    if not a.legacy_root:raise ValueError("set HC_LEGACY_ROOT or --legacy-root")
    root=Path(a.legacy_root);out=Path(a.output);meta_path=out.with_suffix('.json')
    if out.exists() or meta_path.exists():raise FileExistsError('preserve previous inference')
    asset=json.loads((Path(a.input).parent/'asset.json').read_text())
    if digest(Path(a.input))!=asset['geometry_sha256']:raise ValueError('geometry provenance mismatch')
    sys.path.insert(0,str(root))
    from gpu_guard import select
    card=select(ignore_power=True);os.environ['CUDA_VISIBLE_DEVICES']=card['uuid']
    import numpy as np
    import torch
    from grasp_gen.grasp_server import GraspGenSampler,load_grasp_cfg
    torch.manual_seed(a.seed);np.random.seed(a.seed)
    folder=root/'pretrained/GraspGenPanda';cfg=load_grasp_cfg(str(folder/'graspgen_franka_panda.yml'))
    start=time.monotonic();sampler=GraspGenSampler(cfg);torch.cuda.synchronize()
    load_seconds=time.monotonic()-start
    with np.load(a.input,allow_pickle=False) as geometry:
        points=geometry['points_object_m'];tcp=geometry['T_actual_gripper_root_TCP']
    ids=np.random.default_rng(a.seed).choice(len(points),int(cfg.data.num_points),replace=len(points)<int(cfg.data.num_points))
    start=time.monotonic()
    with torch.inference_mode():
        grasps,scores=GraspGenSampler.run_inference(points[ids],sampler,grasp_threshold=-1.,
            num_grasps=a.count,topk_num_grasps=a.count,min_grasps=1,max_tries=1,remove_outliers=False)
    torch.cuda.synchronize();seconds=time.monotonic()-start
    poses=grasps.detach().cpu().numpy();scores=scores.detach().cpu().numpy()
    if poses.shape!=(len(scores),4,4) or not len(scores) or not np.isfinite(poses).all() or not np.isfinite(scores).all():
        raise ValueError('invalid official inference outputs')
    if not np.allclose(poses[:,:3,:3]@poses[:,:3,:3].transpose(0,2,1),np.eye(3),atol=1e-3):raise ValueError('invalid rotations')
    # The legacy measured mount correction is explicitly provisional. Physical
    # validation is still required and cannot be inferred from model confidence.
    mounting=np.eye(4);mounting[2,3]=.006
    mapped=poses@mounting@tcp
    np.savez_compressed(out,T_O_actual_TCP=mapped,confidence=scores,input_indices=ids)
    report={**asset,'provider':'official pretrained GraspGen Panda PTv3 diffusion/discriminator',
            'local_training':False,'physical_success_verified':False,'seed':a.seed,'count':len(scores),
            'candidate_sha256':digest(out),'checkpoint_sha256':{f.name:digest(f) for f in folder.iterdir() if f.is_file()},
            'mount_shift_m':.006,'mapping_scope':'legacy provisional mount alignment, subject to actual contact/holding verification',
            'model_load_seconds':load_seconds,'inference_seconds':seconds,'gpu':card,
            'score_range':[float(scores.min()),float(scores.max())]}
    meta_path.write_text(json.dumps(report,indent=2));print(json.dumps({k:v for k,v in report.items() if k not in ('ep_meta','checkpoint_sha256')}))


if __name__=='__main__':main()
