"""One serial entry for registered trace, component and gated native jobs."""
from __future__ import annotations
import argparse, csv, fcntl, hashlib, html, json, os, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from five_chains.validation_protocol import validate_protocol, native_evidence, source_manifest, manifest_digest
from five_chains.chain_summary import summarize, write_outputs
from five_chains.paths import work_root


def start_ticks(pid: int) -> str | None:
    p=Path('/proc',str(pid),'stat')
    if not p.exists():return None
    raw=p.read_text();return raw[raw.rfind(')')+2:].split()[19]


def native_job(job: dict, directory: Path, output: Path, wall_seconds: int) -> dict:
    receipt=native_evidence(job,directory,ROOT)
    command=['bash',str(ROOT/'scripts/remote_python.sh'),str(ROOT/'scripts/evaluate_episode.py'),
        '--task',job['task'],'--seed',str(job['seed']),'--layout',str(job['layout']),
        '--style',str(job['style']),'--output',str(output/'episode'),'--audit','--validation-setting',job['setting'],
        '--registration',str((directory/job['registration']).resolve()),'--preflight',str((directory/job['preflight']).resolve())]
    if job.get('record_video',False):command.append('--record-video')
    output.mkdir(exist_ok=False)
    with (output/'process.log').open('x') as stream:
        child=subprocess.Popen(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
        ticks=start_ticks(child.pid)
        process={'pid':child.pid,'start_ticks':ticks,'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
            'command':command,'evidence':receipt,'started_unix':time.time()}
        (output/'process.json').write_text(json.dumps(process,indent=2))
        try:child.wait(timeout=wall_seconds)
        except subprocess.TimeoutExpired:
            if ticks is not None and start_ticks(child.pid)==ticks:
                os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    if start_ticks(child.pid)==ticks:os.killpg(child.pid,signal.SIGKILL)
                    child.wait()
            raise RuntimeError('registered native job wall budget exceeded')
    process.update(returncode=child.returncode,finished_unix=time.time(),observed_start_ticks=start_ticks(child.pid))
    (output/'completion.json').write_text(json.dumps(process,indent=2))
    if child.returncode:raise RuntimeError('native worker failed')
    outcome=json.loads((output/'episode/result.json').read_text())
    result=summarize(output/'episode/ticks.jsonl.gz','V3_native')
    if outcome.get('status')!='completed' or outcome.get('changed_code_during_run') or outcome['audited_env_steps']!=outcome['executions'] or outcome['executions']!=result['recorded_tick_rows']:
        raise RuntimeError('native terminal/source/step audit failed')
    write_outputs(result,output/'summary')
    return {'id':job['id'],'passed':result['trace_complete'],'evidence_level':'V3_native','task_success':outcome['success']}



def aggregate_reports(jobs: list[dict], output: Path) -> None:
    records=[];timeline=[];columns=[]
    for job in jobs:
        base=output/job['id'];summary=base if job['mode']=='trace' else base/'summary'
        path=summary/'chain_validation.csv'
        if path.exists():
            with path.open(encoding='utf-8-sig',newline='') as stream:
                for row in csv.DictReader(stream):
                    columns=list(row.keys());records.append({'job_id':job['id'],'mode':job['mode'],**row})
        events=summary/'timeline.json'
        if events.exists():timeline.extend({'job_id':job['id'],**r} for r in json.loads(events.read_text()))
    keys=['job_id','mode']+columns
    with (output/'chain_validation.csv').open('x',encoding='utf-8-sig',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=keys);writer.writeheader();writer.writerows(records)
    (output/'timeline.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2))
    headings=['job_id','mode','chain','setting','evidence_level','trigger_records','actual_recipe_calls','status']
    body='<html><meta charset="utf-8"><title>Chain validation</title><style>body{font:15px/1.6 system-ui;margin:30px}table{border-collapse:collapse}td,th{border:1px solid #ccd;padding:7px}</style><h1>Chain validation</h1><p>Fixture PASS is synthetic component evidence. Old natural traces prove recorded behavior, not causal usefulness. No native joint pass or new task success is inferred.</p><p><a href="chain_validation.csv">Complete table</a> | <a href="timeline.json">Timeline</a> | <a href="completed.json">Terminal receipt</a></p><table><tr>'
    body+=''.join('<th>'+k+'</th>' for k in headings)+'</tr>'
    for row in records:body+='<tr>'+''.join('<td>'+html.escape(str(row.get(k,'')))+'</td>' for k in headings)+'</tr>'
    (output/'report.html').write_text(body+'</table></html>',encoding='utf-8')

def main(argv: list[str] | None = None) -> None:
    parser=argparse.ArgumentParser()
    parser.add_argument('--protocol',type=Path,default=ROOT/'protocol.json')
    parser.add_argument('--output',type=Path)
    parser.add_argument('--validate-only',action='store_true')
    parser.add_argument('--execute-native',action='store_true')
    args=parser.parse_args(argv)
    protocol_path=args.protocol.resolve()
    protocol=validate_protocol(json.loads(protocol_path.read_text()),protocol_path.parent)
    for job in protocol['jobs']:
        if job['mode']=='native':
            native_evidence(job,protocol_path.parent,ROOT)
            if not args.validate_only and not args.execute_native:raise ValueError('native execution requires --execute-native and valid evidence')
    if args.validate_only:
        print(json.dumps({'valid':True,'jobs':len(protocol['jobs']),'native_jobs':sum(j['mode']=='native' for j in protocol['jobs'])}));return
    if args.output is None:raise ValueError('--output is required for execution')
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=False)
    manifest=source_manifest(ROOT)
    (output/'run_manifest.json').write_text(json.dumps({'protocol':protocol,'protocol_sha256':hashlib.sha256(protocol_path.read_bytes()).hexdigest(),
        'source_manifest':manifest,'source_manifest_sha256':manifest_digest(manifest),'native_jobs_default':False},indent=2))
    work_root().mkdir(parents=True,exist_ok=True)
    results=[]
    with (work_root()/'chain_validation_suite.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        for job in protocol['jobs']:
            target=output/job['id']
            try:
                if job['mode']=='trace':
                    result=summarize((protocol_path.parent/job['trace']).resolve(),'V1_natural_trace',job['expected_ticks'])
                    write_outputs(result,target)
                    row={'id':job['id'],'passed':result['trace_complete'],'evidence_level':'V1_natural_trace'}
                elif job['mode']=='fixture':
                    from five_chains.validation_fixtures import run_fixture
                    row=run_fixture(job['case'],job['setting'],target)
                    row['id']=job['id']
                    result=summarize(target/'ticks.jsonl','V0_component_fixture')
                    write_outputs(result,target/'summary')
                    row['passed']=bool(row['passed'] and result['trace_complete'])
                else:row=native_job(job,protocol_path.parent,target,protocol['wall_budget_seconds'])
            except Exception as exc:
                row={'id':job['id'],'passed':False,'error':repr(exc),'mode':job['mode']}
            results.append(row)
            with (output/'results.jsonl').open('a') as stream:stream.write(json.dumps(row)+'\n')
            print(json.dumps({'id':job['id'],'passed':row['passed']}),flush=True)
    aggregate_reports(protocol['jobs'],output)
    unchanged=manifest==source_manifest(ROOT)
    terminal={'completed':len(results),'planned':len(protocol['jobs']),'all_passed':all(r['passed'] for r in results),
        'source_unchanged':unchanged,'native_jobs':sum(j['mode']=='native' for j in protocol['jobs']),
        'note':'component fixture PASS is not native rollout evidence; natural trace completeness is not causal usefulness'}
    (output/'completed.json').write_text(json.dumps(terminal,indent=2))
    if not unchanged or not terminal['all_passed']:raise SystemExit(1)


if __name__=='__main__':main()
