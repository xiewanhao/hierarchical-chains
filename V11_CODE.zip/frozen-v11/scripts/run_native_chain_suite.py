"""Serial fresh native cases, preregistration and automatic raw-log verdicts.

Example: bash scripts/remote_python.sh scripts/run_native_chain_suite.py
  --group heat_fast --test-gate /absolute/test_gate.json --output /new/evidence
Group gates never launch joint/demand work without an explicit passing Gate A.
"""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.validation_protocol import source_manifest, manifest_digest
from five_chains.native_validation_summary import inspect_native
from five_chains.chain_summary import summarize, write_outputs


def cases(group: str) -> list[dict]:
    if group=='steam_demand':
        result=[]
        for probe in ('demand_geometry','demand_fast','demand_tilt'):
            for layer in (3,2,1):
                result.append({'task':'SteamInMicrowave','layout':8,'style':34,'seed':2000,
                    'control_profile':'r46_known_steam','probe':probe,'setting':'normal',
                    'post_window':2,'record_video':True,'demand_layer':layer,
                    'target':'bowl','input_mode':'identical_raw_observation',
                    'acquire_object':'vegetable' if layer==3 else 'bowl',
                    'handoff_phase':'lift' if layer==3 else 'carry_reached',
                    **({'reference':'bowl','reference_bound':True} if layer==1 else {})})
        result.append({**result[2],'reference':'microwave_interior','reference_bound':False,
            'handoff_phase':'carry_reached'})
        return result
    base = {'task':'HeatMug','layout':11,'style':34,'seed':2012,'post_window':24,'record_video':True}
    probes = {'heat_fast':['fast'],'heat_stop':['reflex_stop'],'heat_prep':['preparation'],
              'coffee_fast':['fast'],'coffee_relation':['relation'],'steam_geometry':['geometry'],
              'steam_load':['reflex_gripper'],'steam_relation':['relation'],
              'heat_reselection':['reselection'],'steam_joint':['joint']}
    if group not in probes:raise ValueError('unknown registered native group')
    if group.startswith('coffee_'):base.update(task='PrepareCoffee',layout=8,seed=2000)
    if group.startswith('steam_'):base.update(task='SteamInMicrowave',layout=8,seed=2000,control_profile='r46_known_steam')
    if group=='steam_load':base.update(load_injection='qualified_observation',load_phase='raise_to_entry')
    if group=='steam_relation':base.update(relation_phase='carry',relation_object='bowl',relation_control_scope='whole_chain')
    settings = ['normal','off','full_recompute']
    if group=='heat_prep':settings=['normal','freeze_after_prep']
    if group=='steam_joint':settings=['normal']
    return [{**base,'probe':probe,'setting':setting,
             **({'full_recompute_mode':'literal_flag'} if setting=='full_recompute' else {})}
            for probe in probes[group] for setting in settings]


def main() -> None:
    p = argparse.ArgumentParser();p.add_argument('--group',required=True);p.add_argument('--test-gate',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--gate-a',type=Path)
    p.add_argument('--setting',choices=['normal','off','full_recompute','freeze_after_prep'])
    args = p.parse_args();root = Path(__file__).resolve().parents[1]
    if args.group in ('steam_joint','steam_demand'):
        if args.gate_a is None or not json.loads(args.gate_a.read_text()).get('all_single_chains_passed'):
            raise ValueError('joint/demand native work requires actual complete single-chain Gate A')
    jobs = cases(args.group)
    if args.setting is not None:
        jobs = [j for j in jobs if j['setting']==args.setting]
        if not jobs:raise ValueError('setting is not applicable to this group')
    source = manifest_digest(source_manifest(root))
    gate = json.loads(args.test_gate.read_text())
    if gate['source_manifest_sha256']!=source:raise ValueError('tests source mismatch')
    out = args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    outcomes = []
    for index,case in enumerate(jobs):
        suffix = f'_L{case["demand_layer"]}' if 'demand_layer' in case else ''
        identifier = f'{index:02d}_{case["probe"]}_{case["setting"]}{suffix}'
        reg = {'schema':'native_chain_case/v1','created_utc':datetime.now(timezone.utc).isoformat(),
            'case':case,'source_manifest_sha256':source,'workers':1,'wall_budget_seconds':1200,
            'test_gate':gate,'intervention_scope':'finite native diagnostic; not independent benchmark evidence'}
        registration = out/(identifier+'_registration.json')
        with registration.open('x') as f:json.dump(reg,f,indent=2)
        destination = out/identifier
        cmd = [sys.executable,'-B',str(root/'scripts/run_native_chain_episode.py'),
               '--registration',str(registration),'--output',str(destination)]
        with (out/(identifier+'.log')).open('x') as f:
            proc = subprocess.Popen(cmd,cwd=root,env=os.environ,stdout=f,stderr=subprocess.STDOUT)
            stat = Path(f'/proc/{proc.pid}/stat').read_text()
            receipt = {'pid':proc.pid,'start_ticks':stat[stat.rfind(')')+2:].split()[19],
                'registration':str(registration),'source_manifest_sha256':source,'command':cmd}
            (out/'active_worker.json').write_text(json.dumps(receipt,indent=2))
            status = proc.wait()
        if not (destination/'result.json').exists():
            raise RuntimeError('native worker ended without a complete result: '+identifier)
        summary = inspect_native(destination)
        (destination/'validation_summary.json').write_text(json.dumps(summary,indent=2))
        table = summarize(destination/'ticks.jsonl.gz','V3_native_intervention',summary['native_steps'])
        table['case_assertions'] = summary['checks']
        table['status'] = 'PASS' if summary['status']=='pass' and table['trace_complete'] else 'FAIL'
        table['verdict_scope'] = 'raw-log finite native case assertions; other chains remain unqualified by this case'
        write_outputs(table,destination/'chain_table')
        outcomes.append({'id':identifier,'exit_code':status,'summary':summary})
        (out/'suite_progress.json').write_text(json.dumps({'source_manifest_sha256':source,'outcomes':outcomes},indent=2))
        if status or summary['status']!='pass':
            break
    complete = len(outcomes)==len(jobs) and all(o['summary']['status']=='pass' for o in outcomes)
    same_inputs = {}
    if args.group=='steam_demand':
        for probe in ('demand_geometry','demand_fast','demand_tilt'):
            relevant=[o['summary'] for o in outcomes if o['summary']['case']['probe']==probe]
            signatures=[r['input_sha256'] for summary in relevant for r in summary.get('demand_inputs',[])]
            expected_count=4 if probe=='demand_geometry' else 3
            same_inputs[probe] = len(relevant)==len(signatures)==expected_count and len(set(signatures))==1
        complete = complete and all(same_inputs.values())
    (out/'suite_result.json').write_text(json.dumps({'group':args.group,'all_cases_passed':complete,
        'completed_cases':len(outcomes),'planned_cases':len(jobs),'source_manifest_sha256':source,
        'same_demand_input_signatures':same_inputs,'outcomes':outcomes},indent=2))
    print(json.dumps({'group':args.group,'all_cases_passed':complete,'completed_cases':len(outcomes),'planned_cases':len(jobs)}),flush=True)
    if not complete:raise SystemExit(1)


if __name__=='__main__':main()
