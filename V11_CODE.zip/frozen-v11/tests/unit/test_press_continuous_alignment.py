from dataclasses import replace
import numpy as np
import pytest
from five_chains.config import validate_config
from five_chains.types import ReflexOverride
from test_press_lateral_alignment import prepared


@pytest.mark.parametrize('lateral,axial',[(.02,.04),(.01199999,.04),(.01200001,.04),(.005,.07),(0.,.04),(.02,-.04)])
def test_continuous_alignment_retains_goal_and_original_motion_bounds(C,world,lateral,axial):
    c,p,packet,w,goal=prepared(C,world,lateral,axial)
    cfg=C.c10.config['control'];cfg['press_lateral_alignment']=True;cfg['press_continuous_alignment']=True
    C.c10.solve(packet,c,p,w,None);d=C.c10.reference_diagnostic
    assert np.array_equal(C.c10.last_target,goal) and np.array_equal(packet.params['press_pose'].value,goal)
    assert d['reference_policy']=='continuous_axial_weight'
    assert d['original_position_threshold_m']==.012
    step=C.c10.reference[:3,3]-w.eef_pose_world[:3,3]
    assert np.linalg.norm(step)<=float(packet.params['speed_limit'].value)/C.c10.adapter.control_freq+1e-12
    assert np.linalg.norm(step)<=cfg['max_tracking_lead_m']+1e-12
    assert np.allclose(C.c10.reference[:3,:3],goal[:3,:3])
    assert C.c10.last_error==pytest.approx(np.linalg.norm(step))
    if axial>0.:
        assert d['axial_weight']==pytest.approx(.012**2/(.012**2+lateral**2))
        assert step[2]>0.
    else:assert d['axial_weight']==1. and step[2]<0.


def test_continuous_reference_has_no_original_threshold_jump(C,world):
    from five_chains.components.c10_executor import Executor
    c,p,packet,w,goal=prepared(C,world,.012,.04)
    C.c10.config['control'].update(press_lateral_alignment=True,press_continuous_alignment=True)
    commands=[];targets=[]
    for offset in [-1e-8,1e-8]:
        executor=Executor(C.c10.adapter,C.c10.config)
        moved=w.eef_pose_world.copy();moved[0,3]-=offset
        executor.solve(packet,c,p,replace(w,eef_pose_world=moved),None)
        commands.append(executor.reference[:3,3]);targets.append(executor.reference_diagnostic['intermediate_target_world'][:3,3])
    assert np.linalg.norm(commands[1]-commands[0])<1e-7
    assert np.linalg.norm(targets[1]-targets[0])<1e-7


@pytest.mark.parametrize('override',[ReflexOverride('hold',None,'hold'),ReflexOverride('stop',None,'stop')])
def test_continuous_alignment_does_not_override_reflex(C,world,override):
    c,p,packet,w,goal=prepared(C,world)
    C.c10.config['control'].update(press_lateral_alignment=True,press_continuous_alignment=True)
    C.c10.solve(packet,c,p,w,override)
    assert not C.c10.reference_diagnostic and np.array_equal(C.c10.reference,w.eef_pose_world)


def test_continuous_alignment_requires_selected_skill_and_parent_option(C,world):
    c,p,packet,w,goal=prepared(C,world)
    C.c10.config['control'].update(press_lateral_alignment=False,press_continuous_alignment=True)
    C.c10.solve(packet,c,p,w,None);assert not C.c10.reference_diagnostic
    C.c10.config['control']['press_lateral_alignment']=True
    c=replace(c,call=replace(c.call,skill='other_skill'))
    C.c10.solve(packet,c,p,w,None);assert not C.c10.reference_diagnostic


def test_continuous_alignment_default_and_boolean_validation(cfg):
    assert cfg['control']['press_continuous_alignment'] is False
    cfg['control']['press_continuous_alignment']=1
    with pytest.raises(ValueError,match='continuous press alignment'):validate_config(cfg)
