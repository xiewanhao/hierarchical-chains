"""Contract and callback regressions. These are synthetic, not native evidence."""
from dataclasses import replace
import json
from pathlib import Path
import shutil
import numpy as np
import pytest
from five_chains.native_validation import configure, DemandSelector
from five_chains.components.c11_selector import ScriptedSelector
from five_chains.components.c12_contract import ContractDispatcher
from five_chains.types import SkillCall, ChainId, ContractConflict


@pytest.mark.parametrize('primary,layer,bindings',[
    ('place_object_in_container',3,{'object':'bowl','target':'microwave_interior'}),
    ('carry_container_to_region',3,{'object':'bowl','target':'microwave_interior'}),
    ('local_pose_servo',1,{'reference':'microwave_interior'})])
def test_only_identical_attitude_shared_feedback_scalar(primary,layer,bindings):
    d = ContractDispatcher(); aux = SkillCall('aux',2,'maintain_container_attitude',{'object':'bowl'})
    c = d.expand(SkillCall('main',layer,primary,bindings,(aux,)))
    assert c.fields['stiffness_scale'].writable_by == {ChainId.PREP,ChainId.FB_FAST}
    assert c.fields['stiffness_scale'].value_range == (.5,1.5)
    assert c.fields['tilt_limit'].default == [-.15,.15]


def test_incompatible_aux_scalar_still_rejected(tmp_path):
    d = ContractDispatcher(); shutil.copytree(d.templates,tmp_path/'templates')
    path = tmp_path/'templates/maintain_container_attitude.yaml'; raw = json.loads(path.read_text())
    raw['fields']['stiffness_scale']['value_range'] = [.5,2.]
    path.write_text(json.dumps(raw))
    aux = SkillCall('aux',2,'maintain_container_attitude',{'object':'bowl'})
    with pytest.raises(ContractConflict):
        ContractDispatcher(tmp_path/'templates').expand(SkillCall('p',3,'place_object_in_container',{'object':'bowl','target':'x'},(aux,)))


def test_l2_fast_feedback_is_now_declared(C,cfg,world):
    from five_chains.chains.c1_prep import chain1_prep
    from five_chains.chains.c3_feedback import chain3a_fast
    from five_chains.types import FeedbackDelta
    world = replace(world,signals={**world.signals,'grasp_transforms':{'bowl':np.eye(4)}})
    call = SkillCall('l2',2,'maintain_container_attitude',{'object':'bowl'})
    c,p6,p7,prop = chain1_prep(call,world,C)
    packet,_ = C.c10.arbitrate(None,[prop],c,C.c12)
    assert float(packet.params['stiffness_scale'].value) == 1.
    fast = chain3a_fast(c,packet,FeedbackDelta(world.stamp,(),{'eef_track_err':.03}),C,cfg)
    assert set(fast.updates) == {'stiffness_scale'}
    assert 1. < float(fast.updates['stiffness_scale'].value) <= 1.5


@pytest.mark.parametrize('probe,chain', [('fast','c3a_fb_fast'),('reflex_stop','c2_reflex')])
def test_off_controls_are_explicit(cfg,probe,chain):
    configure(cfg,{'probe':probe,'setting':'off'})
    assert chain in cfg['ablation']['disable_chains']
    assert cfg['control']['max_ticks'] == 6000


def test_no_preparation_disable_or_r50_application(cfg):
    with pytest.raises(ValueError):configure(cfg,{'probe':'preparation','setting':'off'})
    cfg['control']['close_reference_bridge_capture'] = True
    with pytest.raises(ValueError):configure(cfg,{'probe':'fast','setting':'normal'})


def test_demand_selector_only_uses_script_on_explicit_handoff():
    first = SkillCall('a',1,'local_pose_servo',{'reference':'bowl'})
    second = replace(first,call_id='b',layer=2,skill='maintain_container_attitude',bindings={'object':'bowl'})
    original = ScriptedSelector([first,first]); wrapper = DemandSelector(original)
    assert wrapper.select('',{},[]) == first
    wrapper.pending = ScriptedSelector([second])
    assert wrapper.select('',{},[]) == second and original.calls == 1
    assert wrapper.select('',{},[]) == first and original.calls == 2


def test_full_recompute_pose_view_never_synchronizes_live_controller(world):
    from five_chains.native_validation import PreparationSnapshotAdapter
    from types import SimpleNamespace
    def forbidden():raise AssertionError('live controller synchronization is prohibited in shadow C6')
    adapter = SimpleNamespace(env=object(),robot=object(),arm='right',gripper_collision_ids=np.array([2,3]),
                              posture_solver=None,current_pose=forbidden)
    view = PreparationSnapshotAdapter(adapter,world)
    assert np.array_equal(view.current_pose(),world.eef_pose_world)
    returned = view.current_pose();returned[0,3] += 100
    assert np.array_equal(view.current_pose(),world.eef_pose_world)
    assert view.posture_solver is None and not hasattr(view,'controller')


@pytest.mark.parametrize('when', ['before','after'])
def test_runtime_validation_stop_counts_actual_executions_only(cfg,tmp_path,when):
    from five_chains.build import build_components
    from five_chains.envs.kinematic_testbed import KinematicTestbed
    from five_chains.trace import Tracer
    from five_chains.runtime import run_episode
    env = KinematicTestbed(cfg); call = SkillCall('a',1,'local_pose_servo',{'reference':'bowl'})
    C = build_components(env,ScriptedSelector([call]),cfg)
    log = Tracer(tmp_path/'trace.jsonl')
    class Hook:
        stop_reason = 'validation_complete'
        def __call__(self,tick,obs,ctx,C):return obs
        def after_prepare(self,*args):pass
        def before_execute(self,tick,*args):return when == 'before' and tick == 3
        def after_execute(self,tick,*args):return when == 'after' and tick == 3
    result = run_episode(env,'synthetic_callback',C,cfg,log,Hook());log.close(result)
    assert not result.success and result.reason == 'validation_complete'
    assert C.c10.executions == env.executions == (3 if when == 'before' else 4)
    assert sum(json.loads(s)['kind']=='tick' for s in (tmp_path/'trace.jsonl').read_text().splitlines()) == env.executions


@pytest.mark.parametrize('setting',['normal','off','full_recompute'])
def test_recovery_callback_and_selection_stop_do_not_require_new_skill_entry(cfg,tmp_path,setting):
    from five_chains.build import build_components
    from five_chains.envs.kinematic_testbed import KinematicTestbed
    from five_chains.trace import Tracer
    from five_chains.runtime import run_episode
    cfg.setdefault('replan',{})['max_reselections'] = 0 if setting=='off' else 1
    env = KinematicTestbed(cfg)
    first = SkillCall('a',1,'local_pose_servo',{'reference':'bowl'})
    # The new L2 contract would reject absent grasp on initialize_entry.
    # Reselection proof stops before making that separate readiness claim.
    second = SkillCall('b',2,'maintain_container_attitude',{'object':'bowl'})
    C = build_components(env,ScriptedSelector([first,second]),cfg)
    log = Tracer(tmp_path/'trace.jsonl'); observed=[]
    class Hook:
        stop_reason = 'validation_complete'
        def __call__(self,tick,obs,ctx,C):
            if ctx.contract is not None and ctx.steps == 3:
                ctx.contract = replace(ctx.contract,termination=replace(ctx.contract.termination,timeout_steps=3))
            return obs
        def before_recovery(self,tick,contract,world,reason,ctx,C):
            observed.append(('recovery',C.c10.executions,reason))
        def after_select(self,tick,call,ctx,C):
            if ctx.selector_calls == 2:
                observed.append(('selection',C.c10.executions,call.call_id))
                return True
            return False
    result = run_episode(env,'synthetic_recovery_callback',C,cfg,log,Hook());log.close(result)
    assert env.executions == C.c10.executions == 3
    assert observed[0] == ('recovery',3,'contract_timeout')
    if setting=='off':
        assert result.reason == 'contract_failure:contract_timeout' and len(observed)==1
    else:
        assert result.reason == 'validation_complete' and observed[1]==('selection',3,'b')
    assert result.prep_calls == 1 and not result.success


def test_native_reselection_gate_uses_actual_call_signature_and_same_time():
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook = object.__new__(NativeInterventions); records=[]
    hook.reselection_from={'call_id':'old','skill':'local_pose_servo','bindings':{'reference':'bowl'},
                          'steps':5,'time':.25,'selections':1}
    hook.env=SimpleNamespace(sim=SimpleNamespace(data=SimpleNamespace(time=.25)))
    hook.tracer=SimpleNamespace(write=records.append)
    ctx=SimpleNamespace(selector_calls=2);C=SimpleNamespace(c10=SimpleNamespace(executions=5))
    with pytest.raises(RuntimeError):
        hook.after_select(6,SkillCall('newid',1,'local_pose_servo',{'reference':'bowl'}),ctx,C)
    assert not records[-1]['failed_signature_excluded']
    assert hook.after_select(6,SkillCall('newid',1,'local_pose_servo',{'reference':'microwave_interior'}),ctx,C)
    assert records[-1]['same_physical_state'] and not records[-1]['new_C1_readiness_claimed']


def test_timeout_full_recompute_runs_before_recovery_without_current_osc(world):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook = object.__new__(NativeInterventions); seen=[]
    hook.case={'probe':'reselection','setting':'full_recompute'}
    hook.reselection_from={'call_id':'old'};hook.last_executed_action=np.zeros(3)
    hook.provider=SimpleNamespace(capture=lambda action,scope:{'token':'bound_current_state_only'})
    hook.full_recompute=lambda *args:seen.append(args)
    contract=SimpleNamespace(call=SkillCall('old',1,'local_pose_servo',{'reference':'bowl'}),contract_id='old')
    ctx=SimpleNamespace(p7=SimpleNamespace(phase_name='track'))
    hook.before_recovery(5,contract,world,'contract_timeout',ctx,None)
    assert len(seen)==1 and seen[0][-1]=='before_timeout_recovery_no_current_command'
    assert seen[0][-2]=='bound_current_state_only'


def test_known_r46_profile_retains_control_values_and_portable_lock():
    from five_chains.native_validation import control_configuration
    root=Path(__file__).resolve().parents[2]
    case={'task':'SteamInMicrowave','control_profile':'r46_known_steam'}
    r46=control_configuration(root,case)
    current=control_configuration(root,{'task':'SteamInMicrowave'})
    flags=('strict_grasp_approach_tracking','strict_payload_alignment_tracking','grasp_approach_stall_refresh')
    for flag in flags:
        assert r46['control']['posture_ik']['path_planning'][flag] is False
    for key in ('reference_speed_m_s','reference_rotation_rad_s','max_tracking_lead_m','reached_m','reached_rad','max_ticks'):
        assert r46['control'][key]==current['control'][key]
    assert r46['reflex']==current['reflex'] and r46['base']==current['base']
    assert r46['selector']['gpu_lock_path'] is None
    with pytest.raises(ValueError):control_configuration(root,{**case,'task':'HeatMug'})


@pytest.mark.parametrize('band,expected', [((1.,3.),True),((2.,6.),False)])
def test_physical_load_probe_uses_measured_axis_without_forging_force(band,expected):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook=object.__new__(NativeInterventions);records=[];translations=[]
    hook.case={'probe':'reflex_gripper','setting':'normal','load_injection':'physical_microshift'}
    hook.handoff=False;hook.injected=False;hook.events=[];hook.tracer=SimpleNamespace(write=records.append)
    native={'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,
            'pad_normal_loads_n':[1.7,2.1]}
    eef=np.eye(4);eef[:3,:3]=[[0,-1,0],[1,0,0],[0,0,1]]
    obs={'state':{'eef_pose_world':eef,'signals':{'grasp_transforms':{'bowl':np.eye(4)},
        'gripper_opening_axis_eef':[1,0,0],'native_motion_diagnostics':{'gripper_reference_feedback':native}}}}
    def translate(tick,observed,ctx,name,entity,delta):
        translations.append((name,entity,delta));return observed
    hook.translate=translate
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('c',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})),
        p7=SimpleNamespace(phase_name='carry',steps_in_phase=6),packet=SimpleNamespace(bounds=SimpleNamespace(gripper_load_band_n=band)),executed_actuator='arm')
    result=hook(5,obs,ctx,None)
    assert bool(translations)==expected
    assert result['state']['signals']['native_motion_diagnostics']['gripper_reference_feedback']['pad_normal_loads_n']==[1.7,2.1]
    if expected:
        assert np.allclose(translations[0][2],[0,.0005,0],atol=1e-14,rtol=0)
        assert records[-1]['force_signal_overridden'] is False


def test_native_load_summary_never_credits_another_calls_recovery(tmp_path):
    from five_chains.native_validation_summary import inspect_native
    import gzip
    result={'case':{'probe':'reflex_gripper','setting':'normal','load_injection':'physical_microshift'},
        'evidence_level':'V0_component_fixture','source_unchanged':True,'step_audit_passed':False,
        'audited_env_steps':0,'reason':'validation_complete','validation':{'finite_window_completed':True},'success':False}
    (tmp_path/'result.json').write_text(json.dumps(result))
    rows=[{'kind':'perturbation','name':'load_micro_translation_0p5mm','tick':10,'call_id':'A','target':'bowl.pose'},
        {'kind':'tick','tick':10,'call_id':'A','triggers':['c2_reflex'],'reflex_bounds':{'gripper_load_band_n':[1.,3.]},
            'reflex':{'kind':'gripper_reference','gripper_action':1.},'native_motion_diagnostics':{'gripper_reference_feedback':{
                'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,'pad_normal_loads_n':[.5,2.]}}},
        {'kind':'native_probe_response','tick':10,'call_id':'B','native_gripper':{'closing_intent':True,
            'bilateral_native_pads':True,'pad_normal_loads_n':[2.,2.]}}]
    with gzip.open(tmp_path/'ticks.jsonl.gz','wt') as f:
        for r in rows:f.write(json.dumps(r)+'\n')
    summary=inspect_native(tmp_path)
    assert summary['checks']['actual_native'] is False
    assert summary['checks']['actual_native_underload_observed'] is True
    assert summary['checks']['native_load_returned_to_band'] is False


def test_qualified_observation_off_preserves_warmup_until_registered_input(cfg):
    configure(cfg,{'probe':'reflex_gripper','setting':'off','load_injection':'qualified_observation'})
    assert 'c2_reflex' not in cfg['ablation']['disable_chains']
    assert cfg['chain_validation']['disable_c2_from_registered_input'] is True


@pytest.mark.parametrize('probe,flag', [('relation','phase_only_from_registered_input'),
                                      ('geometry','disable_c4_from_registered_input')])
def test_native_parameter_ablation_starts_at_registered_physical_input(cfg,probe,flag):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    configure(cfg,{'probe':probe,'setting':'off'})
    assert cfg['chain_validation'][flag] is True
    assert not cfg['chain_validation'].get('phase_only_no_parameter_update',False)
    assert 'c4_vision' not in cfg['ablation']['disable_chains']
    hook=object.__new__(NativeInterventions);records=[]
    hook.case={'probe':probe,'setting':'off'};hook.cfg=cfg;hook.disabled_chains=set()
    hook.tracer=SimpleNamespace(write=records.append)
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('c',3,'place_object_in_container',{})))
    hook.control_boundary(20,ctx)
    assert (cfg['chain_validation'].get('phase_only_no_parameter_update',False) if probe=='relation'
            else 'c4_vision' in hook.disabled_chains)
    assert records==[{'kind':'native_control_boundary','tick':20,'call_id':'c',
        'chain':'c3b_fb_full' if probe=='relation' else 'c4_vision',
        'disabled_from_registered_input':True,'warmup_enabled':True,'phase_progression_enabled':True}]


@pytest.mark.parametrize('phase,field,expected', [('align_payload_outside','payload_alignment_pose',False),
                                                ('carry','place_pose',True),('carry','other',False)])
@pytest.mark.parametrize('setting',['normal','off'])
def test_geometry_input_requires_current_C10_place_field(cfg,phase,field,expected,setting):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook=object.__new__(NativeInterventions);translations=[]
    hook.case={'probe':'geometry','setting':setting};hook.handoff=False;hook.injected=False
    configure(cfg,hook.case);hook.disabled_chains=set()
    hook.events=[];hook.env=SimpleNamespace(objects={'bowl':object()});hook.cfg=cfg
    hook.tracer=SimpleNamespace(write=lambda r:None)
    hook.translate=lambda tick,obs,ctx,name,entity,delta:(translations.append((entity,delta)) or obs)
    call=SkillCall('c',3,'place_object_in_container',{'object':'vegetable','target':'bowl'})
    ctx=SimpleNamespace(contract=SimpleNamespace(call=call,phases=[SimpleNamespace(target_field=field)]),
        p7=SimpleNamespace(phase_name=phase,steps_in_phase=5,phase_index=0),
        packet=SimpleNamespace(params={'place_pose':object()}),executed_actuator='arm')
    obs={'state':{'signals':{'grasp_transforms':{'vegetable':np.eye(4)}}}}
    hook(10,obs,ctx,SimpleNamespace(c10=SimpleNamespace(last_target=np.eye(4))))
    assert bool(translations)==expected
    assert ('c4_vision' in hook.disabled_chains)==(expected and setting=='off')


@pytest.mark.parametrize('phase,steps,expected', [('base_to_clearance',9,False),
                                                ('raise_to_entry',2,False),('raise_to_entry',3,True)])
def test_registered_load_stage_is_online_not_a_saved_tick(cfg,phase,steps,expected):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook=object.__new__(NativeInterventions);events=[]
    hook.case={'probe':'reflex_gripper','setting':'normal','load_injection':'qualified_observation',
        'load_phase':'raise_to_entry'}
    hook.handoff=False;hook.injected=False;hook.events=[];hook.emit=lambda *a:events.append(a)
    native={'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,
        'pad_normal_loads_n':[2.,2.2],'actuator_kp_n_m':[1000.,1000.],'joint_frictionloss_n':[1.,1.],
        'reference_width_m':.064,'measured_width_m':.071,'open_step_width_m':.008}
    obs={'state':{'signals':{'grasp_transforms':{'vegetable':np.eye(4)},
        'native_motion_diagnostics':{'gripper_reference_feedback':native}}}}
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('c',3,'place_object_in_container',{'object':'vegetable'})),
        p7=SimpleNamespace(phase_name=phase,steps_in_phase=steps),packet=SimpleNamespace(bounds=SimpleNamespace(
            gripper_load_band_n=(1.,3.),gripper_preload_margin_m=.002)),executed_actuator='arm')
    hook(998,obs,ctx,None)
    assert bool(events)==expected and native['pad_normal_loads_n']==[2.,2.2]


@pytest.mark.parametrize('loads,gap,expected', [([2.,2.2],.006,True),([3.8,3.8],.008,False),([2.,2.],.002,False)])
def test_load_fault_overlay_never_fabricates_native_eligibility(loads,gap,expected):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook=object.__new__(NativeInterventions);records=[]
    hook.case={'probe':'reflex_gripper','setting':'off','load_injection':'qualified_observation'}
    hook.handoff=False;hook.injected=False;hook.events=[];hook.disabled_chains=set()
    hook.emit=lambda *args:records.append(args)
    native={'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,
        'pad_normal_loads_n':loads,'actuator_kp_n_m':[1000.,1000.],'joint_frictionloss_n':[1.,1.],
        'reference_width_m':.04,'measured_width_m':.04+gap,'open_step_width_m':.008}
    obs={'state':{'signals':{'grasp_transforms':{'bowl':np.eye(4)},'native_motion_diagnostics':{'gripper_reference_feedback':native}}}}
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('c',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})),
        p7=SimpleNamespace(phase_name='carry',steps_in_phase=6),packet=SimpleNamespace(bounds=SimpleNamespace(
            gripper_load_band_n=(1.,3.),gripper_preload_margin_m=.002)),executed_actuator='arm')
    result=hook(5,obs,ctx,None)
    assert bool(records)==expected
    assert bool(hook.disabled_chains)==expected
    assert native['pad_normal_loads_n']==loads
    if expected:assert result['state']['signals']['native_motion_diagnostics']['gripper_reference_feedback']['pad_normal_loads_n']==[.5,.5]


def test_same_cycle_injection_can_disable_reflex_without_disabling_warmup(cfg,tmp_path):
    from five_chains.build import build_components
    from five_chains.envs.kinematic_testbed import KinematicTestbed
    from five_chains.trace import Tracer
    from five_chains.runtime import run_episode
    from copy import deepcopy
    cfg['reflex']['enabled']=True;cfg['control']['max_ticks']=5
    env=KinematicTestbed(cfg);C=build_components(env,ScriptedSelector([SkillCall('a',1,'local_pose_servo',{'reference':'bowl'})]),cfg)
    log=Tracer(tmp_path/'trace.jsonl')
    class Hook:
        disabled_chains=set()
        def __call__(self,tick,obs,ctx,C):
            obs=deepcopy(obs)
            if tick in (1,3):obs['state']['signals']['unexpected_contact']=True
            if tick==3:self.disabled_chains.add('c2_reflex')
            return obs
    r=run_episode(env,'synthetic_delayed_ablation',C,cfg,log,Hook());log.close(r)
    rows=[json.loads(x) for x in (tmp_path/'trace.jsonl').read_text().splitlines()];ticks={x['tick']:x for x in rows if x['kind']=='tick'}
    assert ticks[1]['reflex']['kind']=='stop' and ticks[3]['reflex'] is None


@pytest.mark.parametrize('field,executed_hash,version,expected', [
    ('place_pose','action-A',2,True),('payload_alignment_pose','action-A',2,False),
    ('place_pose','other-action',2,False),('place_pose','action-A',3,False)])
def test_geometry_summary_requires_active_field_and_actual_executed_binding(tmp_path,field,executed_hash,version,expected):
    from five_chains.native_validation_summary import inspect_native
    import gzip
    result={'case':{'probe':'geometry','setting':'normal'},'evidence_level':'V0_component_fixture',
        'source_unchanged':True,'step_audit_passed':True,'audited_env_steps':1,
        'reason':'validation_complete','validation':{'finite_window_completed':True},'success':False}
    before={'name':field,'value':[0.],'source_chain':'c1_prep','stamp':0}
    after={'name':field,'value':[.05],'source_chain':'c4_vision','stamp':10}
    rows=[{'kind':'perturbation','name':'target_5cm','tick':10,'call_id':'A','target':'bowl.pose','phase':'carry'},
        {'kind':'tick','tick':10,'call_id':'A','phase':'carry','triggers':['c4_vision'],
         'writes':[{'chain':'c4_vision','name':field}],'changed_keys':['bowl.pose'],'parameters':{field:after}},
        {'kind':'native_target_before_input','tick':10,'call_id':'A','target_field':field,
         'parameter':before,'previous_last_target':[0.]},
        {'kind':'native_current_target','tick':10,'call_id':'A','phase':'carry','target_field':field,
         'parameter':after,'last_target':[.05],'packet_version':2,'action_sha256':'action-A'},
        {'kind':'execution','loop_tick':10,'call_id':'A','status':'returned','packet_version':version,
         'action_sha256':'action-A','executed_action_sha256':executed_hash}]
    (tmp_path/'result.json').write_text(json.dumps(result))
    with gzip.open(tmp_path/'ticks.jsonl.gz','wt') as f:
        for r in rows:f.write(json.dumps(r)+'\n')
    summary=inspect_native(tmp_path)
    assert summary['checks']['geometry_current_C10_target_bound'] is expected
    assert summary['checks']['actual_native'] is False


def test_observation_load_summary_rejects_another_calls_native_return(tmp_path):
    from five_chains.native_validation_summary import inspect_native
    import gzip
    result={'case':{'probe':'reflex_gripper','setting':'normal'},'evidence_level':'V0_component_fixture',
        'source_unchanged':True,'step_audit_passed':False,'audited_env_steps':0,
        'reason':'validation_complete','validation':{'finite_window_completed':True},'success':False}
    rows=[{'kind':'perturbation','name':'low_load_observation','tick':10,'call_id':'A'},
        {'kind':'tick','tick':10,'call_id':'A','triggers':['c2_reflex'],
         'reflex_bounds':{'gripper_load_band_n':[1.,3.]},'reflex':{'kind':'gripper_reference','gripper_action':1.}},
        {'kind':'native_probe_response','tick':10,'call_id':'B','native_gripper':{
         'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,
         'pad_normal_loads_n':[2.,2.]}}]
    (tmp_path/'result.json').write_text(json.dumps(result))
    with gzip.open(tmp_path/'ticks.jsonl.gz','wt') as f:
        for r in rows:f.write(json.dumps(r)+'\n')
    summary=inspect_native(tmp_path)
    assert summary['checks']['load_branch_adopted'] is True
    assert summary['checks']['native_load_returned_to_band'] is False
    assert summary['checks']['prepared_action_executed'] is False


def test_unknown_load_phase_cannot_silently_change_the_registered_input(cfg):
    with pytest.raises(ValueError):
        configure(cfg,{'probe':'reflex_gripper','setting':'normal',
            'load_injection':'qualified_observation','load_phase':'carry'})


def test_relation_physical_hook_enables_phase_only_at_input(cfg):
    from five_chains.native_validation import NativeInterventions
    from types import SimpleNamespace
    hook=object.__new__(NativeInterventions)
    hook.case={'probe':'relation','setting':'off'};configure(cfg,hook.case)
    hook.cfg=cfg;hook.handoff=False;hook.injected=False;hook.events=[]
    hook.tracer=SimpleNamespace(write=lambda r:None);translations=[]
    hook.translate=lambda tick,obs,ctx,name,entity,delta:(translations.append(delta) or obs)
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('c',3,'place_object_in_container',{'object':'obj','target':'bowl'})),
        p7=SimpleNamespace(phase_name='carry',steps_in_phase=5),packet=object(),executed_actuator='arm')
    obs={'state':{'eef_pose_world':np.eye(4),'signals':{'grasp_transforms':{'obj':np.eye(4)}}}}
    assert not cfg['chain_validation'].get('phase_only_no_parameter_update',False)
    hook(10,obs,ctx,None)
    assert translations==[[0.,0.,.005]] and cfg['chain_validation']['phase_only_no_parameter_update']
