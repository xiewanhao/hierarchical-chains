from types import SimpleNamespace as N
from dataclasses import replace
import numpy as np
import pytest
from five_chains.geometry import pose
from five_chains.envs.robocasa_adapter import RoboCasaAdapter


@pytest.mark.parametrize('skill,enabled,expected',[
    ('approach_control',True,True),('activate_control',True,True),
    ('close_hinged_door',True,False),('approach_control',False,False)])
def test_cost_experiment_is_routed_only_for_selected_button_approach(C,world,monkeypatch,skill,enabled,expected):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    w=replace(world,signals={**world.signals,'surface_normals':{'handle':np.array([-1.,0.,0.]),'start':np.array([-1.,0.,0.])},
        'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    c,p6,p7,proposal=chain1_prep(SkillCall('scope',3,skill,{'appliance':'microwave','handle':'handle','control':'start'}),w,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12);p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name=='approach'),phase_name='approach')
    planning=C.c10.config['control']['posture_ik']['path_planning'];planning['enabled']=True;planning['optimize_restarts']=enabled
    C.c10.config['base']['assist_during_door']=False
    seen=[]
    monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',lambda target,*args,**kwargs:seen.append(kwargs) or target,raising=False)
    C.c10.solve(packet,c,p7,w,None)
    assert len(seen)==1 and bool(seen[0].get('cost_candidates',False))==expected
