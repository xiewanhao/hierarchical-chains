from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import json
import numpy as np
import pytest
from five_chains.config import load_config
from five_chains.paths import legacy_root, runtime_paths, gpu_lock
from five_chains.chain_summary import summarize
from five_chains.validation_protocol import validate_protocol, native_evidence, apply_setting
from five_chains.validation_fixtures import run_fixture, observed_fixture
from five_chains.build import build_components
from five_chains.trace import Tracer
from five_chains.components.c11_selector import ScriptedSelector
from five_chains.envs.kinematic_testbed import KinematicTestbed
from five_chains.chains.c1_prep import chain1_prep
from five_chains.types import SkillCall, ChainId, Proposal

ROOT=Path(__file__).resolve().parents[2]


@pytest.mark.parametrize('case,setting',[(j['case'],j['setting']) for j in json.loads((ROOT/'protocol.json').read_text())['jobs']])
def test_component_protocol_cases_execute_real_methods_without_native_physics(tmp_path,case,setting):
    result=run_fixture(case,setting,tmp_path/'case')
    assert result['passed'],result
    assert result['native_physical_steps']==0
    summary=summarize(tmp_path/'case/ticks.jsonl','V0_component_fixture')
    assert summary['trace_complete'],summary['integrity_errors']
    assert summary['physical_ticks']==0
    assert summary['actual_recipe_calls'] is not None


def audited_components(tmp_path):
    cfg=load_config();cfg['chain_validation']={'audit':True}
    env=KinematicTestbed(cfg);trace=Tracer(tmp_path/'audit.jsonl')
    c=build_components(env,ScriptedSelector([]),cfg,trace)
    world=c.c4.update(observed_fixture())
    contract,p6,p7,prep=chain1_prep(SkillCall('local',1,'local_pose_servo',{'reference':'bowl'}),world,c)
    packet,_=c.c10.arbitrate(None,[prep],contract,c.c12)
    return c,trace,world,contract,p6,p7,packet


def test_arbitration_records_intermediate_winner_and_real_rejection(tmp_path):
    c,t,w,contract,p6,p7,packet=audited_components(tmp_path)
    first=replace(packet.params['stiffness_scale'],value=np.asarray(.9),source_chain=ChainId.PREP)
    last=replace(first,value=np.asarray(1.2),source_chain=ChainId.FB_FAST)
    forbidden=replace(last,source_chain=ChainId.VISION)
    bad_unit=replace(last,unit='bad')
    before=packet.version
    final,rejected=c.c10.arbitrate(packet,[Proposal(ChainId.FB_FAST,{'stiffness_scale':last}),
        Proposal(ChainId.PREP,{'stiffness_scale':first}),Proposal(ChainId.VISION,{'stiffness_scale':forbidden}),
        Proposal(ChainId.FB_FAST,{'stiffness_scale':bad_unit})],contract,c.c12)
    assert final.params['stiffness_scale'] is last and final.version==before+2
    assert [r.reason for r in rejected]==['permission_denied','metadata_mismatch']
    t.close({'fixture':True})
    events=[json.loads(l) for l in (tmp_path/'audit.jsonl').read_text().splitlines()]
    decisions=[r for r in events if r['kind']=='arbitration'][-4:]
    assert [r['decision'] for r in decisions]==['accepted_intermediate','rejected','final_survivor','rejected']
    assert decisions[0]['superseded_by']==decisions[2]['proposal_id']


def test_same_parameter_object_in_two_proposals_has_only_last_write_winner(tmp_path):
    c,t,w,contract,p6,p7,packet=audited_components(tmp_path)
    p=replace(packet.params['stiffness_scale'],source_chain=ChainId.FB_FAST)
    c.c10.arbitrate(packet,[Proposal(ChainId.FB_FAST,{'stiffness_scale':p})]*2,contract,c.c12)
    t.close({})
    decisions=[json.loads(l) for l in (tmp_path/'audit.jsonl').read_text().splitlines() if '"kind": "arbitration"' in l][-2:]
    assert [r['decision'] for r in decisions]==['accepted_intermediate','final_survivor']


def test_audit_wrapper_preserves_keyword_method_calls(tmp_path):
    c,t,w,contract,p6,p7,packet=audited_components(tmp_path)
    assert c.c9.step(bounds=packet.bounds,obs={}) is None
    result=c.c6.prepare(contract=contract,world=w,prev=p6,fields=frozenset(),chain=ChainId.PREP)
    assert result.fields==p6.fields
    t.close({})


def test_post_step_observation_failure_keeps_actual_execution_count(tmp_path):
    c,t,w,contract,p6,p7,packet=audited_components(tmp_path)
    class Env:
        steps=0
        def step(self,action):self.steps+=1;return {},0.,False,{}
    def fail(obs):raise ValueError('observation failed after step')
    c.adapter.observe=fail
    env=Env()
    with pytest.raises(ValueError):c.c10.execute(env,np.zeros(3))
    assert env.steps==c.c10.executions==1
    t.close({})
    rows=[json.loads(l) for l in (tmp_path/'audit.jsonl').read_text().splitlines()]
    event=next(r for r in rows if r['kind']=='execution')
    assert event['status']=='raised' and event['step_after']==1


def test_legacy_stamps_do_not_become_recipe_calls_or_zero_latency(tmp_path):
    p=tmp_path/'old.jsonl'
    p.write_text(json.dumps({'kind':'tick','tick':7,'triggers':['c4_vision'],'preparation_provenance':{'x':{'stamp':7}},'component_seconds':{}})+'\n'+json.dumps({'kind':'summary','tick_rows':1})+'\n')
    r=summarize(p,expected_ticks=1)
    assert r['actual_recipe_calls'] is None and r['explicit_causal_latencies']==[]
    assert r['status']=='NOT_OBSERVED'


def test_truncated_log_cannot_pass(tmp_path):
    p=tmp_path/'incomplete.jsonl';p.write_text('{"kind":"tick","tick":1}\n')
    result=summarize(p)
    assert not result['trace_complete'] and result['status']=='FAIL'


@pytest.mark.parametrize('mutate',[lambda p:p.update(parallel_workers=2),lambda p:p.update(max_ticks=True),
    lambda p:p['jobs'][0].update(setting='disable_c2'),lambda p:p['jobs'].append(deepcopy(p['jobs'][0])),
    lambda p:p.update(schema_version='unknown')])
def test_invalid_protocol_rejected_before_any_job(tmp_path,mutate):
    p=json.loads((ROOT/'protocol.json').read_text());mutate(p)
    with pytest.raises(ValueError):validate_protocol(p,tmp_path)
    assert list(tmp_path.iterdir())==[]


def test_native_evidence_rejects_boolean_only_gate_receipt(tmp_path):
    case={'task':'HeatMug','seed':2000,'layout':11,'style':34,'setting':'normal'}
    (tmp_path/'registration.json').write_text(json.dumps({'case':case}))
    (tmp_path/'preflight.json').write_text(json.dumps({'full_tests_passed':True,'mypy_passed':True,'physical_steps':0}))
    with pytest.raises(ValueError):native_evidence({**case,'registration':'registration.json','preflight':'preflight.json'},tmp_path,ROOT)


def test_model_paths_fail_explicitly_without_environment_and_never_write_credentials(tmp_path,monkeypatch):
    monkeypatch.delenv('HC_LEGACY_ROOT',raising=False)
    with pytest.raises(ValueError):legacy_root({})
    monkeypatch.setenv('HC_LEGACY_ROOT',str(tmp_path))
    cfg=runtime_paths(load_config(),tmp_path/'output')
    assert cfg['selector']['legacy_root']==str(tmp_path)
    assert gpu_lock(cfg['selector'],tmp_path/'x')==tmp_path/'output/neural_gpu.lock'
    assert list(tmp_path.iterdir())==[]


def test_audit_spans_are_nested_without_double_counting(tmp_path):
    c,t,w,contract,p6,p7,packet=audited_components(tmp_path);t.close({})
    rows=[json.loads(l) for l in (tmp_path/'audit.jsonl').read_text().splitlines()]
    ends={r['invocation_id']:r for r in rows if r['kind']=='invocation_end'}
    assert all(0<=r['exclusive_ns']<=r['inclusive_ns'] for r in ends.values())
    assert any(r['parent_id'] is not None for r in ends.values())
    assert all(r['status']=='returned' for r in ends.values())


def test_audit_on_off_preserves_all_fixture_actions_parameters_and_phases(tmp_path):
    from five_chains.runtime import run_episode
    outputs=[]
    for enabled in (False,True):
        cfg=load_config();cfg['control']['max_ticks']=12;cfg['chain_validation']={'audit':enabled}
        env=KinematicTestbed(cfg);trace=Tracer(tmp_path/('on.jsonl' if enabled else 'off.jsonl'))
        c=build_components(env,ScriptedSelector([SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})]),cfg,trace)
        def change(tick,obs,ctx,c):
            if tick==5:
                obs=deepcopy(obs);obs['state']['entities']['bowl']['pose_world'][0,3]+=.05
                obs['state']['signals']['continuous']['eef_track_err']=.03
            return obs
        result=run_episode(env,'synthetic_fixture',c,cfg,trace,perturb=change);trace.close(result)
        records=[json.loads(l) for l in (tmp_path/('on.jsonl' if enabled else 'off.jsonl')).read_text().splitlines()]
        outputs.append([{k:r[k] for k in ('tick','phase','action','parameters','version','writes','rejected','triggers')} for r in records if r['kind']=='tick'])
    assert len(outputs[0])==12 and outputs[0]==outputs[1]


def test_fixture_log_cannot_be_relabeled_as_native(tmp_path):
    run_fixture('fast','normal',tmp_path/'case')
    result=summarize(tmp_path/'case/ticks.jsonl','V3_native')
    assert not result['trace_complete'] and result['physical_ticks']==0
    assert any('relabeled' in s for s in result['integrity_errors'])


def test_component_frames_cannot_be_exported_as_native_video(tmp_path):
    from types import SimpleNamespace
    from five_chains.validation_media import FrameRecorder,verified_frames
    data=SimpleNamespace(qpos=np.zeros(2),qvel=np.zeros(2),ctrl=np.zeros(2),time=.05)
    sim=SimpleNamespace(data=data,render=lambda **kwargs:np.zeros((8,8,3),dtype=np.uint8))
    env=SimpleNamespace(sim=sim,rng=np.random.default_rng(1))
    recorder=FrameRecorder(tmp_path/'frames',{'fixture':True},'source','camera',evidence_level='V0_component_fixture')
    recorder.capture(env,1)
    with pytest.raises(ValueError):verified_frames(tmp_path/'frames/frames.json')


def test_frame_capture_detects_input_mutation_without_restoring_state(tmp_path):
    from types import SimpleNamespace
    from five_chains.validation_media import FrameRecorder
    data=SimpleNamespace(qpos=np.zeros(2),qvel=np.zeros(2),ctrl=np.zeros(2),time=.05)
    def bad_render(**kwargs):data.qpos[0]=1.;return np.zeros((8,8,3),dtype=np.uint8)
    env=SimpleNamespace(sim=SimpleNamespace(data=data,render=bad_render),rng=np.random.default_rng(1))
    recorder=FrameRecorder(tmp_path/'frames',{'fixture':True},'source','camera',evidence_level='V0_component_fixture')
    with pytest.raises(RuntimeError):recorder.capture(env,1)
    assert data.qpos[0]==1. and not (tmp_path/'frames/frames.json').exists()


def test_phase_only_runtime_never_calls_parameter_feedback(tmp_path,monkeypatch):
    import five_chains.runtime as runtime
    cfg=load_config();cfg['control']['max_ticks']=16
    apply_setting(cfg,'phase_only_no_parameter_update')
    env=KinematicTestbed(cfg);trace=Tracer(tmp_path/'phase.jsonl')
    c=build_components(env,ScriptedSelector([SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})]),cfg,trace)
    def forbidden(*args,**kwargs):raise AssertionError('full parameter work was executed')
    monkeypatch.setattr(runtime,'chain3b_full',forbidden)
    def observe(tick,obs,ctx,components):
        if tick==2:
            obs=deepcopy(obs);obs['state']['signals']['predicates']['test_event']=True
        return obs
    episode=runtime.run_episode(env,'synthetic_fixture',c,cfg,trace,perturb=observe);trace.close(episode)
    events=[json.loads(l) for l in (tmp_path/'phase.jsonl').read_text().splitlines()]
    assert any(r['kind']=='phase_update' for r in events)
    assert sum(r.get('component')=='c6.prepare' and r['kind']=='invocation_start' for r in events)==1


def test_timeline_keeps_unknown_skill_in_old_trace_instead_of_inventing_it(tmp_path):
    p=tmp_path/'old.jsonl';p.write_text('{"kind":"tick","tick":5,"call_id":"old","phase":"carry"}\n{"kind":"summary","tick_rows":1}\n')
    result=summarize(p)
    assert result['timeline'][0]['skill'] is None
    assert result['timeline'][0]['physical_step_index']==1 and result['timeline'][0]['obs_stamp'] is None


def test_full_geometry_work_is_charged_to_geometry_not_prep_permissions(tmp_path):
    run_fixture('geometry','shadow_full_equivalent',tmp_path/'case')
    events=[json.loads(l) for l in (tmp_path/'case/ticks.jsonl').read_text().splitlines()]
    calls=[r for r in events if r['kind']=='invocation_start' and r['component']=='recipe.prepare']
    assert any(r['field']=='stiffness_scale' and r['chain']=='c1_prep' and r['owner_chain']=='c4_vision' for r in calls)
    summary=summarize(tmp_path/'case/ticks.jsonl','V0_component_fixture')
    assert summary['actual_recipe_calls']['c4_vision/stiffness_scale']>=1


def test_legacy_gate_checks_live_bytes_not_only_preflight_boolean(tmp_path):
    from hashlib import sha256
    from five_chains.validation_protocol import verify_legacy_files
    original=tmp_path/'original';original.mkdir();file=original/'weights.bin';file.write_bytes(b'original')
    manifest=tmp_path/'protected.json';manifest.write_text(json.dumps({'weights.bin':sha256(file.read_bytes()).hexdigest()}))
    verify_legacy_files(manifest,original)
    file.write_bytes(b'changed_after_preflight')
    with pytest.raises(ValueError):verify_legacy_files(manifest,original)
