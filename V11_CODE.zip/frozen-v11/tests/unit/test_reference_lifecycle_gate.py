# -*- coding: utf-8 -*-
"""Synthetic transaction regressions; no native environment or historical oracle."""
from dataclasses import replace
from copy import deepcopy
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.envs.reference_bridge import Scope, Branch, ReferenceBridge
from five_chains.components.c10_executor import Executor


def scope(tick=10, phase='close'):
    return Scope('call',phase,tick,'target','scene',False)


def commit(bridge):
    bridge.prepare([0.],np.zeros(7),1.,0)
    bridge.before_execute([0.],np.zeros(7),1.,0)
    bridge.after_execute(np.zeros(7),1.05,1)


@pytest.mark.parametrize('changes,reasons',[
    ({'scene_signature':'changed'},['exact_scene_changed']),
    ({'target_signature':'changed'},['target_changed']),
    ({'scene_signature':'changed','target_signature':'changed'},['target_changed','exact_scene_changed']),
    ({'call':'new'},['call_changed']),
    ({'overridden':True},['reflex_override']),
    ({'phase':'release'},['out_of_scope_phase']),
    ({'tick':10},['nonincreasing_solve_tick']),
    ({'tick':9},['nonincreasing_solve_tick']),
])
def test_exact_scope_loss_clears_both_lease_and_receipt(changes,reasons):
    b=ReferenceBridge();b.begin(scope());commit(b)
    # Deliberately synthetic sentinel; not a saved historical runtime Branch.
    b.branch=N()
    b.begin(replace(scope(11),**changes))
    assert b.branch is None and b.receipt is None
    assert b.snapshot()['lifecycle_invalidation_reasons']==reasons
    ready=b.proposal_readiness(-.5)
    assert not ready['admitted'] and ready['reference'] is None
    assert 'no_current_exact_forecast_lease' in ready['application_blockers']


def test_poststep_commit_requires_before_step_acknowledgement():
    b=ReferenceBridge();b.begin(scope());b.prepare([0.],np.zeros(7),1.,0)
    with pytest.raises(ValueError,match='receipt mismatch'):
        b.after_execute(np.zeros(7),1.05,1)
    assert b.receipt is None and b.pending is None


def test_duplicate_preexecute_acknowledgement_cannot_be_reused():
    b=ReferenceBridge();b.begin(scope());b.prepare([0.],np.zeros(7),1.,0)
    b.before_execute([0.],np.zeros(7),1.,0)
    with pytest.raises(ValueError):b.before_execute([0.],np.zeros(7),1.,0)
    with pytest.raises(ValueError):b.after_execute(np.zeros(7),1.05,1)
    assert b.receipt is None


def test_duplicate_preparation_aborts_pending_transaction():
    b=ReferenceBridge();b.begin(scope());b.prepare([0.],np.zeros(7),1.,0)
    with pytest.raises(ValueError):b.prepare([0.],np.zeros(7),1.,0)
    assert b.pending is None and b.receipt is None


def test_nonincreasing_tick_cannot_prepare_even_after_invalidation():
    b=ReferenceBridge();b.begin(scope());commit(b);b.begin(scope())
    with pytest.raises(ValueError,match='nonincreasing'):b.prepare([0.],np.zeros(7),1.05,1)
    assert b.receipt is None


def test_skipped_solve_tick_is_not_immediately_previous_execution():
    b=ReferenceBridge();b.begin(scope());commit(b);b.begin(scope(12))
    assert b.receipt is not None  # Past fact retained, no current slew anchor.
    assert not b.proposal_readiness(-.5)['previous_executed_close_reference_available']


def test_positive_shadow_components_never_grant_reference_application():
    b=ReferenceBridge();b.begin(scope());commit(b);b.begin(scope(11))
    s=scope(9,'approach')
    b.branch=Branch.captured(s,0,[{'angle_rad':-1.,'joints_rad':[0.]*7},
                                 {'angle_rad':0.,'joints_rad':[.1]*7}],np.zeros(7))
    b.diagnostic.update(native_preview_available=True,shadow_QP={'status':'synthetic_feasible'})
    ready=b.proposal_readiness(-.5)
    assert ready['forecast_lease_valid'] and ready['previous_executed_close_reference_available']
    assert not ready['admitted'] and ready['reference'] is None
    assert ready['application_blockers']==['no_complete_original_forecast_source_capture',
                                         'runtime_candidate_qualification_not_implemented',
                                         'reference_application_transaction_not_implemented']


@pytest.mark.parametrize('where',['before','after'])
def test_actual_executor_aborts_pre_or_post_hook_failure_without_retry(cfg,where):
    cfg=deepcopy(cfg);cfg['control']['close_reference_bridge_capture']=True
    events=[]
    class Adapter:
        def reference_bridge_before_execute(self,*args):
            events.append('before')
            if where=='before':raise ValueError('synthetic full token changed')
        def reference_bridge_after_execute(self,*args):
            events.append('after')
            if where=='after':raise ValueError('synthetic poststep receipt mismatch')
        def reference_bridge_abort(self):events.append('abort')
        def observe(self,*args):raise AssertionError('failed receipt must not become observation')
    class Env:
        def step(self,action):events.append('step');return {},0.,False,{}
    e=Executor(Adapter(),cfg)
    with pytest.raises(ValueError):e.execute(Env(),np.zeros(1))
    assert events==(['before','abort'] if where=='before' else ['before','step','after','abort'])
    assert e.executions==(0 if where=='before' else 1)
