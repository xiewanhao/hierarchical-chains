"""Synthetic regressions for real flag wiring; these do not attest native runs."""
from pathlib import Path
from types import SimpleNamespace
import gzip
import json
import runpy
import numpy as np
import pytest
from five_chains.native_validation import configure, NativeInterventions
from five_chains.native_validation_summary import inspect_native
from five_chains.types import SkillCall, PhysParam, FieldKind, ChainId, ReflexOverride


def test_literal_mode_keeps_warmup_then_switches_real_runtime_flag(cfg):
    case={'probe':'geometry','setting':'full_recompute','full_recompute_mode':'literal_flag'}
    configure(cfg,case)
    assert cfg['ablation']['vision_full_recompute'] is False
    hook=object.__new__(NativeInterventions);records=[]
    hook.case=case;hook.cfg=cfg;hook.full_activation=None;hook.tracer=SimpleNamespace(write=records.append)
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('A',3,'place_object_in_container',{}),fields={'place_pose':object()}))
    hook.activate_full(10,ctx,SimpleNamespace(c6=SimpleNamespace(recipe_calls=7)))
    assert cfg['ablation']['vision_full_recompute'] is True
    assert records[0]['flag']=='ablation.vision_full_recompute' and records[0]['warmup_value'] is False
    hook.activate_full(11,ctx,None)
    assert len(records)==1


def test_ambiguous_full_setting_does_not_silently_mean_shadow(cfg):
    with pytest.raises(ValueError):configure(cfg,{'probe':'geometry','setting':'full_recompute'})


def test_all_native_full_jobs_request_literal_flag():
    module=runpy.run_path(str(Path(__file__).resolve().parents[2]/'scripts/run_native_chain_suite.py'))
    for group in ('heat_fast','heat_stop','heat_reselection','coffee_relation','steam_load','steam_geometry'):
        full=[x for x in module['cases'](group) if x['setting']=='full_recompute']
        assert len(full)==1 and full[0]['full_recompute_mode']=='literal_flag'


def write_case(tmp_path,result,rows):
    (tmp_path/'result.json').write_text(json.dumps(result))
    with gzip.open(tmp_path/'ticks.jsonl.gz','wt') as f:
        for r in rows:f.write(json.dumps(r)+'\n')


@pytest.mark.parametrize('complete,mode,flag,expected',[(True,'actual_c4_full',True,True),
    (False,'actual_c4_full',True,False),(True,'supplemental_shadow_cost',True,False),
    (True,'actual_c4_full',False,False)])
def test_full_flag_requires_actual_all_field_C4_invocations(tmp_path,complete,mode,flag,expected):
    result={'case':{'probe':'geometry','setting':'full_recompute','full_recompute_mode':'literal_flag'},
        'evidence_level':'V0_component_fixture','source_unchanged':True,'step_audit_passed':False,
        'audited_env_steps':0,'reason':'validation_complete','validation':{'finite_window_completed':True},'success':False}
    fields=['place_pose','grasp_pose']
    rows=[{'kind':'perturbation','name':'target_5cm','tick':10,'call_id':'A','target':'bowl.pose','phase':'carry'},
        {'kind':'tick','tick':10,'call_id':'A','phase':'carry','triggers':['c4_vision'],'writes':[],
            'changed_keys':['bowl.pose'],'parameters':{}},
        {'kind':'native_full_flag_activation','tick':10,'call_id':'A','flag':'ablation.vision_full_recompute',
            'value':flag,'warmup_value':False},
        {'kind':'native_full_recompute_comparison','tick':10,'mode':mode,'literal_flag_value':flag,
            'recipe_calls':2,'seconds':1.,'fields':fields,'adopted':mode=='actual_c4_full','adopted_fields':['place_pose']},
        {'kind':'invocation_start','loop_tick':10,'call_id':'A','owner_chain':'c4_vision',
            'component':'c6.prepare','requested_fields':fields},
        {'kind':'invocation_start','loop_tick':10,'call_id':'A','owner_chain':'c4_vision',
            'component':'c8.readout','requested_fields':fields if complete else ['place_pose']}]
    write_case(tmp_path,result,rows);summary=inspect_native(tmp_path)
    assert bool(summary['checks']['actual_literal_C4_full_prepare_and_adoption']) is expected
    assert summary['checks']['actual_native'] is False


def test_adaptive_recompute_cannot_widen_load_recovery_criterion(tmp_path):
    result={'case':{'probe':'reflex_gripper','setting':'normal','load_injection':'qualified_observation'},
        'evidence_level':'V0_component_fixture','source_unchanged':True,'step_audit_passed':False,
        'audited_env_steps':0,'reason':'validation_complete','validation':{'finite_window_completed':True},'success':False}
    rows=[{'kind':'perturbation','name':'low_load_observation','tick':10,'call_id':'A','gripper_load_band_n_before':[1.,3.]},
        {'kind':'tick','tick':10,'call_id':'A','triggers':['c2_reflex'],'reflex_bounds':{'gripper_load_band_n':[1.,6.]},
            'reflex':{'kind':'gripper_reference','gripper_action':1.}},
        {'kind':'native_probe_response','tick':10,'call_id':'A','native_gripper':{
            'source':'native_simulator_contact_solver','closing_intent':True,'bilateral_native_pads':True,'pad_normal_loads_n':[4.,4.]}}]
    write_case(tmp_path,result,rows);summary=inspect_native(tmp_path)
    assert summary['checks']['original_load_band_preserved'] is False
    assert summary['checks']['native_load_returned_to_band'] is False


def test_joint_timeout_waits_for_executed_restore(C):
    contract=C.c12.expand(SkillCall('A',3,'place_object_in_container',{'object':'vegetable','target':'bowl'}))
    hook=object.__new__(NativeInterventions);events=[]
    hook.case={'probe':'joint','setting':'normal'};hook.injected=True;hook.joint_restored=False
    hook.handoff=False;hook.reselection_from=None;hook.env=SimpleNamespace(sim=SimpleNamespace(data=SimpleNamespace(time=.6)))
    hook.emit=lambda *a:events.append(a)
    ctx=SimpleNamespace(contract=contract,p7=SimpleNamespace(phase_name='carry'),packet=object(),steps=7,selector_calls=1)
    c=SimpleNamespace(c10=SimpleNamespace(executions=12));obs={'state':{'signals':{'grasp_transforms':{}}}}
    hook(11,obs,ctx,c)
    assert hook.reselection_from is None and not events
    hook.joint_restored=True;hook(12,obs,ctx,c)
    assert hook.reselection_from['steps']==12 and hook.reselection_from['time']==.6
    assert ctx.contract.termination.timeout_steps==7 and events[0][2]=='contract_timeout'


@pytest.mark.parametrize('steps,stop,expected',[(11,True,False),(11,False,False),(12,False,True)])
def test_joint_restore_is_post_execution_and_same_call(C,steps,stop,expected):
    contract=C.c12.expand(SkillCall('A',3,'place_object_in_container',{'object':'vegetable','target':'bowl'}))
    hook=object.__new__(NativeInterventions);records=[]
    hook.case={'probe':'joint','setting':'normal'};hook.injected=True;hook.joint_restored=False
    hook.events=[{'name':'unexpected_contact','call_id':'A'}];hook.executions_at_last_event=10
    hook.tracer=SimpleNamespace(write=records.append)
    value=PhysParam('stiffness_scale',FieldKind.SCALAR,np.asarray(1.),'',None,ChainId.PREP,0)
    ctx=SimpleNamespace(contract=contract,p7=SimpleNamespace(phase_name='carry'),packet=SimpleNamespace(params={'stiffness_scale':value},version=2))
    c=SimpleNamespace(c10=SimpleNamespace(executions=steps));obs={'state':{'signals':{}}}
    hook.after_execute(11,obs,ctx,c,None,np.zeros(9),ReflexOverride('stop',None,'test') if stop else None)
    assert hook.joint_restored is expected
    assert any(r['kind']=='native_joint_restored_execution' for r in records) is expected


def test_joint_relation_input_uses_measured_approach_axis():
    hook=object.__new__(NativeInterventions);moves=[]
    hook.case={'probe':'joint','setting':'normal'};hook.injected=False;hook.handoff=False;hook.events=[]
    hook.reselection_from=None
    hook.translate=lambda tick,obs,ctx,name,entity,delta:(moves.append((entity,delta)) or obs)
    eef=np.eye(4);eef[:3,:3]=[[1,0,0],[0,0,-1],[0,1,0]]
    obs={'state':{'eef_pose_world':eef,'signals':{'grasp_transforms':{'bowl':np.eye(4)}}}}
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('A',3,'place_object_in_container',{'object':'bowl'})),
        p7=SimpleNamespace(phase_name='carry',steps_in_phase=5),packet=object(),executed_actuator='arm')
    hook(10,obs,ctx,None)
    assert moves==[('bowl',[0.,-.005,0.])]


@pytest.mark.parametrize('phase,field,expected',[('align_payload_outside','payload_alignment_pose',False),
    ('carry','other',False),('carry','place_pose',True)])
def test_joint_geometry_waits_for_current_place_target(phase,field,expected):
    hook=object.__new__(NativeInterventions);moves=[]
    hook.case={'probe':'joint','setting':'normal'};hook.injected=False;hook.handoff=False
    hook.events=[{'name':'grasp_relation_5mm'}];hook.reselection_from=None
    hook.env=SimpleNamespace(objects={'bowl':object()});hook.tracer=SimpleNamespace(write=lambda r:None)
    hook.translate=lambda tick,obs,ctx,name,entity,delta:(moves.append((entity,delta)) or obs)
    obs={'state':{'signals':{'grasp_transforms':{'vegetable':np.eye(4)}}}}
    call=SkillCall('A',3,'place_object_in_container',{'object':'vegetable','target':'bowl'})
    ctx=SimpleNamespace(contract=SimpleNamespace(call=call,phases=[SimpleNamespace(target_field=field)]),
        p7=SimpleNamespace(phase_name=phase,steps_in_phase=5,phase_index=0),
        packet=SimpleNamespace(params={'place_pose':object()}),executed_actuator='arm')
    hook(10,obs,ctx,SimpleNamespace(c10=SimpleNamespace(last_target=np.eye(4))))
    assert bool(moves) is expected


def test_joint_summary_never_credits_a_late_unrelated_relation_edge(tmp_path):
    result={'case':{'probe':'joint','setting':'normal','post_window':24},'evidence_level':'V0_component_fixture',
        'source_unchanged':True,'step_audit_passed':False,'audited_env_steps':0,'success':False,
        'reason':'validation_complete','validation':{'finite_window_completed':True}}
    rows=[{'kind':'perturbation','name':'grasp_relation_5mm','tick':10,'call_id':'A'},
        {'kind':'tick','tick':35,'call_id':'A','triggers':['c3b_fb_full'],'events':['grasp_relation_changed'],
            'writes':[{'chain':'c3b_fb_full','name':'place_pose'}]}]
    write_case(tmp_path,result,rows);summary=inspect_native(tmp_path)
    assert summary['checks']['measured_relation_edge'] is False
    assert summary['checks']['joint_all_registered_events'] is False
