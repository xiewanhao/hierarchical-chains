from types import SimpleNamespace as N
import numpy as np
import mujoco
import pytest
from five_chains.envs.contact_telemetry import sample_joint_dynamics
from five_chains.config import validate_config


def model():
    return mujoco.MjModel.from_xml_string('''<mujoco><option gravity="0 0 0"/><worldbody><body><inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/><joint name="a" type="hinge" axis="0 0 1" range="-1 1" frictionloss=".1"/></body></worldbody><actuator><motor joint="a" gear="3" ctrlrange="-1 1"/></actuator></mujoco>''')


def test_native_buffers_mapping_units_copy_and_zero_state_writes():
    m=model();d=mujoco.MjData(m);d.ctrl[0]=.25;mujoco.mj_forward(m,d)
    names=['qpos','qvel','ctrl','qacc','qacc_warmstart','qfrc_actuator','qfrc_constraint','qM','efc_force'];before={n:np.asarray(getattr(d,n)).copy() for n in names}
    c=N(torques=np.array([.9]),kp=np.ones(6))
    r=sample_joint_dynamics(m,d,np.array([0]),c)
    assert r['native_ctrl'][0]==.25 and r['actuator_force'][0]==.25 and r['qfrc_actuator'][0]==.75
    assert r['actuator_gear'][0,0]==3 and r['source']=='native_simulator_joint_dynamics_buffers'
    assert len(r['friction_dof_rows'])==1
    f=r['friction_dof_rows'][0];assert f['dof_id']==0 and np.array_equal(f['jacobian_columns'],[0]) and np.array_equal(f['jacobian_values'],[1.])
    assert all(np.array_equal(getattr(d,n),a) for n,a in before.items())
    r['native_ctrl'][0]=999.;r['cached_osc']['torques'][0]=999.
    assert d.ctrl[0]==.25 and c.torques[0]==.9


def test_missing_cached_controller_values_remain_unknown_not_zero():
    m=model();d=mujoco.MjData(m);mujoco.mj_forward(m,d)
    r=sample_joint_dynamics(m,d,np.array([0]),N())
    assert r['cached_osc']['torques'] is None and r['cached_osc']['mass_matrix'] is None


def test_telemetry_default_disabled_and_must_be_boolean(cfg):
    assert not cfg['environment']['joint_dynamics_telemetry']
    cfg['environment']['joint_dynamics_telemetry']=1
    with pytest.raises(ValueError):validate_config(cfg)
