"""Synthetic contract/input regressions; none of these are native run evidence."""
from copy import deepcopy
from dataclasses import replace
from types import SimpleNamespace
import json
import numpy as np
import pytest
from five_chains.types import SkillCall, FeedbackDelta
from five_chains.components.c12_contract import ContractDispatcher
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.c3_feedback import chain3a_fast
from five_chains.chains.c4_vision import chain4_vision
from five_chains.native_validation import NativeInterventions, configure
from five_chains.observation_projection import tilt_deviation
from five_chains.envs.reference_bridge import digest
from five_chains.native_validation_summary import demand_evidence


def calls():
    return [SkillCall('l3',3,'place_object_in_container',{'object':'vegetable','target':'bowl'}),
            SkillCall('l2',2,'maintain_container_attitude',{'object':'bowl'}),
            SkillCall('l1',1,'local_pose_servo',{'object':'bowl','reference':'bowl'})]


@pytest.mark.parametrize('angle',[0.,.1,.15,.25,.7,np.pi])
def test_shared_projection_matches_original_native_formula_exactly(angle):
    contract=ContractDispatcher().expand(calls()[1]);up=np.array([np.sin(angle),0,np.cos(angle)])
    original=max(0.,float(np.arccos(np.clip(up[2],-1,1)))-.15)
    assert tilt_deviation(contract,{'bowl':up})==original
    for call in (calls()[0],calls()[2]):
        assert tilt_deviation(ContractDispatcher().expand(call),{'bowl':up})==0.


def test_projection_respects_actual_constraint_entity_and_rejects_bad_measurement():
    c=ContractDispatcher().expand(calls()[1]);limit=c.fields['tilt_limit']
    c=replace(c,fields={**c.fields,'tilt_limit':replace(limit,arguments={'entity':'other'})})
    assert tilt_deviation(c,{'bowl':np.array([0,0,.5])})==0.
    with pytest.raises(ValueError):tilt_deviation(c,{'other':np.array([0,np.nan,1])})


@pytest.mark.parametrize('probe',['demand_geometry','demand_fast','demand_tilt'])
def test_all_layers_receive_identical_raw_inputs_and_never_move_plant(C,cfg,world,monkeypatch,probe):
    monkeypatch.setattr('five_chains.native_validation.physical_signature',lambda env:{'fixture':'unchanged'})
    world=replace(world,signals={**world.signals,'grasp_transforms':{'bowl':np.eye(4),'vegetable':np.eye(4)}})
    signatures=[]
    for call in calls():
        contract,p6,p7,proposal=chain1_prep(call,world,C)
        packet,_=C.c10.arbitrate(None,[proposal],contract,C.c12)
        index=next(i for i,p in enumerate(contract.phases) if p.name=={3:'carry',2:'hold_attitude',1:'track'}[call.layer])
        p7=replace(p7,phase_index=index,phase_name=contract.phases[index].name,steps_in_phase=1)
        case={'probe':probe,'setting':'normal','target':'bowl','demand_layer':call.layer,
            'acquire_object':call.bindings['object']}
        records=[];hook=object.__new__(NativeInterventions)
        hook.case=case;hook.cfg=cfg;hook.injected=False;hook.demand_call_id=call.call_id
        hook.events=[];hook.preview_ticks=set();hook.env=object()
        hook.tracer=SimpleNamespace(rows=1,write=records.append)
        ctx=SimpleNamespace(contract=contract,packet=packet,p7=p7,executed_actuator='arm')
        obs={'state':{'entities':{n:{'pose_world':e.pose_world.copy()} for n,e in world.entities.items()},
            'signals':{'grasp_transforms':{'bowl':np.eye(4),'vegetable':np.eye(4)},
                       'continuous':{'eef_track_err':.001,'tilt_dev':0.}}}}
        old=deepcopy(obs)
        result=hook.demand_observation(4,obs,ctx,C)
        assert hook.injected
        raw=next(r for r in records if r['kind']=='native_demand_raw_input')
        signatures.append(raw['input_sha256'])
        for name in obs['state']['entities']:
            assert np.array_equal(obs['state']['entities'][name]['pose_world'],old['state']['entities'][name]['pose_world'])
        assert obs['state']['signals']['continuous']==old['state']['signals']['continuous']
        if probe=='demand_tilt':
            proposal=chain3a_fast(contract,packet,FeedbackDelta(4,(),result['state']['signals']['continuous']),C,cfg)
            assert bool(proposal)==(call.layer==2)
    assert len(set(signatures))==1


@pytest.mark.parametrize('index,expected,recipe_count',[(0,{'place_pose','base_at_target'},1),(1,set(),0),(2,{'local_target'},0)])
def test_original_geometry_chain_computes_only_current_contract_dependencies(C,world,index,expected,recipe_count):
    world=replace(world,signals={**world.signals,'grasp_transforms':{'bowl':np.eye(4),'vegetable':np.eye(4)}})
    c,p6,p7,prepared=chain1_prep(calls()[index],world,C)
    bowl=world.entities['bowl'];moved=bowl.pose_world.copy();moved[0,3]+=.05
    world=replace(world,stamp=world.stamp+1,changed_keys=frozenset({'bowl.pose'}),
        entities={**world.entities,'bowl':replace(bowl,pose_world=moved)})
    count=C.c6.recipe_calls
    refreshed,proposal=chain4_vision(c,p6,p7,world,C,False)
    assert (set(proposal.updates) if proposal else set())==expected
    assert C.c6.recipe_calls-count==recipe_count
    # Local rigid P6 can stay valid while C8 must read it in the moved frame.
    # Updating a physical field is not necessarily another recipe invocation.
    field={0:'place_pose',2:'local_target'}.get(index)
    if field:
        assert refreshed.fields[field] is p6.fields[field]
        assert np.allclose(proposal.updates[field].value[:3,3]-prepared.updates[field].value[:3,3],
                           [.05,0.,0.],rtol=0,atol=1e-12)


def test_demand_configuration_rejects_vegetable_as_l2_container(cfg):
    case={'probe':'demand_tilt','setting':'normal','demand_layer':2,'target':'bowl',
        'input_mode':'identical_raw_observation','post_window':2,'acquire_object':'vegetable','handoff_phase':'lift'}
    with pytest.raises(ValueError,match='container'):configure(cfg,case)


def demand_fixture():
    call={'call_id':'new','layer':2,'skill':'maintain_container_attitude','bindings':{'object':'bowl'}}
    c=ContractDispatcher().expand(SkillCall(**call))
    fields={n:{'depends_on':sorted(s.depends_on),'writable_by':[x.value for x in s.writable_by]} for n,s in c.fields.items()}
    raw={'schema':'demand_raw_input/v1','kind':'object_up_vector_observation','entity':'bowl',
        'tilt_rad':.25,'up_world':[float(np.sin(.25)),0.,float(np.cos(.25))]}
    grasp=np.eye(4).tolist();param={'name':'posture_reference','value':grasp}
    case={'probe':'demand_tilt','demand_layer':2,'acquire_object':'bowl'}
    rows=[{'kind':'diagnostic_skill_handoff','tick':4,'new_call':call,'measured_object':'bowl',
           'measured_grasp':grasp,'history_success_appended':False},
          {'kind':'native_demand_raw_input','tick':6,'call_id':'new','input_spec':raw,
           'input_sha256':digest(raw),'active_state_preserved':True,'projected_continuous':{'tilt_dev':.1},
           'contract_declares_tilt_limit':True,'current_measured_grasp':grasp},
          {'kind':'native_contract_fields','tick':5,'call_id':'new','fields':fields},
          {'kind':'native_target_before_input','tick':6,'call_id':'new','target_field':'posture_reference','parameter':param},
          {'kind':'native_current_target','tick':6,'call_id':'new','phase':'hold_attitude',
           'target_field':'posture_reference','parameter':param,'packet_version':2,'action_sha256':'action'},
          {'kind':'execution','loop_tick':5,'call_id':'new','status':'returned'},
          {'kind':'execution','loop_tick':6,'call_id':'new','status':'returned','packet_version':2,
           'action_sha256':'action','executed_action_sha256':'action'},
          {'kind':'tick','tick':6,'call_id':'new','phase':'hold_attitude',
           'parameters':{'posture_reference':param},'continuous':{'eef_track_err':0.},
           'grasp_transforms':{'bowl':grasp},'writes':[{'chain':'c3a_fb_fast','name':'stiffness_scale'}]}]
    return rows,case


@pytest.mark.parametrize('fault',['missing_input','wrong_hash','no_grasp','wrong_action','no_prior_execution'])
def test_demand_verdict_does_not_accept_missing_or_unbound_evidence(fault):
    rows,case=demand_fixture()
    assert all(demand_evidence(rows,case)[0].values())
    if fault=='missing_input':rows=[r for r in rows if r['kind']!='native_demand_raw_input']
    if fault=='wrong_hash':rows[1]['input_sha256']='different'
    if fault=='no_grasp':rows[-1]['grasp_transforms']={}
    if fault=='wrong_action':rows[-2]['executed_action_sha256']='different'
    if fault=='no_prior_execution':rows=[r for r in rows if not(r['kind']=='execution' and r['loop_tick']==5)]
    assert not all(demand_evidence(rows,case)[0].values())


def test_native_suite_registers_complete_same_input_matrix():
    from scripts.run_native_chain_suite import cases
    jobs=cases('steam_demand')
    assert len(jobs)==10
    assert all(j['post_window']==2 and j['input_mode']=='identical_raw_observation' for j in jobs)
    assert len([j for j in jobs if j['probe']=='demand_geometry'])==4
    assert {j['demand_layer'] for j in jobs}=={1,2,3}
    assert all(j['acquire_object']=='bowl' for j in jobs if j['demand_layer']==2)


@pytest.mark.parametrize('phase,should_move',[('align_payload_outside',False),('carry',True)])
def test_registered_bowl_relation_does_not_inject_in_an_earlier_stage(phase,should_move):
    moves=[];hook=object.__new__(NativeInterventions)
    hook.case={'probe':'relation','setting':'normal','relation_phase':'carry','relation_object':'bowl'}
    hook.handoff=False;hook.injected=False;hook.events=[]
    hook.translate=lambda tick,obs,ctx,name,entity,delta:(moves.append((entity,delta)) or obs)
    obs={'state':{'eef_pose_world':np.eye(4),'signals':{'grasp_transforms':{'bowl':np.eye(4)},'continuous':{}}}}
    ctx=SimpleNamespace(contract=SimpleNamespace(call=SkillCall('b',3,'place_object_in_container',{'object':'bowl'})),
        p7=SimpleNamespace(phase_name=phase,steps_in_phase=4),packet=object(),executed_actuator='arm')
    hook(7,obs,ctx,None)
    assert bool(moves)==should_move
    if moves:assert moves==[('bowl',[0.,0.,.005])]


def test_new_steam_relation_is_one_fixed_input_with_three_original_settings():
    from scripts.run_native_chain_suite import cases
    jobs=cases('steam_relation')
    assert [j['setting'] for j in jobs]==['normal','off','full_recompute']
    assert all(j['relation_phase']=='carry' and j['relation_object']=='bowl' and
        j['control_profile']=='r46_known_steam' and j['post_window']==24 for j in jobs)
