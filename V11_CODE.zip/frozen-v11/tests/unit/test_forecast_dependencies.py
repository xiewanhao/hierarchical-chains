# -*- coding: utf-8 -*-
"""Synthetic closure and actual-method regressions, not native validation."""
from copy import deepcopy
from dataclasses import replace
from types import SimpleNamespace as N
import json
import numpy as np
import pytest
from five_chains.envs.forecast_dependencies import (ForecastSource,canonical,definition,
    fixed_inputs,model_fingerprint,implementation_fingerprint)
from five_chains.envs.reference_bridge import Branch,ReferenceBridge,Scope
from five_chains.envs.reference_bridge import digest
from five_chains.envs.reference_bridge import choose_branch
from five_chains.envs.robocasa_adapter import RoboCasaAdapter


def fixture(cfg):
    a=object.__new__(RoboCasaAdapter);a.config=deepcopy(cfg)
    a.config['control']['close_reference_bridge_capture']=True
    a._reference_bridge_in_scope=True
    s=Scope('call','approach',10,'target','scene',False)
    a.reference_bridge=ReferenceBridge();a.reference_bridge.begin(s)
    a.posture_solver=N(qpos=np.arange(7),joints=np.arange(7),proprio=np.arange(7),site=0,
        lower=np.full(7,-3.),upper=np.full(7,3.),rest=np.zeros(7),config={'seed':0})
    model=N(jnt_qposadr=np.arange(8),geom_pos=np.zeros((2,3)),
            opt=N(disableflags=0,timestep=.002,gravity=np.array([0.,0.,-9.81])))
    a.env=N(microwave=N(door_joint_names=['door'],handle_name='handle_main'),
            sim=N(model=N(_model=model,joint_name2id=lambda n:7)))
    q=np.zeros(9);q[7]=-1.
    nominal=np.eye(4);nominal[0,3]=.1
    w=N(stamp=10,signals={'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],
        'anchor_world':[0.,0.,0.]},'grasp_transforms':{}},entities={'handle':N(pose_world=nominal.copy())})
    c=('microwave','handle',.005)
    d=definition(a,q,np.zeros(7),nominal,np.eye(4),w,c,7,s)
    knots=[{'stage':'enter_contact','angle_rad':-1.,'joints_rad':[0.]*7},
           {'stage':'hinge_arc','angle_rad':0.,'joints_rad':[.1]*7}]
    return a,q,w,c,s,d,knots


def test_source_is_detached_and_bound_to_actual_knots_endpoint_call_tick(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    b=Branch.captured(s,0,knots,np.zeros(7),source)
    q[8]=4.;d['original_endpoint'][0]=1.;knots[0]['joints_rad'][0]=2.
    assert b.source_record.read()['definition']['original_qpos'][8]==0.
    assert b.source_record.read()['knots'][0]['joints_rad'][0]==0.
    external=source.read();external['definition']['original_qpos'][0]=5.
    assert source.read()['definition']['original_qpos'][0]==0.


@pytest.mark.parametrize('change',['call','tick','endpoint','knots'])
def test_branch_rejects_provenance_mismatch(cfg,change):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots);endpoint=np.zeros(7)
    if change=='call':s=replace(s,call='other')
    if change=='tick':s=replace(s,tick=11)
    if change=='endpoint':endpoint[0]=.01
    if change=='knots':knots[-1]['joints_rad'][0]=.2
    with pytest.raises(ValueError,match='source does not bind'):
        Branch.captured(s,0,knots,endpoint,source)


@pytest.mark.parametrize('kind,component',[
    ('scene','fixed_scene_qpos'),('grasp','grasp_transforms'),('model','model'),('option','model'),
    ('anchor','hinge_anchor_world'),('axis','hinge_axis_world'),('rest','solver'),
    ('solver_config','solver'),('policy','posture_config'),('preload','contact'),
    ('prefix','forecast_contact_prefix'),
])
def test_each_fixed_dependency_change_is_exactly_rejected(cfg,kind,component):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    if kind=='scene':q[8]=1e-15
    if kind=='grasp':w.signals['grasp_transforms']={'object':np.eye(4)}
    if kind=='model':a.env.sim.model._model.geom_pos[0,0]=1e-15
    if kind=='option':a.env.sim.model._model.opt.disableflags=1
    if kind=='anchor':w.signals['microwave_hinge']['anchor_world'][0]=1e-15
    if kind=='axis':w.signals['microwave_hinge']['axis_world'][0]=1e-15
    if kind=='rest':a.posture_solver.rest[0]=1e-15
    if kind=='solver_config':a.posture_solver.config['seed']=1
    if kind=='policy':a.config['control']['posture_ik']['path_planning']['hinge_continuation']['samples']+=1
    if kind=='preload':c=(c[0],c[1],c[2]+1e-15)
    if kind=='prefix':a.env.microwave.handle_name='other_handle_main'
    result=source.compare_fixed(fixed_inputs(a,q,w,c,7))
    assert result['changed_components']==[component] and not result['fixed_prerequisites_equal']
    assert not result['forecast_reuse_admitted'] and result['reference'] is None


def test_arm_door_and_unrelated_packet_field_are_not_fixed_source_scene(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    q[:8]=.01;w.signals['microwave_hinge']['angle']=-.5
    w.closed_handle_pose=np.full((4,4),42.)  # Not read by the original function.
    result=source.compare_fixed(fixed_inputs(a,q,w,c,7))
    assert result['fixed_prerequisites_equal']
    assert not result['forecast_reuse_admitted'] and result['reference'] is None
    b=Branch.captured(s,0,knots,np.zeros(7),source)
    # The separate original target and exact scene runtime guards stay intact.
    assert b.reference(replace(s,phase='close',tick=11,target_signature='changed'),-.5) is None
    assert b.reference(replace(s,phase='close',tick=11,scene_signature='changed'),-.5) is None


@pytest.mark.parametrize('bad',['integrity','missing','nonfinite','future','scope','unknown_option'])
def test_invalid_or_incomplete_capture_fails_closed(cfg,bad):
    a,q,w,c,s,d,knots=fixture(cfg)
    if bad=='integrity':
        source=ForecastSource.seal(d,knots)
        with pytest.raises(ValueError):replace(source,payload_sha256='bad').read()
    elif bad=='missing':
        del d['observed_handle_center']
        with pytest.raises(ValueError):ForecastSource.seal(d,knots)
    elif bad=='nonfinite':
        knots[0]['angle_rad']=float('nan')
        with pytest.raises(ValueError):ForecastSource.seal(d,knots)
    elif bad in ('future','scope'):
        s=replace(s,tick=11) if bad=='future' else replace(s,phase='close')
        with pytest.raises(ValueError):definition(a,q,np.zeros(7),np.eye(4),np.eye(4),w,c,7,s)
    else:
        a.env.sim.model._model.opt.unknown=N()
        with pytest.raises(ValueError):model_fingerprint(a.env.sim.model._model)


def test_current_fixed_schema_cannot_omit_a_dependency(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    current=fixed_inputs(a,q,w,c,7);del current['model']
    result=source.compare_fixed(current)
    assert result['missing_or_extra_components']==['model'] and not result['fixed_prerequisites_equal']


def test_implementation_versions_and_source_are_bound_but_never_grant_reuse(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    value=implementation_fingerprint()
    assert len(value['local_source_sha256'])==4 and len(value['library_versions'])==3
    current=fixed_inputs(a,q,w,c,7);current['implementation']['library_versions']['mujoco']='different'
    result=source.compare_fixed(current)
    assert result['changed_components']==['implementation'] and not result['fixed_prerequisites_equal']


def test_identical_numeric_branch_with_ambiguous_source_is_rejected(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    b=Branch.captured(s,0,knots,np.zeros(7),source)
    d['original_qpos'][0]=.01
    other=Branch.captured(s,1,knots,np.zeros(7),ForecastSource.seal(d,knots))
    assert choose_branch([np.zeros(7)],[b,other]) is None
    assert choose_branch([np.zeros(7)],[b,b]) is b


@pytest.mark.parametrize('invalid_capture',[False,True,'seal'])
def test_actual_original_forecast_capture_adds_no_queries_or_decisions(cfg,monkeypatch,invalid_capture):
    import five_chains.envs.scene_path as paths
    class Scene:
        def __init__(self,*args):pass
        def configure(self,*args):pass
        def valid(self,q):return True
    monkeypatch.setattr(paths,'StaticScene',Scene)
    outputs=[]
    for enabled in [False,True]:
        a,q,w,c,s,d,knots=fixture(cfg);a.config['control']['close_reference_bridge_capture']=enabled
        if invalid_capture is True:a.env.sim.model._model.opt.unknown=N()
        if invalid_capture=='seal':
            def invalid_seal(*args):raise ValueError('synthetic seal failure')
            monkeypatch.setattr(ForecastSource,'seal',invalid_seal)
        calls=[];solver=a.posture_solver
        def solve(target,q,**kwargs):
            calls.append(target.copy());solver.target=target.copy()
            return N(success=True,joints=np.full(7,len(calls)*.001))
        solver.solve=solve;solver.forward=lambda *args:solver.target.copy()
        nominal=np.eye(4);nominal[0,3]=.1
        result=a.hinge_contact_continuation(q,np.zeros(7),nominal,np.eye(4),w,c)
        outputs.append((result,calls))
    off,on=outputs
    for x,y in zip(off[1],on[1]):np.testing.assert_array_equal(x,y)
    assert len(off[1])==len(on[1]) and off[0]['admitted'] and on[0]['admitted']
    knots=on[0].pop('captured_knots');status=on[0].pop('source_capture_status')
    if invalid_capture:
        assert 'captured_source' not in on[0] and status.startswith('source_capture_rejected:')
    else:
        source=on[0].pop('captured_source')
        assert source.binds(s.call,s.tick,np.zeros(7),knots)
        assert status=='captured_original_inputs'
    assert off[0]==on[0]


def test_complete_source_still_cannot_admit_application_or_renew_changed_target(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);source=ForecastSource.seal(d,knots)
    b=a.reference_bridge;b.branch=Branch.captured(s,0,knots,np.zeros(7),source)
    b.begin(replace(s,phase='close',tick=11))
    b.prepare([0.],np.zeros(7),1.,0);b.before_execute([0.],np.zeros(7),1.,0)
    b.after_execute(np.zeros(7),1.05,1);b.begin(replace(s,phase='close',tick=12))
    b.diagnostic['native_preview_available']=True
    ready=b.proposal_readiness(-.5)
    assert ready['forecast_source_capture_available'] and ready['forecast_lease_valid']
    assert not ready['admitted'] and ready['reference'] is None
    b.begin(replace(s,phase='close',tick=13,target_signature='updated'))
    assert b.branch is None and b.receipt is None


def test_actual_adapter_compares_source_without_renewing_changed_target(cfg):
    a,q,w,c,s,d,knots=fixture(cfg)
    parameter=N(kind=N(value='pose'),frame_entity='world',value=np.eye(4))
    scene=digest(([float(q[8])],{}))
    s=replace(s,target_signature=digest(('pose','world',parameter.value)),scene_signature=scene)
    a.reference_bridge=ReferenceBridge();a.reference_bridge.begin(s)
    source=ForecastSource.seal(d,knots)
    a.reference_bridge.branch=Branch.captured(s,0,knots,np.zeros(7),source)
    contract=N(contract_id='call',call=N(skill='close_hinged_door',bindings={'appliance':'microwave','handle':'handle'}),
        fields={'closed_handle_pose':N(arguments={'contact_preload_m':.005})})
    w.stamp=11;w.signals['robot_kinematic_qpos']=q
    parameter.value[0,3]=.01
    a.reference_bridge_begin(N(params={'closed_handle_pose':parameter}),contract,N(phase_name='close'),w,None)
    b=a.reference_bridge
    assert b.source_comparison['fixed_prerequisites_equal']
    assert not b.source_comparison['forecast_reuse_admitted']
    assert b.invalidation_reasons==['target_changed'] and b.branch is None and b.receipt is None


def test_shadow_hook_requires_complete_source_in_addition_to_actual_receipt(cfg):
    a,q,w,c,s,d,knots=fixture(cfg)
    a.config['control']['close_reference_native_preview_shadow']=True
    a._reference_preview_door_qpos=7
    a.controller=N(initial_joint=np.zeros(7));a.env.sim.data=N(time=1.1,qpos=q)
    a.env.sim.model._model.jnt_range=np.tile([-3.,3.],(7,1))
    b=a.reference_bridge;source=ForecastSource.seal(d,knots)
    b.branch=Branch.captured(s,0,knots,np.zeros(7),source)
    b.begin(replace(s,phase='close',tick=11));b.prepare([0.],np.zeros(7),1.,0)
    b.before_execute([0.],np.zeros(7),1.,0);b.after_execute(np.zeros(7),1.05,1)
    b.begin(replace(s,phase='close',tick=12));calls=[]
    class Provider:
        def baseline(self,action,scope):return {'binding':{'token':'synthetic','scope':scope,'action':np.array(action)},'baseline':{'reference':[0.]*7}}
        def verify(self,action,scope,token):assert token=='synthetic'
        def shadow_solve(self,preview,previous,desired):
            calls.append((previous,desired));return {'reference':[.03]*7,'proposal_applied':False}
    a.native_reference_preview=Provider();a.reference_bridge_prepare(np.zeros(1),1)
    assert len(calls)==1 and calls[0][0]==[0.]*7
    assert not b.proposal_readiness(-1.)['admitted']
    np.testing.assert_array_equal(a.controller.initial_joint,np.zeros(7))


def test_missing_library_metadata_rejects_capture_component(monkeypatch):
    import five_chains.envs.forecast_dependencies as dependencies
    from importlib.metadata import PackageNotFoundError
    def missing(name):raise PackageNotFoundError(name)
    monkeypatch.setattr(dependencies,'version',missing)
    with pytest.raises(ValueError,match='fingerprint unavailable'):implementation_fingerprint()


@pytest.mark.parametrize('change',['nan_payload','infinity_sign','signed_zero','dtype','shape','finite'])
def test_native_model_metadata_uses_exact_bytes_including_nonfinite(cfg,change):
    a,q,w,c,s,d,knots=fixture(cfg);m=a.env.sim.model._model
    m.mesh_polynormal=np.array([np.nan,np.inf,0.,1.],dtype=np.float64)
    before=model_fingerprint(m)
    assert before==model_fingerprint(m)
    assert before['nonfinite_array_entries']=={'mesh_polynormal':2}
    if change=='nan_payload':m.mesh_polynormal.view(np.uint64)[0]^=np.uint64(1)
    if change=='infinity_sign':m.mesh_polynormal[1]=-np.inf
    if change=='signed_zero':m.mesh_polynormal[2]=-0.
    if change=='dtype':m.mesh_polynormal=m.mesh_polynormal.astype(np.float32)
    if change=='shape':m.mesh_polynormal=m.mesh_polynormal.reshape(2,2)
    if change=='finite':m.mesh_polynormal[-1]=2.
    assert model_fingerprint(m)['arrays_sha256']!=before['arrays_sha256']


def test_byte_model_identity_does_not_accept_nonfinite_forecast_qpos(cfg):
    a,q,w,c,s,d,knots=fixture(cfg);a.env.sim.model._model.mesh_polynormal=np.array([np.nan,np.inf])
    q[0]=np.nan
    with pytest.raises(ValueError,match='invalid source qpos'):fixed_inputs(a,q,w,c,7)


@pytest.mark.parametrize('bad',['object_array','nonfinite_option'])
def test_native_byte_metadata_still_rejects_unsupported_or_nonfinite_options(cfg,bad):
    a,q,w,c,s,d,knots=fixture(cfg);m=a.env.sim.model._model
    if bad=='object_array':m.extra=np.array([object()],dtype=object)
    else:m.opt.timestep=np.inf
    with pytest.raises(ValueError):model_fingerprint(m)
