from types import SimpleNamespace as N
import copy
import numpy as np
import pytest
from five_chains.envs.contact_telemetry import sample_contacts


def contact(a,b,d):
    return N(geom1=a,geom2=b,dist=d,pos=np.array([1.,2.,3.]),frame=np.eye(3).ravel(),friction=np.arange(5.),dim=3)


def test_native_contact_diagnostics_are_read_only_and_filter_only_relevant_pairs():
    model=object();data=N(ncon=3,time=3.25,qvel=np.array([.2,.3]),contact=[contact(0,1,-.003),contact(2,3,.0001),contact(3,4,-.002)])
    before=copy.deepcopy(data);calls=[]
    def force(m,d,i,out):
        assert m is model and d is data
        calls.append(i);out[:]=np.arange(6.)+10*i
    record=sample_contacts(model,data,frozenset([0]),frozenset([2]),('robot','fixture','payload','other','distractor'),force)
    assert calls==[0,1] and record['native_contact_count']==3 and record['recorded_contact_count']==2
    assert record['contacts'][0]['distance_m']==-.003
    assert record['contacts'][1]['touches_payload']
    assert np.array_equal(record['contacts'][1]['solver_wrench_contact_frame'],np.arange(6.)+10)
    assert np.array_equal(data.qvel,before.qvel) and data.time==before.time
    assert all(np.array_equal(a.pos,b.pos) and a.dist==b.dist for a,b in zip(data.contact,before.contact))
    # Returned arrays do not alias simulation state; no fake force_world channel.
    record['full_qvel'][0]=99;record['contacts'][0]['position_world_m'][0]=99
    assert data.qvel[0]==.2 and data.contact[0].pos[0]==1
    assert 'force_world' not in record and 'unexpected_contact' not in record


def test_no_contacts_is_explicit_not_an_independently_measured_zero_force():
    r=sample_contacts(None,N(ncon=0,time=0.,qvel=np.zeros(2)),frozenset([0]),frozenset(),('robot',),lambda *a:pytest.fail('no contact force should be queried'))
    assert not r['contacts'] and r['native_contact_count']==0
    assert 'not independent' in r['scope']


def test_nonfinite_native_wrench_fails_instead_of_fabricating_force():
    def bad(m,d,i,out):out[:]=np.nan
    with pytest.raises(ValueError,match='non-finite native contact'):
        sample_contacts(None,N(ncon=1,time=0.,qvel=np.zeros(2),contact=[contact(0,1,-.001)]),frozenset([0]),frozenset(),('robot','fixture'),bad)
