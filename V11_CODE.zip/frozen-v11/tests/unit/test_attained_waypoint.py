from types import SimpleNamespace as N
from dataclasses import replace
import numpy as np
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.geometry import pose


def adapter(cfg,world,valid=lambda q:True):
    a=object.__new__(RoboCasaAdapter);a.config=cfg;cfg['control']['posture_ik']['enabled']=True
    a.posture_solver=N(qpos=np.arange(2),lower=-np.ones(2),upper=np.ones(2),joints=np.arange(2))
    a.motion_path=(np.zeros(2),np.array([.5,0.]));a.motion_index=0;a.motion_key=('free',0)
    a.motion_goal=pose([0.,0.,0.]);a.motion_origin=world.base_pose_world.copy();a.motion_stamp=world.stamp
    a.motion_scene=N(forward=lambda q:pose([0.,0.,0.]),valid=valid)
    a.controller=N(initial_joint=np.zeros(2));a.posture_diagnostic={}
    a.env=N(sim=N(model=N(_model=N(jnt_range=np.array([[-1.,1.],[-1.,1.]])))))
    w=replace(world,eef_pose_world=pose([0.,0.,0.]),changed_keys=frozenset(),signals={'robot_kinematic_qpos':np.array([-.5,0.])})
    return a,w


def test_unheld_free_motion_can_continue_from_redundant_attained_pose(cfg,world):
    a,w=adapter(cfg,world)
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==1 and a.posture_diagnostic['attained_connection_checked']
    # The existing joint tracking criterion is unchanged.
    assert a.posture_diagnostic['joint_tracking_tolerance_rad']==.1


def test_collision_and_native_joint_crossing_block_handoff(cfg,world):
    a,w=adapter(cfg,world,lambda q:abs(q[0])>.1)
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==0 and not a.posture_diagnostic['attained_connection_checked']
    a,w=adapter(cfg,world);w=replace(w,signals={'robot_kinematic_qpos':np.array([-1.000001,0.])})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==0


def test_not_attained_pose_and_terminal_waypoint_never_skip(cfg,world):
    calls=[];a,w=adapter(cfg,world,lambda q:calls.append(q) or True)
    w=replace(w,eef_pose_world=pose([.1,0.,0.]))
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==0 and not calls
    a,w=adapter(cfg,world);a.motion_index=1
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==1 and not a.posture_diagnostic['attained_connection_checked']


def test_hinge_branch_tracking_rejects_redundant_handoff_but_retains_other_paths(cfg,world):
    a,w=adapter(cfg,world)
    cfg['control']['posture_ik']['path_planning']['hinge_continuation']['track_admitted_branch']=True
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,hinge_contact=('microwave','handle',.005))
    assert a.motion_index==0
    assert a.posture_diagnostic['admitted_hinge_branch_tracking']
    assert a.posture_diagnostic['joint_tracking_tolerance_rad']==.1
    # Other free motions retain the previously sampled redundant handoff.
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==1 and a.posture_diagnostic['attained_connection_checked']


def test_hinge_branch_tracking_advances_only_after_original_joint_and_pose_tolerances(cfg,world):
    a,w=adapter(cfg,world)
    cfg['control']['posture_ik']['path_planning']['hinge_continuation']['track_admitted_branch']=True
    w=replace(w,signals={'robot_kinematic_qpos':np.array([-.05,0.])})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,hinge_contact=('microwave','handle',.005))
    assert a.motion_index==1
    a,w=adapter(cfg,world);w=replace(w,eef_pose_world=pose([.1,0.,0.]),signals={'robot_kinematic_qpos':np.zeros(2)})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,hinge_contact=('microwave','handle',.005))
    assert a.motion_index==0


def test_hinge_branch_default_preserves_original_handoff(cfg,world):
    a,w=adapter(cfg,world)
    assert not cfg['control']['posture_ik']['path_planning']['hinge_continuation']['track_admitted_branch']
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,hinge_contact=('microwave','handle',.005))
    assert a.motion_index==1


def test_hinge_approach_completion_requires_attained_final_joint_waypoint(cfg,world):
    a,w=adapter(cfg,world)
    policy=cfg['control']['posture_ik']['path_planning']['hinge_continuation']
    policy.update(enabled=True,track_admitted_branch=True)
    cfg['control']['posture_ik']['path_planning']['enabled']=True
    contract=N(contract_id='free',call=N(skill='close_hinged_door'))
    phase=N(phase_index=0,phase_name='approach')
    assert not a.hinge_approach_branch_ready(contract,phase,np.array([.5,0.]))
    a.motion_index=1
    assert not a.hinge_approach_branch_ready(contract,phase,np.zeros(2))
    assert a.hinge_approach_branch_ready(contract,phase,np.array([.45,0.]))
    assert not a.hinge_approach_branch_ready(contract,phase,np.array([np.nan,0.]))
    a.motion_key=('wrong',0)
    assert not a.hinge_approach_branch_ready(contract,phase,np.array([.5,0.]))
    phase.phase_name='around_door'
    assert a.hinge_approach_branch_ready(contract,phase,np.zeros(2))


def test_disabled_planner_does_not_impose_hinge_branch_completion(cfg,world):
    a,w=adapter(cfg,world)
    cfg['control']['posture_ik']['path_planning']['enabled']=False
    cfg['control']['posture_ik']['path_planning']['hinge_continuation'].update(enabled=True,track_admitted_branch=True)
    assert a.hinge_approach_branch_ready(N(call=N(skill='close_hinged_door')),N(phase_name='approach'),np.zeros(2))
