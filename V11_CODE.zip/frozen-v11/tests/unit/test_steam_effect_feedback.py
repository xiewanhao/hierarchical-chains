"""Regression: native completed placements must reach the existing selector mask."""
import sys
from types import SimpleNamespace as N, ModuleType
import numpy as np
import pytest
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.components.c11_selector import apply_observed_effect_eligibility
from five_chains.types import SkillCall


@pytest.mark.parametrize('skill', ['place_object_in_container', 'carry_container_to_region'])
def test_steam_builder_filters_only_currently_satisfied_completed_binding(tmp_path, skill):
    a=object.__new__(RoboCasaAdapter)
    a.config={'environment':{'selector_camera':'agentview'}}
    a.env=N(sim=N(render=lambda **kw:np.zeros((256,256,3),dtype=np.uint8)))
    live=[True];queries=[]
    def query(obj,target):
        queries.append((obj,target))
        return live[0] and (obj,target)==('bowl','microwave_interior')
    a.placement_satisfied=query
    history=[SkillCall('done',3,skill,{'object':'bowl','target':'microwave_interior'})]
    obs={'state':{'entities':{'bowl':{},'vegetable':{},'microwave_interior':{}},
                  'signals':{'predicates':{'bowl_in_microwave':True}}}}
    sample=a.selector_sample('Steam',obs,history,tmp_path/'camera.png')
    calls=[{'primary':k,'bindings':{'object':'bowl','target':'microwave_interior'}}
           for k in ('place_object_in_container','carry_container_to_region')]
    calls += [{'primary':'place_object_in_container','bindings':{'object':'vegetable','target':'bowl'}},
              {'primary':'close_and_start_appliance','bindings':{'appliance':'microwave'}}]
    model=N(candidates=lambda incoming:calls)
    report=apply_observed_effect_eligibility(model,sample)
    assert model.candidates(sample)==calls[2:]
    assert len(report['rejected'])==2
    assert model.candidates({})==calls
    assert queries==[('bowl','microwave_interior')]
    # Re-read live native geometry: a disturbed or removed bowl becomes eligible.
    live[0]=False
    fresh=a.selector_sample('Steam',obs,history,tmp_path/'fresh.png')
    model=N(candidates=lambda incoming:calls)
    report=apply_observed_effect_eligibility(model,fresh)
    assert model.candidates(fresh)==calls and not report['rejected']
    # Initially satisfied objects without completed history are not inferred plans.
    live[0]=True
    assert not a.selector_sample('Steam',obs,[],tmp_path/'initial.png')['measured_satisfied_effects']


def test_native_relation_reader_uses_unmodified_native_queries(monkeypatch):
    utils=ModuleType('robocasa.utils');queries=[]
    utils.object_utils=N(check_obj_in_receptacle=lambda *args:queries.append(('receptacle',args)) or True,
                         obj_inside_of=lambda *args:queries.append(('inside',args)) or False)
    monkeypatch.setitem(sys.modules,'robocasa.utils',utils)
    a=object.__new__(RoboCasaAdapter);a.env=N(objects={'vegetable':object(),'bowl':object()},microwave=object())
    assert a.placement_satisfied('vegetable','bowl')
    assert queries[-1]==('receptacle',(a.env,'vegetable','bowl'))
    assert not a.placement_satisfied('bowl','microwave_interior')
    assert queries[-1]==('inside',(a.env,'bowl',a.env.microwave))
    before=len(queries)
    assert not a.placement_satisfied(None,'bowl')
    assert not a.placement_satisfied('bowl','unknown')
    assert len(queries)==before
