from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.config import validate_config
from five_chains.geometry import pose
from test_attained_waypoint import adapter


def held_adapter(cfg,world):
    a,w=adapter(cfg,world)
    cfg['control']['posture_ik']['path_planning']['strict_payload_alignment_tracking']=True
    a.grasp_transforms={'basket':np.eye(4)}
    return a,replace(w,signals={**w.signals,'grasp_transforms':a.grasp_transforms})


def test_explicit_payload_preserves_original_joint_pose_and_reference_slew(cfg,world):
    a,w=held_adapter(cfg,world)
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,'basket',payload_alignment_tracking=True,prefer_nearby_orientation=True)
    assert a.motion_index==0 and a.posture_diagnostic['strict_payload_alignment_tracking']
    assert not a.posture_diagnostic['attained_connection_checked']
    assert a.posture_diagnostic['joint_tracking_tolerance_rad']==.1
    w=replace(w,signals={**w.signals,'robot_kinematic_qpos':np.array([-.05,0.])})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,'basket',payload_alignment_tracking=True)
    assert a.motion_index==1
    assert np.max(np.abs(a.controller.initial_joint))<=cfg['control']['posture_ik']['max_reference_step_rad']


def test_payload_cartesian_and_final_branch_both_remain_required(cfg,world):
    a,w=held_adapter(cfg,world)
    w=replace(w,eef_pose_world=pose([.013,0.,0.]),signals={**w.signals,'robot_kinematic_qpos':np.zeros(2)})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,'basket',payload_alignment_tracking=True)
    assert a.motion_index==0
    cfg['control']['posture_ik']['path_planning']['enabled']=True
    c=N(contract_id='free',call=N(skill='carry_container_to_region',bindings={'object':'basket'}),phases=[N(target_field='payload_alignment_pose')]);p=N(phase_index=0,phase_name='align_payload_outside')
    assert not a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
    a.motion_index=1
    assert not a.hinge_approach_branch_ready(c,p,np.zeros(2))
    assert not a.hinge_approach_branch_ready(c,p,np.array([np.nan,0.]))
    assert a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
    a.motion_key=('old',0)
    assert not a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
    p.phase_name='raise_torso'
    assert a.hinge_approach_branch_ready(c,p,np.zeros(2))


@pytest.mark.parametrize('explicit,enabled,contact,held,hinge',[(False,True,'basket','basket',False),(True,False,'basket','basket',False),(True,True,None,'basket',False),(True,True,'basket','other',False),(True,True,'basket',None,False),(True,True,'basket','basket',True)])
def test_payload_adapter_requires_explicit_matching_held_object(cfg,world,explicit,enabled,contact,held,hinge):
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning']['strict_payload_alignment_tracking']=enabled
    w=replace(w,signals={**w.signals,'grasp_transforms':{held:np.eye(4)} if held else {}})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,contact,payload_alignment_tracking=explicit,hinge_contact=('cab','handle',0.) if hinge else None)
    assert a.motion_index==1 and not a.posture_diagnostic['strict_payload_alignment_tracking']


@pytest.mark.parametrize('phase,held,enabled,override,expected',[('align_payload_outside','basket',True,False,True),('align_payload_outside','other',True,False,False),('align_payload_outside',None,True,False,False),('align_payload_outside','basket',False,False,False),('align_payload_outside','basket',True,True,False),('raise_to_entry','basket',True,False,False),('lift','basket',True,False,False)])
def test_c10_only_selected_held_alignment_requests_strict_scope(C,world,monkeypatch,phase,held,enabled,override,expected):
    from five_chains.types import SkillCall,ReflexOverride
    from five_chains.chains.c1_prep import chain1_prep
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'vegetable','target':'bowl'})
    c,_,p7,proposal=chain1_prep(call,world,C);packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name==phase),phase_name=phase)
    cfg=C.c10.config;cfg['control']['posture_ik']['path_planning'].update(enabled=True,strict_payload_alignment_tracking=enabled)
    w=replace(world,signals={**world.signals,'grasp_transforms':{'vegetable' if held=='basket' else held:np.eye(4)} if held else {}})
    calls=[];monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',lambda target,*args,**kwargs:calls.append(kwargs) or target,raising=False)
    C.c10.solve(packet,c,p7,w,ReflexOverride('hold',None,'test') if override else None)
    assert bool(calls and calls[0].get('payload_alignment_tracking'))==expected


def test_payload_flag_default_and_boolean_validation(cfg):
    assert cfg['control']['posture_ik']['path_planning']['strict_payload_alignment_tracking'] is False
    cfg['control']['posture_ik']['path_planning']['strict_payload_alignment_tracking']=1
    with pytest.raises(ValueError,match='strict payload alignment'):validate_config(cfg)
