from dataclasses import replace
from copy import deepcopy
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose
from five_chains.types import SkillCall
from five_chains.skills.recipes import RecipeRegistry,GeometricGraspProvider


def prepare(cfg,C,world,enabled,transform=None,angle=-1.3):
    cfg=deepcopy(cfg);cfg['base']['door_arc_bisector_heading']=enabled
    transform=np.eye(4) if transform is None else transform
    w=replace(world,entities={n:replace(e,pose_world=transform@e.pose_world) for n,e in world.entities.items()},
              base_pose_world=transform@world.base_pose_world,
              signals={**world.signals,'microwave_hinge':{'angle':angle,'anchor_world':(transform@np.array([.6,.1,1.,1.]))[:3],
                 'axis_world':transform[:3,:3]@np.array([0.,0.,1.])}})
    call=SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'})
    c=C.c12.expand(call);recipes=RecipeRegistry(GeometricGraspProvider(cfg),cfg)
    goal=w.entities['microwave'].pose_world@recipes.prepare(c.fields['base_at_door'],c,w)
    return goal,w


def test_balanced_heading_keeps_existing_stance_translation_and_bisects_bearings(cfg,C,world):
    old,_=prepare(cfg,C,world,False);new,w=prepare(cfg,C,world,True)
    assert np.allclose(old[:3,3],new[:3,3])
    h=w.signals['microwave_hinge'];anchor=np.array(h['anchor_world']);handle=w.entities['handle'].pose_world[:3,3]
    closed=anchor+Rotation.from_rotvec(-h['angle']*h['axis_world']).as_matrix()@(handle-anchor)
    first=handle[:2]-new[:2,3];last=closed[:2]-new[:2,3]
    expected=first/np.linalg.norm(first)+last/np.linalg.norm(last);expected/=np.linalg.norm(expected)
    assert np.allclose(new[:2,0],expected)


def test_heading_forecast_is_equivariant_under_scene_translation_and_rotation(cfg,C,world):
    first,_=prepare(cfg,C,world,True)
    transform=pose([1.2,-.7,.1],Rotation.from_euler('z',.8).as_matrix())
    moved,_=prepare(cfg,C,world,True,transform)
    assert np.allclose(moved,transform@first)


def test_closed_door_keeps_original_heading_without_a_new_turn(cfg,C,world):
    old,_=prepare(cfg,C,world,False,angle=0.)
    new,_=prepare(cfg,C,world,True,angle=0.)
    assert np.allclose(new,old)
