from dataclasses import replace
import numpy as np
import pytest
from five_chains.geometry import pose,inverse
from five_chains.chains.c1_prep import chain1_prep
from test_elevated_receptacle import elevated
from five_chains.config import validate_config


def test_source_clearance_preserves_world_attitude_and_final_placement(C,call,world):
    w=elevated(world,held=True);original=C.c12.expand(call);c=C.c12.initialize_entry(original,w)
    names=[p.name for p in c.phases]
    assert names.index('lift')<names.index('clear_source')<names.index('base_to_clearance')
    assert c.phases[names.index('clear_source')].gripper=='close'
    assert c.phases[names.index('base_to_clearance')].enter_when=='reached'
    assert c.fields['place_pose'] is original.fields['place_pose']
    spec=c.fields['source_clearance_pose'];local=C.c6.recipes.prepare(spec,c,w)
    goal=w.entities['vegetable'].pose_world@local;delta=goal[:3,3]-w.entities['vegetable'].pose_world[:3,3]
    toward=w.base_pose_world[:2,3]-w.eef_pose_world[:2,3];toward/=np.linalg.norm(toward)
    assert np.allclose(delta,np.r_[toward*.05,.075])
    assert np.allclose(goal[:3,:3],w.entities['vegetable'].pose_world[:3,:3])


def test_clear_source_uses_existing_c10_collision_planning(C,call,world):
    w=elevated(world,held=True);C.c10.config['control']['posture_ik']['path_planning']['enabled']=True
    c,p6,p7,prop=chain1_prep(call,w,C);packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    index=next(i for i,p in enumerate(c.phases) if p.name=='clear_source');p7=replace(p7,phase_index=index,phase_name='clear_source')
    calls=[];C.c10.adapter.prepare_motion_path=lambda target,*args:calls.append(target.copy()) or target.copy()
    C.c10.solve(packet,c,p7,w,None)
    assert calls and C.c10.last_actuator=='arm'
    assert np.allclose(calls[0],packet.params['source_clearance_pose'].value)


@pytest.mark.parametrize('key,value',[('retreat_m',0.),('up_m',float('nan')),('up_m',.21)])
def test_invalid_developmental_clearance_is_rejected(cfg,key,value):
    cfg['grasp']['source_transport_clearance'][key]=value
    with pytest.raises(ValueError,match='bounded source transport'):validate_config(cfg)
