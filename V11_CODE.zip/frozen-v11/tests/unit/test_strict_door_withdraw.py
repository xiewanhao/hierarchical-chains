from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.geometry import pose
from five_chains.config import validate_config
from test_attained_waypoint import adapter


def test_explicit_door_withdraw_retains_old_joint_and_cartesian_criteria(cfg,world):
    a,w=adapter(cfg,world)
    cfg['control']['posture_ik']['path_planning']['strict_door_withdraw_tracking']=True
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,door_withdraw_tracking=True)
    assert a.motion_index==0 and not a.posture_diagnostic['attained_connection_checked']
    assert a.posture_diagnostic['strict_door_withdraw_tracking']
    assert not a.posture_diagnostic['admitted_hinge_branch_tracking']
    assert a.posture_diagnostic['joint_tracking_tolerance_rad']==.1
    w=replace(w,signals={'robot_kinematic_qpos':np.array([-.05,0.])})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,door_withdraw_tracking=True)
    assert a.motion_index==1


def test_scope_and_default_preserve_other_free_handoffs(cfg,world):
    a,w=adapter(cfg,world)
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,door_withdraw_tracking=True)
    assert a.motion_index==1 and not a.posture_diagnostic['strict_door_withdraw_tracking']
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning']['strict_door_withdraw_tracking']=True
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None)
    assert a.motion_index==1 and not a.posture_diagnostic['strict_door_withdraw_tracking']


def test_not_cartesian_attained_never_advances_strict_withdraw(cfg,world):
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning']['strict_door_withdraw_tracking']=True
    w=replace(w,eef_pose_world=pose([.013,0.,0.]),signals={'robot_kinematic_qpos':np.zeros(2)})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,door_withdraw_tracking=True)
    assert a.motion_index==0


def test_final_branch_required_only_for_selected_door_withdraw(cfg,world):
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning'].update(enabled=True,strict_door_withdraw_tracking=True)
    c=N(contract_id='free',call=N(skill='close_hinged_door'));p=N(phase_index=0,phase_name='withdraw')
    assert not a.hinge_approach_branch_ready(c,p,np.zeros(2))
    a.motion_index=1
    assert not a.hinge_approach_branch_ready(c,p,np.zeros(2))
    assert a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
    assert not a.hinge_approach_branch_ready(c,p,np.array([float('nan'),0.]))
    c.call.skill='place_object_in_container'
    assert a.hinge_approach_branch_ready(c,p,np.zeros(2))
    c.call.skill='close_hinged_door';p.phase_name='release_contact'
    assert a.hinge_approach_branch_ready(c,p,np.zeros(2))


def test_setting_defaults_false_and_requires_bool(cfg):
    pc=cfg['control']['posture_ik']['path_planning'];assert pc['strict_door_withdraw_tracking'] is False
    pc['strict_door_withdraw_tracking']=1
    with pytest.raises(ValueError,match='strict door withdraw'):validate_config(cfg)


@pytest.mark.parametrize('skill,phase,expected',[('close_hinged_door','withdraw',True),('close_hinged_door','approach',False),('close_hinged_door','around_door',False)])
def test_c10_scopes_strict_tracking_to_selected_door_withdraw(C,world,monkeypatch,skill,phase,expected):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    w=replace(world,signals={**world.signals,'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    c,p6,p7,proposal=chain1_prep(SkillCall('door',3,skill,{'appliance':'microwave','handle':'handle'}),w,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name==phase),phase_name=phase)
    C.c10.config['control']['posture_ik']['path_planning'].update(enabled=True,strict_door_withdraw_tracking=True)
    C.c10.config['base']['assist_during_door']=False
    calls=[];monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',lambda target,*a,**k:calls.append(k) or target,raising=False)
    C.c10.solve(packet,c,p7,w,None)
    assert bool(calls and calls[0].get('door_withdraw_tracking'))==expected
