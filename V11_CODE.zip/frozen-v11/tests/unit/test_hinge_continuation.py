from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.geometry import pose
from five_chains.config import validate_config


def setup(cfg,world,monkeypatch,mode):
    from five_chains.envs import scene_path
    calls=[]
    class Scene:
        def __init__(self,*args):pass
        def configure(self,q,held,joints,contact,relation,tilt,epsilon):
            calls.append((q.copy(),contact,epsilon))
        def valid(self,q):return mode!='collision'
    monkeypatch.setattr(scene_path,'StaticScene',Scene)
    class Solver:
        qpos=np.array([1])
        site=0
        def solve(self,target,q):
            self.target=target.copy()
            return N(success=not(mode=='ik' and q[0]>-.5),joints=[q[1]+(1. if mode=='jump' else .001)])
        def forward(self,q,joints):return self.target.copy()
    a=object.__new__(RoboCasaAdapter);a.config=cfg;a.posture_solver=Solver()
    a.env=N(sim=N(model=N(_model=N(jnt_qposadr=np.array([0])),joint_name2id=lambda n:0)),
            microwave=N(door_joint_names=['door'],handle_name='fixture_handle_main'))
    w=replace(world,signals={**world.signals,'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    nominal=pose(w.entities['handle'].pose_world[:3,3]+np.array([0.,-.06,0.]))
    return a,w,nominal,calls


def test_future_hinge_gate_rejects_endpoint_with_no_continuation_without_state_writes(cfg,world,monkeypatch):
    a,w,nominal,calls=setup(cfg,world,monkeypatch,'ik');q=np.array([-1.,0.]);before=q.copy()
    r=a.hinge_contact_continuation(q,np.array([0.]),nominal,nominal,w,('microwave','handle',.005))
    assert not r['admitted'] and r['reason']=='strict_ik' and r['failed_stage']=='hinge_arc'
    assert np.array_equal(q,before) and calls
    assert all(c[1]=='fixture_handle' and c[2]==cfg['control']['posture_ik']['path_planning']['penetration_epsilon_m'] for c in calls)


def test_future_hinge_gate_accepts_strict_continuous_clear_branch(cfg,world,monkeypatch):
    a,w,nominal,calls=setup(cfg,world,monkeypatch,'clear');q=np.array([-1.,0.])
    r=a.hinge_contact_continuation(q,np.array([0.]),nominal,nominal,w,('microwave','handle',.005))
    assert r['admitted'] and r['last_angle_rad']==0. and r['samples']>=64
    assert np.array_equal(q,[-1.,0.]) and calls[-1][0][0]==0.


@pytest.mark.parametrize('mode,reason',[('jump','branch_discontinuity'),('collision','scene_collision')])
def test_forecast_cannot_accept_branch_jump_or_other_scene_collision(cfg,world,monkeypatch,mode,reason):
    a,w,nominal,calls=setup(cfg,world,monkeypatch,mode)
    r=a.hinge_contact_continuation(np.array([-1.,0.]),np.array([0.]),nominal,nominal,w,('microwave','handle',.005))
    assert not r['admitted'] and r['reason']==reason


def test_invalid_continuation_forecast_cannot_widen_branch_jump_guard(cfg):
    cfg['control']['posture_ik']['path_planning']['hinge_continuation']['max_joint_step_rad']=.4
    with pytest.raises(ValueError,match='hinge continuation'):validate_config(cfg)


@pytest.mark.parametrize('enabled,phase,expected',[(True,'approach',True),(False,'approach',False),(True,'around_door',False)])
def test_c10_routes_forecast_only_for_selected_door_contact_approach(C,world,monkeypatch,enabled,phase,expected):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    w=replace(world,signals={**world.signals,'surface_normals':{'handle':np.array([-1.,0.,0.])},
        'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    c,p6,p7,proposal=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),w,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name==phase),phase_name=phase)
    C.c10.config['control']['posture_ik']['path_planning']['enabled']=True
    C.c10.config['control']['posture_ik']['path_planning']['hinge_continuation']['enabled']=enabled
    C.c10.config['base']['assist_during_door']=False
    seen=[]
    def plan(target,*args,**kwargs):seen.append(kwargs);return target
    monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',plan,raising=False)
    C.c10.solve(packet,c,p7,w,None)
    assert len(seen)==1 and ('hinge_contact' in seen[0])==expected
    if expected:assert seen[0]['hinge_contact']==('microwave','handle',.005)
