from types import SimpleNamespace as N
from dataclasses import replace
import numpy as np
import pytest
from five_chains.types import ReflexBounds, ReflexOverride
from five_chains.components.c09_reflex import ReflexLayer
from five_chains.envs.robocasa_adapter import RoboCasaAdapter


def obs(loads=(2.,2.),reference=.056,width=.070,**changes):
    sample=dict(source='native_simulator_contact_solver',closing_intent=True,bilateral_native_pads=True,
                actuator_kp_n_m=[1000.,1000.],joint_frictionloss_n=[1.,1.],
                pad_normal_loads_n=list(loads),reference_width_m=reference,measured_width_m=width,open_step_width_m=.008)
    sample.update(changes)
    return {'state':{'signals':{'native_motion_diagnostics':{'gripper_reference_feedback':sample}}}}


def bounds():return ReflexBounds(.003,.03,None,True,(1.,3.),.002)


def test_native_load_feedback_closes_holds_and_bounded_open_pulses():
    layer=ReflexLayer(True);b=bounds()
    assert layer.step(b,obs((.8,2.))).gripper_action==1.
    assert layer.step(b,obs()).gripper_action==0.
    assert layer.step(b,obs((5.,5.))).gripper_action==-1.
    # A full native8mm opening step must not pass measured jawwidth-preload.
    assert layer.step(b,obs((5.,5.),reference=.064)).gripper_action==0.
    assert layer.step(b,obs((5.,5.),reference=.060)).gripper_action==0.  # Native friction loss requires4mm total reserve.
    assert layer.step(b,obs((5.,2.))).gripper_action==0.  # Both sides needed before opening.


def test_native_feedback_never_masks_missing_bilateral_contact_or_stop():
    layer=ReflexLayer(True);b=bounds()
    assert layer.step(b,obs(bilateral_native_pads=False)) is None
    assert layer.step(b,obs(closing_intent=False)) is None
    assert ReflexLayer(False).step(b,obs()) is None
    assert layer.step(replace(b,gripper_load_band_n=None),obs()) is None
    state=obs();state['state']['signals']['unexpected_contact']=True
    assert layer.step(b,state).kind=='stop'
    with pytest.raises(ValueError):layer.step(b,obs(source='imagined_force'))
    with pytest.raises(ValueError):layer.step(b,obs((float('nan'),2.)))


def test_official_panda_zero_holds_reference_and_fractional_nonzero_is_full_pulse():
    from robosuite.models.grippers.panda_gripper import PandaGripper
    g=object.__new__(PandaGripper);g.current_action=np.array([-.5,.5])
    assert np.array_equal(g.format_action(np.array([0.])),[-.5,.5])
    before=g.current_action.copy();full=g.format_action(np.array([1.])).copy();g.current_action=before.copy()
    assert np.allclose(g.format_action(np.array([.001])),full)
    g.current_action=before.copy();opened=g.format_action(np.array([-1.]))
    # Native qtarget width changes8mm, not a fractional force command.
    assert np.isclose(sum(abs(.02*(v+(1 if i==0 else -1))) for i,v in enumerate(opened))-
                      sum(abs(.02*(v+(1 if i==0 else -1))) for i,v in enumerate(before)),.008)


def test_reference_command_changes_only_the_native_gripper_segment():
    a=object.__new__(RoboCasaAdapter);a.arm='right';a.composite=N(_action_split_indexes={'right_gripper':(2,3)})
    a.env=N(action_spec=(-np.ones(4),np.ones(4)))
    original=np.array([.1,.2,1.,.3]);saved=original.copy()
    held=a.gripper_reference_action(original,0.)
    assert np.array_equal(original,saved) and np.array_equal(held, [.1,.2,0.,.3])
    with pytest.raises(ValueError):a.gripper_reference_action(original,.1)


def test_gripper_only_reflex_does_not_hold_arm_or_override_open_release(C,call,world):
    from five_chains.chains.c1_prep import chain1_prep
    contract,_,phase,proposal=chain1_prep(call,world,C);packet,_=C.c10.arbitrate(None,[proposal],contract,C.c12)
    phase=replace(phase,phase_index=next(i for i,p in enumerate(contract.phases) if p.name=='grasp'),phase_name='grasp')
    normal=C.c10.solve(packet,contract,phase,world,None);target=C.c10.last_target.copy()
    C.c10.reference=None;C.c10.reference_key=None
    C.adapter.gripper_reference_action=lambda action,command:np.r_[action,command]
    adjusted=C.c10.solve(packet,contract,phase,world,ReflexOverride('gripper_reference',None,'native_gripper_reference_feedback',0.))
    assert np.allclose(normal,adjusted[:-1]) and adjusted[-1]==0. and np.allclose(C.c10.last_target,target)
    open_phase=replace(phase,phase_index=next(i for i,p in enumerate(contract.phases) if p.name=='release'),phase_name='release')
    output=C.c10.solve(packet,contract,open_phase,world,ReflexOverride('gripper_reference',None,'native_gripper_reference_feedback',-1.))
    assert output.shape==normal.shape and C.c10.last_gripper=='open'


def test_c8_uses_selected_candidate_load_and_preserves_unsupported_grasps(C,call,world):
    from five_chains.types import P7
    C.c8.config['reflex']['bounds']['gripper_load_band_n']=[1.,3.]
    contract=C.c12.expand(call);phase=P7.initial(contract)
    def prepared(cost,feasible=True):return N(fields={'grasp_pose':N(status='ready',provenance={'gravity_support':{'reduced_model_feasible':feasible,'minimum_normal_per_pad_n':cost}})})
    assert C.c8.bounds(contract,phase,prepared(.272)).gripper_load_band_n==(1.,3.)
    assert C.c8.bounds(contract,phase,prepared(1.)).gripper_load_band_n==(2.,4.)
    assert C.c8.bounds(contract,phase,prepared(None,False)).gripper_load_band_n is None
    assert C.c8.bounds(contract,phase,prepared(6.)).gripper_load_band_n is None
    assert C.c8.bounds(contract,phase).gripper_load_band_n is None
