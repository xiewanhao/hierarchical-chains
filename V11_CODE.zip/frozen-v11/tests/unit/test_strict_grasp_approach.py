from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.config import validate_config
from five_chains.geometry import pose
from test_attained_waypoint import adapter


def test_explicit_grasp_approach_requires_original_joint_and_pose(cfg,world):
    a,w=adapter(cfg,world);pc=cfg['control']['posture_ik']['path_planning'];pc['strict_grasp_approach_tracking']=True
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,'vegetable',grasp_approach_tracking=True)
    assert a.motion_index==0 and a.posture_diagnostic['strict_grasp_approach_tracking']
    assert not a.posture_diagnostic['attained_connection_checked'] and a.posture_diagnostic['joint_tracking_tolerance_rad']==.1
    w=replace(w,signals={'robot_kinematic_qpos':np.array([-.05,0.])})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,'vegetable',grasp_approach_tracking=True)
    assert a.motion_index==1


@pytest.mark.parametrize('explicit,enabled,contact,held',[(False,True,'vegetable',False),(True,False,'vegetable',False),(True,True,None,False),(True,True,'vegetable',True)])
def test_other_free_scope_retains_original_handoff(cfg,world,explicit,enabled,contact,held):
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning']['strict_grasp_approach_tracking']=enabled
    if held:w=replace(w,signals={**w.signals,'grasp_transforms':{'vegetable':np.eye(4)}})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,contact,grasp_approach_tracking=explicit)
    assert a.motion_index==1 and not a.posture_diagnostic['strict_grasp_approach_tracking']


def test_strict_grasp_cannot_advance_without_original_cartesian_admission(cfg,world):
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning']['strict_grasp_approach_tracking']=True
    w=replace(w,eef_pose_world=pose([.013,0.,0.]),signals={'robot_kinematic_qpos':np.zeros(2)})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,'vegetable',grasp_approach_tracking=True)
    assert a.motion_index==0


def test_final_grasp_approach_needs_final_original_joint_waypoint(cfg,world):
    a,w=adapter(cfg,world);cfg['control']['posture_ik']['path_planning'].update(enabled=True,strict_grasp_approach_tracking=True)
    c=N(contract_id='free',call=N(skill='carry_container_to_region'),phases=[N(target_field='pregrasp_pose')]);p=N(phase_index=0,phase_name='approach')
    assert not a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
    a.motion_index=1;assert not a.hinge_approach_branch_ready(c,p,np.zeros(2))
    assert a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
    assert not a.hinge_approach_branch_ready(c,p,np.array([np.nan,0.]))
    p.phase_name='descend';assert a.hinge_approach_branch_ready(c,p,np.zeros(2))


@pytest.mark.parametrize('skill,phase,held,expected',[('place_object_in_container','approach',False,True),('carry_container_to_region','approach',False,True),('place_object_in_container','descend',False,False),('place_object_in_container','approach',True,False)])
def test_c10_requests_only_selected_unheld_pregrasp(C,world,monkeypatch,skill,phase,held,expected):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    call=SkillCall('object',3,skill,{'object':'vegetable','target':'bowl'})
    c,_,p7,proposal=chain1_prep(call,world,C);packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name==phase),phase_name=phase)
    cfg=C.c10.config;cfg['control']['posture_ik']['path_planning'].update(enabled=True,strict_grasp_approach_tracking=True);cfg['base']['assist_during_approach']=False
    w=replace(world,signals={**world.signals,'grasp_transforms':{'vegetable':np.eye(4)} if held else {}})
    calls=[];monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',lambda target,*args,**kwargs:calls.append(kwargs) or target,raising=False)
    C.c10.solve(packet,c,p7,w,None)
    assert bool(calls and calls[0].get('grasp_approach_tracking'))==expected


def test_strict_grasp_default_false_and_boolean_validation(cfg):
    assert cfg['control']['posture_ik']['path_planning']['strict_grasp_approach_tracking'] is False
    cfg['control']['posture_ik']['path_planning']['strict_grasp_approach_tracking']=1
    with pytest.raises(ValueError,match='strict grasp approach'):validate_config(cfg)
