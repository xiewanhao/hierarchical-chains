from dataclasses import replace
import numpy as np
import pytest
from five_chains.config import validate_config
from five_chains.types import SkillCall
from five_chains.chains.c1_prep import chain1_prep


@pytest.mark.parametrize('enabled,strict,clear,phase,expected',[
    (True,True,True,'withdraw',True),
    (False,True,True,'withdraw',False),
    (True,False,True,'withdraw',False),
    (True,True,False,'withdraw',False),
    (True,True,True,'approach',False),
    (True,True,True,'around_door',False),
])
def test_withdraw_attitudes_require_selected_strict_phase_and_admission(C,world,monkeypatch,enabled,strict,clear,phase,expected):
    w=replace(world,signals={**world.signals,'surface_normals':{'handle':np.array([-1.,0.,0.])},
        'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    c,p6,p7,proposal=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),w,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name==phase),phase_name=phase)
    planning=C.c10.config['control']['posture_ik']['path_planning']
    planning.update(enabled=True,strict_door_withdraw_tracking=strict,door_withdraw_nearby_orientation=enabled)
    C.c10.config['base']['assist_during_door']=False
    seen=[]
    monkeypatch.setattr(C.c10.adapter,'contact_egress_start_clear',lambda w:clear,raising=False)
    monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',lambda target,*a,**k:seen.append((target.copy(),a,k)) or target,raising=False)
    C.c10.solve(packet,c,p7,w,None)
    assert seen and seen[0][1][-1] is expected
    if phase=='withdraw':
        assert np.array_equal(seen[0][0],packet.params['withdraw_pose'].value)
        assert bool(seen[0][2].get('door_withdraw_tracking')) is strict
        assert 'hinge_contact' not in seen[0][2] and 'cost_candidates' not in seen[0][2]


def test_default_off_and_boolean_validation(cfg):
    planning=cfg['control']['posture_ik']['path_planning']
    assert planning['door_withdraw_nearby_orientation'] is False
    planning['door_withdraw_nearby_orientation']=1
    with pytest.raises(ValueError,match='door withdraw orientation'):validate_config(cfg)


def test_nominal_cartesian_attainment_cannot_bypass_strict_final_branch(cfg,world):
    from types import SimpleNamespace as N
    from test_attained_waypoint import adapter
    a,w=adapter(cfg,world)
    cfg['control']['posture_ik']['path_planning'].update(enabled=True,strict_door_withdraw_tracking=True)
    original_reference=a.controller.initial_joint.copy()
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,
        prefer_nearby_orientation=True,door_withdraw_tracking=True)
    assert a.motion_index==0 and a.posture_diagnostic['strict_door_withdraw_tracking']
    assert not a.posture_diagnostic['attained_connection_checked']
    assert not hasattr(a,'contact_posture_key')
    assert np.max(np.abs(a.controller.initial_joint-original_reference))<=.03+1e-12
    c=N(contract_id='free',call=N(skill='close_hinged_door'))
    p=N(phase_index=0,phase_name='withdraw')
    assert not a.hinge_approach_branch_ready(c,p,w.signals['robot_kinematic_qpos'])
    w=replace(w,signals={'robot_kinematic_qpos':np.array([-.05,0.])})
    a.prepare_motion_path(a.motion_goal,w,a.motion_key,None,None,None,
        prefer_nearby_orientation=True,door_withdraw_tracking=True)
    assert a.motion_index==1
    assert not a.hinge_approach_branch_ready(c,p,w.signals['robot_kinematic_qpos'])
    assert a.hinge_approach_branch_ready(c,p,np.array([.45,0.]))
