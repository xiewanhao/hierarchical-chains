# -*- coding: utf-8 -*-
from dataclasses import replace
import copy
import numpy as np
import pytest
from five_chains.envs.reference_admission import (solve, Context, ForecastLease, ExecutedReferenceLedger)


def problem():
    return dict(base_reference=np.zeros(7), previous_executed_reference=np.zeros(7),
                forecast_reference=np.full(7, .02), A=np.zeros((7, 7)),
                base_torque=np.zeros(7), native_joint_ranges=np.tile([-2., 2.], (7, 1)),
                native_torque_ranges=np.tile([-12., 12.], (7, 1)))


def test_box_projection_is_global_solution_and_inputs_unchanged():
    p = problem(); p['forecast_reference'] = np.array([1., -.1, .01, 0, -.2, .005, 2.])
    before = copy.deepcopy(p); r = solve(**p)
    np.testing.assert_allclose(r['reference'], [.03, -.03, .01, 0, -.03, .005, .03], atol=1e-14)
    for k in p: np.testing.assert_array_equal(p[k], before[k])
    assert abs(r['certificate']['primal_dual_gap']) < 1e-12


def test_coupled_torque_needs_both_coordinates_not_only_saturated_joint():
    p = problem(); p['A'][6, :2] = [100., 100.]
    p['native_torque_ranges'][6] = [-1., 1.]
    r = solve(**p)
    np.testing.assert_allclose(r['reference'][:2], [.005, .005], atol=1e-10)
    np.testing.assert_allclose(r['reference'][2:], .02, atol=1e-10)
    assert r['predicted_torque'][6] == pytest.approx(1., abs=1e-10)
    assert r['method'] == 'highs_feasibility_then_SLSQP'


def test_all_seven_native_torque_bounds_including_negative_active_faces():
    p = problem(); p['A'] = 100 * np.eye(7)
    p['forecast_reference'] = np.array([.02, -.02, .02, -.02, .02, -.02, .02])
    p['native_torque_ranges'] = np.tile([-.5, 1.], (7, 1))
    r = solve(**p)
    np.testing.assert_allclose(r['reference'], [.01, -.005, .01, -.005, .01, -.005, .01], atol=1e-10)


def test_native_joint_margin_intersects_original_slew():
    p = problem(); p['native_joint_ranges'][0] = [-1., .025]
    r = solve(**p)
    assert r['reference'][0] == pytest.approx(.01, abs=1e-14)


def test_actual_reference_outside_reachable_inner_box_is_rejected():
    p = problem(); p['previous_executed_reference'][0] = 2.1
    r = solve(**p)
    assert r['status'] == 'infeasible_box' and r['reference'] is None


def test_primary_torque_excess_cannot_be_repaired_with_zero_map():
    p = problem(); p['base_torque'][3] = 13.
    r = solve(**p)
    assert r['status'] == 'infeasible_certified' and r['reference'] is None
    assert r['infeasibility_certificate']['separation_gap'] < 0


def test_slew_limited_authority_cannot_hide_primary_infeasibility():
    p = problem(); p['base_torque'][4] = 20.; p['A'][4, 0] = 1.
    r = solve(**p)
    assert r['status'] == 'infeasible_certified' and r['reference'] is None


def test_rank_one_redundant_constraints_have_certified_unique_projection():
    p = problem(); p['A'] = np.outer(np.arange(1., 8.), np.ones(7))
    p['native_torque_ranges'] = np.column_stack((-np.arange(1., 8.) * .07, np.arange(1., 8.) * .07))
    r = solve(**p)
    np.testing.assert_allclose(r['reference'], .01, atol=1e-9)
    assert abs(r['certificate']['primal_dual_gap']) < 1e-9


@pytest.mark.parametrize('kind', ['nan', 'inf', 'shape', 'joint_range', 'torque_range', 'margin'])
def test_invalid_inputs_return_no_reference(kind):
    p = problem()
    if kind == 'nan': p['A'][0, 0] = np.nan
    if kind == 'inf': p['forecast_reference'][1] = np.inf
    if kind == 'shape': p['A'] = np.zeros((6, 7))
    if kind == 'joint_range': p['native_joint_ranges'][0] = [1., -1.]
    if kind == 'torque_range': p['native_torque_ranges'][0] = [0., 0.]
    if kind == 'margin': p['native_joint_ranges'][0] = [0., .02]
    assert solve(**p)['reference'] is None


def test_fixed_input_determinism():
    p = problem(); p['A'][6, :2] = [100., 100.]; p['native_torque_ranges'][6] = [-1., 1.]
    assert solve(**p) == solve(**p)


def context():
    return Context('episode', 'call', 'contact', 'target', 'scene', 'close', 10, .5)


def lease(c):
    return ForecastLease(c.episode, c.call, c.contact_key, c.target_signature,
                         c.scene_generation, 9, 0., 1., 'online_private_forecast_from_observed_scene')


@pytest.mark.parametrize('change', [dict(call='other'), dict(phase='release_contact'),
    dict(episode='new'), dict(contact_key='new'), dict(target_signature='new'),
    dict(scene_generation='new'), dict(measured_angle=1.01), dict(measured_angle=np.nan), dict(tick=8)])
def test_forecast_call_phase_domain_and_future_guard(change):
    c = context(); assert not lease(c).valid(replace(c, **change))


def test_saved_fixture_cannot_masquerade_as_runtime_forecast():
    c = context()
    assert not replace(lease(c), source_kind='saved_future_actual_trajectory').valid(c)


def test_unexecuted_proposal_does_not_become_previous_reference():
    c = context(); book = ExecutedReferenceLedger(c, np.zeros(7)); p = problem()
    del p['previous_executed_reference']; nxt = replace(c, tick=11)
    r = book.propose(nxt, lease(c), 'execute-11', **p)
    np.testing.assert_array_equal(book.reference, np.zeros(7))
    assert book.propose(replace(c, tick=12), lease(c), 'execute-12', **p)['reference'] is None
    assert book.acknowledge(nxt, 'execute-11', r['reference'], True)
    np.testing.assert_array_equal(book.reference, r['reference'])
    assert book.propose(nxt, lease(c), 'duplicate-tick', **p)['reference'] is None


@pytest.mark.parametrize('failure', ['wrong_token', 'failure', 'different_executed_reference'])
def test_failed_or_mismatched_execution_invalidates_ledger(failure):
    c = context(); book = ExecutedReferenceLedger(c, np.zeros(7)); p = problem()
    del p['previous_executed_reference']; nxt = replace(c, tick=11)
    r = book.propose(nxt, lease(c), 'token', **p)
    token = 'wrong' if failure == 'wrong_token' else 'token'
    ref = np.zeros(7) if failure == 'different_executed_reference' else r['reference']
    assert not book.acknowledge(nxt, token, ref, failure != 'failure')
    assert not book.valid
    np.testing.assert_array_equal(book.reference, np.zeros(7))


def test_base_reference_is_distinct_from_actual_previous_executed_reference():
    p = problem(); p['base_reference'] = np.full(7, .2); p['A'] = np.eye(7)
    p['base_torque'] = np.full(7, .2)
    r = solve(**p)
    np.testing.assert_allclose(r['predicted_torque'], .02, atol=1e-14)


def test_context_change_invalidates_and_cannot_silently_resume_old_call():
    c = context(); book = ExecutedReferenceLedger(c, np.zeros(7)); p = problem()
    del p['previous_executed_reference']
    assert book.propose(replace(c, call='new', tick=11), lease(c), 'token', **p)['reference'] is None
    assert not book.valid
    assert book.propose(replace(c, tick=12), lease(c), 'old', **p)['reference'] is None
