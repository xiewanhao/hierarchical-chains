# -*- coding: utf-8 -*-
"""Synthetic necessary-evidence fixtures, never runtime receipt authority."""
from copy import deepcopy
from dataclasses import asdict,replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.envs.candidate_qualification import inspect,numerical_evidence
from five_chains.envs.forecast_dependencies import ForecastSource,fixed_inputs
from five_chains.envs.reference_bridge import Branch
from test_forecast_dependencies import fixture


def setup(cfg):
    a,q,w,c,s,d,knots=fixture(cfg)
    for k in knots:k['joints_rad']=[.2]*7
    source=ForecastSource.seal(d,knots);b=a.reference_bridge
    b.branch=Branch.captured(s,0,knots,np.zeros(7),source)
    b.begin(replace(s,phase='close',tick=11));b.prepare([0.],np.zeros(7),1.,0)
    b.before_execute([0.],np.zeros(7),1.,0);b.after_execute(np.zeros(7),1.05,1)
    b.begin(replace(s,phase='close',tick=12))
    b.source_comparison=source.compare_fixed(fixed_inputs(a,q,w,c,7))
    b.prepare([0.],np.zeros(7),1.05,1)
    action=np.zeros(1);base={'reference':[0.]*7,'torque':[.1]*7,'A':np.eye(7).tolist(),
        'primary_and_compensation':[.1]*7,'native_torque_ranges':[[-1.,1.]]*7,
        'original_action':[0.],'token':'fresh','full_qpos_qvel_unchanged':True,'private_integration_state_copied':True}
    binding={'token':'fresh','scope':b.scope,'action':action}
    preview={'binding':binding,'baseline':base}
    native={**deepcopy(base),'reference':[.03]*7,'torque':[.13]*7,'original_action':[0.],
        'token':'fresh','full_qpos_qvel_unchanged':True,'private_integration_state_copied':True}
    proposal={'status':'admitted_mathematical_fixture','proposal_applied':False,'reference':[.03]*7,
        'predicted_torque':[.13]*7,'private_native_verification':native,
        'certificate':{'normalized_inequality_multipliers':[.17]*7+[0.]*21},
        'input_binding':{'native_preview_token':'fresh','scope':asdict(b.scope),
            'previous_executed_reference':[0.]*7,'desired_forecast_reference':[.2]*7}}
    def verify(action,scope,token):
        if token!='fresh':raise ValueError('stale token')
    provider=N(verify=verify);ranges=np.tile([-3.,3.],(7,1))
    return b,preview,proposal,provider,action,ranges


def run(v):
    b,preview,proposal,provider,action,ranges=v
    return inspect(b,preview,proposal,provider,action,-.5,ranges)


def test_complete_synthetic_necessary_evidence_still_cannot_apply(cfg):
    result=run(setup(cfg))
    assert result['necessary_conditions_complete'] and result['numerical_evidence']['verified']
    assert not result['current_candidate_qualification_available'] and not result['experimental_admitted']
    assert result['reference'] is None and not result['proposal_applied']
    assert result['blockers']==['no_independent_current_candidate_qualification','reference_application_transaction_not_implemented']


@pytest.mark.parametrize('kind',['token','scope','previous','desired','native_action','native_reference','native_ranges','multipliers','primary','baseline_token','baseline_action'])
def test_changed_context_or_forged_numerics_rejects_candidate(cfg,kind):
    v=setup(cfg);p=v[2]
    if kind=='token':p['input_binding']['native_preview_token']='old'
    if kind=='scope':p['input_binding']['scope']['tick']+=1
    if kind=='previous':p['input_binding']['previous_executed_reference'][0]=1e-15
    if kind=='desired':p['input_binding']['desired_forecast_reference'][0]+=1e-15
    if kind=='native_action':p['private_native_verification']['original_action'][0]=1e-15
    if kind=='native_reference':p['private_native_verification']['reference'][0]+=1e-15
    if kind=='native_ranges':p['private_native_verification']['native_torque_ranges'][0][0]-=1e-15
    if kind=='multipliers':p['certificate']['normalized_inequality_multipliers']=[0.]*28
    if kind=='primary':p['private_native_verification']['primary_and_compensation'][0]+=.01
    if kind=='baseline_token':v[1]['baseline']['token']='old'
    if kind=='baseline_action':v[1]['baseline']['original_action'][0]=1e-15
    result=run(v)
    assert not result['checks']['N_current_candidate_numeric_native'] and not result['necessary_conditions_complete']
    assert result['reference'] is None


@pytest.mark.parametrize('joint',range(7))
@pytest.mark.parametrize('sign',[-1.,1.])
def test_each_original_native_torque_bound_is_rechecked(cfg,joint,sign):
    v=setup(cfg);v[2]['private_native_verification']['torque'][joint]=sign*1.1
    assert not run(v)['checks']['N_current_candidate_numeric_native']


@pytest.mark.parametrize('missing',['source','fixed','lease','receipt','candidate'])
def test_missing_independent_evidence_is_not_relabelled(cfg,missing):
    v=list(setup(cfg));b=v[0]
    if missing=='source':b.branch=replace(b.branch,source_record=None)
    if missing=='fixed':b.source_comparison['fixed_prerequisites_equal']=False
    if missing=='lease':b.branch=replace(b.branch,target_signature='other')
    if missing=='receipt':b.receipt=None
    if missing=='candidate':v[2]=None
    result=run(v);assert not result['necessary_conditions_complete'] and not result['experimental_admitted']
    assert b.branch is None or b.branch.target_signature!='other' or not result['checks']['L_original_exact_lease']


@pytest.mark.parametrize('change',['stale_token','action','pending_reference'])
def test_stale_current_preparation_raises_existing_failure_route(cfg,change):
    v=setup(cfg)
    if change=='stale_token':v[1]['binding']['token']='old'
    if change=='action':v[4][0]=.1
    if change=='pending_reference':v[0].pending['reference'][0]=1e-15
    with pytest.raises(ValueError):run(v)


@pytest.mark.parametrize('change',['time','count'])
def test_previous_receipt_must_match_current_execution_boundary(cfg,change):
    v=setup(cfg)
    if change=='time':v[0].pending['physical_time']+=.05
    else:v[0].pending['expected_execution_count']+=1
    assert not run(v)['checks']['N_current_candidate_numeric_native']


def test_inspection_does_not_commit_or_mutate_proposal_or_bridge(cfg):
    v=setup(cfg);before=v[0].snapshot();proposal=deepcopy(v[2]);reference=list(v[0].receipt['actual_executed_reference'])
    a=run(v);b=run(v)
    assert a==b and v[0].snapshot()==before and v[2]==proposal
    assert v[0].receipt['actual_executed_reference']==reference
