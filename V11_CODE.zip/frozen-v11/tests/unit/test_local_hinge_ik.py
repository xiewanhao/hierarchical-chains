import numpy as np
import mujoco
import pytest
from five_chains.envs.pose_ik import RobotPoseIK
from five_chains.geometry import pose
from five_chains.config import validate_config
from test_hinge_continuation import setup


def solver(cfg):
    m=mujoco.MjModel.from_xml_string('<mujoco><worldbody><body><inertial mass="1" pos="0 0 0" diaginertia="1 1 1"/><joint type="slide" axis="1 0 0" range="-1 1"/><site/></body></worldbody></mujoco>')
    return m,RobotPoseIK(m,0,np.array([0]),np.array([0]),np.zeros(1),cfg['control']['posture_ik'])


def test_local_ik_reaches_close_target_without_mutating_bounds_or_inputs(cfg):
    m,s=solver(cfg);q=m.qpos0.copy();lo=s.lower.copy();hi=s.upper.copy()
    r=s.solve(pose([.2,0,0]),q,max_joint_step_rad=.3)
    assert r.success and abs(r.joints[0])<=.3 and r.position_error_m<.004
    assert np.array_equal(q,m.qpos0) and np.array_equal(s.lower,lo) and np.array_equal(s.upper,hi)


def test_local_search_does_not_loosen_original_strict_ik_or_native_margin(cfg):
    m,s=solver(cfg);q=m.qpos0.copy();target=pose([.5,0,0])
    assert s.solve(target,q).success
    r=s.solve(target,q,max_joint_step_rad=.3)
    assert not r.success and abs(r.joints[0])<=.3 and r.position_error_m>.004
    q=np.array([.96]);r=s.solve(pose([1.1,0,0]),q,max_joint_step_rad=.3)
    assert not r.success and r.joints[0]<=s.upper[0]


@pytest.mark.parametrize('step',[0.,-1.,float('nan'),float('inf')])
def test_invalid_local_joint_bound_rejected(cfg,step):
    m,s=solver(cfg)
    with pytest.raises(ValueError):s.solve(pose([.2,0,0]),m.qpos0,max_joint_step_rad=step)


def test_forecast_local_box_used_only_when_explicitly_enabled(cfg,world,monkeypatch):
    a,w,target,calls=setup(cfg,world,monkeypatch,'clear');seen=[];raw=a.posture_solver.solve
    def solve(goal,q,**kw):seen.append(kw);return raw(goal,q)
    a.posture_solver.solve=solve
    r=a.hinge_contact_continuation(np.array([-1.,0.]),np.array([0.]),target,target,w,('microwave','handle',.005))
    assert r['admitted'] and all(not k for k in seen) and not r['local_joint_search']
    seen.clear();cfg['control']['posture_ik']['path_planning']['hinge_continuation']['local_joint_search']=True
    r=a.hinge_contact_continuation(np.array([-1.,0.]),np.array([0.]),target,target,w,('microwave','handle',.005))
    assert r['admitted'] and all(k=={'max_joint_step_rad':.3} for k in seen) and r['local_joint_search']


def test_local_search_does_not_disable_original_jump_or_collision_postcheck(cfg,world,monkeypatch):
    a,w,target,calls=setup(cfg,world,monkeypatch,'jump');raw=a.posture_solver.solve
    a.posture_solver.solve=lambda target,q,**kw:raw(target,q)
    cfg['control']['posture_ik']['path_planning']['hinge_continuation']['local_joint_search']=True
    r=a.hinge_contact_continuation(np.array([-1.,0.]),np.array([0.]),target,target,w,('microwave','handle',.005))
    assert not r['admitted'] and r['reason']=='branch_discontinuity'


def test_local_hinge_search_must_be_boolean(cfg):
    cfg['control']['posture_ik']['path_planning']['hinge_continuation']['local_joint_search']=1
    with pytest.raises(ValueError):validate_config(cfg)
