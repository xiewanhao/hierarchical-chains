from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.config import validate_config
from five_chains.envs.scene_path import JointPlan
from five_chains.envs.pose_ik import IKResult
from five_chains.geometry import pose
from test_attained_waypoint import adapter


@pytest.mark.parametrize('failed', [False, True])
def test_strict_grasp_uses_original_forty_frames_same_goal_and_propagates_failure(cfg, world, monkeypatch, failed):
    a, w = adapter(cfg, world)
    pc = cfg['control']['posture_ik']['path_planning']
    pc.update(enabled=True, strict_grasp_approach_tracking=True, grasp_approach_stall_refresh=True, goal_seeds=1)
    pc['measured_stall_refresh']['enabled'] = True
    cfg['control']['posture_ik']['orientation_projection'] = False
    a.posture_solver.solve = lambda target, seed, **kw: IKResult(True, (.5, 0.), 0., 0., 1)
    a.posture_solver.forward = lambda q, joints: a.motion_goal.copy()
    a.motion_scene.configure = lambda *args: None
    a.motion_scene.checks = 0
    a.motion_scene.explain = lambda q: {}
    a.env.objects = {}
    a.env.sim.model.joint_name2id = lambda n: 0
    plans = []

    def plan(start, goals, *args):
        plans.append((start.copy(), goals, args))
        return JointPlan(() if failed else (start.copy(), start + np.array([.03, 0.]), np.array([.5, 0.])),
                         1, 2, True, 'search_exhausted' if failed else 'sampled_clear')

    monkeypatch.setattr('five_chains.envs.scene_path.plan_joint_path', plan)
    goal = a.motion_goal.copy()
    for i in range(40):
        ww = replace(w, stamp=i+1, signals={**w.signals, 'arm_joint_state': {'velocities_rad_s': np.zeros(2)},
                     'native_motion_diagnostics': {'simulation_time_s': i*.05}})
        a.prepare_motion_path(goal, ww, a.motion_key, None, None, 'vegetable', grasp_approach_tracking=True)
        if i < 39:
            assert not plans and a.motion_index == 0
            # Duplicate observations cannot count as another physics frame.
            a.prepare_motion_path(goal, ww, a.motion_key, None, None, 'vegetable', grasp_approach_tracking=True)
            assert not plans
    assert len(plans) == 1 and np.array_equal(goal, a.motion_goal)
    assert np.array_equal(plans[0][0], w.signals['robot_kinematic_qpos'])
    assert a.motion_stall_feedback.attempts == 1
    ev = a.posture_diagnostic['stall_refresh_evidence']
    assert ev['scope'] == 'strict_grasp_approach' and ev['old_waypoint_pose_attained']
    assert ev['distinct_frames'] == 40 and pc['measured_stall_refresh']['max_replans'] == 2
    if failed:
        assert a.motion_failure == 'search_exhausted' and not a.motion_path
    else:
        assert not a.posture_diagnostic['attained_connection_checked']
        assert a.posture_diagnostic['joint_tracking_tolerance_rad'] == .1
        assert np.max(np.abs(a.controller.initial_joint)) <= .03 + 1e-12
        contract = N(contract_id='free', call=N(skill='carry_container_to_region'), phases=[N(target_field='pregrasp_pose')])
        phase = N(phase_index=0, phase_name='approach')
        assert not a.hinge_approach_branch_ready(contract, phase, w.signals['robot_kinematic_qpos'])


@pytest.mark.parametrize('gate', ['flag_off', 'strict_off', 'request_off', 'no_contact', 'held',
                                'moving', 'unattained', 'reference_unsettled', 'out_of_bounds'])
def test_grasp_refresh_retains_scope_and_original_numeric_guards(cfg, world, gate):
    a, w = adapter(cfg, world)
    pc = cfg['control']['posture_ik']['path_planning']
    pc.update(enabled=True, strict_grasp_approach_tracking=True, grasp_approach_stall_refresh=True)
    pc['measured_stall_refresh']['enabled'] = True
    if gate == 'flag_off': pc['grasp_approach_stall_refresh'] = False
    if gate == 'strict_off': pc['strict_grasp_approach_tracking'] = False
    if gate == 'held': w = replace(w, signals={**w.signals, 'grasp_transforms': {'vegetable': np.eye(4)}})
    if gate == 'unattained': w = replace(w, eef_pose_world=pose([.013, 0., 0.]))
    if gate == 'out_of_bounds': w = replace(w, signals={**w.signals, 'robot_kinematic_qpos': np.array([-1.00001, 0.])})
    for i in range(45):
        if gate == 'reference_unsettled': a.controller.initial_joint = np.array([-.04, 0.])
        ww = replace(w, stamp=i+1, signals={**w.signals,
                     'arm_joint_state': {'velocities_rad_s': np.array([.00101 if gate == 'moving' else 0., 0.])},
                     'native_motion_diagnostics': {'simulation_time_s': i*.05}})
        a.prepare_motion_path(a.motion_goal, ww, a.motion_key, None, None,
                              None if gate == 'no_contact' else 'vegetable',
                              grasp_approach_tracking=gate != 'request_off')
    assert a.motion_stall_feedback.attempts == 0
    assert not a.posture_diagnostic.get('measured_stall_refresh', False)


def test_grasp_refresh_defaults_off_and_rejects_nonboolean(cfg):
    assert cfg['control']['posture_ik']['path_planning']['grasp_approach_stall_refresh'] is False
    cfg['control']['posture_ik']['path_planning']['grasp_approach_stall_refresh'] = 1
    with pytest.raises(ValueError, match='grasp approach stall refresh'):
        validate_config(cfg)
