import numpy as np
import pytest
from five_chains.envs.scene_path import plan_joint_path
from five_chains.config import validate_config


def config():
    return dict(seed=56,validation_step_rad=.025,extension_rad=.2,iterations=1800,
                restarts=3,optimize_restarts=True,goal_bias=.2,connect_steps=80,
                shortcut_attempts=50,waypoint_step_rad=.04)


def test_existing_restart_candidates_select_lowest_dense_path_cost_without_inflating_budgets():
    start=np.array([-.8,0.]);goal=np.array([.8,0.]);saved=start.copy();cfg=config()
    valid=lambda q:not(abs(q[0])<=.2 and abs(q[1])<=.25)
    plan=plan_joint_path(start,(goal,),-np.ones(2),np.ones(2),valid,cfg)
    assert plan.path and len(plan.candidate_waypoints)==cfg['restarts']
    assert len(plan.path)==min(plan.candidate_waypoints)
    assert plan.candidate_waypoints[plan.selected_candidate]==len(plan.path)
    assert plan.iterations<=cfg['iterations']
    assert plan.shortcut_attempts<=cfg['shortcut_attempts']
    assert np.array_equal(start,saved) and np.array_equal(plan.path[-1],goal)
    for a,b in zip(plan.path,plan.path[1:]):
        assert np.max(np.abs(b-a))<=cfg['waypoint_step_rad']+1e-10
        assert all(valid(a+(b-a)*s) for s in np.linspace(0.,1.,20))
    repeat=plan_joint_path(start,(goal,),-np.ones(2),np.ones(2),valid,cfg)
    assert plan.candidate_waypoints==repeat.candidate_waypoints and plan.iterations==repeat.iterations
    assert len(plan.path)==len(repeat.path) and all(np.array_equal(a,b) for a,b in zip(plan.path,repeat.path))


def test_default_disabled_path_and_rng_sequence_are_preserved():
    cfg=config();cfg.pop('optimize_restarts');start=np.array([-.8,0.]);goal=np.array([.8,0.])
    valid=lambda q:not(abs(q[0])<=.2 and abs(q[1])<=.25)
    old=plan_joint_path(start,(goal,),-np.ones(2),np.ones(2),valid,cfg)
    explicit=plan_joint_path(start,(goal,),-np.ones(2),np.ones(2),valid,{**cfg,'optimize_restarts':False})
    assert old.iterations==explicit.iterations and len(old.path)==len(explicit.path)
    assert all(np.array_equal(a,b) for a,b in zip(old.path,explicit.path))
    assert len(explicit.candidate_waypoints)==1 and explicit.selected_candidate==0


def test_clear_direct_path_keeps_immediate_handoff_without_extra_search():
    cfg=config();plan=plan_joint_path(np.zeros(2),(np.ones(2)*.5,),-np.ones(2),np.ones(2),lambda q:True,cfg)
    assert plan.path and plan.iterations==0 and len(plan.candidate_waypoints)==1
    assert plan.shortcut_attempts==0


def test_all_failed_restarts_still_share_original_per_goal_iteration_limit():
    cfg={**config(),'iterations':13};start=np.array([-.8,0.]);goals=(np.array([.8,0.]),np.array([.9,.1]))
    plan=plan_joint_path(start,goals,-np.ones(2),np.ones(2),lambda q:abs(q[0])>.7,cfg)
    assert not plan.path and plan.status=='search_exhausted'
    assert plan.iterations==13*len(goals) and not plan.candidate_waypoints and plan.shortcut_attempts==0


def test_later_failed_restart_cannot_discard_an_earlier_certified_path(monkeypatch):
    cfg={**config(),'seed':10,'iterations':3,'extension_rad':2.}
    class Rng:
        def __init__(self,seed):self.seed=seed
        def random(self):return 1.
        def uniform(self,*args):return np.array([-.3,.6]) if self.seed==10 else np.zeros(2)
        def choice(self,*args,**kwargs):return np.array([0,1])
    monkeypatch.setattr(np.random,'default_rng',lambda seed:Rng(seed))
    valid=lambda q:not(abs(q[0])<=.2 and abs(q[1])<=.25)
    plan=plan_joint_path(np.array([-.8,0.]),(np.array([.8,0.]),),-np.ones(2),np.ones(2),valid,cfg)
    assert plan.path and len(plan.candidate_waypoints)==1 and plan.iterations==3
    assert all(valid(q) for q in plan.path)


def test_restart_optimization_setting_is_explicit_boolean(cfg):
    cfg['control']['posture_ik']['path_planning']['optimize_restarts']='yes'
    with pytest.raises(ValueError,match='restart optimization'):validate_config(cfg)
