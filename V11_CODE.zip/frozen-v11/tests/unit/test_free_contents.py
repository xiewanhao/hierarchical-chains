from dataclasses import replace
from copy import deepcopy
import numpy as np
import pytest
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose
from five_chains.skills.recipes import RecipeRegistry, GeometricGraspProvider
from five_chains.skills.live_grasps import free_content_attitudes
from five_chains.types import ReadoutError


def content_world(world):
    cavity=replace(world.entities['microwave_interior'],pose_world=pose([.9,.5,1.45]),extent=np.array([.25,.22,.20]))
    bowl=replace(world.entities['bowl'],pose_world=cavity.pose_world@pose([.04,.01,0.]))
    return replace(world,entities={**world.entities,'bowl':bowl,'microwave_interior':cavity},
        signals={**world.signals,'grasp_modes':{'bowl':'rim'},'object_top_offsets':{'bowl':[0.,0.,.05]},
          'cavity_entities':['microwave_interior'],'grasp_transforms':{'vegetable':pose([0,0,.02])}})


def test_free_content_options_keep_center_and_are_access_frame_covariant():
    goal=pose([.2,.3,1.5],Rotation.from_euler('xyz',[.2,-.3,.4]).as_matrix())
    access=pose([.5,.6,1.4],Rotation.from_euler('z',.7).as_matrix())
    transform=pose([1.,2.,.1],Rotation.from_euler('z',-.4).as_matrix())
    a=free_content_attitudes(goal,access);b=free_content_attitudes(transform@goal,transform@access)
    assert np.array_equal(a[0],goal) and len(a)==5
    for first,second in zip(a,b):
        assert np.array_equal(first[:3,3],goal[:3,3])
        assert np.isclose(np.linalg.det(first[:3,:3]),1.)
        assert np.allclose(transform@first,second)


@pytest.mark.parametrize('blocked',['unheld','upright','tilt','outside_cavity','nonrim','disabled',None])
def test_only_unconstrained_held_contents_use_orientation_search(C,call,world,blocked):
    cfg=deepcopy(C.c6.recipes.config);cfg['grasp']['free_content_attitude_search']=blocked!='disabled'
    seen=[]
    class Provider(GeometricGraspProvider):
        def free_content_pose(self,entity,world,goal,access):
            seen.append(goal.copy());return free_content_attitudes(goal,world.entities[access].pose_world)[1]
    recipes=RecipeRegistry(Provider(cfg),cfg);w=content_world(world)
    c=C.c12.expand(call);c=replace(c,followup={**c.followup,'access_frame':'microwave_interior'})
    if blocked=='unheld':w=replace(w,signals={**w.signals,'grasp_transforms':{}})
    if blocked=='upright':w=replace(w,signals={**w.signals,'upright_entities':['vegetable']})
    if blocked=='outside_cavity':w=replace(w,signals={**w.signals,'cavity_entities':[]})
    if blocked=='nonrim':w=replace(w,signals={**w.signals,'grasp_modes':{}})
    if blocked=='tilt':c=replace(c,fields={**c.fields,'tilt_limit':c.fields['speed_limit']})
    nominal_cfg=deepcopy(cfg);nominal_cfg['grasp']['free_content_attitude_search']=False
    nominal=RecipeRegistry(GeometricGraspProvider(nominal_cfg),nominal_cfg).prepare(c.fields['place_pose'],c,w)
    result=recipes.prepare(c.fields['place_pose'],c,w)
    assert np.allclose(result[:3,3],nominal[:3,3])
    if blocked is None:
        assert len(seen)==1 and not np.allclose(result[:3,:3],nominal[:3,:3])
    else:assert not seen and np.array_equal(result,nominal)


def test_free_contents_rejects_callback_that_changes_release_point(C,call,world):
    cfg=deepcopy(C.c6.recipes.config);cfg['grasp']['free_content_attitude_search']=True
    class BadProvider(GeometricGraspProvider):
        def free_content_pose(self,entity,world,goal,access):
            result=goal.copy();result[2,3]-=.01;return result
    recipes=RecipeRegistry(BadProvider(cfg),cfg);w=content_world(world)
    c=C.c12.expand(call);c=replace(c,followup={**c.followup,'access_frame':'microwave_interior'})
    with pytest.raises(ReadoutError,match='center/height'):recipes.prepare(c.fields['place_pose'],c,w)
