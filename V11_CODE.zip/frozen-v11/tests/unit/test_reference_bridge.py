# -*- coding: utf-8 -*-
from dataclasses import replace
from types import SimpleNamespace as N
from copy import deepcopy
import numpy as np
import pytest
from five_chains.envs.reference_bridge import Scope, Branch, ReferenceBridge, choose_branch
from five_chains.components.c10_executor import Executor
from five_chains.envs.robocasa_adapter import RoboCasaAdapter


def scope(phase='approach',tick=10):
    return Scope('call',phase,tick,'target','scene',False)


def branch(s=None,query=0,value=1.):
    return Branch.captured(s or scope(),query,[
        {'angle_rad':-1.,'joints_rad':[0.]*7},
        {'angle_rad':-1.,'joints_rad':[value]*7},
        {'angle_rad':0.,'joints_rad':[2.]*7}],np.zeros(7))


def test_last_enter_contact_sample_and_signed_angle_interpolation():
    b=branch();np.testing.assert_array_equal(b.reference(scope('close',11),-1.),np.ones(7))
    np.testing.assert_array_equal(b.reference(scope('close',11),-.5),np.full(7,1.5))
    assert b.reference(scope('close',11),-.5) is not b.reference(scope('close',11),-.5)


@pytest.mark.parametrize('change',[dict(call='other'),dict(phase='release'),dict(tick=9),
    dict(target_signature='new'),dict(scene_signature='new'),dict(overridden=True)])
def test_forecast_rejects_changed_scope_or_future_input(change):
    assert branch().reference(replace(scope('close',11),**change),-.5) is None


@pytest.mark.parametrize('angle',[-1.01,.001,float('nan')])
def test_forecast_never_extrapolates(angle):
    assert branch().reference(scope('close',11),angle) is None


def test_selected_path_uses_endpoint_not_restart_candidate_index():
    b0=branch();b1=replace(branch(query=5),approach_endpoint=tuple([.5]*7))
    assert choose_branch([np.zeros(7),np.full(7,.5)],[b0,b1]) is b1
    assert choose_branch([], [b0]) is None
    assert choose_branch([np.full(7,.6)],[b0,b1]) is None


def test_ambiguous_different_forecasts_are_rejected_without_search():
    assert choose_branch([np.zeros(7)],[branch(value=1.),branch(value=1.1)]) is None


def test_only_roundoff_endpoint_matching_is_permitted():
    b=branch();assert choose_branch([np.full(7,1e-15)],[b]) is b
    assert choose_branch([np.full(7,1e-10)],[b]) is None


def test_proposals_and_new_solve_cannot_commit_execution_history():
    b=ReferenceBridge();b.begin(scope('close'));b.prepare([0.],np.zeros(7),1.,0)
    assert b.receipt is None
    b.begin(scope('close',11));assert b.pending is None and b.receipt is None


def test_first_close_freeze_requires_execution_before_previous_close_is_available():
    b=ReferenceBridge();b.begin(scope());b.branch=branch()
    b.prepare([0.],np.zeros(7),1.,0);b.before_execute([0.],np.zeros(7),1.,0);b.after_execute(np.zeros(7),1.05,1)
    b.begin(scope('close',11));assert b.receipt is None
    assert not b.proposal_readiness(-.5)['previous_executed_close_reference_available']
    b.prepare([1.],np.ones(7),1.05,1);b.before_execute([1.],np.ones(7),1.05,1)
    b.after_execute(np.ones(7),1.1,2);b.begin(scope('close',12))
    ready=b.proposal_readiness(-.5)
    assert ready['forecast_lease_valid'] and ready['previous_executed_close_reference_available']
    assert not ready['admitted'] and ready['reference'] is None


@pytest.mark.parametrize('kind',['action','reference','time','counter'])
def test_stale_binding_rejected_before_step(kind):
    b=ReferenceBridge();b.begin(scope('close'));b.prepare([0.],np.zeros(7),1.,0)
    args=[np.array([0.]),np.zeros(7),1.,0]
    args[{'action':0,'reference':1,'time':2,'counter':3}[kind]] = {
        'action':np.array([1.]),'reference':np.ones(7),'time':1.1,'counter':1}[kind]
    with pytest.raises(ValueError):b.before_execute(*args)
    assert b.pending is None and b.receipt is None


def test_exception_invalidates_forecast_and_receipts():
    b=ReferenceBridge();b.begin(scope());b.branch=branch();b.prepare([0.],np.zeros(7),1.,0)
    b.abort();assert b.branch is None and b.receipt is None and b.pending is None


def test_post_step_reference_mismatch_is_never_committed():
    b=ReferenceBridge();b.begin(scope('close'));b.prepare([0.],np.zeros(7),1.,0)
    with pytest.raises(ValueError):b.after_execute(np.ones(7),1.05,1)
    assert b.receipt is None


def test_audit_snapshot_is_detached_from_ledger_and_branch():
    b=ReferenceBridge();b.begin(scope('close'));b.branch=branch()
    b.prepare([0.],np.zeros(7),1.,0);b.before_execute([0.],np.zeros(7),1.,0);b.after_execute(np.zeros(7),1.05,1)
    saved=b.snapshot();saved['receipt']['actual_executed_reference'][0]=9.
    saved['branch']['joints'][0][0]=9.
    assert b.receipt['actual_executed_reference'][0]==0. and b.branch.joints[0][0]==1.


def test_actual_executor_commits_after_step_and_before_observation(cfg):
    cfg=deepcopy(cfg);cfg['control']['close_reference_bridge_capture']=True
    bridge=ReferenceBridge();bridge.begin(scope('close'));bridge.prepare([0.],np.zeros(7),1.,0)
    clock=N(time=1.);events=[]
    class Adapter:
        def reference_bridge_before_execute(self,action,count):
            events.append('before');bridge.before_execute(action,np.zeros(7),clock.time,count)
        def reference_bridge_after_execute(self,count):
            events.append('after');bridge.after_execute(np.zeros(7),clock.time,count)
        def reference_bridge_abort(self):bridge.abort()
        def observe(self,obs):events.append('observe');assert bridge.receipt is not None;return {}
        def success(self):return False
    class Env:
        def step(self,action):events.append('step');clock.time+=.05;return {},0.,False,{}
    executor=Executor(Adapter(),cfg);executor.execute(Env(),np.array([0.]))
    assert events==['before','step','after','observe'] and executor.executions==1


def test_actual_executor_step_exception_has_no_commit(cfg):
    cfg=deepcopy(cfg);cfg['control']['close_reference_bridge_capture']=True
    events=[]
    class Adapter:
        def reference_bridge_before_execute(self,*args):events.append('before')
        def reference_bridge_after_execute(self,*args):events.append('after')
        def reference_bridge_abort(self):events.append('abort')
    class Env:
        def step(self,action):raise RuntimeError('synthetic failure')
    executor=Executor(Adapter(),cfg)
    with pytest.raises(RuntimeError):executor.execute(Env(),np.zeros(1))
    assert executor.executions==0 and events==['before','abort']


def test_adapter_scene_excludes_only_arm_and_door_not_base_or_fingers():
    model=N(jnt_qposadr=np.arange(10));controller=N(initial_joint=np.zeros(7))
    a=object.__new__(RoboCasaAdapter);a.controller=controller;a.posture_solver=N(qpos=np.arange(7))
    a.env=N(microwave=N(door_joint_names=['door']),sim=N(model=N(_model=model,joint_name2id=lambda n:7)))
    contract=N(call=N(skill='close_hinged_door',bindings={'appliance':'microwave'}),contract_id='call')
    param=N(kind=N(value='pose'),frame_entity='world',value=np.eye(4));packet=N(params={'closed_handle_pose':param})
    p7=N(phase_name='approach');world=N(stamp=10,signals={'robot_kinematic_qpos':np.zeros(10)})
    a.reference_bridge_begin(packet,contract,p7,world,None);original=a.reference_bridge.scope.scene_signature
    world.signals['robot_kinematic_qpos'][:8]=1.;world.stamp=11
    a.reference_bridge_begin(packet,contract,p7,world,None);assert a.reference_bridge.scope.scene_signature==original
    world.signals['robot_kinematic_qpos'][8]=1e-15;world.stamp=12
    a.reference_bridge_begin(packet,contract,p7,world,None);assert a.reference_bridge.scope.scene_signature!=original


def test_original_forecast_computation_capture_adds_no_queries_or_decisions(cfg,monkeypatch):
    # Synthetic backend, actual adapter method. No native environment/IK call.
    import five_chains.envs.scene_path as paths
    class Scene:
        def __init__(self,*args):pass
        def configure(self,*args):pass
        def valid(self,q):return True
    monkeypatch.setattr(paths,'StaticScene',Scene)
    outputs=[]
    for capture in [False,True]:
        a=object.__new__(RoboCasaAdapter);a.config=deepcopy(cfg)
        a.config['control']['close_reference_bridge_capture']=capture
        calls=[]
        class Solver:
            qpos=np.arange(7);site=0
            def solve(self,target,q,**kwargs):
                calls.append(target.copy());self.target=target.copy()
                return N(success=True,joints=np.full(7,len(calls)*.001))
            def forward(self,q,joints):return self.target.copy()
        a.posture_solver=Solver()
        a.env=N(microwave=N(door_joint_names=['door'],handle_name='handle_main'),
                sim=N(model=N(_model=N(jnt_qposadr=np.arange(8)),joint_name2id=lambda n:7)))
        nominal=np.eye(4);nominal[0,3]=.1
        world=N(signals={'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[0.,0.,0.]}},
                entities={'handle':N(pose_world=nominal)})
        result=a.hinge_contact_continuation(np.zeros(8),np.zeros(7),nominal,np.eye(4),world,('microwave','handle',.005))
        outputs.append((result,calls))
    off,on=outputs
    assert len(off[1])==len(on[1]) and off[0]['admitted'] and on[0]['admitted']
    for left,right in zip(off[1],on[1]):np.testing.assert_array_equal(left,right)
    captured=on[0].pop('captured_knots');assert len(captured)==on[0]['samples']
    assert on[0].pop('source_capture_status')=='not_in_runtime_scope'
    assert off[0]==on[0]
