from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.config import validate_config


@pytest.mark.parametrize('clear,position,held,expected',[(True,0.,False,True),(False,0.,False,False),(True,1.00001,False,False),(True,0.,True,False)])
def test_egress_entry_requires_original_full_scene_and_native_bounds(cfg,world,monkeypatch,clear,position,held,expected):
    from five_chains.envs import scene_path
    calls=[]
    class Scene:
        def __init__(self,*args):pass
        def configure(self,q,objects,joints,contact,relation,tilt,epsilon):
            assert objects=={} and joints=={} and contact is None
            assert relation is None and tilt is None
            assert epsilon==cfg['control']['posture_ik']['path_planning']['penetration_epsilon_m']
            calls.append(q.copy())
        def valid(self,q):return clear
    monkeypatch.setattr(scene_path,'StaticScene',Scene)
    a=object.__new__(RoboCasaAdapter);a.config=cfg
    a.posture_solver=N(qpos=np.array([0]),joints=np.array([0]),site=0)
    a.env=N(sim=N(model=N(_model=N(jnt_range=np.array([[-1.,1.]])))))
    w=replace(world,signals={'robot_kinematic_qpos':np.array([position]),'grasp_transforms':{'held':np.eye(4)} if held else {}})
    assert a.contact_egress_start_clear(w)==expected
    assert bool(calls)==(not held and abs(position)<=1.)


@pytest.mark.parametrize('nearby',[False,True])
@pytest.mark.parametrize('enabled,clear,phase,planned',[(True,True,'release_contact',True),(True,False,'release_contact',False),(False,True,'release_contact',False),(True,True,'close',False),(True,True,'settle_door',False)])
def test_only_clear_door_egress_routes_original_goal_through_existing_planner(C,world,monkeypatch,enabled,clear,phase,planned,nearby):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    w=replace(world,signals={**world.signals,'surface_normals':{'handle':np.array([-1.,0.,0.])},
        'microwave_hinge':{'angle':-1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    c,p6,p7,proposal=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),w,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name==phase),phase_name=phase)
    planning=C.c10.config['control']['posture_ik']['path_planning'];planning['enabled']=True;planning['contact_egress_planning'].update(enabled=enabled,measured_stall_refresh=True,prefer_nearby_orientation=nearby)
    C.c10.config['base']['assist_during_door']=False
    seen=[];frozen=[]
    monkeypatch.setattr(C.c10.adapter,'contact_egress_start_clear',lambda world:clear,raising=False)
    monkeypatch.setattr(C.c10.adapter,'prepare_motion_path',lambda target,*args,**kwargs:seen.append((target.copy(),args,kwargs)) or target,raising=False)
    monkeypatch.setattr(C.c10.adapter,'prepare_contact_posture',lambda *args:frozen.append(args),raising=False)
    C.c10.solve(packet,c,p7,w,None)
    assert bool(seen)==planned and bool(frozen)!=planned
    if planned:
        assert np.array_equal(seen[0][0],packet.params['release_pose'].value)
        assert seen[0][1][4] is None and 'hinge_contact' not in seen[0][2]
        assert seen[0][2]['contact_egress_refresh'] is True
        assert seen[0][1][-1] is nearby


def test_invalid_contact_egress_setting_rejected(cfg):
    cfg['control']['posture_ik']['path_planning']['contact_egress_planning']['enabled']='yes'
    with pytest.raises(ValueError,match='contact egress'):validate_config(cfg)


def test_egress_refresh_defaults_disabled_and_invalid_values_rejected(cfg):
    assert not cfg['control']['posture_ik']['path_planning']['contact_egress_planning']['measured_stall_refresh']
    cfg['control']['posture_ik']['path_planning']['contact_egress_planning']['measured_stall_refresh']='yes'
    with pytest.raises(ValueError,match='contact egress stall'):validate_config(cfg)


def test_egress_nearby_orientation_defaults_false_and_requires_bool(cfg):
    pc=cfg['control']['posture_ik']['path_planning']['contact_egress_planning']
    assert pc['prefer_nearby_orientation'] is False
    pc['prefer_nearby_orientation']=1
    with pytest.raises(ValueError,match='egress orientation'):validate_config(cfg)
