from dataclasses import replace
from types import SimpleNamespace as N
import numpy as np
import pytest
from five_chains.envs.scene_path import MeasuredStallFeedback, JointPlan
from five_chains.envs.pose_ik import IKResult
from five_chains.config import validate_config
from test_attained_waypoint import adapter


def policy(cfg, frames=4):
    p=cfg['control']['posture_ik']['path_planning']['measured_stall_refresh']
    p.update(enabled=True,distinct_frames=frames)
    return p


def sample(f,p,t,**kwargs):
    args=dict(key=('door',2),token=(10,6),time_s=t,current=np.array([.14,0.]),velocity=np.zeros(2),
        lower=-np.ones(2),upper=np.ones(2),joint_error=.14,joint_tolerance=.1,
        pose_attained=True,reference_settled=True,policy=p)
    args.update(kwargs)
    return f.observe(**args)


def test_only_distinct_physical_frames_count_and_attempts_are_bounded(cfg):
    f=MeasuredStallFeedback();p=policy(cfg)
    assert not sample(f,p,0.)
    for _ in range(100):assert not sample(f,p,0.)
    assert f.frames==1
    assert [sample(f,p,i*.05) for i in range(1,4)]==[False,False,True]
    assert f.attempts==1
    assert [sample(f,p,i*.05) for i in range(4,8)]==[False,False,False,True]
    assert f.attempts==2
    assert not any(sample(f,p,i*.05) for i in range(8,40))
    f.begin(('different_phase',3));f.begin(('door',2))
    assert f.attempts==2


@pytest.mark.parametrize('override',[
    {'velocity':np.array([.01,0.])},{'velocity':np.array([float('nan'),0.])},
    {'velocity':np.array([])},{'current':np.array([1.00001,0.])},
    {'current':np.array([float('inf'),0.])},{'joint_error':float('nan')},
    {'pose_attained':False},{'reference_settled':False},{'joint_error':.0999},
    {'time_s':float('nan')},
])
def test_missing_invalid_moving_out_of_range_or_unattained_never_triggers(cfg,override):
    f=MeasuredStallFeedback();p=policy(cfg)
    for i in range(8):
        args={**override};t=args.pop('time_s',i*.05)
        assert not sample(f,p,t,**args)
    assert f.attempts==0


def test_progress_waypoint_and_frame_gap_reset_window(cfg):
    f=MeasuredStallFeedback();p=policy(cfg)
    assert not sample(f,p,0.)
    assert not sample(f,p,.05)
    assert not sample(f,p,.10,joint_error=.137)  # >2mrad progress
    assert f.frames==1
    assert not sample(f,p,.15,token=(10,7));assert f.frames==1
    assert not sample(f,p,.4,token=(10,7));assert f.frames==1
    assert not sample(f,p,.45,token=(10,7),current=np.array([.143,0.]));assert f.frames==1
    assert not sample(f,p,.1,token=(10,7));assert f.frames==1  # rewind resets


def test_default_disabled_and_reentry_budget_survives_path_changes(cfg):
    f=MeasuredStallFeedback();p=cfg['control']['posture_ik']['path_planning']['measured_stall_refresh']
    assert not p['enabled']
    assert not any(sample(f,p,i*.05) for i in range(100))
    p=policy(cfg);assert sum(sample(f,p,i*.05) for i in range(100,104))==1
    assert not sample(f,p,5.2,token=(20,1));assert f.attempts==1
    f.begin(('door',3));assert f.attempts==0
    f.begin(('door',2));assert f.attempts==1


@pytest.mark.parametrize('field,value',[('distinct_frames',1),('max_replans',3),('max_velocity_rad_s',float('nan')),('enabled',1)])
def test_config_rejects_unbounded_or_invalid_policy(cfg,field,value):
    cfg['control']['posture_ik']['path_planning']['measured_stall_refresh'][field]=value
    with pytest.raises(ValueError):validate_config(cfg)


@pytest.mark.parametrize('failed',[False,True])
def test_real_backend_route_preserves_target_gate_strict_tracking_and_failure(cfg,world,monkeypatch,failed):
    a,w=adapter(cfg,world);p=policy(cfg,2)
    planner=cfg['control']['posture_ik']['path_planning']
    planner['hinge_continuation'].update(enabled=True,track_admitted_branch=True)
    planner['goal_seeds']=1;cfg['control']['posture_ik']['orientation_projection']=False
    a.controller.initial_joint=a.motion_path[0].copy()
    a.posture_solver.solve=lambda target,seed,**kw:IKResult(True,(.5,0.),0.,0.,1)
    a.posture_solver.forward=lambda q,joints:a.motion_goal.copy()
    a.motion_scene.configure=lambda *args:None
    a.motion_scene.checks=0;a.motion_scene.explain=lambda q:{}
    a.env.objects={};a.env.sim.model.joint_name2id=lambda n:0
    gates=[];a.hinge_contact_continuation=lambda *args:gates.append(args) or {'admitted':True}
    plans=[]
    def plan(start,goals,*args):
        plans.append((start.copy(),goals,args))
        return JointPlan(() if failed else (start.copy(),start+np.array([.03,0.]),np.array([.5,0.])),1,2,True,
            'search_exhausted' if failed else 'sampled_clear')
    monkeypatch.setattr('five_chains.envs.scene_path.plan_joint_path',plan)
    saved=a.motion_goal.copy();key=a.motion_key
    for i in range(2):
        ww=replace(w,stamp=i+1,signals={**w.signals,'arm_joint_state':{'velocities_rad_s':np.zeros(2)},
            'native_motion_diagnostics':{'simulation_time_s':i*.05}})
        a.prepare_motion_path(saved,ww,key,None,None,None,hinge_contact=('microwave','handle',.005))
        if i==0:assert a.motion_index==0 and not plans  # no relaxed handoff
    assert len(plans)==1 and len(gates)==1
    assert np.array_equal(saved,a.motion_goal) and np.array_equal(plans[0][0],w.signals['robot_kinematic_qpos'])
    assert a.motion_stall_feedback.attempts==1 and a.posture_diagnostic['measured_stall_refresh']
    if failed:assert a.motion_failure=='search_exhausted' and not a.motion_path
    else:
        assert a.motion_failure is None and a.posture_diagnostic['joint_tracking_tolerance_rad']==.1
        assert not a.posture_diagnostic['attained_connection_checked']
        assert np.max(np.abs(a.controller.initial_joint))<=.03+1e-12


def test_only_explicit_free_egress_observation_may_refresh_unattained_pose(cfg):
    f=MeasuredStallFeedback();p=policy(cfg)
    for i in range(8):assert not sample(f,p,i*.05,pose_attained=False)
    assert f.attempts==0
    assert [sample(f,p,i*.05,pose_attained=False,require_pose_attained=False) for i in range(8,12)]==[False,False,False,True]
    assert f.attempts==1


@pytest.mark.parametrize('admission,requested,enabled,failed',[(True,True,True,False),(True,True,True,True),(False,True,True,False),(True,False,True,False),(True,True,False,False)])
def test_egress_refresh_rechecks_admission_and_preserves_original_unattained_thresholds(cfg,world,monkeypatch,admission,requested,enabled,failed):
    from five_chains.geometry import pose
    a,w=adapter(cfg,world);policy(cfg,2)
    planner=cfg['control']['posture_ik']['path_planning']
    planner['contact_egress_planning'].update(enabled=True,measured_stall_refresh=enabled)
    a.contact_egress_start_clear=lambda w:admission
    w=replace(w,eef_pose_world=pose([.0134,0.,0.]))
    planner['goal_seeds']=1;cfg['control']['posture_ik']['orientation_projection']=False
    a.controller.initial_joint=a.motion_path[0].copy()
    a.posture_solver.solve=lambda target,seed,**kw:IKResult(True,(.5,0.),0.,0.,1)
    a.posture_solver.forward=lambda q,joints:a.motion_goal.copy()
    a.motion_scene.configure=lambda *args:None
    a.motion_scene.checks=0;a.motion_scene.explain=lambda q:{}
    a.env.objects={};a.env.sim.model.joint_name2id=lambda n:0
    plans=[]
    def plan(start,goals,*args):
        plans.append((start.copy(),goals,args))
        return JointPlan(() if failed else (start.copy(),start+np.array([.03,0.]),np.array([.5,0.])),1,2,True,'search_exhausted' if failed else 'sampled_clear')
    monkeypatch.setattr('five_chains.envs.scene_path.plan_joint_path',plan)
    saved=a.motion_goal.copy();key=a.motion_key
    for i in range(2):
        ww=replace(w,stamp=i+1,signals={**w.signals,'arm_joint_state':{'velocities_rad_s':np.zeros(2)},'native_motion_diagnostics':{'simulation_time_s':i*.05}})
        a.prepare_motion_path(saved,ww,key,None,None,None,contact_egress_refresh=requested)
        if i==0:assert a.motion_index==0
    expected=admission and requested and enabled
    assert len(plans)==int(expected)
    assert np.array_equal(saved,a.motion_goal)
    assert cfg['control']['reached_m']==.012 and planner['joint_reached_rad']==.1
    if expected:
        ev=a.posture_diagnostic['stall_refresh_evidence']
        assert ev['scope']=='full_scene_contact_egress' and not ev['old_waypoint_pose_attained']
        assert a.motion_stall_feedback.attempts==1
        assert np.array_equal(plans[0][0],w.signals['robot_kinematic_qpos'])
        if failed:assert a.motion_failure=='search_exhausted'
        else:assert np.max(np.abs(a.controller.initial_joint))<=.03+1e-12
    else:assert a.motion_stall_feedback.attempts==0 and a.motion_index==0
