from types import SimpleNamespace as N
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.geometry import pose


def setup():
    adapter=object.__new__(RoboCasaAdapter)
    adapter.config={'grasp':{'cavity_exit_clearance_m':.04}}
    entities={'bowl':{'pose_world':pose([0.,0.,.1]),'extent':np.array([.08,.08,.04])},
              'cavity':{'pose_world':np.eye(4),'extent':np.array([.3,.3,.3])}}
    return adapter,entities


def test_distance_above_bowl_does_not_complete_retreat_inside_cavity():
    a,e=setup();eef=pose([0.,0.,.27])
    assert np.linalg.norm(eef[:3,3]-e['bowl']['pose_world'][:3,3])>.12
    assert not a.receptacle_egress_clear('bowl',e,('cavity',),eef,False)
    assert not a.receptacle_egress_clear('bowl',e,('cavity',),eef,True)


def test_actual_original_retreat_reach_and_cavity_clearance_both_required():
    a,e=setup()
    assert not a.receptacle_egress_clear('bowl',e,('cavity',),pose([0.,-.32,.27]),True)
    assert not a.receptacle_egress_clear('bowl',e,('cavity',),pose([0.,-.4,.27]),False)
    assert a.receptacle_egress_clear('bowl',e,('cavity',),pose([0.,-.4,.27]),True)


def test_moved_out_receiving_object_does_not_keep_stale_cavity_gate():
    a,e=setup();e['bowl']['pose_world']=pose([.7,0.,.1])
    assert a.receptacle_egress_clear('bowl',e,('cavity',),pose([.7,0.,.27]),False)
    assert a.receptacle_egress_clear('bowl',e,(),pose([.7,0.,.27]),False)


def test_cavity_egress_uses_observed_rotated_frame_not_world_axis():
    a,e=setup();transform=pose([1.,2.,.3],Rotation.from_euler('z',.8).as_matrix())
    e={n:{**v,'pose_world':transform@v['pose_world']} for n,v in e.items()}
    assert a.receptacle_egress_clear('bowl',e,('cavity',),transform@pose([0.,-.4,.27]),True)
    assert not a.receptacle_egress_clear('bowl',e,('cavity',),transform@pose([0.,.4,.27]),True)


def test_nested_cavity_uses_smallest_observed_enclosure():
    a,e=setup();e['outer']={'pose_world':np.eye(4),'extent':np.array([1.,1.,1.])}
    assert a.receptacle_egress_clear('bowl',e,('outer','cavity'),pose([0.,-.4,.27]),True)
