from dataclasses import replace
from types import SimpleNamespace
import numpy as np
from five_chains.geometry import pose
from five_chains.skills.live_grasps import gravity_support_cost, CurrentAssetGrasps


def contacts():
    return [dict(side=0,point=[-.03,0,0],frame=np.eye(3),sign=1.,mu=.5),
            dict(side=1,point=[.03,0,0],frame=np.eye(3),sign=-1.,mu=.5)]


def test_centered_pair_balances_gravity_and_scales_with_mass():
    value=gravity_support_cost(contacts(),np.zeros(3),np.array([0.,0.,-2.]),.03)
    assert np.isclose(value,2.)
    assert np.isclose(gravity_support_cost(contacts(),np.zeros(3),np.array([0.,0.,-4.]),.03),2*value)


def test_bilateral_geometry_alone_does_not_balance_off_axis_gravity_torque():
    assert gravity_support_cost(contacts(),np.array([0.,.01,0.]),np.array([0.,0.,-2.]),.03) is None
    same_side=contacts();same_side[1]['sign']=1.
    assert gravity_support_cost(same_side,np.zeros(3),np.array([0.,0.,-2.]),.03) is None


def test_contact_patch_can_balance_torque_without_soft_torsion():
    patch=contacts()
    patch += [{**c,'point':np.array(c['point'])+[0,.02,0]} for c in contacts()]
    assert gravity_support_cost(patch,np.array([0.,.01,0.]),np.array([0.,0.,-2.]),.03) is not None


def test_support_statistic_is_coordinate_invariant():
    from scipy.spatial.transform import Rotation
    r=Rotation.from_euler('xyz',[.3,.4,.2]).as_matrix();shift=np.array([.1,.2,.3])
    transformed=[{**c,'point':r@np.array(c['point'])+shift,'frame':np.array(c['frame'])@r.T} for c in contacts()]
    assert np.isclose(gravity_support_cost(transformed,shift,r@np.array([0.,0.,-2.]),.03),2.)


def test_c6_uses_gravity_rank_before_motion_cost_but_keeps_fallback(cfg,world):
    from five_chains.skills.recipes import RecipeRegistry
    from five_chains.types import SkillCall
    from five_chains.components.c12_contract import ContractDispatcher
    contract=ContractDispatcher().expand(SkillCall('p',3,'place_object_in_container',{'object':'vegetable','target':'bowl'}))
    near=pose([0.,0.,0.]);far=pose([.02,0,0]);registry=RecipeRegistry(config=cfg)
    registry.grasp_provider=SimpleNamespace(candidates=lambda *args:(near,far),stability_rank=lambda t:int(np.allclose(t,near)))
    result=registry.prepare(contract.fields['grasp_pose'],contract,world)
    assert np.allclose(result,far)
    registry.grasp_provider.candidates=lambda *args:(near,)
    assert np.allclose(registry.prepare(contract.fields['grasp_pose'],contract,world),near)


def test_missing_diagnostic_preserves_original_rank():
    provider=object.__new__(CurrentAssetGrasps)
    provider.records=[];provider.original=object()
    assert provider.stability_rank(pose([0.,0.,0.]))==(1,0.)


def test_transverse_proposals_keep_orientation_and_total_declared_offset():
    from five_chains.skills.live_grasps import transverse_grasp_candidates
    from scipy.spatial.transform import Rotation
    original=pose([.1,.2,.3],Rotation.from_euler('xyz',[.2,.3,.4]).as_matrix())
    saved=original.copy();opening=np.array([0.,1.,0.])
    proposals=transverse_grasp_candidates([original],opening,.008)
    assert len(proposals)==7
    for candidate,anchor in proposals:
        delta=candidate[:3,3]-anchor[:3,3]
        assert np.linalg.norm(delta)<=.008
        assert abs(delta@(original[:3,:3]@opening))<1e-12
        assert abs(delta@original[:3,2])<1e-12
        assert np.array_equal(candidate[:3,:3],original[:3,:3])
    assert np.array_equal(original,saved)


def test_static_feasible_rank_prefers_lower_required_squeeze():
    a=object.__new__(CurrentAssetGrasps);a.original=object()
    first=pose([0.,0.,0.]);second=pose([.01,0.,0.])
    a.records=[(first,{'gravity_support':{'reduced_model_feasible':True,'minimum_normal_per_pad_n':9.}}),
               (second,{'gravity_support':{'reduced_model_feasible':True,'minimum_normal_per_pad_n':.3}})]
    assert a.stability_rank(second)<a.stability_rank(first)
