"""Synthetic regression only; actual whole-chain off still needs native evidence."""
from types import SimpleNamespace
from copy import deepcopy
import pytest
from five_chains.native_validation import NativeInterventions,configure
from five_chains.native_validation_summary import whole_relation_disable_evidence


def case(scope='whole_chain'):
    return {'probe':'relation','setting':'off','relation_control_scope':scope,'post_window':24}


def test_literal_off_is_registered_but_not_active_during_warmup(cfg):
    configure(cfg,case())
    assert cfg['chain_validation']['disable_full_relation_from_registered_input']
    assert 'c3b_fb_full' not in cfg['ablation']['disable_chains']
    assert not cfg['chain_validation'].get('phase_only_no_parameter_update',False)


def test_literal_boundary_disables_runtime_and_grasp_repair_routes(cfg):
    c=case();configure(cfg,c);records=[]
    hook=NativeInterventions.__new__(NativeInterventions)
    hook.case=c;hook.cfg=cfg;hook.disabled_chains=set();hook.tracer=SimpleNamespace(write=records.append)
    hook.control_boundary(10,SimpleNamespace(contract=SimpleNamespace(call=SimpleNamespace(call_id='call'))))
    assert hook.disabled_chains=={'c3b_fb_full'}
    assert 'c3b_fb_full' in cfg['ablation']['disable_chains']
    assert cfg['chain_validation']['phase_only_no_parameter_update'] is False
    assert records[0]['phase_progression_enabled'] is False
    assert records[0]['control_scope']=='whole_chain'


def test_legacy_parameter_only_scope_is_preserved_and_named(cfg):
    c=case('phase_only');configure(cfg,c);records=[]
    hook=NativeInterventions.__new__(NativeInterventions)
    hook.case=c;hook.cfg=cfg;hook.disabled_chains=set();hook.tracer=SimpleNamespace(write=records.append)
    hook.control_boundary(10,SimpleNamespace(contract=SimpleNamespace(call=SimpleNamespace(call_id='call'))))
    assert not hook.disabled_chains and records[0]['phase_progression_enabled'] is True
    assert 'control_scope' not in records[0]  # Existing record schema is preserved.
    assert cfg['chain_validation']['phase_only_no_parameter_update'] is True


@pytest.mark.parametrize('probe,scope',[('relation','missing'),('fast','whole_chain'),('geometry','whole_chain')])
def test_scope_cannot_silently_change_other_controls(cfg,probe,scope):
    c=case(scope);c['probe']=probe
    with pytest.raises(ValueError,match='relation control scope'):configure(cfg,c)


def rows():
    result=[{'kind':'native_control_boundary','tick':10,'call_id':'call','chain':'c3b_fb_full',
      'control_scope':'whole_chain','disabled_from_registered_input':True,'warmup_enabled':True,
      'phase_progression_enabled':False,'phase_only_no_parameter_update':False,'active_disabled_chains':['c3b_fb_full']}]
    for tick in range(10,34):
        result.append({'kind':'execution','loop_tick':tick,'status':'returned','call_id':'call'})
        result.append({'kind':'tick','tick':tick,'call_id':'call','phase':'carry','triggers':[],'writes':[]})
    return result


def test_raw_verifier_accepts_complete_synthetic_off_window():
    assert all(whole_relation_disable_evidence(rows(),case()).values())


@pytest.mark.parametrize('fault',['c7','full_trigger','full_readout','phase_still_enabled','missing_execution'])
def test_boolean_boundary_is_not_sufficient_without_actual_absence(fault):
    data=deepcopy(rows())
    if fault=='c7':data.append({'kind':'invocation_start','loop_tick':12,'component':'c7.update'})
    if fault=='full_trigger':data[2]['triggers']=['c3b_fb_full']
    if fault=='full_readout':data.append({'kind':'invocation_start','loop_tick':12,'component':'c8.readout','chain':'c3b_fb_full'})
    if fault=='phase_still_enabled':data[0]['phase_progression_enabled']=True
    if fault=='missing_execution':del data[1]
    assert not all(whole_relation_disable_evidence(data,case()).values())
