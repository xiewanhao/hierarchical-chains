from dataclasses import replace
import numpy as np
import pytest
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose, inverse
from five_chains.types import SkillCall
from five_chains.chains.c1_prep import chain1_prep


def elevated(world, enclosed=True, held=False):
    cavity=replace(world.entities['microwave_interior'],pose_world=pose([.9,.5,1.45],Rotation.from_euler('z',.6).as_matrix()),extent=np.array([.25,.22,.20]))
    bowl=replace(world.entities['bowl'],pose_world=cavity.pose_world@pose([.04,.01,0.]))
    signals={**world.signals,'grasp_modes':{'bowl':'rim'},'object_top_offsets':{'bowl':[0.,0.,.05]},
             'cavity_entities':['microwave_interior'] if enclosed else [],
             'fixture_front_entities':['microwave_interior'] if enclosed else [],
             'cavity_obstacles':{'microwave_interior':['handle']},
             'torso':{'position_m':0.,'origin_world':[0.,0.,.7],'range_m':[0.,.34]}}
    if held:signals['grasp_transforms']={'vegetable':pose([0.,0.,.02])}
    return replace(world,entities={**world.entities,'bowl':bowl,'microwave_interior':cavity},signals=signals)


@pytest.mark.parametrize('enclosed',[False,True])
def test_elevated_receptacle_preserves_selected_call_final_goal_and_termination(C,call,world,enclosed):
    w=elevated(world,enclosed);original=C.c12.expand(call);c=C.c12.initialize_entry(original,w)
    assert c.call is call and c.termination==original.termination and not c.sub_calls
    assert c.fields['place_pose'] is original.fields['place_pose']
    old=C.c6.recipes.prepare(original.fields['place_pose'],original,w)
    new=C.c6.recipes.prepare(c.fields['place_pose'],c,w)
    assert np.array_equal(old,new)
    local=C.c6.recipes.prepare(c.fields['lift_pose'],c,w)
    delta=w.entities['vegetable'].pose_world[:3,:3]@local[:3,3]
    assert np.allclose(delta,[0.,0.,.16])
    phases=[p.name for p in c.phases]
    assert phases.index('lift')<phases.index('base_to_target')<phases.index('carry')
    assert phases.index('raise_torso')<phases.index('carry')
    if enclosed:
        assert phases.index('base_to_clearance')<phases.index('align_payload_outside')<phases.index('raise_torso')
        assert c.fields['base_at_target'].prep_frame=='microwave_interior'
        assert c.followup['access_frame']=='microwave_interior'
        assert {'handle.pose','handle.extent'}<=c.fields['entry_clearance_pose'].depends_on
    else:
        assert phases.index('base_to_target')<phases.index('raise_torso')
        assert c.followup['access_frame'] is None


def test_enclosing_cavity_access_uses_rotated_opening_and_preserves_payload_height(C,call,world):
    w=elevated(world);c=C.c12.initialize_entry(C.c12.expand(call),w)
    stance=c.fields['base_at_target'];base=w.entities[stance.prep_frame].pose_world@C.c6.recipes.prepare(stance,c,w)
    w=replace(w,base_pose_world=base)
    spec=c.fields['payload_alignment_pose'];local=C.c6.recipes.prepare(spec,c,w);goal=w.entities[spec.prep_frame].pose_world@local
    access=w.entities['microwave_interior'];relative=inverse(access.pose_world)@goal
    assert np.isclose(relative[1,3],-access.extent[1]-C.c6.recipes.config['grasp']['entrance_clearance_m'])
    assert np.isclose(goal[2,3],w.entities['vegetable'].pose_world[2,3])
    entry=c.fields['entry_clearance_pose'];entry_goal=w.entities[entry.prep_frame].pose_world@C.c6.recipes.prepare(entry,c,w)
    placement=c.fields['place_pose'];final=w.entities[placement.prep_frame].pose_world@C.c6.recipes.prepare(placement,c,w)
    assert np.isclose(entry_goal[2,3],final[2,3]+C.c6.recipes.config['grasp']['transfer_height_margin_m'])


def test_held_high_target_reentry_lifts_with_closed_gripper_and_executes_torso_via_c10(C,call,world):
    w=elevated(world,held=True);c,p6,p7,prop=chain1_prep(call,w,C)
    assert c.phases[0].name=='lift'
    assert all(p.gripper=='close' for p in c.phases[:next(i for i,p in enumerate(c.phases) if p.name=='release')])
    assert .2<float(prop.updates['torso_height'].value)<=.34
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    index=next(i for i,p in enumerate(c.phases) if p.name=='raise_torso');p7=replace(p7,phase_index=index,phase_name='raise_torso')
    commands=[];C.c10.adapter.torso_action=lambda target,*args:commands.append(target) or np.array([target])
    C.c10.solve(packet,c,p7,w,None)
    assert commands and C.c10.last_actuator=='torso'
    assert commands[-1]==float(prop.updates['torso_height'].value)


@pytest.mark.parametrize('mode',['low','not_receptacle','direct_cavity'])
def test_unrelated_calls_keep_existing_phase_decomposition(C,call,world,mode):
    w=elevated(world)
    if mode=='low':w=replace(w,entities={**w.entities,'bowl':replace(w.entities['bowl'],pose_world=pose([.4,0,.8]))})
    if mode=='not_receptacle':w=replace(w,signals={**w.signals,'grasp_modes':{}})
    if mode=='direct_cavity':call=replace(call,bindings={'object':'bowl','target':'microwave_interior'})
    c=C.c12.initialize_entry(C.c12.expand(call),w)
    assert c.followup.get('entry_variant')!='elevated_receptacle'
    if mode=='direct_cavity':assert c.followup['entry_variant']=='selected_cavity_placement'
    else:assert 'raise_torso' not in [p.name for p in c.phases]


def test_receptacle_retreat_exits_observed_cavity_without_raising_or_turning(C,call,world):
    w=elevated(world);c=C.c12.initialize_entry(C.c12.expand(call),w)
    frame=w.entities['microwave_interior'].pose_world
    current=frame@pose([.03,.02,.10],Rotation.from_euler('y',np.pi/2).as_matrix())
    w=replace(w,eef_pose_world=current)
    target=C.c6.recipes.prepare(c.fields['retreat_pose'],c,w)
    local=inverse(frame)@target
    assert np.isclose(local[1,3],-w.entities['microwave_interior'].extent[1]-C.c6.recipes.config['grasp']['entrance_clearance_m'])
    assert np.isclose(target[2,3],current[2,3])
    assert np.allclose(target[:3,:3],current[:3,:3])
    assert np.isclose(local[0,3],(inverse(frame)@current)[0,3])


def test_retreat_does_not_use_stale_cavity_reference_after_receptacle_moves(C,call,world):
    w=elevated(world);c=C.c12.initialize_entry(C.c12.expand(call),w)
    w=replace(w,entities={**w.entities,'bowl':replace(w.entities['bowl'],pose_world=pose([3.,3.,.8]))})
    stale=C.c6.recipes.prepare(c.fields['retreat_pose'],c,w)
    plain=C.c6.recipes.prepare(c.fields['retreat_pose'],replace(c,followup={}),w)
    assert np.array_equal(stale,plain)
