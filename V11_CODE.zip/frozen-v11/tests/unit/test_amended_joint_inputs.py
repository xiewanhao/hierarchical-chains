"""Synthetic amended-protocol tests; native joint evidence remains separate."""
from types import SimpleNamespace as NS
from copy import deepcopy
import numpy as np
import pytest
from five_chains.native_validation import NativeInterventions, configure

def case():
    return {'probe':'joint','setting':'normal','joint_scope':'user_skip_button_lowload_v1',
        'joint_relation_object':'bowl','joint_target':'microwave_interior',
        'joint_geometry_mode':'one_frame_target_observation',
        'skipped_requirements':['joint_button_lowload_same_tick'],'human_authorization_reference':'explicit-human-skip'}

@pytest.mark.parametrize('key,value',[('joint_relation_object','vegetable'),('joint_geometry_mode','teleport_fixture'),
    ('human_authorization_reference',''),('skipped_requirements',[])])
def test_no_silent_scope_substitution(cfg,key,value):
    c=case();c[key]=value
    with pytest.raises(ValueError,match='amended joint'):configure(cfg,c)

def test_explicit_amendment_keeps_original_force_controller_settings(cfg):
    old=deepcopy(cfg);configure(cfg,case())
    assert cfg['control']==old['control']
    assert cfg['reflex']['bounds']==old['reflex']['bounds']

def fixture(monkeypatch):
    hook=NativeInterventions.__new__(NativeInterventions);hook.case=case();hook.env=object()
    hook.events=[];hook.relation_response_checked=False;records=[]
    hook.tracer=NS(write=records.append);hook.target_before_input=lambda *args:None
    hook.emit=lambda tick,ctx,name,*args:hook.events.append({'name':name,'physical_step_index':10})
    calls=[];hook.translate=lambda *args:calls.append(args) or args[1]
    monkeypatch.setattr('five_chains.native_validation.physical_signature',lambda env:{'unchanged':True})
    ctx=NS(contract=NS(call=NS(call_id='held',bindings={'object':'bowl','target':'microwave_interior'}),
        phases=[NS(target_field='place_pose')]),executed_actuator='arm',p7=NS(phase_name='carry',phase_index=0,steps_in_phase=3))
    obs={'state':{'signals':{'grasp_transforms':{'bowl':np.eye(4)}},'eef_pose_world':np.eye(4),
                  'entities':{'microwave_interior':{'pose_world':np.eye(4)}}}}
    return hook,ctx,obs,NS(c10=NS(executions=13)),calls,records

def test_relation_uses_actual_bowl_only(monkeypatch):
    h,c,o,C,calls,records=fixture(monkeypatch)
    c.contract.call.bindings['object']='vegetable'
    assert h.registered_joint_carry_inputs(10,o,c,C) is o and not calls
    c.contract.call.bindings['object']='bowl';h.registered_joint_carry_inputs(10,o,c,C)
    assert calls[0][4]=='bowl' and np.linalg.norm(calls[0][5])==pytest.approx(.005)
    assert records[0]['skipped_is_not_passed'] is True

def test_geometry_waits_for_executed_relation_response(monkeypatch):
    h,c,o,C,calls,_=fixture(monkeypatch);h.events=[{'name':'grasp_relation_5mm','physical_step_index':10}]
    assert h.registered_joint_carry_inputs(11,o,c,C) is o
    h.relation_response_checked=True;C.c10.executions=12
    assert h.registered_joint_carry_inputs(12,o,c,C) is o

def test_target_overlay_is_current_observation_only(monkeypatch):
    h,c,o,C,calls,records=fixture(monkeypatch);h.events=[{'name':'grasp_relation_5mm','physical_step_index':10}]
    h.relation_response_checked=True
    result=h.registered_joint_carry_inputs(13,o,c,C)
    assert not calls and result is not o
    assert np.array_equal(o['state']['entities']['microwave_interior']['pose_world'],np.eye(4))
    assert result['state']['entities']['microwave_interior']['pose_world'][0,3]==.05
    assert records[-1]['active_state_preserved'] and records[-1]['future_observations_unmodified']
