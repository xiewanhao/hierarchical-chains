# -*- coding: utf-8 -*-
from dataclasses import replace
from types import SimpleNamespace as N
import sys
from copy import deepcopy
import numpy as np
import pytest
from five_chains.envs.native_reference_preview import NativeReferencePreview,clone_controller
from five_chains.envs.reference_bridge import Scope,ReferenceBridge,Branch
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.components.c10_executor import Executor


def fake_provider(monkeypatch):
    def get_state(model,data,target,spec):target[:]=data.integration
    mj=N(mjtState=N(mjSTATE_INTEGRATION=1),mj_stateSize=lambda m,s:5,mj_getState=get_state)
    monkeypatch.setitem(sys.modules,'mujoco',mj)
    model=N(jnt_range=np.tile([-2.,2.],(7,1)),actuator_ctrlrange=np.tile([-12.,12.],(7,1)),geom_friction=np.ones((1,3)))
    controller=N(sim=object(),robot_model=object(),kp=np.ones(6),initial_joint=np.zeros(7),goal_pos=np.zeros(3),new_update=False)
    a=N(env=N(sim=N(model=N(_model=model),data=N(_data=N(integration=np.arange(5.)))),action_spec=(np.full(2,-1.),np.ones(2))),
        composite=N(part_controllers={'arm':controller},grippers={'arm':N(current_action=np.zeros(1))}),
        controller=controller,posture_solver=N(joints=np.arange(7)))
    return NativeReferencePreview(a),Scope('call','close',5,'target','scene',False)


@pytest.mark.parametrize('kind',['integration','kp','goal','reference','model_range','model_friction','gripper','scope','action'])
def test_all_causal_preview_bindings_invalidate(monkeypatch,kind):
    p,s=fake_provider(monkeypatch);a=p.adapter;action=np.zeros(2);b=p.capture(action,s)
    if kind=='integration':a.env.sim.data._data.integration[2]+=.001
    if kind=='kp':a.controller.kp[0]+=.1
    if kind=='goal':a.controller.goal_pos[0]+=.01
    if kind=='reference':a.controller.initial_joint[0]+=.01
    if kind=='model_range':a.env.sim.model._model.jnt_range[0,0]-=.01
    if kind=='model_friction':a.env.sim.model._model.geom_friction[0,0]+=.01
    if kind=='gripper':a.composite.grippers['arm'].current_action[0]=1.
    if kind=='scope':s=replace(s,tick=6)
    if kind=='action':action[0]=.01
    with pytest.raises(ValueError):p.verify(action,s,b['token'])


def test_same_state_binding_is_deterministic_and_has_detached_state(monkeypatch):
    p,s=fake_provider(monkeypatch);b=p.capture(np.zeros(2),s)
    p.verify(np.zeros(2),s,b['token']);b['state'][0]=999.
    assert p.adapter.env.sim.data._data.integration[0]==0.
    assert b['token']==p.capture(np.zeros(2),s)['token']


def test_controller_nested_buffers_are_not_shared():
    live=N(sim=object(),robot_model=object(),nested={'x':[np.arange(3.)]},initial_joint=np.zeros(7))
    private=N();cloned=clone_controller(live,private)
    cloned.nested['x'][0][0]=99.;cloned.initial_joint[0]=1.
    assert live.nested['x'][0][0]==0. and live.initial_joint[0]==0.
    assert cloned.sim is private


def test_unknown_controller_mutable_state_fails_closed():
    with pytest.raises(ValueError):clone_controller(N(sim=object(),interpolator=object()),N())


def test_nested_known_sim_reference_is_rebound_but_unknown_sim_is_rejected():
    live_sim=object();private_sim=object();controller=N(sim=live_sim,config={'nested':{'sim':live_sim}})
    cloned=clone_controller(controller,private_sim)
    assert cloned.config['nested']['sim'] is private_sim
    with pytest.raises(ValueError):clone_controller(N(sim=live_sim,config={'sim':object()}),private_sim)


def test_nonfinite_state_and_native_action_violation_are_rejected(monkeypatch):
    p,s=fake_provider(monkeypatch)
    with pytest.raises(ValueError):p.capture([2.,0.],s)
    p.adapter.env.sim.data._data.integration[0]=np.nan
    with pytest.raises(ValueError):p.capture([0.,0.],s)


def test_shadow_qp_uses_actual_executed_reference_and_checks_native_result(monkeypatch):
    p,s=fake_provider(monkeypatch);preview={'binding':p.capture([0.,0.],s),
        'baseline':dict(reference=[0.]*7,torque=[0.]*7,A=np.eye(7).tolist(),native_torque_ranges=[[-12.,12.]]*7)}
    seen=[]
    def check(pr,ref):seen.append(np.array(ref));return dict(torque=list(ref),affine_residual_nm=0.,primary_difference_nm=0.)
    p.verify_reference=check
    result=p.shadow_solve(preview,np.zeros(7),np.ones(7))
    np.testing.assert_allclose(seen[0],.03,atol=1e-15)
    assert not result['proposal_applied'] and np.array_equal(p.adapter.controller.initial_joint,np.zeros(7))


def test_shadow_qp_rejects_native_torque_disagreement(monkeypatch):
    p,s=fake_provider(monkeypatch);preview={'binding':p.capture([0.,0.],s),
        'baseline':dict(reference=[0.]*7,torque=[0.]*7,A=np.eye(7).tolist(),native_torque_ranges=[[-12.,12.]]*7)}
    p.verify_reference=lambda pr,ref:dict(torque=[13.]*7)
    with pytest.raises(ValueError):p.shadow_solve(preview,np.zeros(7),np.ones(7))


def test_adapter_shadow_runtime_uses_lease_and_real_receipt_not_pending(cfg):
    a=object.__new__(RoboCasaAdapter);a.config=deepcopy(cfg);a.config['control']['close_reference_native_preview_shadow']=True
    a._reference_bridge_in_scope=True;a._reference_preview_door_qpos=0
    a.controller=N(initial_joint=np.zeros(7));a.env=N(sim=N(data=N(time=1.1,qpos=np.array([-.5]))))
    a.posture_solver=N(joints=np.arange(7));a.env.sim.model=N(_model=N(jnt_range=np.tile([-3.,3.],(7,1))))
    b=ReferenceBridge();s=Scope('call','close',10,'target','scene',False);b.begin(s)
    approach=replace(s,phase='approach',tick=8)
    b.branch=Branch.captured(approach,0,[dict(angle_rad=-1.,joints_rad=[0.]*7),dict(angle_rad=0.,joints_rad=[1.]*7)],np.zeros(7))
    b.prepare([0.],np.zeros(7),1.,0);b.before_execute([0.],np.zeros(7),1.,0);b.after_execute(np.zeros(7),1.05,1);b.begin(replace(s,tick=11))
    a.reference_bridge=b;calls=[]
    class Provider:
        def baseline(self,action,scope):return dict(binding={'token':'token','scope':scope,'action':np.array(action)},baseline={'reference':[0.]*7})
        def verify(self,action,scope,token):assert token=='token'
        def shadow_solve(self,preview,previous,desired):
            calls.append((previous,desired));return {'reference':[.03]*7,'proposal_applied':False}
    a.native_reference_preview=Provider()
    a.reference_bridge_prepare(np.zeros(1),1)
    # A synthetic branch with no complete actual input capture is insufficient.
    assert not calls
    assert not b.proposal_readiness(-.5)['forecast_source_capture_available']
    np.testing.assert_array_equal(a.controller.initial_joint,np.zeros(7))
    assert b.receipt['actual_executed_reference']==[0.]*7 and b.pending['reference']==[0.]*7


def test_preview_error_becomes_explicit_C10_failure_before_execution(cfg):
    config=deepcopy(cfg);config['control']['close_reference_bridge_capture']=True
    class Adapter:
        def reference_bridge_begin(self,*args):pass
        def reference_bridge_prepare(self,*args):raise ValueError('invalid preview')
        def reference_bridge_abort(self):self.aborted=True
    a=Adapter();ex=Executor(a,config);ex._solve_motion=lambda *args:np.zeros(1)
    ex.solve(None,None,None,None,None)
    assert ex.failure_reason=='reference_preview:invalid preview' and ex.executions==0 and a.aborted
