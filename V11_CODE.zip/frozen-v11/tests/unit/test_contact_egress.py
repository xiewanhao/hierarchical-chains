from copy import deepcopy
from dataclasses import replace
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.envs.contact_telemetry import contact_separation
from five_chains.geometry import pose
from five_chains.types import SkillCall, FeedbackDelta, ChainId
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.c3_feedback import chain3b_full


def contact(first=2,second=3,normal=(0.,-1.,0.),load=10.):
    return dict(geom_ids=[first,second],distance_m=-.0005,
                solver_wrench_contact_frame=[load,0,0,0,0,0],
                contact_frame_rows=[list(normal),[0,0,1],[1,0,0]])


def test_separation_signed_pair_order_and_no_source_mutation():
    rows=[contact(),contact(3,2,(0.,1.,0.)),contact(2,9,(1.,0.,0.))]
    before=deepcopy(rows)
    result=contact_separation(rows,frozenset([2]),frozenset([3]))
    assert result['contact_count']==2 and np.allclose(result['direction_world'],[0.,-1.,0.])
    assert rows==before and result['source']=='native_simulator_contact_solver'


def test_separation_rejects_opposing_pinch_and_unloaded_unrelated_contacts():
    assert contact_separation([contact(),contact(normal=(0.,1.,0.))],frozenset([2]),frozenset([3])) is None
    assert contact_separation([contact(load=0),contact(5,3)],frozenset([2]),frozenset([3])) is None


def test_separation_rotates_with_observed_contact_geometry():
    rotation=Rotation.from_euler('z',.7).as_matrix()
    result=contact_separation([contact(normal=rotation@np.array([0.,-1.,0.]))],frozenset([2]),frozenset([3]))
    assert np.allclose(result['direction_world'],rotation@np.array([0.,-1.,0.]))


def test_measured_egress_freezes_at_phase_entry_without_dragging_along_fixture_normal(C,world):
    C.c6.recipes.config['grasp']['native_contact_egress']=True
    direction=contact_separation([contact()],frozenset([2]),frozenset([3]))
    direction['target_entity']='handle'
    w=replace(world,eef_pose_world=pose([.45,-1.41,1.61],Rotation.from_euler('z',.4).as_matrix()),
        signals={'surface_normals':{'handle':np.array([1.,0.,0.])},
                 'microwave_hinge':{'angle':0.,'axis_world':[0.,0.,1.],'anchor_world':[.4,-1.9,1.6]},
                 'native_motion_diagnostics':{'handle_contact_egress':direction}})
    call=SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'})
    c,p6,p7,prop=chain1_prep(call,w,C)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name=='settle_door'),phase_name='settle_door')
    w=replace(w,stamp=w.stamp+1)
    p6,p7,update=chain3b_full(c,p6,p7,w,FeedbackDelta(w.stamp,('door_closed_settled',),{}),C)
    release=update.updates['release_pose'].value
    assert p7.phase_name=='release_contact'
    assert np.allclose(release[:3,3]-w.eef_pose_world[:3,3],[0.,-.06,0.])
    assert np.array_equal(release[:3,:3],w.eef_pose_world[:3,:3])
    later=replace(w,stamp=w.stamp+1,eef_pose_world=pose([8.,8.,8.]),signals={**w.signals,'native_motion_diagnostics':{}})
    values=C.c8.readout(c,p6,p7,later,frozenset({'release_pose'}),ChainId.FB_FULL)
    assert np.array_equal(values['release_pose'].value,release)


def test_missing_or_untrusted_egress_keeps_original_prepared_fallback(C,world):
    c=C.c12.expand(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}))
    w=replace(world,signals={'surface_normals':{'handle':np.array([1.,0.,0.])}})
    old=C.c6.recipes.prepare(c.fields['release_pose'],c,w)
    C.c6.recipes.config['grasp']['native_contact_egress']=True
    for data in ({},{'source':'unknown','target_entity':'handle','direction_world':[0,-1,0]},
                 {'source':'native_simulator_contact_solver','target_entity':'other','direction_world':[0,-1,0]}):
        current=replace(w,signals={**w.signals,'native_motion_diagnostics':{'handle_contact_egress':data} if data else {}})
        assert np.array_equal(C.c6.recipes.prepare(c.fields['release_pose'],c,current),old)
