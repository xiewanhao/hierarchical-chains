from dataclasses import replace
import numpy as np
import pytest
from five_chains.types import SkillCall,ReflexOverride
from five_chains.geometry import pose
from five_chains.config import validate_config
from five_chains.chains.c1_prep import chain1_prep


def prepared(C,world,lateral=.02,axial=.04):
    world=replace(world,signals={**world.signals,'surface_normals':{'start':np.array([-1.,0.,0.])}})
    c,_,p7,prop=chain1_prep(SkillCall('button',3,'activate_control',{'appliance':'microwave','control':'start'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    p7=replace(p7,phase_index=1,phase_name='press')
    goal=pose([.1,.2,1.])
    packet=replace(packet,params={**packet.params,'press_pose':replace(packet.params['press_pose'],value=goal)})
    w=replace(world,eef_pose_world=pose(goal[:3,3]-[lateral,0.,axial]),signals={**world.signals,'native_motion_diagnostics':{'simulation_time_s':1.}})
    return c,p7,packet,w,goal


@pytest.mark.parametrize('enabled,lateral,axial,active',[(True,.02,.04,True),(False,.02,.04,False),(True,.01199,.04,False),(True,.005,.04,False),(True,.02,-.04,False)])
def test_reference_alignment_preserves_goal_speed_and_original_threshold(C,world,enabled,lateral,axial,active):
    c,p,packet,w,goal=prepared(C,world,lateral,axial);cfg=C.c10.config['control'];cfg['press_lateral_alignment']=enabled
    frozen=packet.params['press_pose'].value.copy()
    C.c10.solve(packet,c,p,w,None)
    assert np.array_equal(packet.params['press_pose'].value,frozen)
    assert np.array_equal(C.c10.last_target,goal)
    step=C.c10.reference[:3,3]-w.eef_pose_world[:3,3]
    assert np.linalg.norm(step)<=float(packet.params['speed_limit'].value)/C.c10.adapter.control_freq+1e-12
    assert np.linalg.norm(step)<=cfg['max_tracking_lead_m']+1e-12
    if active:
        assert C.c10.reference_diagnostic['active']
        assert abs(step[2])<1e-12 and step[0]>0.
    elif enabled:assert not C.c10.reference_diagnostic['active']
    else:assert not C.c10.reference_diagnostic


@pytest.mark.parametrize('override',[ReflexOverride('hold',None,'test_hold'),ReflexOverride('stop',None,'test_stop')])
def test_reflex_override_retains_precedence(C,world,override):
    c,p,packet,w,goal=prepared(C,world);C.c10.config['control']['press_lateral_alignment']=True
    C.c10.solve(packet,c,p,w,override)
    assert not C.c10.reference_diagnostic
    assert np.array_equal(C.c10.reference,w.eef_pose_world)


def test_scope_does_not_change_other_selected_skills(C,world):
    c,p,packet,w,goal=prepared(C,world);C.c10.config['control']['press_lateral_alignment']=True
    c=replace(c,call=replace(c.call,skill='other_skill'))
    C.c10.solve(packet,c,p,w,None)
    assert not C.c10.reference_diagnostic
    assert C.c10.reference[2,3]>w.eef_pose_world[2,3]


def test_alignment_uses_rotated_original_axis_without_changing_attitude(C,world):
    from scipy.spatial.transform import Rotation
    c,p,packet,w,goal=prepared(C,world);R=Rotation.from_euler('y',np.pi/2).as_matrix();goal[:3,:3]=R
    packet=replace(packet,params={**packet.params,'press_pose':replace(packet.params['press_pose'],value=goal)})
    current=goal.copy();current[:3,3]-=R@np.array([.02,0.,.04]);w=replace(w,eef_pose_world=current)
    C.c10.config['control']['press_lateral_alignment']=True;C.c10.solve(packet,c,p,w,None)
    step=C.c10.reference[:3,3]-current[:3,3]
    assert abs(step@R[:,2])<1e-12
    assert np.allclose(C.c10.reference[:3,:3],R)


def test_default_false_and_boolean_validation(cfg):
    assert cfg['control']['press_lateral_alignment'] is False
    cfg['control']['press_lateral_alignment']=1
    with pytest.raises(ValueError,match='press lateral alignment'):validate_config(cfg)
