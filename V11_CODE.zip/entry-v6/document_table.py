"""Read-only document table from actual records, with explicit finite scopes.

No simulator imports or inferred recipe calls from parameter stamps. This module
does not turn a table, passing fixture, or incomplete cohort into native proof.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone
from hashlib import sha256
import csv, gzip, json

CHAINS = {'preparation':'c1_prep','fast':'c3a_fb_fast','reflex_stop':'c2_reflex',
          'reflex_gripper':'c2_reflex','relation':'c3b_fb_full','geometry':'c4_vision','reselection':'c5_replan'}
REQUIRED = {('preparation',s) for s in ('normal','freeze_after_prep')} | {
    (probe,setting) for probe in CHAINS if probe!='preparation'
    for setting in ('normal','off','full_recompute')}

def read(path): return json.loads(Path(path).read_text())
def digest(path): return sha256(Path(path).read_bytes()).hexdigest()

def permission_checks(records, selected_ticks, chain, actual_writes=False):
    """Use only contracts already present before the actual proposal tick."""
    contracts = {}; checks = []; selected = {id(r) for r in selected_ticks}
    decisions = {}; packets = {}
    for row in records:
        if row['kind']=='native_contract_fields': contracts[row['call_id']] = row['fields']
        elif row['kind']=='contract_snapshot':
            contract = row['contract']; contracts[contract['call']['call_id']] = contract['fields']
        elif row['kind']=='arbitration':
            decisions[(row.get('call_id'),row.get('loop_tick'),row.get('chain'),row.get('field'))] = row
        elif row['kind']=='action_prepared':
            packets[(row.get('call_id'),row.get('loop_tick'))] = row.get('parameters',{})
        if id(row) not in selected: continue
        fields = contracts.get(row['call_id'],{})
        proposals = ([{'chain':w['chain'],'fields':[w['name']]} for w in row.get('writes',[])]
                     if actual_writes else row.get('proposals',[]))
        for proposal in proposals:
            if proposal['chain']!=chain: continue
            for name in proposal['fields']:
                spec = fields.get(name)
                decision = decisions.get((row['call_id'],row['tick'],chain,name),{})
                parameter = packets.get((row['call_id'],row['tick']),{}).get(name,{})
                default_nonwrite = bool(not actual_writes and spec is not None and chain=='c1_prep'
                    and spec.get('writable_by')==[] and spec.get('recipe') is None
                    and decision.get('permission') is False and decision.get('decision')=='bound_default_not_update'
                    and parameter.get('stamp')==-1 and parameter.get('value')==spec.get('default')
                    and all(parameter.get(k)==spec.get(k) for k in ('kind','unit','frame_entity'))
                    and not any(w['name']==name for w in row.get('writes',[])))
                authorized = None if spec is None else chain in spec.get('writable_by',[])
                checks.append({'tick':row['tick'],'call_id':row['call_id'],'field':name,
                    'contract_present':spec is not None,
                    'writer_authorized':authorized,
                    'immutable_default_bound_without_chain_update':default_nonwrite,
                    'permission_disposition_valid':authorized is True or default_nonwrite})
    return checks

def summarize_case(record):
    directory = Path(record['directory']); result = read(directory/'result.json')
    registration = read(directory/'registration.json'); case = result['case']; probe = case['probe']
    if probe not in CHAINS: raise ValueError('Document single-control scope required')
    chain = CHAINS[probe]; trace = directory/'ticks.jsonl.gz'
    for key,path in [('raw_sha256',trace),('result_sha256',directory/'result.json')]:
        if key in record and digest(path)!=record[key]: raise ValueError('Recorded bytes changed: '+key)
    with gzip.open(trace,'rt',encoding='utf-8') as stream: records = [json.loads(line) for line in stream]
    events = [r for r in records if r['kind']=='perturbation']
    unique_input = len(events)==1
    event = events[0] if unique_input else None
    start = event['tick'] if event is not None else None
    ticks = [r for r in records if r['kind']=='tick']
    selected = ticks if chain=='c1_prep' else ([r for r in ticks if r['tick']>=start] if unique_input else [])
    tail = records if chain=='c1_prep' else (records[records.index(event):] if unique_input else [])
    trigger = sum(chain in r.get('triggers',[]) for r in selected)
    episode_trigger = sum(chain in r.get('triggers',[]) for r in ticks)
    if chain=='c5_replan':
        trigger = sum(r['kind']=='reselection_requested' for r in tail)
        episode_trigger = sum(r['kind']=='reselection_requested' for r in records)
    proposed = Counter(); adopted = Counter(); rejected = Counter(); reasons = Counter(); reflex = Counter()
    for row in selected:
        for proposal in row.get('proposals',[]):
            if proposal['chain']==chain: proposed.update(proposal['fields'])
        adopted.update(w['name'] for w in row.get('writes',[]) if w['chain']==chain)
        rejected.update(w['reason'] for w in row.get('rejected',[]) if w['chain']==chain)
        if chain in row.get('triggers',[]):
            reasons.update('event:'+x for x in row.get('events',[]))
            reasons.update('changed:'+x for x in row.get('changed_keys',[]))
        if chain=='c2_reflex' and row.get('reflex'): reflex.update([row['reflex']['kind']])
    calls = Counter(); recipes = Counter(); costs = defaultdict(int)
    starts = {r['invocation_id']:r for r in records if r['kind']=='invocation_start'}
    for row in tail:
        owner = row.get('owner_chain') or row.get('chain')
        if row['kind']=='invocation_start' and owner==chain:
            calls.update([row['component']])
            if row['component']=='recipe.prepare': recipes.update([row.get('field','unknown')])
        if row['kind']=='invocation_end':
            invocation = starts.get(row['invocation_id'],{})
            owner = invocation.get('owner_chain') or invocation.get('chain')
            if owner==chain: costs[row['component']] += row['exclusive_ns']
    latency = None
    if chain=='c1_prep' and unique_input:
        gates = [r for r in records if r['kind']=='native_preparation_gate']
        if gates:
            first = next((r for r in records if r['kind']=='execution' and r.get('status')=='returned'
                          and r['loop_tick']>=gates[0]['tick']),None)
            if first: latency = first['loop_tick']-gates[0]['tick']
    elif chain=='c5_replan' and unique_input:
        gates = [r for r in tail if r['kind']=='native_reselection_gate']
        if gates: latency = min(r['tick'] for r in gates)-start
    else:
        signals = [r for r in selected if ((r.get('reflex') or {}).get('kind') in ('stop','gripper_reference')
                   if chain=='c2_reflex' else any(w['chain']==chain for w in r.get('writes',[])))]
        if signals and unique_input: latency = min(r['tick'] for r in signals)-start
    permissions = permission_checks(records, selected, chain)
    write_permissions = permission_checks(records, selected, chain, actual_writes=True)
    full = [r for r in tail if r['kind']=='native_full_recompute_comparison']
    expected_source = sha256(json.dumps(read(directory/'source_manifest.json'),sort_keys=True,separators=(',',':')).encode()).hexdigest()
    identity = (result['case']==registration['case'] and expected_source==result['source_manifest_sha256']
                ==registration['source_manifest_sha256']==registration['test_gate']['source_manifest_sha256'])
    native = (result.get('evidence_level')=='V3_native_intervention' and result.get('status')=='completed'
              and result.get('source_unchanged') is True and result.get('step_audit_passed') is True and identity)
    valid_permission = all(p['permission_disposition_valid'] for p in permissions) if unique_input else None
    actual_writes_authorized = all(p['writer_authorized'] is True for p in write_permissions) if unique_input else None
    passed = bool(native and record.get('passed') is True and unique_input and valid_permission and actual_writes_authorized)
    scope = ('whole_episode_preparation' if chain=='c1_prep' else 'registered_input_through_finite_endpoint')
    if not unique_input:scope='no_unique_registered_input_no_response_window'
    return {'probe':probe,'chain':chain,'setting':case['setting'],'scope':scope,
        'conclusion':'通' if passed else '未通','passed':passed,'native_identity_and_source_bound':native,
        'input_name':event['name'] if event else None,'input_tick':start,'input_mode':event['mode'] if event else None,
        'registered_input_count':len(events),'registered_input_observed':unique_input,
        'input_status':'observed' if unique_input else ('missing' if not events else 'ambiguous'),
        'input_candidates':[{'name':e['name'],'tick':e['tick']} for e in events],
        'scope_trigger_count':trigger if unique_input else None,'episode_trigger_count':episode_trigger,
        'trigger_context_not_causal_proof':dict(reasons),'proposed_fields':dict(proposed),
        'proposal_permission_checks':permissions,
        'all_proposed_writes_authorized':all(p['writer_authorized'] is True for p in permissions) if unique_input else None,
        'all_proposal_dispositions_valid':valid_permission,
        'actual_write_permission_checks':write_permissions,'all_actual_chain_writes_authorized':actual_writes_authorized,
        'immutable_contract_default_nonwrites':[p['field'] for p in permissions if p['immutable_default_bound_without_chain_update']],
        'adopted_fields':dict(adopted),'reflex_overrides':dict(reflex),'rejection_reasons':dict(rejected),
        'response_decision_cycles':latency,'actual_recipe_calls_by_field':dict(recipes),
        'actual_owned_component_calls':dict(calls),
        'owned_exclusive_component_seconds':{n:v/1e9 for n,v in costs.items()},
        'owned_exclusive_seconds_total':sum(costs.values())/1e9 if costs else None,
        'full_record_recipe_calls':sum(r['recipe_calls'] for r in full) if full else None,
        'full_record_seconds':sum(r['seconds'] for r in full) if full else None,
        'shadow_only_extra_seconds':sum(r['seconds'] for r in full if r.get('adopted') is False) if full else None,
        'off_control_scope':('whole_chain' if probe=='relation' and case.get('relation_control_scope')=='whole_chain'
                             else 'parameter_readout_disabled_phase_progression_retained') if probe=='relation' and case['setting']=='off'
                            else ('max_reselections_zero' if probe=='reselection' and case['setting']=='off' else case['setting']),
        'native_steps':result['audited_env_steps'],'actual_model_calls':result['actual_model_calls'],
        'raw_sha256':digest(trace),'result_sha256':digest(directory/'result.json'),'directory':str(directory),
        'limits':['Context counts and decision cycles are not physical causal response latency.',
                  'Missing/ambiguous registered inputs have no designated response window, latency or window-permission verdict; episode activity does not fill this gap.',
                  'Actual recipe invocations are counted; parameter stamps are not recipe calls.',
                  'Supplemental shadow work is never C4 adoption; costs are not added twice.',
                  'C5 ends before next C1; load observation fault is not physical underload.']}

def write_document_table(records, output):
    """Exactly one row for each available single-control case; expose coverage."""
    rows = [summarize_case(record) for record in records]
    coverage = Counter((r['probe'],r['setting']) for r in rows)
    complete = set(coverage)==REQUIRED and all(v==1 for v in coverage.values())
    strict = bool(rows) and all(r['off_control_scope']=='whole_chain' for r in rows
                              if r['probe']=='relation' and r['setting']=='off')
    result = {'created_utc':datetime.now(timezone.utc).isoformat(),'rows':rows,'row_count':len(rows),
        'complete_twenty_case_coverage':complete,'strict_relation_off_present':('relation','off') in coverage and strict,
        'all_available_rows_passed':bool(rows) and all(r['passed'] for r in rows),
        'document_single_controls_passed':complete and strict and all(r['passed'] for r in rows),
        'whole_document_completed':False,'new_physical_steps':0,
        'scope':'Existing recorded native single controls only; no joint, new reproduction or task-rate claim.'}
    output = Path(output); output.mkdir(parents=True,exist_ok=True)
    with (output/'document_chain_validation.json').open('x',encoding='utf-8') as f:
        json.dump(result,f,ensure_ascii=False,indent=2)
    columns = [('chain','链路'),('probe','验证分支'),('setting','设置'),('scope_trigger_count','触发次数'),
        ('trigger_context_not_causal_proof','触发原因'),('proposed_fields','重算提议字段'),
        ('all_proposed_writes_authorized','提议均有链路写权'),('all_proposal_dispositions_valid','提议权限处理正确'),
        ('immutable_contract_default_nonwrites','只读默认绑定非链路写入'),
        ('all_actual_chain_writes_authorized','实际写入均有权限'),('adopted_fields','实际采纳字段'),
        ('reflex_overrides','实际反射覆盖'),('rejection_reasons','拒绝原因'),
        ('response_decision_cycles','响应拍数'),('owned_exclusive_seconds_total','组件排他耗时秒'),
        ('actual_recipe_calls_by_field','实际recipe调用次数'),('shadow_only_extra_seconds','额外影子计算秒'),
        ('conclusion','结论'),('scope','统计作用域'),('off_control_scope','关闭作用域'),('raw_sha256','原始日志SHA256')]
    with (output/'chain_validation.csv').open('x',encoding='utf-8-sig',newline='') as f:
        writer = csv.writer(f); writer.writerow([label for _,label in columns])
        for row in rows:
            writer.writerow([json.dumps(row[key],ensure_ascii=False) if isinstance(row[key],(dict,list))
                             else row[key] for key,_ in columns])
    return result
