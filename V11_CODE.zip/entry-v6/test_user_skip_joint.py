"""Protocol regression only; no native claims from these synthetic fixtures."""
from pathlib import Path
import gzip, tempfile, unittest
import reproduce_document_validation as subject

class SkipTests(unittest.TestCase):
    def protocol(self):
        return {'protocol':'user_authorized_skip_button_lowload','human_authorization_reference':'actual human skip',
                'case':{'probe':'joint','task':'SteamInMicrowave','setting':'normal',
                        'joint_scope':'user_skip_button_lowload_v1','skipped_requirements':['joint_button_lowload_same_tick']}}
    def test_explicit_skip_plan_preserves_joint(self):
        jobs=subject.plan_jobs(None,'joint',self.protocol())
        self.assertEqual(len(jobs),1)
        self.assertEqual(jobs[0]['stage'],'joint')
    def test_no_reference_or_broader_skip_is_rejected(self):
        p=self.protocol();p.pop('human_authorization_reference')
        with self.assertRaisesRegex(ValueError,'human authorization'):subject.plan_jobs(None,'joint',p)
        p=self.protocol();p['case']['skipped_requirements'].append('all_joint')
        with self.assertRaisesRegex(ValueError,'single-item skip'):subject.plan_jobs(None,'joint',p)
    def test_skip_does_not_pass_missing_remaining_joint_evidence(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            with gzip.open(p/'ticks.jsonl.gz','wt') as f:f.write('')
            verdict=subject.audit_joint(p,{'status':'pass','checks':{},'events':[]},self.protocol()['protocol'])
            self.assertFalse(verdict['passed'])
            self.assertEqual(verdict['skipped_requirements'],['joint_button_lowload_same_tick'])
            self.assertFalse(verdict['original_document_completed'])

if __name__=='__main__':unittest.main()
