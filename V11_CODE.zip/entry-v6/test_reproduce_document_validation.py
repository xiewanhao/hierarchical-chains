"""Orchestrator regressions; none of these fixtures are native evidence."""
from pathlib import Path
import importlib.util,json,os,tempfile,unittest
from unittest.mock import patch
import reproduce_document_validation as subject

SOURCE=Path(os.environ.get('HC_SOURCE_ROOT',str(Path(__file__).resolve().parents[1]/'improve_chain_native_validation_20261117_v10_literal_control')))


class ReproductionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.runtime=subject.load_runtime(SOURCE)

    def test_single_covers_twenty_real_named_controls(self):
        jobs=subject.plan_jobs(self.runtime,'single')
        self.assertEqual(len(jobs),20)
        self.assertEqual(len({j['id'] for j in jobs}),20)
        full=[j['case'] for j in jobs if j['case']['setting']=='full_recompute']
        self.assertEqual(len(full),6)
        self.assertTrue(all(c['full_recompute_mode']=='literal_flag' for c in full))

    def test_demand_uses_qualified_timing_and_same_inputs(self):
        jobs=subject.plan_jobs(self.runtime,'demand')
        self.assertEqual(len(jobs),10)
        for job in jobs:
            c=job['case'];self.assertEqual(c['post_window'],2)
            self.assertEqual(c['handoff_phase'],'lift' if c['demand_layer']==3 else 'carry_reached')
            self.assertEqual(c['input_mode'],'identical_raw_observation')
        self.assertEqual(sum(j['case'].get('reference_bound') is False for j in jobs),1)

    def test_whole_plan_refuses_implicit_joint_adaptation(self):
        with self.assertRaisesRegex(ValueError,'unanswered protocol'):subject.plan_jobs(self.runtime,'all')
        with self.assertRaisesRegex(ValueError,'human authorization'):
            subject.plan_jobs(self.runtime,'joint',{'protocol':'explicitly_authorized_adaptation'})

    def test_complete_plan_requires_real_steam_joint_case(self):
        with self.assertRaisesRegex(ValueError,'real normal Steam'):
            subject.plan_jobs(self.runtime,'joint',{'protocol':'strict_document','case':{'task':'HeatMug','probe':'joint','setting':'normal'}})
        plan=subject.plan_jobs(self.runtime,'all',{'protocol':'strict_document','case':{'task':'SteamInMicrowave','probe':'joint','setting':'normal'}})
        self.assertEqual(len(plan),31)

    def test_missing_or_hash_mismatched_test_logs_rejected(self):
        from five_chains.validation_protocol import manifest_digest,source_manifest
        with tempfile.TemporaryDirectory() as d:
            log=Path(d)/'tests.log';log.write_text('initial')
            gate={'source_manifest_sha256':manifest_digest(source_manifest(SOURCE)),
              'pytest_passed':True,'mypy_passed':True,'pytest_log':str(log),'mypy_log':str(log),
              'pytest_sha256':subject.digest(log),'mypy_sha256':subject.digest(log)}
            subject.verify_test_gate(SOURCE,gate)
            log.write_text('modified')
            with self.assertRaisesRegex(ValueError,'hash mismatch'):subject.verify_test_gate(SOURCE,gate)

    def test_bare_gate_a_boolean_not_enough(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'gate.json';p.write_text(json.dumps({'all_single_chains_passed':True}))
            with self.assertRaisesRegex(ValueError,'twenty-case'):subject.validate_gate_a(p,lambda _:None,SOURCE)

    def test_duplicate_native_case_cannot_fill_twenty_scopes(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'gate.json';p.write_text(json.dumps({'all_single_chains_passed':True,
              'cases':[{'directory':'/fake/copy'}]*20}))
            with self.assertRaisesRegex(ValueError,'distinct native'):subject.validate_gate_a(p,lambda _:None,SOURCE)

    def test_demand_empty_and_different_input_hashes_rejected(self):
        self.assertFalse(subject.audit_demand([])['passed'])
        records=[]
        for i,job in enumerate(subject.plan_jobs(self.runtime,'demand')):
            records.append({**job,'passed':True,'summary':{'case':job['case'],'demand_inputs':[{'input_sha256':'same'}]}})
        self.assertTrue(subject.audit_demand(records)['passed'])
        records[0]['summary']['demand_inputs'][0]['input_sha256']='different'
        self.assertFalse(subject.audit_demand(records)['passed'])

    def test_joint_without_actual_lowload_never_qualifies(self):
        import gzip
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            with gzip.open(p/'ticks.jsonl.gz','wt') as stream:stream.write('')
            result=subject.audit_joint(p,{'status':'pass','events':[],
              'checks':{'joint_actual_restore_before_timeout':True}},'strict_document')
            self.assertFalse(result['passed'])
            self.assertFalse(result['checks']['actual_fast_lowload_same_tick'])

    def test_post_input_video_requires_real_next_execution(self):
        record={'case':{'probe':'geometry'},'summary':{'events':[{'physical_step_index':10}]}}
        m={'frames':[{'physical_step_index':11},{'physical_step_index':12}]}
        self.assertEqual(subject.frame_scope(record,m)['scope'],'post_input_executed_frames')
        m['frames'][0]['physical_step_index']=10
        with self.assertRaisesRegex(ValueError,'first actual execution'):subject.frame_scope(record,m)

    def test_reselection_video_cannot_add_physics_after_event(self):
        record={'case':{'probe':'reselection'},'summary':{'events':[{'physical_step_index':10}]}}
        m={'frames':[{'physical_step_index':9},{'physical_step_index':10}]}
        self.assertEqual(subject.frame_scope(record,m)['scope'],'pre_timeout_executed_frames_then_same_state_decision')
        m['frames'][-1]['physical_step_index']=11
        with self.assertRaisesRegex(ValueError,'no added physics'):subject.frame_scope(record,m)


    def test_legacy_phase_only_relation_runtime_rejected(self):
        class Legacy:
            @staticmethod
            def cases(group):
                return [{'setting':'off','probe':'relation'}] if group=='steam_relation' else []
        with self.assertRaisesRegex(ValueError,'Whole relation-chain'):
            subject.plan_jobs(Legacy(),'single')

    def test_whole_chain_scope_not_inferred_from_empty_writes(self):
        self.assertFalse(all(subject.strict_relation_control(Path('/not/read'),{'probe':'relation','setting':'off'}).values()))

    def test_off_raw_c7_call_with_no_loop_tick_invalidates_gate(self):
        import gzip
        case={'probe':'relation','setting':'off','relation_control_scope':'whole_chain','post_window':24}
        rows=[{'kind':'native_control_boundary','chain':'c3b_fb_full','call_id':'held','control_scope':'whole_chain',
               'warmup_enabled':True,'disabled_from_registered_input':True,'phase_progression_enabled':False,
               'phase_only_no_parameter_update':False,'active_disabled_chains':['c3b_fb_full']}]
        for tick in range(24):
            rows.extend([{'kind':'tick','tick':tick,'call_id':'held','phase':'carry','triggers':[],'writes':[]},
                         {'kind':'execution','status':'returned','call_id':'held'}])
        with tempfile.TemporaryDirectory() as d:
            directory=Path(d)
            def write():
                with gzip.open(directory/'ticks.jsonl.gz','wt') as stream:
                    for row in rows:stream.write(json.dumps(row)+'\n')
            write();self.assertTrue(all(subject.strict_relation_control(directory,case).values()))
            rows.append({'kind':'invocation_start','component':'c7.update'})
            write();self.assertFalse(subject.strict_relation_control(directory,case)['no_phase_or_full_execution'])

    def test_whole_off_requires_all_twenty_four_returned_executions(self):
        import gzip
        case={'probe':'relation','setting':'off','relation_control_scope':'whole_chain','post_window':24}
        rows=[{'kind':'native_control_boundary','chain':'c3b_fb_full','call_id':'held','control_scope':'whole_chain',
               'warmup_enabled':True,'disabled_from_registered_input':True,'phase_progression_enabled':False,
               'phase_only_no_parameter_update':False,'active_disabled_chains':['c3b_fb_full']}]
        rows.extend({'kind':'tick','call_id':'held','phase':'carry','triggers':[],'writes':[]} for _ in range(24))
        rows.extend({'kind':'execution','status':'returned','call_id':'held'} for _ in range(23))
        with tempfile.TemporaryDirectory() as d:
            directory=Path(d)
            with gzip.open(directory/'ticks.jsonl.gz','wt') as stream:
                for row in rows:stream.write(json.dumps(row)+'\n')
            self.assertFalse(subject.strict_relation_control(directory,case)['complete_same_call_carry_executions'])


    def test_full_completion_requires_actual_complete_document_table_binding(self):
        stages={s:{'passed':True} for s in ('single','demand','joint')}
        args=['all',stages,{'passed':True},{'actual_joint_timeline':'present'},None,[{'passed':True}],[{}]]
        self.assertFalse(subject.whole_document_ready(*args,None))
        self.assertFalse(subject.whole_document_ready(*args,{'document_single_controls_passed':True}))
        bound={'document_single_controls_passed':True,'row_count':20,'complete_twenty_case_coverage':True,'csv_sha256':'csv','json_sha256':'json'}
        self.assertTrue(subject.whole_document_ready(*args,bound))
        bound['document_single_controls_passed']=False
        self.assertFalse(subject.whole_document_ready(*args,bound))

    def test_full_completion_cannot_override_an_invalid_native_record(self):
        stages={s:{'passed':True} for s in ('single','demand','joint')}
        bound={'document_single_controls_passed':True,'row_count':20,'complete_twenty_case_coverage':True,'csv_sha256':'csv','json_sha256':'json'}
        self.assertFalse(subject.whole_document_ready('all',stages,{'passed':True},{'timeline':True},None,[{'passed':False}],[{}],bound))


if __name__=='__main__':unittest.main()
