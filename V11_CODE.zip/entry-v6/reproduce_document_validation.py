"""Serial document-validation entry point around an unchanged native runtime.

Run through SOURCE_ROOT/scripts/remote_python.sh. --plan-only never starts a
simulator. A complete all-stage claim requires real single, demand and joint
evidence, all seven paired clips, and an executed joint timeline. Current V10
does not implement the requested joint low-load event; this runner cannot turn
its absence into a pass. No joint adaptation is authorized by this file.
"""
from __future__ import annotations
from pathlib import Path
from hashlib import sha256
from datetime import datetime,timezone
from collections import Counter
import argparse,csv,importlib.util,json,os,shutil,subprocess,sys,traceback

GROUPS=('heat_prep','heat_fast','heat_stop','heat_reselection','steam_load','steam_geometry','steam_relation')


def read(path):return json.loads(Path(path).read_text())
def digest(path):return sha256(Path(path).read_bytes()).hexdigest()
def save(path,value):
    with Path(path).open('x') as stream:json.dump(value,stream,indent=2)


def load_runtime(root):
    sys.path.insert(0,str(root))
    path=root/'scripts/run_native_chain_suite.py'
    spec=importlib.util.spec_from_file_location('document_native_cases',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def plan_jobs(runtime,stage,joint_case=None):
    jobs=[]
    if stage in ('single','all'):
        for group in GROUPS:
            for index,case in enumerate(runtime.cases(group)):
                if group=='steam_relation' and case.get('relation_control_scope')!='whole_chain':
                    raise ValueError('Whole relation-chain control required; phase-only legacy runtime is insufficient')
                jobs.append({'stage':'single','group':group,'id':f'{group}_{index:02d}_{case["setting"]}','case':case})
    if stage in ('demand','all'):
        for index,case in enumerate(runtime.cases('steam_demand')):
            case=dict(case)
            case['handoff_phase']='lift' if case['demand_layer']==3 else 'carry_reached'
            jobs.append({'stage':'demand','group':'steam_demand','id':f'demand_{index:02d}','case':case})
    if stage in ('joint','all'):
        if joint_case is None:raise ValueError('Complete joint registration is required; the unanswered protocol difference is not approval')
        if joint_case.get('protocol') not in ('strict_document','explicitly_authorized_adaptation','user_authorized_skip_button_lowload'):
            raise ValueError('Joint protocol must explicitly distinguish original wording from authorized adaptation')
        if joint_case['protocol'] in ('explicitly_authorized_adaptation','user_authorized_skip_button_lowload') and not joint_case.get('human_authorization_reference'):
            raise ValueError('No human authorization reference for joint adaptation')
        case=joint_case['case']
        if joint_case['protocol']=='user_authorized_skip_button_lowload' and (case.get('joint_scope')!='user_skip_button_lowload_v1' or case.get('skipped_requirements')!=['joint_button_lowload_same_tick']):
            raise ValueError('Explicit single-item skip scope required')
        if case.get('probe')!='joint' or case.get('task')!='SteamInMicrowave' or case.get('setting')!='normal':
            raise ValueError('Joint stage requires a real normal Steam joint case')
        jobs.append({'stage':'joint','group':'steam_joint','id':'steam_joint_00','case':case})
    return jobs


def verify_test_gate(root,gate):
    from five_chains.validation_protocol import source_manifest,manifest_digest
    source=manifest_digest(source_manifest(root))
    if gate.get('source_manifest_sha256')!=source or not gate.get('pytest_passed') or not gate.get('mypy_passed'):
        raise ValueError('Matching complete runtime tests and mypy are required')
    for key in ('pytest','mypy'):
        if digest(gate[key+'_log'])!=gate[key+'_sha256']:raise ValueError('Test log hash mismatch')
    return source


def strict_relation_control(directory,case):
    """Read actual returned executions and invocations after the disable boundary."""
    import gzip
    if case.get('relation_control_scope')!='whole_chain':
        return {'whole_relation_scope':False}
    checks={'whole_relation_scope':True}
    if case['setting']!='off':return checks
    with gzip.open(directory/'ticks.jsonl.gz','rt') as handle:rows=[json.loads(line) for line in handle]
    boundaries=[i for i,r in enumerate(rows) if r['kind']=='native_control_boundary' and r.get('chain')=='c3b_fb_full']
    checks['single_whole_disable_boundary']=len(boundaries)==1
    if len(boundaries)!=1:return checks
    tail=rows[boundaries[0]:];boundary=tail[0];call=boundary['call_id']
    ticks=[r for r in tail if r['kind']=='tick']
    executions=[r for r in tail if r['kind']=='execution' and r.get('status')=='returned']
    calls=[r for r in tail if r['kind']=='invocation_start']
    checks['actual_disable_configuration']=(boundary.get('control_scope')=='whole_chain' and
      boundary.get('warmup_enabled') is True and boundary.get('disabled_from_registered_input') is True and
      boundary.get('phase_progression_enabled') is False and boundary.get('phase_only_no_parameter_update') is False and
      'c3b_fb_full' in boundary.get('active_disabled_chains',[]))
    checks['complete_same_call_carry_executions']=(case.get('post_window')==24 and
      len(ticks)==len(executions)==24 and all(r.get('call_id')==call and r.get('phase')=='carry' for r in ticks) and
      all(r.get('call_id')==call for r in executions))
    checks['no_phase_or_full_execution']=not any(r.get('component') in ('c7.update','chain.c3b_fb_full') or
      (r.get('owner_chain') or r.get('chain'))=='c3b_fb_full' for r in calls)
    checks['no_full_trigger_or_write']=not any({'c3b_fb_full','c3b_phase_only'} & set(r.get('triggers',[])) or
      any(w['chain']=='c3b_fb_full' for w in r.get('writes',[])) for r in ticks)
    return checks


def independent_case(directory,summary):
    """Do not accept a boolean verdict without its native/source/model records."""
    from five_chains.validation_protocol import manifest_digest
    r=read(directory/'result.json');reg=read(directory/'registration.json')
    source=manifest_digest(read(directory/'source_manifest.json'))
    checks={
      'completed_native':r.get('evidence_level')=='V3_native_intervention' and r.get('status')=='completed',
      'source_registration':r['case']==reg['case'] and source==r['source_manifest_sha256']==reg['source_manifest_sha256']==reg['test_gate']['source_manifest_sha256'],
      'actual_model_IO':len(list((directory/'selector').glob('decision_*.input.json')))==len(list((directory/'selector').glob('decision_*.output.json')))==r['actual_model_calls'] and r['actual_model_calls']>0,
      'source_steps':r['source_unchanged'] is True and r['step_audit_passed'] is True,
      'serial_original_horizon':reg['workers']==1 and reg['wall_budget_seconds']==1200,
      'raw_verdict':summary['status']=='pass' and all(summary['checks'].values()),
    }
    if r['case']['setting']=='full_recompute':
        checks['literal_flag']=r['case'].get('full_recompute_mode')=='literal_flag' and summary['checks'].get('literal_full_flag_enabled_at_input') is True
        checks['measured_full_work']=bool(summary['full_recomputes']) and all(
            x['recipe_calls']>0 and x['seconds']>0 and x.get('literal_flag_value') is True for x in summary['full_recomputes'])
        if r['case']['probe']=='geometry':
            checks['actual_C4_all_field_adoption']=summary['checks'].get('actual_literal_C4_full_prepare_and_adoption') is True
    if r['case']['probe']=='relation':
        expected=[] if r['case']['setting']=='off' else ['place_pose']
        checks['exact_held_relation_scope']=bool(summary['relation']) and all(sorted(x['writes'])==expected for x in summary['relation'])
        checks.update(strict_relation_control(directory,r['case']))
    if r['case']['probe']=='geometry' and r['case']['setting']=='normal':
        import gzip
        event=next(e for e in summary['events'] if e['name']=='target_5cm')
        fields=None;frame=None
        with gzip.open(directory/'ticks.jsonl.gz','rt') as handle:
            for line in handle:
                row=json.loads(line)
                if row['kind']=='native_contract_fields' and row['call_id']==event['call_id']:fields=row['fields']
                if row['kind']=='contract_snapshot' and row.get('stage')=='initialize_entry' and row['contract']['call']['call_id']==event['call_id']:
                    fields=row['contract']['fields']
                if row['kind']=='tick' and row['tick']==event['tick']:frame=row;break
        affected={n for n,s in (fields or {}).items() if 'c4_vision' in s['writable_by'] and set(s['depends_on'])&set((frame or {}).get('changed_keys',[]))}
        proposed={n for p in (frame or {}).get('proposals',[]) if p['chain']=='c4_vision' for n in p['fields']}
        adopted={w['name'] for w in (frame or {}).get('writes',[]) if w['chain']=='c4_vision'}
        checks['exact_actual_affected_fields']=bool(fields and frame and affected) and proposed==adopted==affected
    return checks


def audit_demand(records):
    selected=[r for r in records if r['stage']=='demand'];proof={}
    for probe,count in [('demand_geometry',4),('demand_fast',3),('demand_tilt',3)]:
        cells=[r for r in selected if r['summary']['case']['probe']==probe]
        inputs=[i for r in cells for i in r['summary'].get('demand_inputs',[])]
        topology=sorted((r['summary']['case']['demand_layer'],r['summary']['case'].get('reference_bound',True)) for r in cells)
        expected=sorted([(3,True),(2,True),(1,True)]+([(1,False)] if count==4 else []))
        proof[probe]={'complete':len(cells)==len(inputs)==count and topology==expected and
            len({i['input_sha256'] for i in inputs})==1 and all(r['passed'] for r in cells),
            'input_hashes':sorted({i['input_sha256'] for i in inputs}),'cells':len(cells)}
    return {'passed':all(p['complete'] for p in proof.values()),'groups':proof}


def audit_joint(directory,summary,protocol):
    import gzip
    with gzip.open(directory/'ticks.jsonl.gz','rt') as handle:rows=[json.loads(line) for line in handle]
    ticks={r['tick']:r for r in rows if r['kind']=='tick'}
    events=summary['events']
    if protocol=='user_authorized_skip_button_lowload':
        stop_ticks={e['tick'] for e in events if e['name']=='unexpected_contact'}
        fast_ticks={e['tick'] for e in events if e['name']=='tracking_3cm'}
        call_skills={r['call_id']:r['skill'] for r in rows if r['kind']=='native_preparation_gate'}
        both=stop_ticks & fast_ticks
        checks={'all_other_native_joint_checks':summary['status']=='pass' and all(summary['checks'].values()),
            'explicit_amended_runtime_scope':summary['checks'].get('joint_amended_scope_explicit') is True,
            'actual_restore_before_timeout':summary['checks'].get('joint_actual_restore_before_timeout') is True,
            'fast_stop_same_tick':summary['checks'].get('joint_fast_and_stop_same_tick') is True,
            'actual_button_approach_contract':bool(both) and all(call_skills.get(ticks.get(t,{}).get('call_id'))=='approach_control' and ticks.get(t,{}).get('phase')=='approach' for t in both),
            'no_fabricated_lowload_event':not any(e['name']=='low_load_observation' for e in events),
            'all_chain_routes_observed':{'c1_prep','c2_reflex','c3a_fb_fast','c3b_fb_full','c4_vision'}<=set(c for r in ticks.values() for c in r.get('triggers',[])) and any(r['kind']=='reselection_requested' for r in rows)}
        return {'passed':all(checks.values()),'checks':checks,'skipped_requirements':['joint_button_lowload_same_tick'],
            'original_document_completed':False,'scope':'Human explicitly excluded button-stage lowload; all remaining joint requirements still mandatory.'}
    fast={e['tick'] for e in events if e['name']=='tracking_3cm'}
    load=[e for e in events if e['name']=='low_load_observation']
    same=[e for e in load if e['tick'] in fast]
    checks={'existing_joint_native_checks':summary['status']=='pass',
      'actual_fast_lowload_same_tick':bool(same) and all((ticks.get(e['tick'],{}).get('reflex') or {}).get('kind')=='gripper_reference' and e.get('gripper_load_band_n_before')==[1.,3.] for e in same),
      'native_load_response_present':bool(summary.get('gripper')),
      'restore_actually_executed':summary['checks'].get('joint_actual_restore_before_timeout') is True}
    if protocol=='strict_document':
        checks['original_button_approach_scope']=bool(same) and all(ticks.get(e['tick'],{}).get('phase')=='approach_control' for e in same)
    return {'passed':all(checks.values()),'checks':checks,
      'scope':'Missing load guard/data is a failed requirement, never fabricated permission.'}


def validate_gate_a(path,inspector,root):
    from five_chains.validation_protocol import source_manifest
    expected=source_manifest(root)
    core={n:h for n,h in expected.items() if n.startswith(('five_chains/components/','five_chains/chains/','five_chains/skills/'))}
    gate=read(path)
    if not gate.get('all_single_chains_passed') or len(gate.get('cases',[]))!=20:
        raise ValueError('Complete twenty-case Gate A required')
    if len({item['directory'] for item in gate['cases']})!=20:
        raise ValueError('Twenty distinct native cases required; duplicate paths cannot fill missing scopes')
    records=[]
    coverage=Counter();relation_sources=set()
    for item in gate['cases']:
        directory=Path(item['directory'])
        if not directory.is_absolute():
            anchor=gate.get('evidence_root')
            if not anchor:raise ValueError('Relative Gate A requires an explicit evidence_root')
            directory=Path(anchor)/directory
        if digest(directory/'ticks.jsonl.gz')!=item['raw_sha256'] or digest(directory/'result.json')!=item['result_sha256']:
            raise ValueError('Gate A raw/result bytes changed')
        summary=inspector(directory)
        if not all(independent_case(directory,summary).values()):raise ValueError('Gate A native case not valid now')
        actual=read(directory/'source_manifest.json')
        if not core or any(actual.get(n)!=h for n,h in core.items()):raise ValueError('Gate A uses different core components/recipes/templates')
        case=read(directory/'registration.json')['case'];coverage[(case['probe'],case['setting'])]+=1
        if case['probe']=='relation':relation_sources.add(read(directory/'result.json')['source_manifest_sha256'])
        records.append(item)
    required=Counter({('preparation',s):1 for s in ('normal','freeze_after_prep')})
    required.update({(probe,setting):1 for probe in ('fast','reflex_stop','reflex_gripper','relation','geometry','reselection')
                     for setting in ('normal','off','full_recompute')})
    if len(relation_sources)!=1:raise ValueError('Relation triplet must use one identical frozen source')
    if coverage!=required:raise ValueError('Gate A does not cover all preparation and six three-setting scopes')
    return records


def collect_tables(records,out):
    target=out/'chain_diagnostics.csv';header=None
    with target.open('x',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream)
        for entry in records:
            with (Path(entry['directory'])/'chain_table/chain_validation.csv').open(encoding='utf-8-sig',newline='') as handle:
                reader=csv.reader(handle);fields=next(reader)
                if header is None:header=fields;writer.writerow(['stage','case_id']+header)
                if fields!=header:raise ValueError('Chain table schema changed')
                for row in reader:writer.writerow([entry['stage'],entry['id']]+row)
    from document_table import write_document_table
    document_table=write_document_table([r for r in records if r['stage']=='single'],out)
    with (out/'native_cases.csv').open('x',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['stage','case_id','probe','setting','native_steps','reason','registered_pass'])
        for r in records:writer.writerow([r['stage'],r['id'],r['case']['probe'],r['case']['setting'],
          r['summary']['native_steps'],r['summary']['reason'],r['passed']])
    with (out/'demand_matrix.csv').open('x',encoding='utf-8-sig',newline='') as stream:
        writer=csv.writer(stream);writer.writerow(['probe','layer','reference','raw_input_sha256','C4_adopted_fields','fast_stiffness_adopted','registered_pass'])
        for r in records:
            if r['stage']!='demand':continue
            s=r['summary'];inputs=s.get('demand_inputs',[])
            fields=sorted({n for row in s['geometry'] for n in row['writes']})
            writer.writerow([r['case']['probe'],r['case']['demand_layer'],r['case'].get('reference'),
                inputs[0]['input_sha256'] if len(inputs)==1 else 'missing_or_ambiguous',json.dumps(fields),
                s['checks'].get('demand_tracking_actual_stiffness_adopted',s['checks'].get('demand_tilt_actual_stiffness_ownership')),r['passed']])


    return {'document_single_controls_passed':document_table['document_single_controls_passed'],
            'row_count':document_table['row_count'],
            'complete_twenty_case_coverage':document_table['complete_twenty_case_coverage'],
            'csv_sha256':digest(out/'chain_validation.csv'),
            'json_sha256':digest(out/'document_chain_validation.json')}


def collect_tables_guarded(records,out):
    try:return collect_tables(records,out),None
    except Exception as exc:return None,{'error':repr(exc),'traceback':traceback.format_exc()}


def whole_document_ready(stage,stages,media,timeline,error,records,jobs,document_table):
    return bool(stage=='all' and all(stages.get(s,{}).get('passed') for s in ('single','demand','joint'))
        and media.get('passed') and timeline and error is None and len(records)==len(jobs)
        and all(r['passed'] for r in records) and document_table
        and document_table.get('document_single_controls_passed')
        and document_table.get('row_count')==20 and document_table.get('complete_twenty_case_coverage')
        and document_table.get('csv_sha256') and document_table.get('json_sha256'))


def frame_scope(record,manifest):
    """Associate real frames with the registered input without invented motion."""
    events=record['summary']['events']
    if len(events)!=1 or not manifest['frames']:raise ValueError('One registered single-chain input and real frames required')
    physical=events[0]['physical_step_index']
    first=manifest['frames'][0]['physical_step_index'];last=manifest['frames'][-1]['physical_step_index']
    if record['case']['probe']=='reselection':
        if last!=physical:raise ValueError('Reselection clip must end at the input physical state with no added physics')
        scope='pre_timeout_executed_frames_then_same_state_decision'
    else:
        if first!=physical+1:raise ValueError('Post-input clip must start after the first actual execution')
        scope='post_input_executed_frames'
    return {'scope':scope,'input_physical_step':physical,'first_frame_step':first,'last_frame_step':last}


def paired_media(records,out):
    """Original post-execute frames only; no interpolation or extra simulation."""
    from five_chains.validation_media import verified_frames
    import numpy as np
    output=out/'paired_media';output.mkdir(exist_ok=False)
    records=[r for r in records if r['stage']=='single'];clips=[];errors=[]
    ffmpeg=shutil.which('ffmpeg')
    if ffmpeg is None:
        try:
            import imageio_ffmpeg
            ffmpeg=imageio_ffmpeg.get_ffmpeg_exe()
        except ImportError:return {'passed':False,'clips':[],'errors':['ffmpeg unavailable; frames preserved']}
    for group in GROUPS:
        try:
            left=next(r for r in records if r['group']==group and r['case']['setting']=='normal')
            setting='freeze_after_prep' if group=='heat_prep' else 'off'
            right=next(r for r in records if r['group']==group and r['case']['setting']==setting)
            a=Path(left['directory'])/'frames/frames.json';b=Path(right['directory'])/'frames/frames.json'
            av,bv=verified_frames(a),verified_frames(b)
            normalize=lambda v:{k:x for k,x in v['case'].items() if k not in ('setting','record_video')}
            if normalize(av)!=normalize(bv) or av['source_manifest_sha256']!=bv['source_manifest_sha256']:
                raise ValueError('Paired case/source identity mismatch')
            scopes=[frame_scope(r,m) for r,m in [(left,av),(right,bv)]]
            if any(len(m['frames'])!=24 or not np.allclose(np.diff([f['simulation_time_s'] for f in m['frames']]),.05,atol=1e-8,rtol=0) for m in (av,bv)):
                raise ValueError('Original twenty-Hz complete24-frame windows required')
            clip=output/(group+'_normal_'+setting+'.mp4')
            command=[ffmpeg,'-n','-threads','1','-framerate','20','-start_number',str(av['frames'][0]['physical_step_index']),
                '-i',str(a.parent/'frame_%06d.png'),'-threads','1','-framerate','20','-start_number',str(bv['frames'][0]['physical_step_index']),
                '-i',str(b.parent/'frame_%06d.png'),'-filter_complex_threads','1','-filter_complex','[0:v][1:v]hstack=inputs=2:shortest=1',
                '-frames:v','24','-c:v','libx264','-threads','1','-pix_fmt','yuv420p',str(clip)]
            with (output/(group+'.encode.log')).open('x') as log:subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,check=True)
            check=subprocess.run([ffmpeg,'-v','error','-threads','1','-i',str(clip),'-progress','pipe:1','-nostats','-f','null','-'],capture_output=True,text=True,check=True)
            frames=[int(line.split('=',1)[1]) for line in check.stdout.splitlines() if line.startswith('frame=')]
            if not frames or frames[-1]!=24:raise ValueError('Decoded video does not contain the actual24-frame window')
            alignment={'left':'normal','right':setting,'source_manifest_sha256':av['source_manifest_sha256'],
                'left_manifest_sha256':digest(a),'right_manifest_sha256':digest(b),'frame_scopes':scopes,
                'frames':24,'fps':20,'decoded_frame_count_verified':frames[-1],
                'no_interpolation':True,'no_simulator_or_GPU':True,'video_sha256':digest(clip),
                'warmup_trajectories_may_differ_not_strict_dynamic_causal_evidence':True,'encode_command':command}
            save(clip.with_suffix('.alignment.json'),alignment)
            clips.append({'group':group,'video':str(clip),'sha256':digest(clip),
                          'alignment':str(clip.with_suffix('.alignment.json'))})
        except Exception as exc:errors.append({'group':group,'error':repr(exc)})
    return {'passed':len(clips)==len(GROUPS) and not errors,'clips':clips,'errors':errors}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--source-root',type=Path,default=os.environ.get('HC_SOURCE_ROOT'))
    p.add_argument('--test-gate',type=Path);p.add_argument('--gate-a',type=Path)
    p.add_argument('--joint-registration',type=Path);p.add_argument('--output',type=Path)
    p.add_argument('--stage',choices=['single','demand','joint','all'],default='all')
    p.add_argument('--plan-only',action='store_true');args=p.parse_args()
    if args.source_root is None:raise ValueError('Set HC_SOURCE_ROOT or --source-root')
    root=args.source_root.resolve();runtime=load_runtime(root)
    joint=read(args.joint_registration) if args.joint_registration else None
    jobs=plan_jobs(runtime,args.stage,joint)
    if args.plan_only:
        print(json.dumps({'jobs':jobs,'no_simulator_started':True,'whole_document_completed':False},indent=2));return
    if args.output is None or args.test_gate is None:raise ValueError('--output and --test-gate required')
    from five_chains.native_validation_summary import inspect_native
    from five_chains.chain_summary import summarize,write_outputs
    from five_chains.validation_protocol import verify_legacy_files
    gate=read(args.test_gate);source=verify_test_gate(root,gate)
    legacy=Path(os.environ['HC_LEGACY_ROOT']);verify_legacy_files(root/'configs/protected_legacy.json',legacy)
    if args.stage in ('demand','joint'):
        if args.gate_a is None:raise ValueError('--gate-a is required before demand/joint')
        validate_gate_a(args.gate_a,inspect_native,root)
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name)==os.getpid():continue
        try:parts=(proc/'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if any(x.endswith((b'/run_native_chain_episode.py',b'/run_native_chain_suite.py',b'/run_registered_demand_v9_attempt2.py')) for x in parts):
            raise RuntimeError('Existing native driver/worker active; do not compete or restart')
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    registrations=out/'registration';registrations.mkdir()
    stamp=datetime.now(timezone.utc).isoformat()
    for job in jobs:
        reg={'schema':'native_chain_case/v1','created_utc':stamp,'case':job['case'],
             'source_manifest_sha256':source,'workers':1,'wall_budget_seconds':1200,'test_gate':gate,
             'intervention_scope':'Document reproduction; original native controller and success preserved; no task-rate claim'}
        save(registrations/(job['id']+'.json'),reg)
    save(out/'plan.json',{'source_manifest_sha256':source,'jobs':jobs,'created_utc':stamp,'joint_protocol':joint,
                         'orchestrator_sha256':digest(Path(__file__))})
    records=[];stages={};error=None;media={'passed':False,'reason':'not_run'};timeline=None;document_table=None
    try:
        for job in jobs:
            if job['stage']!='single' and args.stage=='all' and not stages.get('single',{}).get('passed'):
                single=[r for r in records if r['stage']=='single']
                stages['single']={'passed':len(single)==20 and all(r['passed'] for r in single)}
                save(out/'gate_a.json',{'all_single_chains_passed':stages['single']['passed'],
                    'evidence_root':str(out),'cases':[{'directory':r['directory'],'raw_sha256':digest(Path(r['directory'])/'ticks.jsonl.gz'),
                      'result_sha256':digest(Path(r['directory'])/'result.json')} for r in single]})
                if not stages['single']['passed']:raise RuntimeError('Gate A failed; no demand/joint launched')
            destination=out/job['stage']/job['id'];destination.parent.mkdir(exist_ok=True)
            cmd=['bash',str(root/'scripts/remote_python.sh'),str(root/'scripts/run_native_chain_episode.py'),
                 '--registration',str(registrations/(job['id']+'.json')),'--output',str(destination)]
            with (out/(job['id']+'.log')).open('x') as log:
                proc=subprocess.Popen(cmd,cwd=root,env=os.environ,stdout=log,stderr=subprocess.STDOUT)
                raw=Path(f'/proc/{proc.pid}/stat').read_text()
                receipt={'pid':proc.pid,'start_ticks':raw[raw.rfind(')')+2:].split()[19],
                    'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'directory':str(destination),'command':cmd}
                save(out/(job['id']+'_process.json'),receipt);status=proc.wait()
            summary=inspect_native(destination);save(destination/'validation_summary.json',summary)
            extra=independent_case(destination,summary)
            table=summarize(destination/'ticks.jsonl.gz','V3_native_intervention',summary['native_steps'])
            table['case_assertions']=summary['checks'];table['status']='PASS' if all(extra.values()) and table['trace_complete'] else 'FAIL'
            write_outputs(table,destination/'chain_table')
            record={**job,'directory':str(destination),'summary':summary,'independent_checks':extra,'passed':all(extra.values()) and table['trace_complete']}
            records.append(record);save(out/(job['id']+'_outcome.json'),record)
            if status:raise RuntimeError('Worker runtime/integrity failure; evidence retained')
        single=[r for r in records if r['stage']=='single']
        if single:stages['single']={'passed':len(single)==20 and all(r['passed'] for r in single)}
        if single and not (out/'gate_a.json').exists():
            save(out/'gate_a.json',{'all_single_chains_passed':stages['single']['passed'],
                'evidence_root':str(out),'cases':[{'directory':r['directory'],'raw_sha256':digest(Path(r['directory'])/'ticks.jsonl.gz'),
                  'result_sha256':digest(Path(r['directory'])/'result.json')} for r in single]})
        if any(r['stage']=='demand' for r in records):stages['demand']=audit_demand(records)
        if any(r['stage']=='joint' for r in records):
            record=next(r for r in records if r['stage']=='joint')
            stages['joint']=audit_joint(Path(record['directory']),record['summary'],joint['protocol'])
            for suffix in ('json','html'):
                original=Path(record['directory'])/('chain_table/timeline.'+suffix)
                shutil.copyfile(original,out/('joint_timeline.'+suffix))
            timeline={'json_sha256':digest(out/'joint_timeline.json'),'html_sha256':digest(out/'joint_timeline.html')}
        if single:media=paired_media(records,out)
    except Exception as exc:error={'error':repr(exc),'traceback':traceback.format_exc()}
    finally:
        finalization_error=None
        if records:
            document_table,finalization_error=collect_tables_guarded(records,out)
            if finalization_error is not None and error is None:error=finalization_error
        completed=args.stage=='all' and all(stages.get(s,{}).get('passed') for s in ('single','demand','joint'))
        result={'stages':stages,'error':error,'finalization_error':finalization_error,'completed_cases':len(records),'planned_cases':len(jobs),
                'all_native_stages_passed':bool(completed),'paired_media':media,'joint_timeline':timeline,'document_table':document_table,
                'requested_scope_completed':whole_document_ready(args.stage,stages,media,timeline,error,records,jobs,document_table),
                'completion_scope':joint['protocol'] if joint else 'partial_stage',
                'skipped_requirements':joint['case'].get('skipped_requirements',[]) if joint else [],
                'whole_document_completed':bool(joint and joint['protocol']=='strict_document' and whole_document_ready(args.stage,stages,media,timeline,error,records,jobs,document_table)),
                'scope':'Native chain behavior, not task rate or continuous safety'}
        save(out/'pipeline_result.json',result)
    print(json.dumps(result),flush=True)
    requested_pass=result['requested_scope_completed'] if args.stage=='all' else stages.get(args.stage,{}).get('passed',False)
    if args.stage=='single':requested_pass=bool(requested_pass and document_table and document_table['document_single_controls_passed'])
    if error or not all(r['passed'] for r in records) or not requested_pass:raise SystemExit(1)


if __name__=='__main__':main()
