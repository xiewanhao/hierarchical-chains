"""Reporting regressions; synthetic traces are never native evidence."""
from pathlib import Path
from unittest.mock import patch
import json,tempfile,unittest
import test_document_table
import document_table as table
import reproduce_document_validation as entry

class IncompleteReportingTests(unittest.TestCase):
    def native_claim_fixture(self,directory):
        helper=test_document_table.DocumentTableTests();record,rows=helper.fixture(directory)
        result=json.loads((directory/'result.json').read_text())
        result['evidence_level']='V3_native_intervention'
        (directory/'result.json').write_text(json.dumps(result))
        return helper,record,rows

    def test_missing_input_does_not_pass_or_invent_response_from_episode_activity(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d);helper,record,rows=self.native_claim_fixture(path)
            helper.write(path,[r for r in rows if r['kind']!='perturbation'])
            result=table.summarize_case(record)
            self.assertTrue(result['native_identity_and_source_bound'])
            self.assertFalse(result['passed'])
            self.assertEqual(result['input_status'],'missing')
            self.assertEqual(result['episode_trigger_count'],1)
            for key in ['input_tick','scope_trigger_count','response_decision_cycles','all_actual_chain_writes_authorized']:
                self.assertIsNone(result[key])
            output=path/'report';value=table.write_document_table([record],output)
            self.assertEqual(value['row_count'],1)
            self.assertFalse(value['document_single_controls_passed'])
            self.assertTrue((output/'chain_validation.csv').is_file())

    def test_multiple_inputs_are_ambiguous_not_implicitly_first_input(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d);helper,record,rows=self.native_claim_fixture(path)
            rows.append({'kind':'perturbation','tick':11,'name':'second','mode':'synthetic'})
            helper.write(path,rows);result=table.summarize_case(record)
            self.assertEqual(result['registered_input_count'],2)
            self.assertEqual(result['input_status'],'ambiguous')
            self.assertFalse(result['passed'])
            self.assertIsNone(result['input_tick'])
            self.assertIsNone(result['response_decision_cycles'])

    def test_preparation_episode_activity_cannot_replace_absent_validation_input(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d);helper=test_document_table.DocumentTableTests()
            record,rows=helper.fixture(path,probe='preparation')
            helper.write(path,[r for r in rows if r['kind']!='perturbation'])
            result=table.summarize_case(record)
            self.assertFalse(result['passed'])
            self.assertIsNone(result['response_decision_cycles'])
            self.assertEqual(result['episode_trigger_count'],1)

    def test_table_exception_returns_structured_failure(self):
        with patch.object(entry,'collect_tables',side_effect=ValueError('bad recorded input')):
            table_result,error=entry.collect_tables_guarded([],Path('unused'))
        self.assertIsNone(table_result)
        self.assertIn('bad recorded input',error['error'])
        self.assertIn('ValueError',error['traceback'])

    def test_guard_preserves_successful_table_verdict_exactly(self):
        expected={'document_single_controls_passed':False,'row_count':20}
        with patch.object(entry,'collect_tables',return_value=expected):
            result,error=entry.collect_tables_guarded([],Path('unused'))
        self.assertIs(result,expected)
        self.assertIsNone(error)

if __name__=='__main__':unittest.main()
