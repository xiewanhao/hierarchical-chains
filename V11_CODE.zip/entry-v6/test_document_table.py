"""Synthetic log/schema regressions only; these are never native evidence."""
from pathlib import Path
from hashlib import sha256
from unittest.mock import patch
import csv, gzip, json, tempfile, unittest
import document_table as subject
import reproduce_document_validation as entry

class DocumentTableTests(unittest.TestCase):
    def fixture(self,directory,probe='fast',authorized=True):
        chain = subject.CHAINS[probe]
        case = {'probe':probe,'setting':'normal'}
        source = sha256(b'{}').hexdigest()
        result = {'case':case,'status':'completed','evidence_level':'V0_component_fixture',
                  'source_unchanged':True,'step_audit_passed':True,'source_manifest_sha256':source,
                  'audited_env_steps':1,'actual_model_calls':0}
        registration = {'case':case,'source_manifest_sha256':source,'test_gate':{'source_manifest_sha256':source}}
        for name,value in [('result.json',result),('registration.json',registration),('source_manifest.json',{})]:
            (directory/name).write_text(json.dumps(value))
        rows = [{'kind':'native_contract_fields','call_id':'call','fields':{
                  'stiffness_scale':{'writable_by':[chain] if authorized else []}}},
                {'kind':'perturbation','tick':10,'event_id':'input','name':'test','mode':'synthetic'},
                {'kind':'invocation_start','invocation_id':'recipe','component':'recipe.prepare','owner_chain':chain,'field':'stiffness_scale'},
                {'kind':'invocation_end','invocation_id':'recipe','component':'recipe.prepare','exclusive_ns':12},
                {'kind':'tick','tick':10,'call_id':'call','phase':'carry','triggers':[chain],
                 'events':['input'],'changed_keys':['test.pose'],
                 'proposals':[{'chain':chain,'fields':['stiffness_scale']}],
                 'writes':[{'chain':chain,'name':'stiffness_scale'}],'rejected':[]}]
        self.write(directory,rows)
        return {'directory':str(directory),'passed':True,'stage':'single','id':'synthetic','case':case,
                'summary':{'native_steps':1,'reason':'fixture'}},rows

    def write(self,directory,rows):
        with gzip.open(directory/'ticks.jsonl.gz','wt') as stream:
            for row in rows: stream.write(json.dumps(row)+'\n')

    def test_unauthorized_proposal_and_fixture_never_pass(self):
        with tempfile.TemporaryDirectory() as d:
            record,_ = self.fixture(Path(d),authorized=False)
            result = subject.summarize_case(record)
            self.assertFalse(result['all_proposed_writes_authorized'])
            self.assertFalse(result['native_identity_and_source_bound'])
            self.assertEqual(result['conclusion'],'未通')

    def test_missing_contract_stays_unknown(self):
        rows = [{'kind':'tick','tick':1,'call_id':'call','proposals':[{'chain':'c4_vision','fields':['place_pose']}]}]
        proof = subject.permission_checks(rows,rows,'c4_vision')
        self.assertIsNone(proof[0]['writer_authorized'])
        self.assertFalse(proof[0]['contract_present'])

    def default_binding_rows(self):
        return [{'kind':'native_contract_fields','call_id':'call','fields':{'speed_limit':{
                    'writable_by':[],'recipe':None,'default':.08,'kind':'scalar','unit':'m/s','frame_entity':None}}},
                {'kind':'arbitration','call_id':'call','loop_tick':0,'chain':'c1_prep','field':'speed_limit',
                    'permission':False,'decision':'bound_default_not_update'},
                {'kind':'action_prepared','call_id':'call','loop_tick':0,'parameters':{'speed_limit':{
                    'value':.08,'kind':'scalar','unit':'m/s','frame_entity':None,'stamp':-1}}},
                {'kind':'tick','tick':0,'call_id':'call','proposals':[{'chain':'c1_prep','fields':['speed_limit']}],'writes':[]}]

    def test_default_binding_stays_unwritable_and_does_not_count_as_chain_update(self):
        rows = self.default_binding_rows()
        proof = subject.permission_checks(rows,[rows[-1]],'c1_prep')[0]
        self.assertFalse(proof['writer_authorized'])
        self.assertTrue(proof['immutable_default_bound_without_chain_update'])
        self.assertTrue(proof['permission_disposition_valid'])

    def test_default_exception_requires_actual_packet_default_value_and_original_stamp(self):
        for field,value in [('value',.09),('stamp',0)]:
            rows = self.default_binding_rows(); rows[2]['parameters']['speed_limit'][field] = value
            self.assertFalse(subject.permission_checks(rows,[rows[-1]],'c1_prep')[0]['permission_disposition_valid'])

    def test_readonly_default_may_never_be_an_actual_chain_write(self):
        rows = self.default_binding_rows(); rows[-1]['writes'] = [{'chain':'c1_prep','name':'speed_limit'}]
        proof = subject.permission_checks(rows,[rows[-1]],'c1_prep',actual_writes=True)[0]
        self.assertFalse(proof['permission_disposition_valid'])
        self.assertFalse(proof['immutable_default_bound_without_chain_update'])

    def test_future_contract_cannot_authorize_past_proposal(self):
        tick = {'kind':'tick','tick':1,'call_id':'call','proposals':[{'chain':'c4_vision','fields':['place_pose']}]}
        rows = [tick,{'kind':'native_contract_fields','call_id':'call','fields':{'place_pose':{'writable_by':['c4_vision']}}}]
        self.assertIsNone(subject.permission_checks(rows,[tick],'c4_vision')[0]['writer_authorized'])

    def test_counts_actual_recipe_calls_not_stamp_changes(self):
        with tempfile.TemporaryDirectory() as d:
            record,rows = self.fixture(Path(d))
            rows.append({'kind':'unrelated_parameter_stamp','stamp':999})
            self.write(Path(d),rows)
            result = subject.summarize_case(record)
            self.assertEqual(result['actual_recipe_calls_by_field'],{'stiffness_scale':1})
            self.assertEqual(result['owned_exclusive_seconds_total'],12e-9)

    def test_c5_without_loop_tick_counted_by_record_order(self):
        with tempfile.TemporaryDirectory() as d:
            record,rows = self.fixture(Path(d),'reselection')
            rows.extend([{'kind':'reselection_requested'},
                         {'kind':'native_reselection_gate','tick':12}])
            self.write(Path(d),rows)
            result = subject.summarize_case(record)
            self.assertEqual(result['scope_trigger_count'],1)
            self.assertEqual(result['response_decision_cycles'],2)

    def test_incomplete_table_has_no_complete_verdict(self):
        with tempfile.TemporaryDirectory() as d:
            result = subject.write_document_table([],Path(d))
            self.assertFalse(result['complete_twenty_case_coverage'])
            self.assertFalse(result['document_single_controls_passed'])
            self.assertFalse(result['whole_document_completed'])

    def test_entry_emits_single_target_row_and_preserves_all_chain_diagnostics(self):
        with tempfile.TemporaryDirectory() as d:
            base = Path(d); source = base/'case'; source.mkdir()
            record,_ = self.fixture(source)
            diagnostics = source/'chain_table'; diagnostics.mkdir()
            with (diagnostics/'chain_validation.csv').open('w',newline='') as f:
                writer = csv.writer(f); writer.writerow(['chain'])
                for chain in subject.CHAINS.values(): writer.writerow([chain])
            output = base/'out'; output.mkdir()
            entry.collect_tables([record],output)
            with (output/'chain_validation.csv').open(encoding='utf-8-sig') as f: actual=list(csv.reader(f))
            with (output/'chain_diagnostics.csv').open(encoding='utf-8-sig') as f: all_chains=list(csv.reader(f))
            self.assertEqual(len(actual),2)
            self.assertEqual(len(all_chains),8)
            self.assertFalse(json.loads((output/'document_chain_validation.json').read_text())['document_single_controls_passed'])

if __name__=='__main__': unittest.main()
