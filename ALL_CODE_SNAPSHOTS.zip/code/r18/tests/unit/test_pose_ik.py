import numpy as np
import pytest
import mujoco
from five_chains.envs.pose_ik import RobotPoseIK
from five_chains.geometry import pose


def test_robot_only_ik_uses_proprioception_and_preserves_model_and_input(cfg):
    model=mujoco.MjModel.from_xml_string('''<mujoco><worldbody><body><inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <joint name="x" type="slide" axis="1 0 0" range="-1 1"/><joint name="y" type="slide" axis="0 1 0" range="-1 1"/>
      <joint name="z" type="slide" axis="0 0 1" range="-1 1"/><site name="tip"/></body>
      <body><freejoint/><inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/></body></worldbody></mujoco>''')
    qpos=model.qpos0.copy();qpos[:3]=[.1,0,.2];qpos[3]=5.
    saved=qpos.copy();model_saved=model.qpos0.copy()
    solver=RobotPoseIK(model,0,np.array([0,1,2]),np.array([0,1,2]),np.zeros(3),cfg['control']['posture_ik'])
    result=solver.solve(pose([.2,.3,.4]),qpos)
    assert result.success and np.allclose(result.joints,[.2,.3,.4],atol=1e-4)
    assert np.array_equal(qpos,saved) and np.array_equal(model.qpos0,model_saved)
    assert solver.data.qpos[3]==model.qpos0[3]  # Unrelated object state was never an IK input.
    unreachable=solver.solve(pose([3,0,0]),qpos)
    assert not unreachable.success and not unreachable.collision_checked


def test_posture_guide_is_only_called_for_unoverridden_arm_motion(C,world):
    from five_chains.types import SkillCall,ReflexOverride
    from five_chains.chains.c1_prep import chain1_prep
    c,_,p7,proposal=chain1_prep(SkillCall('p',1,'local_pose_servo',{'reference':'world'}),world,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    calls=[]
    C.c10.adapter.prepare_posture=lambda target,state,key,*bounds:calls.append((target.copy(),state,key))
    C.c10.solve(packet,c,p7,world,None)
    assert len(calls)==1 and calls[0][2]==('p',p7.phase_index)
    C.c10.solve(packet,c,p7,world,ReflexOverride('hold',None,'test'))
    assert len(calls)==1


def test_approximate_nullspace_reference_does_not_claim_exact_ik_and_is_bounded(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    adapter.posture_solver=N(solve=lambda *a:IKResult(False,(.6,.6,.6),.005,.1,1))
    adapter.posture_key=None;adapter.posture_goal=None;adapter.posture_solution=None;adapter.posture_diagnostic={}
    adapter.controller=N(initial_joint=np.zeros(3))
    world=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    adapter.prepare_posture(pose([0,0,0]),world,('a',0))
    assert adapter.posture_diagnostic['reference_kind']=='approximate'
    assert adapter.posture_diagnostic['success'] is False
    assert np.allclose(adapter.controller.initial_joint,cfg['control']['posture_ik']['max_reference_step_rad'])
    adapter.posture_solver=N(solve=lambda *a:IKResult(False,(.6,.6,.6),.05,.3,1))
    prior=adapter.controller.initial_joint.copy()
    adapter.prepare_posture(pose([0,0,0]),world,('b',0))
    assert adapter.posture_diagnostic['reference_kind']=='rejected'
    assert np.array_equal(prior,adapter.controller.initial_joint)


def test_orientation_projection_respects_nominal_region_and_fixed_tilt(C,world):
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import orientation_command
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    nominal=pose([.2,0,1]);candidate=pose([.2,0,1],Rotation.from_euler('x',.1).as_matrix())
    assert orientation_command(nominal,candidate,.15,np.eye(4),.17) is not None
    assert orientation_command(nominal,candidate,.05) is None
    assert orientation_command(nominal,candidate,.15,np.eye(4),.08) is None
    assert orientation_command(nominal,pose([.21,0,1]),.15) is None
    c,_,p7,proposal=chain1_prep(SkillCall('projection',1,'local_pose_servo',{'reference':'world'}),world,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    C.c10.adapter.prepare_posture=lambda target,*args:pose(target[:3,3],Rotation.from_euler('x',.1).as_matrix()@target[:3,:3])
    original=packet.params[c.phases[p7.phase_index].target_field].value.copy()
    C.c10.solve(packet,c,p7,world,None)
    assert np.allclose(C.c10.last_target,original)  # Termination still uses the nominal goal.
    assert np.array_equal(packet.params[c.phases[p7.phase_index].target_field].value,original)


def test_forward_projection_keeps_nominal_position_and_existing_bounds():
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import forward_command
    nominal=pose([.2,0,1]);forward=pose([.202,0,1],Rotation.from_euler('x',.14).as_matrix())
    allowed=forward_command(nominal,forward,.004,.15)
    assert allowed is not None and np.array_equal(allowed[:3,3],nominal[:3,3])
    assert forward_command(nominal,forward,.001,.15) is None
    assert forward_command(nominal,forward,.004,.13) is None
    assert forward_command(nominal,forward,.004,.15,np.eye(4),.10) is None


def test_failed_second_solve_can_certify_fk_without_claiming_solver_success(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    cfg['control']['posture_ik']['orientation_projection']=True
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    results=iter([IKResult(False,(.1,.1,.1),.007,.1,1),IKResult(False,(.2,.2,.2),.002,.036,1)])
    adapter.posture_solver=N(qpos=np.arange(3),solve=lambda *args:next(results),
        forward=lambda q,j:pose([.002,0,0],Rotation.from_euler('x',.14 if j[0]>.15 else .10).as_matrix()))
    adapter.posture_key=None;adapter.posture_goal=None;adapter.posture_solution=None;adapter.posture_diagnostic={}
    adapter.controller=N(initial_joint=np.zeros(3))
    world=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    command=adapter.prepare_posture(np.eye(4),world,('a',0))
    assert np.linalg.norm(Rotation.from_matrix(command[:3,:3]).as_rotvec())<.15
    assert np.array_equal(command[:3,3],np.zeros(3))
    assert adapter.posture_diagnostic['success'] is False
    assert adapter.posture_diagnostic['projected_ik']['success'] is False
    assert adapter.posture_diagnostic['forward_validated']['position_error_m']<=.004


def test_base_origin_change_invalidates_world_target_posture_cache(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    calls=[]
    adapter.posture_solver=N(solve=lambda *args:calls.append(1) or IKResult(True,(.1,.1,.1),0.,0.,1))
    adapter.posture_key=None;adapter.posture_goal=None;adapter.posture_solution=None;adapter.posture_diagnostic={}
    adapter.controller=N(initial_joint=np.zeros(3))
    world=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    adapter.prepare_posture(np.eye(4),world,('a',0));adapter.prepare_posture(np.eye(4),world,('a',0))
    assert len(calls)==1
    moved=replace(world,base_pose_world=pose([.02,0,0]))
    adapter.prepare_posture(np.eye(4),moved,('a',0))
    assert len(calls)==2
    before=adapter.controller.initial_joint.copy()
    assert adapter.pose_reachable(np.eye(4),moved)
    assert np.array_equal(before,adapter.controller.initial_joint)
    adapter.posture_solver=N(solve=lambda *args:IKResult(False,(.1,.1,.1),.005,.1,1))
    assert not adapter.pose_reachable(np.eye(4),moved)


def test_planned_waypoints_never_replace_packet_or_termination_goal(C,world):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    C.c10.config['control']['posture_ik']['path_planning']['enabled']=True
    c,_,p7,prop=chain1_prep(SkillCall('plan',1,'local_pose_servo',{'reference':'bowl'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    goal=packet.params['local_target'].value.copy();waypoint=world.eef_pose_world.copy();waypoint[1,3]+=.1
    C.c10.adapter.prepare_motion_path=lambda *args:waypoint.copy()
    C.c10.solve(packet,c,p7,world,None)
    assert np.array_equal(C.c10.last_target,goal)
    assert np.array_equal(packet.params['local_target'].value,goal)
    assert C.c10.reference[1,3]>world.eef_pose_world[1,3]


def test_position_only_motion_does_not_replan_as_free_orientation_changes(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from scipy.spatial.transform import Rotation
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    a=object.__new__(RoboCasaAdapter);a.config=cfg
    q=np.zeros(3);goal=pose([.2,0,1.]);key=('route',0)
    a.posture_solver=N(qpos=np.arange(3))
    a.motion_scene=N(forward=lambda joints:goal.copy())
    a.motion_goal=goal.copy();a.motion_origin=world.base_pose_world.copy();a.motion_key=key;a.motion_stamp=0
    a.motion_path=(q,np.ones(3)*.1);a.motion_index=1;a.posture_diagnostic={};a.controller=N(initial_joint=q.copy())
    current=pose([.2,0,1.],Rotation.from_euler('x',.4).as_matrix())
    w=replace(world,eef_pose_world=current,signals={'robot_kinematic_qpos':q})
    target=current.copy();saved=target.copy()
    result=a.prepare_motion_path(target,w,key,None,None,None,True)
    assert np.array_equal(target,saved)
    assert np.array_equal(result,goal) and np.array_equal(a.motion_goal,goal)


def test_position_ik_can_succeed_with_unconstrained_attitude_and_reports_it(cfg):
    from scipy.spatial.transform import Rotation
    model=mujoco.MjModel.from_xml_string('''<mujoco><worldbody><body>
      <inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <joint type="slide" axis="1 0 0" range="-1 1"/><joint type="slide" axis="0 1 0" range="-1 1"/>
      <joint type="slide" axis="0 0 1" range="-1 1"/><site/></body></worldbody></mujoco>''')
    solver=RobotPoseIK(model,0,np.arange(3),np.arange(3),np.zeros(3),cfg['control']['posture_ik'])
    target=pose([.2,.3,.4],Rotation.from_euler('z',1.).as_matrix())
    assert not solver.solve(target,model.qpos0).success
    result=solver.solve(target,model.qpos0,position_only=True)
    assert result.success and not result.orientation_constrained
    assert result.orientation_error_rad>.9 and result.position_error_m<.004


def test_bounded_attitude_probes_preserve_nominal_position_and_input():
    from five_chains.envs.pose_ik import bounded_pose_targets
    from five_chains.geometry import rotation_distance
    target=pose([.2,.3,.4]);saved=target.copy();probes=bounded_pose_targets(target,.12)
    assert len(probes)==7 and np.array_equal(target,saved)
    for probe in probes:
        assert np.array_equal(probe[:3,3],target[:3,3])
        assert rotation_distance(probe[:3,:3],target[:3,:3])<=.12+1e-10


def test_internal_joint_margin_preserves_native_ranges_live_input_and_strict_goal(cfg):
    from copy import deepcopy
    model=mujoco.MjModel.from_xml_string('''<mujoco><compiler angle="radian"/><worldbody><body>
      <inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <joint type="hinge" axis="0 0 1" range="-1 1"/><site pos="1 0 0"/>
      </body></worldbody></mujoco>''')
    conf=deepcopy(cfg['control']['posture_ik']);conf['joint_margin_rad']=.015
    q=np.array([1.00002]);saved=q.copy();bounds=model.jnt_range.copy();initial=model.qpos0.copy()
    solver=RobotPoseIK(model,0,np.array([0]),np.array([0]),np.zeros(1),conf)
    goal=solver.forward(q,(.98,))
    good=solver.solve(goal,q)
    assert good.success and good.joints[0]<=.985+1e-9
    assert good.position_error_m<conf['position_tolerance_m']
    assert good.orientation_error_rad<conf['rotation_tolerance_rad']
    # A target at the physical hard limit is no longer silently admitted as an
    # interior IK goal; the original residual criterion remains decisive.
    edge=solver.solve(solver.forward(q,(1.,)),q)
    assert not edge.success and edge.position_error_m>=conf['position_tolerance_m']
    assert np.array_equal(q,saved) and np.array_equal(model.jnt_range,bounds)
    assert np.array_equal(model.qpos0,initial)


@pytest.mark.parametrize('case',['admitted','position','angle','tilt'])
def test_successful_ik_command_uses_independently_bounded_fk_orientation(cfg,world,case):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    from five_chains.geometry import rotation_distance
    cfg['control']['posture_ik']['orientation_projection']=True
    a=object.__new__(RoboCasaAdapter);a.config=cfg
    target=pose([.2,.3,.4]);saved=target.copy()
    angle=.2 if case=='angle' else .02
    fk=pose([.2+(.01 if case=='position' else .001),.3,.4],Rotation.from_euler('y',angle).as_matrix())
    a.posture_solver=N(solve=lambda *args:IKResult(True,(.1,.2,.3),.001,.02,1),forward=lambda *args:fk.copy())
    a.posture_key=None;a.posture_goal=None;a.posture_solution=None;a.posture_diagnostic={}
    a.controller=N(initial_joint=np.zeros(3))
    w=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    command=a.prepare_posture(target,w,('grasp',4),np.eye(4) if case=='tilt' else None,.01 if case=='tilt' else None)
    assert np.array_equal(target,saved) and np.array_equal(command[:3,3],target[:3,3])
    assert np.max(np.abs(a.controller.initial_joint))<=cfg['control']['posture_ik']['max_reference_step_rad']+1e-12
    if case=='admitted':
        assert np.isclose(rotation_distance(command[:3,:3],target[:3,:3]),.02)
        assert a.posture_diagnostic['successful_ik_forward_command']['nominal_position_retained']
    else:
        assert np.array_equal(command,target)
        assert 'successful_ik_forward_command' not in a.posture_diagnostic


def test_arm_joint_sample_copies_measured_values_and_native_bounds(cfg):
    from types import SimpleNamespace as N
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    a=object.__new__(RoboCasaAdapter)
    q=np.arange(10,dtype=float);vel=np.arange(10,dtype=float)+.1;ranges=np.tile([-3.,3.],(10,1));ref=np.arange(7,dtype=float)
    model=N(jnt_dofadr=np.arange(10),jnt_range=ranges)
    a.env=N(sim=N(data=N(qpos=q,qvel=vel),model=N(_model=model)))
    a.posture_solver=N(joints=np.arange(3,10),qpos=np.arange(2,9));a.controller=N(initial_joint=ref)
    sample=a.arm_joint_state()
    assert np.array_equal(sample['positions_rad'],q[2:9])
    assert np.array_equal(sample['velocities_rad_s'],vel[3:10])
    sample['positions_rad'][:]=0;sample['native_ranges_rad'][:]=0;sample['nullspace_reference_rad'][:]=0
    assert np.array_equal(q,np.arange(10)) and np.all(ranges==np.tile([-3.,3.],(10,1)))
    assert np.array_equal(ref,np.arange(7))
    a.posture_solver=None;assert a.arm_joint_state()=={}
