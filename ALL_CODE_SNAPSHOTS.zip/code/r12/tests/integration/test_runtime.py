from dataclasses import asdict
import inspect
import json
from pathlib import Path
import numpy as np
import pytest
from five_chains.config import load_config
from five_chains.build import build_components
from five_chains.runtime import run_episode
from five_chains.trace import Tracer
from five_chains.components.c11_selector import ScriptedSelector, parse_call
from five_chains.envs.kinematic_testbed import KinematicTestbed


def test_all_five_decisions_and_l4_three_children(tmp_path):
    cfg=load_config(Path(__file__).resolve().parents[2]/"configs/steam_in_microwave.yaml")
    cfg['control']['max_ticks']=3000
    env=KinematicTestbed(cfg)
    selector=ScriptedSelector([parse_call(x) for x in cfg['scripted_calls']])
    trace=Tracer(tmp_path/'ticks.jsonl')
    C=build_components(env,selector,cfg,trace)
    original=env.step
    callers=[]
    def audited(action):
        callers.append(inspect.stack()[1].function)
        return original(action)
    env.step=audited
    result=run_episode(env,'contract_fixture',C,cfg,trace)
    trace.close(result)
    assert result.success,asdict(result)
    assert result.selector_calls==5
    assert result.prep_calls==7
    assert env.executions==result.ticks==len(callers)
    assert set(callers)=={'execute'}
    rows=[json.loads(line) for line in (tmp_path/'ticks.jsonl').read_text().splitlines()]
    ticks=[r for r in rows if r['kind']=='tick']
    assert len(ticks)==result.ticks
    assert len({r['call_id'] for r in ticks})==7
    assert 'c6.prepare' in rows[-1]['costs']


@pytest.mark.parametrize('switch',['freeze','disable_vision','full_recompute','reflex'])
def test_ablation_switches_end_cleanly(cfg,tmp_path,switch):
    from five_chains.types import SkillCall
    cfg['control']['max_ticks']=20
    if switch=='freeze': cfg['ablation']['freeze_after_prep']=True
    if switch=='disable_vision': cfg['ablation']['disable_chains']=['c4_vision']
    if switch=='full_recompute': cfg['ablation']['vision_full_recompute']=True
    if switch=='reflex': cfg['reflex']['enabled']=True
    env=KinematicTestbed(cfg)
    call=SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})
    C=build_components(env,ScriptedSelector([call]),cfg)
    trace=Tracer(tmp_path/'ticks.jsonl')
    result=run_episode(env,'fixture',C,cfg,trace)
    trace.close(result)
    assert result.ticks==20
    assert not result.success
    assert env.executions==20


@pytest.mark.parametrize('switch',['baseline','freeze','disable_vision','disable_fast','disable_full','full_recompute','reflex','disable_reflex'])
def test_ablation_switches_with_forced_inputs(cfg,tmp_path,switch):
    from copy import deepcopy
    from five_chains.types import SkillCall
    cfg['control']['max_ticks']=12
    if switch=='freeze':cfg['ablation']['freeze_after_prep']=True
    if switch.startswith('disable_'):
        cfg['ablation']['disable_chains']=[{'vision':'c4_vision','fast':'c3a_fb_fast','full':'c3b_fb_full','reflex':'c2_reflex'}[switch[8:]]]
    cfg['ablation']['vision_full_recompute']=switch=='full_recompute'
    cfg['reflex']['enabled']=switch in ('reflex','disable_reflex')
    env=KinematicTestbed(cfg)
    call=SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})
    C=build_components(env,ScriptedSelector([call]),cfg)
    trace=Tracer(tmp_path/'ticks.jsonl')
    def perturb(tick,obs,ctx,components):
        if tick!=5:return obs
        env.state['entities']['bowl']['pose_world'][0,3]+=.03
        obs=env.observe({})
        obs['state']['signals']['continuous']['tilt_dev']=.2
        obs['state']['signals']['predicates']['test_event']=True
        obs['state']['signals']['unexpected_contact']=True
        return obs
    result=run_episode(env,'forced_ablation_fixture',C,cfg,trace,perturb);trace.close(result)
    rows=[json.loads(x) for x in (tmp_path/'ticks.jsonl').read_text().splitlines()]
    ticks=[r for r in rows if r['kind']=='tick'];r=ticks[5]
    assert result.ticks==12 and env.executions==12
    assert 'bowl.pose' in r['changed_keys'] and 'test_event' in r['events']
    triggers=set(r['triggers'])
    assert ('c4_vision' in triggers)==(switch not in ('freeze','disable_vision'))
    assert ('c3a_fb_fast' in triggers)==(switch not in ('freeze','disable_fast'))
    assert ('c3b_fb_full' in triggers)==(switch not in ('freeze','disable_full'))
    assert ('c2_reflex' in triggers)==(switch=='reflex')
    if switch=='freeze':
        assert r['parameters']==ticks[0]['parameters'] and not r['writes']
    if switch=='full_recompute':
        assert all(p['stamp']==5 for p in r['preparation_provenance'].values())
        assert {w['name'] for w in r['writes'] if w['chain']=='c4_vision'}=={'local_target'}
        assert r['phase']=='track' and result.prep_calls==1
    elif switch in ('baseline','disable_fast','disable_full'):
        assert r['preparation_provenance']['speed_limit']['stamp']==0


def test_selector_exhaustion_is_logged_failure_without_extra_physics(cfg,tmp_path):
    from five_chains.types import SkillCall
    cfg['control']['max_ticks']=200
    env=KinematicTestbed(cfg);selector=ScriptedSelector([SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})])
    trace=Tracer(tmp_path/'ticks.jsonl');C=build_components(env,selector,cfg,trace)
    result=run_episode(env,'incomplete_task',C,cfg,trace);trace.close(result)
    rows=[json.loads(x) for x in (tmp_path/'ticks.jsonl').read_text().splitlines()]
    assert not result.success and result.reason.startswith('selector_failure:')
    assert result.selector_calls==2 and result.prep_calls==1
    assert result.ticks==env.executions==sum(r['kind']=='tick' for r in rows)<200
    assert len([r for r in rows if r['kind']=='failure'])==1


def test_unavailable_motion_path_ends_via_c5_without_a_physics_step(cfg,tmp_path):
    from five_chains.types import SkillCall
    cfg['control']['posture_ik']['path_planning']['enabled']=True
    env=KinematicTestbed(cfg)
    def blocked(*args):
        env.motion_failure='no_clear_goal'
        return args[1].eef_pose_world.copy()
    env.prepare_motion_path=blocked
    C=build_components(env,ScriptedSelector([SkillCall('local',1,'local_pose_servo',{'reference':'bowl'})]),cfg)
    trace=Tracer(tmp_path/'ticks.jsonl');result=run_episode(env,'fixture',C,cfg,trace);trace.close(result)
    assert not result.success and result.reason=='controller_failure:motion_path:no_clear_goal'
    assert result.ticks==env.executions==C.c10.executions==0
    records=[json.loads(l) for l in (tmp_path/'ticks.jsonl').read_text().splitlines()]
    assert any(r['kind']=='failure' for r in records) and any(r['kind']=='controller_failure' for r in records)


def test_c5_reselects_from_same_state_discards_failed_packet_and_reports_failure(cfg,tmp_path):
    from five_chains.types import SkillCall
    cfg['replan']={'max_reselections':1};cfg['control']['max_ticks']=20
    cfg['control']['posture_ik']['path_planning']['enabled']=True
    env=KinematicTestbed(cfg);observed=[];resets=[]
    reset=env.reset
    def audited_reset(value):resets.append(True);return reset(value)
    env.reset=audited_reset
    class Selector:
        def select(self,task,obs,history):
            observed.append((obs['state']['signals'].copy(),list(history),env.executions))
            return SkillCall('decision_'+str(len(observed)),1,'local_pose_servo',{'reference':'bowl'})
    def planned(target,world,key,*args):
        env.motion_failure='no_clear_goal' if key[0]=='decision_1' else None
        return target
    env.prepare_motion_path=planned;env.success=lambda:env.executions>=2
    trace=Tracer(tmp_path/'replan.jsonl');C=build_components(env,Selector(),cfg,trace)
    result=run_episode(env,'fixture',C,cfg,trace);trace.close(result)
    assert result.success and len(resets)==1 and env.executions==2
    assert len(observed)==2 and observed[1][2]==0
    assert observed[1][0]['failure_feedback'][0]['status']=='failed'
    assert observed[1][1]==[]  # Failure must never be serialized as completion.
    records=[json.loads(x) for x in (tmp_path/'replan.jsonl').read_text().splitlines()]
    assert sum(r['kind']=='reselection_requested' for r in records)==1
    assert {r['call_id'] for r in records if r['kind']=='tick'}=={'decision_2'}
