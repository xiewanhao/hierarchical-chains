from dataclasses import replace
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.types import SkillCall
from five_chains.geometry import pose
from five_chains.chains.c1_prep import chain1_prep


def test_combined_roll_pitch_obeys_true_tilt_cone(C,world):
    C.c10.config["base"]["assist_during_carry"]=False
    world=replace(world,signals={'grasp_transforms':{'bowl':np.eye(4)}})
    auxiliary=SkillCall('upright',2,'maintain_container_attitude',{'object':'bowl'})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'},(auxiliary,))
    c,p6,p7,prop=chain1_prep(call,world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    index=next(i for i,p in enumerate(c.phases) if p.name=='carry')
    p7=replace(p7,phase_index=index,phase_name='carry')
    rotation=Rotation.from_euler('xy',[.15,.15]).as_matrix()
    target=replace(packet.params['place_pose'],value=pose([.4,0,1.],rotation))
    packet=replace(packet,params={**packet.params,'place_pose':target})
    C.c10.solve(packet,c,p7,world,None)
    up=C.c10.last_target[:3,2]
    assert np.arccos(np.clip(up[2],-1,1)) <= .15+1e-10
