from copy import deepcopy
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose, inverse
from five_chains.components.c04_state import StateGeometry
from conftest import observation


def test_reference_roundtrip(C, world):
    t = pose([.4, -.2, 1], Rotation.from_euler("z", .7).as_matrix())
    assert np.allclose(C.c4.from_frame(C.c4.to_frame(t, "bowl", world), "bowl", world), t)


def test_object_and_gripper_targets_noncommuting():
    wm = pose([1, 2, 3], Rotation.from_euler("z", np.pi/2).as_matrix())
    mb = pose([.2, 0, .1])
    eb = pose([0, 0, .15], Rotation.from_euler("x", np.pi).as_matrix())
    wb = wm @ mb
    assert np.allclose(wb[:3, 3], [1, 2.2, 3.1])
    we = wb @ inverse(eb)
    assert np.allclose(we @ eb, wb)


def test_cumulative_drift_triggers_against_last_report(cfg):
    c4 = StateGeometry(cfg["state"])
    obs = observation()
    c4.update(obs)
    obs["state"]["entities"]["bowl"]["pose_world"][0,3] += .003
    assert "bowl.pose" not in c4.update(obs).changed_keys
    obs["state"]["entities"]["bowl"]["pose_world"][0,3] += .003
    assert "bowl.pose" in c4.update(obs).changed_keys


def test_noise_delay_does_not_delay_proprioception(cfg):
    cfg["state"]["backend"] = "noisy"
    c4 = StateGeometry(cfg["state"])
    obs = observation()
    a = c4.update(obs)
    obs["state"]["entities"]["bowl"]["pose_world"][0,3] += .1
    obs["state"]["eef_pose_world"][0,3] += .1
    b = c4.update(obs)
    assert np.array_equal(a.entities["bowl"].pose_world, b.entities["bowl"].pose_world)
    assert a.entities['bowl'].stamp == b.entities['bowl'].stamp
    assert not np.array_equal(a.eef_pose_world, b.eef_pose_world)
    assert not np.array_equal(c4.update(obs).entities["bowl"].pose_world, b.entities["bowl"].pose_world)


def test_position_command_changes_translation_and_preserves_attitude():
    from five_chains.geometry import motion_target
    from five_chains.types import PhysParam,FieldKind,ChainId
    frame=pose([1,2,3],Rotation.from_euler('z',np.pi/2).as_matrix())
    reference=pose([0,0,0],Rotation.from_euler('x',.7).as_matrix())
    parameter=PhysParam('target',FieldKind.POSITION,np.array([.1,0,.2]),'m','fixture',ChainId.PREP,0)
    goal=motion_target(parameter,frame,reference)
    assert np.allclose(goal[:3,3],[1,2.1,3.2])
    assert np.array_equal(goal[:3,:3],reference[:3,:3])


def test_extent_change_has_its_own_geometry_key(cfg):
    from conftest import observation
    from five_chains.components.c04_state import StateGeometry
    c4=StateGeometry(cfg['state']);obs=observation();c4.update(obs)
    obs['state']['entities']['bowl']['extent'][0]+=.02
    world=c4.update(obs)
    assert world.changed_keys==frozenset({'bowl.extent'})
