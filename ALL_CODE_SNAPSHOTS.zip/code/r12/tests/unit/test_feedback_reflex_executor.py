from dataclasses import replace
import inspect
from pathlib import Path
import numpy as np
from five_chains.types import ReflexBounds, FeedbackDelta
from five_chains.components.c05_feedback import FeedbackEncoder
from five_chains.components.c09_reflex import ReflexLayer
from five_chains.chains.c5_replan import chain5_replan


def test_feedback_is_edge_triggered(world):
    c5=FeedbackEncoder()
    w=replace(world,signals={"predicates":{"grasp_established":True}})
    assert c5.encode({},w,None,None).events == ("grasp_established",)
    assert c5.encode({},w,w,None).events == ()
    dropped=replace(world,signals={"predicates":{"grasp_established":False}})
    assert c5.encode({},dropped,w,None).events == ("grasp_lost",)
    assert c5.encode({},dropped,dropped,"reflex_stop").events == ("reflex_stop",)


def test_reflex_bounded_and_disabled():
    b=ReflexBounds(.003,.03,10,True)
    obs={"force_world":[100,100,0]}
    assert ReflexLayer(False).step(b,obs) is None
    v=ReflexLayer(True).step(b,obs)
    assert np.linalg.norm(v.delta_pose[:3,3]) <= .003+1e-15
    assert np.dot(v.delta_pose[:3,3],obs["force_world"]) < 0
    assert ReflexLayer(True).step(b,{"unexpected_contact":True}).kind == "stop"


def test_only_executor_contains_step_call():
    root=Path(__file__).resolve().parents[2]/"five_chains"
    import ast
    callers=[]
    for path in root.rglob("*.py"):
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.Call) and isinstance(node.func,ast.Attribute) and node.func.attr=="step" and isinstance(node.func.value,ast.Name) and node.func.value.id=="env":
                callers.append(path.name)
    assert callers == ["c10_executor.py"]


def test_failure_hook_never_selects(C,call,world):
    class Trace:
        def log_failure(self,cid,reason): self.record=(cid,reason)
    trace=Trace()
    assert chain5_replan(C.c12.expand(call),world,"failed",trace) is None
    assert trace.record == (call.call_id,"failed")


def test_hinge_contact_keeps_attained_posture_instead_of_switching_ik_branch(C,world):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    from dataclasses import replace
    world=replace(world,signals={**world.signals,'surface_normals':{'handle':[0.,-1.,0.]},
        'microwave_hinge':{'angle':-.5,'axis_world':[0.,0.,1.],'anchor_world':[.4,.2,1.]}})
    phases=[]
    C.adapter.prepare_contact_posture=lambda world,key:phases.append(key)
    def unexpected(*args):raise AssertionError('contact must not invoke unconstrained IK')
    C.adapter.prepare_posture=unexpected
    call=SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'})
    contract,_,p7,proposal=chain1_prep(call,world,C)
    packet,_=C.c10.arbitrate(None,[proposal],contract,C.c12)
    for name in ('close','settle_door'):
        index=next(i for i,p in enumerate(contract.phases) if p.name==name)
        C.c10.solve(packet,contract,replace(p7,phase_index=index,phase_name=name),world,None)
    assert len(phases)==2
