from types import SimpleNamespace as N
import numpy as np
from five_chains.envs.multitask_adapter import MultiTaskAdapter


def test_native_placement_uses_unmodified_fixture_predicate(monkeypatch):
    from robocasa.utils import object_utils as OU
    adapter=MultiTaskAdapter.__new__(MultiTaskAdapter);fixture=N();calls=[]
    adapter.env=N(objects={'obj':N()},microwave=fixture);adapter.region_fixtures={}
    monkeypatch.setattr(OU,'obj_inside_of',lambda env,obj,where:calls.append((env,obj,where)) or False)
    assert adapter.placement_satisfied('obj','microwave_interior') is False
    assert calls==[(adapter.env,'obj',fixture)]
    assert adapter.placement_satisfied('missing','microwave_interior') is False


def test_selector_context_binds_entities_without_a_teacher_skill_plan(tmp_path):
    adapter=MultiTaskAdapter.__new__(MultiTaskAdapter);adapter.task_name='PrepareCoffee'
    adapter.config={'environment':{'selector_camera':'camera'}}
    adapter.env=N(objects={'obj':N(),'distr_cab':N()},get_obj_lang=lambda n:'mug' if n=='obj' else 'book',
        sim=N(render=lambda **kw:np.zeros((256,256,3),dtype=np.uint8)))
    obs={'state':{'entities':{'obj':{},'coffee_pouring':{},'start':{}},'signals':{'predicates':{'button_pressed':False}}}}
    sample=adapter.selector_sample('prepare coffee',obs,[],tmp_path/'camera.png');context=sample['call_context']
    assert context['binding_options']=={'object':['obj'],'target':['coffee_pouring']}
    assert context['bindings']=={'reference':'coffee_pouring','appliance':'coffee_machine','control':'start'}
    assert not any(k in context for k in ('task_goals','next_call','expected','teacher_action','goal_order'))
    assert context['goal_window']==[] and sample['completed_goals']==[]
