from types import SimpleNamespace as N
from dataclasses import replace
import numpy as np
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.geometry import pose
from five_chains.types import SkillCall,FeedbackDelta
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.c3_feedback import chain3b_full


def test_loaded_grasp_requires_lift_detachment_stability_and_later_never_rebases(cfg):
    cfg['grasp']['loaded_acquisition']['enabled']=True
    cfg['grasp']['loaded_acquisition']['stable_frames']=3
    a=object.__new__(RoboCasaAdapter);a.config=cfg;a.arm='right'
    position=np.array([.1,0,1.]);supported=[True]
    data=N(time=0.,get_body_xpos=lambda name:position.copy(),get_body_xmat=lambda name:np.eye(3))
    support=object()
    a.env=N(_check_grasp=lambda *args:True,check_contact=lambda first,second:supported[0] if second is support else True,
            sim=N(data=data),counter=support)
    a.robot=N(gripper={'right':N(important_geoms={'left_finger':['l'],'right_finger':['r']})})
    for name in ('grasp_transforms','grasp_origins','grasp_contact_counts','grasp_gap_counts','grasp_evidence_times',
                 'grasp_load_origins','grasp_load_relations','grasp_load_stable_counts'):setattr(a,name,{})
    a.gripper_command='close';a.phase_ticks=30
    a.context=(N(call=N(bindings={'object':'bowl'}),fields={}),N(phase_name='grasp'),np.eye(4),0.)
    item=N(root_body='bowl',contact_geoms=['bowl_geom']);eef=pose([0,0,1.])
    assert not a._estimate_grasp('bowl',item,eef)[0]
    position[2]+=.02;data.time+=.05
    assert not a._estimate_grasp('bowl',item,eef)[0]  # Height alone is insufficient.
    supported[0]=False
    for i in range(3):
        data.time+=.05;held,evidence=a._estimate_grasp('bowl',item,eef)
        assert held==(i==2)
        before=a.grasp_load_stable_counts['bowl'];a._estimate_grasp('bowl',item,eef)
        assert a.grasp_load_stable_counts['bowl']==before
    assert evidence['support_clear'] and evidence['load_height_m']>=.01
    reference=a.grasp_transforms['bowl'].copy()
    a.context=(a.context[0],N(phase_name='lift'),np.eye(4),0.)
    data.time+=.05;position[0]+=.03
    assert not a._estimate_grasp('bowl',item,eef)[0]
    assert 'bowl' not in a.grasp_transforms
    data.time+=.05
    assert not a._estimate_grasp('bowl',item,eef)[0]  # Cannot relatch in transport.


def test_preload_is_world_fixed_and_prepared_once_on_grasp_entry(C,world):
    world=replace(world,signals={'loaded_grasp_enabled':True})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})
    c,p6,p7,prop=chain1_prep(call,world,C)
    idx=next(i for i,p in enumerate(c.phases) if p.name=='descend')
    p7=replace(p7,phase_index=idx,phase_name='descend')
    moved=replace(world,eef_pose_world=pose([.4,.2,.8]),stamp=1)
    p6,p7,update=chain3b_full(c,p6,p7,moved,FeedbackDelta(1,('reached',),{}),C)
    assert p7.phase_name=='grasp' and c.phases[p7.phase_index].target_field=='preload_pose'
    assert np.allclose(update.updates['preload_pose'].value[:3,3],[.4,.2,.84])
    later=replace(moved,eef_pose_world=pose([.4,.2,.82]),stamp=2)
    after,_,again=chain3b_full(c,p6,p7,later,FeedbackDelta(2,('unrelated',),{}),C)
    assert again is None and after.fields['preload_pose'] is p6.fields['preload_pose']
