import numpy as np
import mujoco
from five_chains.envs.pose_ik import RobotPoseIK
from five_chains.geometry import pose


def test_robot_only_ik_uses_proprioception_and_preserves_model_and_input(cfg):
    model=mujoco.MjModel.from_xml_string('''<mujoco><worldbody><body><inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <joint name="x" type="slide" axis="1 0 0" range="-1 1"/><joint name="y" type="slide" axis="0 1 0" range="-1 1"/>
      <joint name="z" type="slide" axis="0 0 1" range="-1 1"/><site name="tip"/></body>
      <body><freejoint/><inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/></body></worldbody></mujoco>''')
    qpos=model.qpos0.copy();qpos[:3]=[.1,0,.2];qpos[3]=5.
    saved=qpos.copy();model_saved=model.qpos0.copy()
    solver=RobotPoseIK(model,0,np.array([0,1,2]),np.array([0,1,2]),np.zeros(3),cfg['control']['posture_ik'])
    result=solver.solve(pose([.2,.3,.4]),qpos)
    assert result.success and np.allclose(result.joints,[.2,.3,.4],atol=1e-4)
    assert np.array_equal(qpos,saved) and np.array_equal(model.qpos0,model_saved)
    assert solver.data.qpos[3]==model.qpos0[3]  # Unrelated object state was never an IK input.
    unreachable=solver.solve(pose([3,0,0]),qpos)
    assert not unreachable.success and not unreachable.collision_checked


def test_posture_guide_is_only_called_for_unoverridden_arm_motion(C,world):
    from five_chains.types import SkillCall,ReflexOverride
    from five_chains.chains.c1_prep import chain1_prep
    c,_,p7,proposal=chain1_prep(SkillCall('p',1,'local_pose_servo',{'reference':'world'}),world,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    calls=[]
    C.c10.adapter.prepare_posture=lambda target,state,key,*bounds:calls.append((target.copy(),state,key))
    C.c10.solve(packet,c,p7,world,None)
    assert len(calls)==1 and calls[0][2]==('p',p7.phase_index)
    C.c10.solve(packet,c,p7,world,ReflexOverride('hold',None,'test'))
    assert len(calls)==1


def test_approximate_nullspace_reference_does_not_claim_exact_ik_and_is_bounded(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    adapter.posture_solver=N(solve=lambda *a:IKResult(False,(.6,.6,.6),.005,.1,1))
    adapter.posture_key=None;adapter.posture_goal=None;adapter.posture_solution=None;adapter.posture_diagnostic={}
    adapter.controller=N(initial_joint=np.zeros(3))
    world=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    adapter.prepare_posture(pose([0,0,0]),world,('a',0))
    assert adapter.posture_diagnostic['reference_kind']=='approximate'
    assert adapter.posture_diagnostic['success'] is False
    assert np.allclose(adapter.controller.initial_joint,cfg['control']['posture_ik']['max_reference_step_rad'])
    adapter.posture_solver=N(solve=lambda *a:IKResult(False,(.6,.6,.6),.05,.3,1))
    prior=adapter.controller.initial_joint.copy()
    adapter.prepare_posture(pose([0,0,0]),world,('b',0))
    assert adapter.posture_diagnostic['reference_kind']=='rejected'
    assert np.array_equal(prior,adapter.controller.initial_joint)


def test_orientation_projection_respects_nominal_region_and_fixed_tilt(C,world):
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import orientation_command
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    nominal=pose([.2,0,1]);candidate=pose([.2,0,1],Rotation.from_euler('x',.1).as_matrix())
    assert orientation_command(nominal,candidate,.15,np.eye(4),.17) is not None
    assert orientation_command(nominal,candidate,.05) is None
    assert orientation_command(nominal,candidate,.15,np.eye(4),.08) is None
    assert orientation_command(nominal,pose([.21,0,1]),.15) is None
    c,_,p7,proposal=chain1_prep(SkillCall('projection',1,'local_pose_servo',{'reference':'world'}),world,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    C.c10.adapter.prepare_posture=lambda target,*args:pose(target[:3,3],Rotation.from_euler('x',.1).as_matrix()@target[:3,:3])
    original=packet.params[c.phases[p7.phase_index].target_field].value.copy()
    C.c10.solve(packet,c,p7,world,None)
    assert np.allclose(C.c10.last_target,original)  # Termination still uses the nominal goal.
    assert np.array_equal(packet.params[c.phases[p7.phase_index].target_field].value,original)


def test_forward_projection_keeps_nominal_position_and_existing_bounds():
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import forward_command
    nominal=pose([.2,0,1]);forward=pose([.202,0,1],Rotation.from_euler('x',.14).as_matrix())
    allowed=forward_command(nominal,forward,.004,.15)
    assert allowed is not None and np.array_equal(allowed[:3,3],nominal[:3,3])
    assert forward_command(nominal,forward,.001,.15) is None
    assert forward_command(nominal,forward,.004,.13) is None
    assert forward_command(nominal,forward,.004,.15,np.eye(4),.10) is None


def test_failed_second_solve_can_certify_fk_without_claiming_solver_success(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from scipy.spatial.transform import Rotation
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    cfg['control']['posture_ik']['orientation_projection']=True
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    results=iter([IKResult(False,(.1,.1,.1),.007,.1,1),IKResult(False,(.2,.2,.2),.002,.036,1)])
    adapter.posture_solver=N(qpos=np.arange(3),solve=lambda *args:next(results),
        forward=lambda q,j:pose([.002,0,0],Rotation.from_euler('x',.14 if j[0]>.15 else .10).as_matrix()))
    adapter.posture_key=None;adapter.posture_goal=None;adapter.posture_solution=None;adapter.posture_diagnostic={}
    adapter.controller=N(initial_joint=np.zeros(3))
    world=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    command=adapter.prepare_posture(np.eye(4),world,('a',0))
    assert np.linalg.norm(Rotation.from_matrix(command[:3,:3]).as_rotvec())<.15
    assert np.array_equal(command[:3,3],np.zeros(3))
    assert adapter.posture_diagnostic['success'] is False
    assert adapter.posture_diagnostic['projected_ik']['success'] is False
    assert adapter.posture_diagnostic['forward_validated']['position_error_m']<=.004


def test_base_origin_change_invalidates_world_target_posture_cache(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from five_chains.envs.pose_ik import IKResult
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    calls=[]
    adapter.posture_solver=N(solve=lambda *args:calls.append(1) or IKResult(True,(.1,.1,.1),0.,0.,1))
    adapter.posture_key=None;adapter.posture_goal=None;adapter.posture_solution=None;adapter.posture_diagnostic={}
    adapter.controller=N(initial_joint=np.zeros(3))
    world=replace(world,signals={'robot_kinematic_qpos':np.zeros(3)})
    adapter.prepare_posture(np.eye(4),world,('a',0));adapter.prepare_posture(np.eye(4),world,('a',0))
    assert len(calls)==1
    moved=replace(world,base_pose_world=pose([.02,0,0]))
    adapter.prepare_posture(np.eye(4),moved,('a',0))
    assert len(calls)==2
    before=adapter.controller.initial_joint.copy()
    assert adapter.pose_reachable(np.eye(4),moved)
    assert np.array_equal(before,adapter.controller.initial_joint)
    adapter.posture_solver=N(solve=lambda *args:IKResult(False,(.1,.1,.1),.005,.1,1))
    assert not adapter.pose_reachable(np.eye(4),moved)


def test_planned_waypoints_never_replace_packet_or_termination_goal(C,world):
    from five_chains.types import SkillCall
    from five_chains.chains.c1_prep import chain1_prep
    C.c10.config['control']['posture_ik']['path_planning']['enabled']=True
    c,_,p7,prop=chain1_prep(SkillCall('plan',1,'local_pose_servo',{'reference':'bowl'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    goal=packet.params['local_target'].value.copy();waypoint=world.eef_pose_world.copy();waypoint[1,3]+=.1
    C.c10.adapter.prepare_motion_path=lambda *args:waypoint.copy()
    C.c10.solve(packet,c,p7,world,None)
    assert np.array_equal(C.c10.last_target,goal)
    assert np.array_equal(packet.params['local_target'].value,goal)
    assert C.c10.reference[1,3]>world.eef_pose_world[1,3]


def test_position_only_motion_does_not_replan_as_free_orientation_changes(cfg,world):
    from types import SimpleNamespace as N
    from dataclasses import replace
    from scipy.spatial.transform import Rotation
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    a=object.__new__(RoboCasaAdapter);a.config=cfg
    q=np.zeros(3);goal=pose([.2,0,1.]);key=('route',0)
    a.posture_solver=N(qpos=np.arange(3))
    a.motion_scene=N(forward=lambda joints:goal.copy())
    a.motion_goal=goal.copy();a.motion_origin=world.base_pose_world.copy();a.motion_key=key;a.motion_stamp=0
    a.motion_path=(q,np.ones(3)*.1);a.motion_index=1;a.posture_diagnostic={};a.controller=N(initial_joint=q.copy())
    current=pose([.2,0,1.],Rotation.from_euler('x',.4).as_matrix())
    w=replace(world,eef_pose_world=current,signals={'robot_kinematic_qpos':q})
    target=current.copy();saved=target.copy()
    result=a.prepare_motion_path(target,w,key,None,None,None,True)
    assert np.array_equal(target,saved)
    assert np.array_equal(result,goal) and np.array_equal(a.motion_goal,goal)


def test_position_ik_can_succeed_with_unconstrained_attitude_and_reports_it(cfg):
    from scipy.spatial.transform import Rotation
    model=mujoco.MjModel.from_xml_string('''<mujoco><worldbody><body>
      <inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <joint type="slide" axis="1 0 0" range="-1 1"/><joint type="slide" axis="0 1 0" range="-1 1"/>
      <joint type="slide" axis="0 0 1" range="-1 1"/><site/></body></worldbody></mujoco>''')
    solver=RobotPoseIK(model,0,np.arange(3),np.arange(3),np.zeros(3),cfg['control']['posture_ik'])
    target=pose([.2,.3,.4],Rotation.from_euler('z',1.).as_matrix())
    assert not solver.solve(target,model.qpos0).success
    result=solver.solve(target,model.qpos0,position_only=True)
    assert result.success and not result.orientation_constrained
    assert result.orientation_error_rad>.9 and result.position_error_m<.004


def test_bounded_attitude_probes_preserve_nominal_position_and_input():
    from five_chains.envs.pose_ik import bounded_pose_targets
    from five_chains.geometry import rotation_distance
    target=pose([.2,.3,.4]);saved=target.copy();probes=bounded_pose_targets(target,.12)
    assert len(probes)==7 and np.array_equal(target,saved)
    for probe in probes:
        assert np.array_equal(probe[:3,3],target[:3,3])
        assert rotation_distance(probe[:3,:3],target[:3,:3])<=.12+1e-10
