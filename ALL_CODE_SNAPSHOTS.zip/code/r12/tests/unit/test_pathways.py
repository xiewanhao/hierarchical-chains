from dataclasses import replace
import numpy as np
import pytest
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.c3_feedback import chain3a_fast, chain3b_full
from five_chains.chains.c4_vision import chain4_vision
from five_chains.types import (ChainId, FeedbackDelta, Proposal, PhysParam, FieldPrep,
    FieldSpec, FieldKind, P6, ReadoutError)
from five_chains.geometry import pose, inverse


def initialize(C, call, world):
    contract, p6, p7, prep = chain1_prep(call, world, C)
    packet, rejected = C.c10.arbitrate(None, [prep], contract, C.c12)
    return contract, p6, p7, packet


def test_prep_complete_and_typed(C, call, world):
    c, p6, p7, packet = initialize(C, call, world)
    assert packet.params.keys() == c.fields.keys()
    assert packet.params["place_pose"].unit == "m"
    assert packet.params["speed_limit"].value == .08  # physical default, not rescaled


def test_vision_locality_preserves_objects_and_stamps(C, call, world):
    c, p6, p7, packet = initialize(C, call, world)
    bowl = replace(world.entities["bowl"], pose_world=pose([.5, 0, .8]))
    w = replace(world, stamp=10, entities={**world.entities, "bowl": bowl}, changed_keys=frozenset({"bowl.pose"}),
                signals={"grasp_transforms": {"vegetable": pose([0,0,.03])}})
    # P6 valid relative preparation survives geometry changes.
    p6_new, proposal = chain4_vision(c, p6, p7, w, C)
    assert p6_new.fields["place_pose"] is p6.fields["place_pose"]
    assert set(proposal.updates) == {"place_pose", "base_at_target"}
    after, _ = C.c10.arbitrate(packet, [proposal], c, C.c12)
    for name in set(packet.params) - set(proposal.updates):
        assert after.params[name] is packet.params[name]
        assert after.params[name].stamp == packet.params[name].stamp
        assert np.array_equal(after.params[name].value, packet.params[name].value)
    assert after.params["place_pose"].stamp == 10


def test_fast_feedback_permission_and_range(C, call, world, cfg):
    c,p6,p7,packet = initialize(C,call,world)
    proposal = chain3a_fast(c,packet,FeedbackDelta(5,(),{"tilt_dev":100}),C,cfg)
    assert set(proposal.updates) == {"stiffness_scale"}
    after,_ = C.c10.arbitrate(packet,[proposal],c,C.c12)
    assert after.params["stiffness_scale"].value == 1.5
    assert after.params["grasp_pose"] is packet.params["grasp_pose"]


def test_phase_event_advances_once_and_measured_grasp(C, call, world):
    c,p6,p7,packet = initialize(C,call,world)
    # Start at grasp, then a grasp event must advance precisely one stage.
    grasp_index=next(i for i,p in enumerate(c.phases) if p.name=='grasp')
    p7=replace(p7,phase_index=grasp_index,phase_name="grasp")
    world=replace(world,signals={"grasp_transforms":{"vegetable":pose([0,0,.03])}})
    p6,new,prop = chain3b_full(c,p6,p7,world,FeedbackDelta(1,("grasp_established",),{}),C)
    assert new.phase_index == grasp_index+1
    assert C.c7.update(c,new,world,FeedbackDelta(2,(),{})).phase_index == grasp_index+1
    assert set(prop.updates) == {"lift_pose"}


def test_reached_pose_without_retention_does_not_finish_lift(C,call,world):
    c,p6,p7,packet=initialize(C,call,world)
    index=next(i for i,p in enumerate(c.phases) if p.name=='lift')
    p7=replace(p7,phase_index=index,phase_name='lift')
    reached=replace(world,signals={'predicates':{'reached':True,'lift_complete':False}})
    assert C.c7.update(c,p7,reached,FeedbackDelta(1,('reached',),{})).phase_index==index
    verified=replace(world,signals={'predicates':{'reached':True,'lift_complete':True}})
    assert C.c7.update(c,p7,verified,FeedbackDelta(2,('lift_complete',),{})).phase_index==index+1


def test_permission_rejection_and_priority(C, call, world):
    c,p6,p7,packet = initialize(C,call,world)
    illegal=replace(packet.params["speed_limit"],value=np.array(100),source_chain=ChainId.VISION)
    after,rejected=C.c10.arbitrate(packet,[Proposal(ChainId.VISION,{"speed_limit":illegal})],c,C.c12)
    assert rejected[0].name == "speed_limit"
    assert after.params["speed_limit"] is packet.params["speed_limit"]
    b=replace(packet.params["place_pose"],source_chain=ChainId.FB_FULL,stamp=2)
    v=replace(b,source_chain=ChainId.VISION,stamp=3)
    after,_=C.c10.arbitrate(packet,[Proposal(ChainId.VISION,{"place_pose":v}),Proposal(ChainId.FB_FULL,{"place_pose":b})],c,C.c12)
    assert after.params["place_pose"] is v


def test_missing_required_fail_prep_retain_during_update(C,call,world):
    c,p6,p7,packet=initialize(C,call,world)
    p6=replace(p6,fields={**p6.fields,"place_pose":FieldPrep("place_pose",None,"missing",ChainId.PREP,0)})
    with pytest.raises(ReadoutError):
        C.c8.readout(c,p6,p7,world,None,ChainId.PREP)
    assert C.c8.readout(c,p6,p7,world,frozenset({"place_pose"}),ChainId.VISION)=={}


def test_all_field_types(C,call,world):
    c,p6,p7,packet=initialize(C,call,world)
    fields={"p":FieldSpec("p",FieldKind.POSITION,"m","world",frozenset({ChainId.PREP}),frozenset(),prep_frame="bowl"),
            "i":FieldSpec("i",FieldKind.INTERVAL,"rad",None,frozenset({ChainId.PREP}),frozenset(),value_range=(-2,2)),
            "d":FieldSpec("d",FieldKind.DISCRETE,"",None,frozenset({ChainId.PREP}),frozenset(),options=("a","b"))}
    c=replace(c,fields=fields)
    p6=P6(c.contract_id,{n:FieldPrep(n,v,"ready",ChainId.PREP,0) for n,v in {"p":np.array([0,0,.1]),"i":np.array([0.,1.]),"d":1}.items()})
    out=C.c8.readout(c,p6,p7,world,None,ChainId.PREP)
    assert np.allclose(out["p"].value,[.4,0,.9])
    assert np.allclose(out["i"].value,[-2,2])
    assert out["d"].value == "b"


def test_measured_held_transform_used_by_readout(C,call,world):
    from scipy.spatial.transform import Rotation
    relation=pose([.02,0,.03],Rotation.from_euler('x',.7).as_matrix())
    world=replace(world,signals={'grasp_transforms':{'vegetable':relation}})
    c,p6,p7,packet=initialize(C,call,world)
    object_goal=world.entities['bowl'].pose_world@pose([0,0,.08])
    assert np.allclose(packet.params['place_pose'].value@relation,object_goal)
    assert c.phases[0].name=='base_to_target'  # continuation does not reopen a held object


def test_followup_changes_preview_and_invalid_candidate_reprepares(C,call,world):
    from five_chains.types import SkillCall
    c=C.c12.expand(replace(call,next_call=SkillCall('next',1,'local_pose_servo',{'reference':'bowl','target':'bowl'})))
    p6=C.c6.prepare(c,world,None,None,ChainId.PREP)
    changed=replace(world,entities={**world.entities,'bowl':replace(world.entities['bowl'],pose_world=pose([.2,.3,.8]))})
    alternate=C.c6.prepare(c,changed,None,None,ChainId.PREP)
    # A changed base turn can preserve the same object-relative candidate.
    assert not np.allclose(p6.fields['grasp_pose'].provenance['preview']['base_turn_world'],alternate.fields['grasp_pose'].provenance['preview']['base_turn_world'])
    calls=C.c6.recipe_calls
    same=C.c6.prepare(c,changed,p6,frozenset({'grasp_pose'}),ChainId.VISION)
    assert same.fields['grasp_pose'] is p6.fields['grasp_pose']
    assert C.c6.recipe_calls==calls
    invalid=replace(changed,signals={'invalid_grasp_fields':['grasp_pose']})
    renewed=C.c6.prepare(c,invalid,p6,frozenset({'grasp_pose'}),ChainId.VISION)
    assert renewed.fields['grasp_pose'] is not p6.fields['grasp_pose']
    assert C.c6.recipe_calls==calls+1


def test_unrelated_event_cannot_reanchor_in_progress_lift(C,call,world):
    from dataclasses import replace
    from five_chains.chains.c1_prep import chain1_prep
    from five_chains.chains.c3_feedback import chain3b_full
    from five_chains.types import FeedbackDelta
    contract,p6,p7,_=chain1_prep(call,world,C)
    index=next(i for i,p in enumerate(contract.phases) if p.name=='lift')
    p7=replace(p7,phase_index=index,phase_name='lift')
    item=world.entities['vegetable']
    moved=item.pose_world.copy();moved[2,3]+=.1
    world=replace(world,entities={**world.entities,'vegetable':replace(item,pose_world=moved)})
    unchanged,new_p7,proposal=chain3b_full(contract,p6,p7,world,FeedbackDelta(1,('unrelated_contact',),{}),C)
    assert new_p7.phase_index==index
    assert unchanged is p6
    assert proposal is None


def test_relation_feedback_rereads_fixed_destination_without_reanchoring_lift(C,world,call):
    from dataclasses import replace
    from five_chains.geometry import pose,inverse
    from five_chains.types import FeedbackDelta,ChainId
    from five_chains.chains.c1_prep import chain1_prep
    from five_chains.chains.c3_feedback import chain3b_full
    import numpy as np
    relation=pose([.02,0.,0.])
    world=replace(world,signals={**world.signals,'grasp_transforms':{'vegetable':relation}})
    c,p6,p7,_=chain1_prep(call,world,C)
    idx=next(i for i,p in enumerate(c.phases) if p.name=='carry')
    p7=replace(p7,phase_index=idx,phase_name='carry')
    before=C.c8.readout(c,p6,p7,world,frozenset(('place_pose',)),ChainId.FB_FULL)['place_pose'].value
    new_relation=pose([.021,0.,0.])
    moved=replace(world,stamp=1,signals={**world.signals,'grasp_transforms':{'vegetable':new_relation}})
    after_p6,_,proposal=chain3b_full(c,p6,p7,moved,FeedbackDelta(1,('grasp_relation_changed',),{}),C)
    assert after_p6 is p6
    assert proposal is not None
    assert np.allclose(proposal.updates['place_pose'].value@new_relation,before@relation)
    # A grasped source-frame +lift offset must not be read again at every slip event.
    c2=C.c12.expand(call);p7=replace(p7,phase_index=next(i for i,p in enumerate(c2.phases) if p.name=='lift'),phase_name='lift')
    assert chain3b_full(c2,p6,p7,moved,FeedbackDelta(1,('grasp_relation_changed',),{}),C)[2] is None
