from dataclasses import replace
import numpy as np
from five_chains.geometry import pose
from five_chains.chains.c1_prep import chain1_prep

def test_source_inside_cabinet_is_extracted_before_world_up_lift(C,call,world):
    cabinet=replace(world.entities['microwave'],name='cab',pose_world=pose([.2,0,1.]),extent=np.array([.4,.2,.4]))
    world=replace(world,entities={**world.entities,'cab':cabinet},signals={'object_support_frames':{'vegetable':'cab'},'enclosed_support_entities':['cab']})
    c,p6,p7,prop=chain1_prep(call,world,C)
    names=[p.name for p in c.phases]
    assert names.index('grasp')<names.index('extract')<names.index('lift')
    assert c.phases[names.index('lift')].enter_when=='reached'
    target=C.c6.recipes.prepare(c.fields['extract_pose'],c,world)
    local=np.linalg.inv(cabinet.pose_world)@target
    assert local[1,3]<=-cabinet.extent[1]-.15+1e-8
    assert target[2,3]==world.entities['vegetable'].pose_world[2,3]
    # Losing support contact after successful acquisition must not erase the
    # already selected source-fixture relation or turn extraction into a no-op.
    acquired=replace(world,signals={'object_support_frames':{},'enclosed_support_entities':['cab'],'grasp_transforms':{'vegetable':np.eye(4)}})
    continued=C.c6.recipes.prepare(c.fields['extract_pose'],c,acquired)
    assert np.allclose(continued,target)

def test_cabinet_front_pregrasp_reverses_contact_approach_not_world_up(C,world):
    world=replace(world,signals={'object_support_frames':{'vegetable':'cab'},'enclosed_support_entities':['cab']})
    contact=pose([0,0,0],np.array([[1.,0,0],[0,0,1],[0,-1,0]]))
    offset=C.c6.recipes.approach_offset(contact,world,'vegetable',.1)
    assert np.allclose(offset,[0,-.1,0])
