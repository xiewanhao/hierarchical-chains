from pathlib import Path
import yaml


def test_packaged_and_source_defaults_match():
    root = Path(__file__).resolve().parents[2]
    source = yaml.safe_load((root / 'configs/default.yaml').read_text())
    packaged = yaml.safe_load((root / 'five_chains/data/default.yaml').read_text())
    assert source == packaged
