import numpy as np
import mujoco
from five_chains.geometry import pose
from five_chains.envs.scene_path import StaticScene,plan_joint_path


def config():
    return dict(seed=56,validation_step_rad=.025,extension_rad=.2,iterations=2000,
                goal_bias=.2,connect_steps=80,shortcut_attempts=30,waypoint_step_rad=.04)


def test_search_routes_around_obstacle_and_preserves_inputs():
    start=np.array([-.8,0.]);goal=np.array([.8,0.]);saved=start.copy()
    def valid(q):return not(abs(q[0])<=.2 and abs(q[1])<=.25)
    result=plan_joint_path(start,(goal,),np.array([-1.,-1.]),np.ones(2),valid,config())
    assert result.status=='sampled_clear' and len(result.path)>2
    assert np.array_equal(start,saved) and np.allclose(result.path[-1],goal)
    for a,b in zip(result.path,result.path[1:]):
        assert np.max(np.abs(b-a))<=.04+1e-10
        assert all(valid(a+(b-a)*s) for s in np.linspace(0,1,10))


def test_no_clear_goal_and_initial_contact_are_explicit():
    start=np.zeros(2);goal=np.ones(2)*.5
    result=plan_joint_path(start,(goal,),-np.ones(2),np.ones(2),lambda q:False,config())
    assert not result.path and result.status=='no_clear_goal'
    result=plan_joint_path(start,(goal,),-np.ones(2),np.ones(2),lambda q:q[0]>0,config())
    assert result.path and not result.initial_clear and result.status=='sampled_escape_from_initial_contact'


def test_static_scene_checks_robot_and_held_payload_without_mutating_plant_state():
    model=mujoco.MjModel.from_xml_string('''<mujoco><option gravity="0 0 0"/>
      <worldbody><geom name="wall" type="box" pos=".7 0 0" size=".05 .1 .1"/>
      <body><joint type="slide" axis="1 0 0" range="-1 1"/>
      <geom name="robot0_link" type="sphere" size=".04" mass="1"/><site name="tip"/></body>
      <body name="vegetable_body" pos=".2 0 0"><freejoint/>
      <geom name="vegetable_g0" type="sphere" size=".04" mass=".1"/></body></worldbody></mujoco>''')
    qpos=model.qpos0.copy();saved=qpos.copy();native=mujoco.MjData(model);native.qpos[:]=qpos
    scene=StaticScene(model,0,np.array([0]))
    scene.configure(qpos,{'vegetable':pose([.2,0,0])},{'vegetable':1},None,None,None,1e-6)
    assert scene.valid(np.array([0.]))
    # Robot remains outside the wall, but its coupled payload reaches it.
    assert not scene.valid(np.array([.5]))
    assert np.array_equal(qpos,saved) and np.array_equal(model.qpos0,saved)
    assert np.array_equal(native.qpos,saved)
    scene.configure(qpos,{}, {}, None, np.eye(4),.1,1e-6)
    assert not scene.valid(np.array([.7]))


def test_scene_path_enforces_fixed_held_object_tilt_at_samples():
    model=mujoco.MjModel.from_xml_string('''<mujoco><worldbody><body>
      <inertial pos="0 0 0" mass="1" diaginertia="1 1 1"/>
      <joint type="hinge" axis="1 0 0" range="-1 1"/><site/></body></worldbody></mujoco>''')
    scene=StaticScene(model,0,np.array([0]))
    scene.configure(model.qpos0,{}, {}, None,np.eye(4),.1,1e-6)
    assert scene.valid(np.array([.05]))
    assert not scene.valid(np.array([.2]))


def test_native_collision_aabb_corners_have_world_frame_and_preserve_model():
    from five_chains.envs.asset_geometry import collision_boxes_world
    model=mujoco.MjModel.from_xml_string('''<mujoco><worldbody><geom type="box" size=".1 .2 .3" pos="1 2 3"/></worldbody></mujoco>''')
    data=mujoco.MjData(model);mujoco.mj_forward(model,data);saved=model.geom_aabb.copy()
    points=collision_boxes_world(model,data,np.array([0]))
    assert points.shape==(8,3)
    assert np.allclose(points.min(axis=0),[.9,1.8,2.7]) and np.allclose(points.max(axis=0),[1.1,2.2,3.3])
    assert np.array_equal(model.geom_aabb,saved)


def test_closed_opposing_jaw_pads_are_internal_but_hand_contacts_still_block():
    xml="""<mujoco><worldbody>
      <body><joint type="slide" axis="1 0 0" range="-1 1"/>
      <geom name="gripper0_right_finger1_pad_collision" type="sphere" size=".1" mass="1"/><site/></body>
      <body pos=".15 0 0"><joint type="slide" axis="0 1 0" range="-1 1"/>
      <geom name="SECOND" type="sphere" size=".1" mass="1"/></body>
      </worldbody></mujoco>"""
    for name,admitted in (('gripper0_right_finger2_pad_collision',True),('gripper0_right_hand_collision',False)):
        model=mujoco.MjModel.from_xml_string(xml.replace('SECOND',name))
        scene=StaticScene(model,0,np.array([0]))
        scene.configure(model.qpos0,{}, {},None,None,None,1e-6)
        assert scene.valid(np.array([0.])) is admitted
        # The simulator contact model itself has not been altered.
        assert scene.data.ncon>0


def test_attained_redundant_posture_connection_requires_dense_clearance_and_bounds():
    from five_chains.envs.scene_path import sampled_joint_connection
    start=np.array([-.5,0.]);goal=np.array([.5,0.]);lo=-np.ones(2);hi=np.ones(2)
    assert sampled_joint_connection(start,goal,lo,hi,lambda q:True,.025)
    # Clear endpoints do not permit crossing an obstacle between them.
    assert not sampled_joint_connection(start,goal,lo,hi,lambda q:abs(q[0])>.1,.025)
    assert not sampled_joint_connection(np.array([-1.01,0.]),goal,lo,hi,lambda q:True,.025)


def test_measured_start_can_leave_planner_margin_without_relaxing_native_joint_limits(cfg):
    from five_chains.envs.scene_path import plan_joint_path
    import numpy as np
    c=cfg['control']['posture_ik']['path_planning'];seen=[]
    def valid(q):seen.append(q.copy());return True
    lower=np.array([-.995]);upper=np.array([.995]);native_lower=np.array([-1.]);native_upper=np.array([1.])
    plan=plan_joint_path(np.array([.999]),(np.array([.8]),),lower,upper,valid,c,native_lower,native_upper)
    assert plan.path and plan.path[0][0]==.999 and plan.path[-1][0]==.8
    assert all(-1.<=q[0]<=1. for q in seen)
    outside=plan_joint_path(np.array([1.000001]),(np.array([.8]),),lower,upper,valid,c,native_lower,native_upper)
    assert not outside.path and outside.status=='start_outside_limits'
    invalid_goal=plan_joint_path(np.array([.999]),(np.array([.998]),),lower,upper,valid,c,native_lower,native_upper)
    assert not invalid_goal.path and invalid_goal.status=='no_clear_goal'
