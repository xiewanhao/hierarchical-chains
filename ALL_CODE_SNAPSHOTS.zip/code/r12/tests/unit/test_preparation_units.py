from dataclasses import replace
import numpy as np
import pytest
from five_chains.chains.c1_prep import chain1_prep
from five_chains.types import SkillCall


@pytest.mark.parametrize('rim',[False,True])
def test_reference_length_changes_latent_values_but_not_physical_readout(C,cfg,call,world,rim):
    if rim:
        call=SkillCall('b',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})
        world=replace(world,signals={'grasp_modes':{'bowl':'rim'},'object_top_offsets':{'bowl':[0,0,.03]}})
    c,a,p7,first=chain1_prep(call,world,C)
    cfg['preparation']['translation_reference_m']=.1
    c,b,p7,second=chain1_prep(call,world,C)
    assert np.allclose(b.fields['pregrasp_pose'].value[:3,3],a.fields['pregrasp_pose'].value[:3,3]*10)
    assert b.fields['speed_limit'].status=='bound' and b.fields['speed_limit'].value is None
    assert b.fields['pregrasp_pose'].provenance['preparation_unit']=='1'
    for name in first.updates:
        assert np.allclose(first.updates[name].value,second.updates[name].value)
    # Stored encoding metadata also makes an old P6 value readable after a config change.
    old=C.c8.readout(c,a,p7,world,None,first.chain)
    assert np.allclose(old['place_pose'].value,first.updates['place_pose'].value)
