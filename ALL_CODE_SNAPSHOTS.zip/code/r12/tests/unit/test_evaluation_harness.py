from types import SimpleNamespace as N
import pytest
from scripts.evaluate_episode import InspectPreparer,BudgetSelector
from five_chains.types import SelectorOutputError


def test_preparation_inspection_preserves_returned_object_and_only_logs_missing():
    ready=N(status='ready');missing=N(name='pose',status='missing',value=None)
    p6=N(contract_id='call',fields={'ready':ready,'missing':missing});records=[]
    wrapped=N(prepare=lambda *args,**kwargs:p6,recipes='original')
    logger=InspectPreparer(wrapped,N(write=records.append))
    # The original P6 and preparation engine are preserved, with no recompute.
    from unittest.mock import patch
    with patch('scripts.evaluate_episode.serial',lambda obj:vars(obj)):
        assert logger.prepare('contract') is p6
    assert logger.recipes=='original' and len(records)==1
    assert set(records[0]['fields'])=={'missing'}


def test_evaluation_decision_budget_does_not_make_an_extra_model_call():
    calls=[];selector=BudgetSelector(N(select=lambda *args:calls.append(args) or 'call'),2)
    assert selector.select('one')=='call' and selector.select('two')=='call'
    with pytest.raises(SelectorOutputError,match='evaluation_decision_budget'):selector.select('three')
    assert len(calls)==selector.calls==2
