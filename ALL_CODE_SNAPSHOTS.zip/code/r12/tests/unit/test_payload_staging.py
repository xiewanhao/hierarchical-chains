from dataclasses import replace
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.chains.c1_prep import chain1_prep
from five_chains.geometry import inverse,pose
from five_chains.types import SkillCall,ReflexOverride


def test_clearance_rotates_payload_offset_and_keeps_low_bowl_outside(C,world):
    entities=dict(world.entities)
    entities['microwave_interior']=replace(entities['microwave_interior'],pose_world=pose([1.,1.,1.5]),extent=np.array([.25,.2,.15]))
    entities['bowl']=replace(entities['bowl'],pose_world=pose([.6,0.,.95]),extent=np.array([.1,.08,.05]))
    world=replace(world,entities=entities,base_pose_world=pose([0,0,.7]),signals={
        'fixture_front_entities':['microwave_interior'],
        'torso':{'position_m':0.,'origin_world':[0,0,.7],'range_m':[0.,.34]}})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})
    contract,p6,p7,proposal=chain1_prep(call,world,C)
    stance=proposal.updates['base_at_clearance'].value
    delta=stance[:3,:3]@world.base_pose_world[:3,:3].T
    payload_center=stance[:3,3]+delta@(entities['bowl'].pose_world[:3,3]-world.base_pose_world[:3,3])
    radius=float(np.abs(np.array([0,1,0])@(delta@entities['bowl'].pose_world[:3,:3]))@entities['bowl'].extent)
    nearest=payload_center[1]+radius
    opening_front=entities['microwave_interior'].pose_world[1,3]-.2
    assert opening_front-nearest >= C.c10.config['base']['payload_clearance_margin_m']-1e-10
    phases=[p.name for p in contract.phases]
    assert phases.index('base_to_clearance')<phases.index('raise_torso')<phases.index('raise_to_entry')<phases.index('base_to_target')<phases.index('carry')


def test_torso_readout_uses_live_mount_and_limits(C,world):
    world=replace(world,signals={'torso':{'position_m':.1,'origin_world':[0,0,.8],'range_m':[0.,.2]}})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})
    c,p6,p7,proposal=chain1_prep(call,world,C)
    target=proposal.updates['torso_height']
    assert target.unit=='m' and target.value.shape==()
    assert 0<=float(target.value)<=.2
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    index=next(i for i,p in enumerate(c.phases) if p.name=='raise_torso')
    p7=replace(p7,phase_index=index,phase_name='raise_torso')
    commands=[]
    C.c10.adapter.torso_action=lambda target,gripper,stiffness:commands.append(target) or np.array([target])
    C.c10.solve(packet,c,p7,world,None)
    assert commands[-1]==float(target.value)
    C.c10.solve(packet,c,p7,world,ReflexOverride('stop',None,'test'))
    assert commands[-1]==.1
    held=replace(world,signals={**world.signals,'grasp_transforms':{'bowl':np.eye(4)}})
    initialized=C.c12.initialize_entry(c,held)
    assert initialized.phases[0].name=='base_to_clearance'


def test_door_route_exits_before_crossing_open_panel(C,world):
    world=replace(world,signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}})
    call=SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'})
    c,p6,p7,proposal=chain1_prep(call,world,C)
    appliance=world.entities['microwave'].pose_world
    handle_local=inverse(appliance)@world.entities['handle'].pose_world
    withdraw=inverse(appliance)@proposal.updates['withdraw_pose'].value
    around=inverse(appliance)@np.r_[proposal.updates['door_clearance_position'].value,1.]
    margin=C.c10.config['grasp']['door_edge_clearance_m']
    assert withdraw[1,3]<=handle_local[1,3]-margin
    assert around[1]<=handle_local[1,3]-margin
    assert np.allclose(proposal.updates['withdraw_pose'].value[:3,3][[0,2]],world.eef_pose_world[:3,3][[0,2]])
    assert [p.name for p in c.phases]==['withdraw','base_to_door','raise_torso','around_door','approach','close','settle_door','release_contact']


def test_fine_base_stance_is_completed_before_arm_pregrasp(C,call,world):
    c,p6,p7,prop=chain1_prep(call,world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    target=packet.params['base_at_object'].value.copy()
    # Coarse arrival can leave 5cm error; fine pregrasp uses the native precise limit.
    target[:2,3]=world.base_pose_world[:2,3]+[.05,0.]
    target[:3,:3]=world.base_pose_world[:3,:3]
    packet=replace(packet,params={**packet.params,'base_at_object':replace(packet.params['base_at_object'],value=target)})
    index=next(i for i,p in enumerate(c.phases) if p.name=='approach')
    p7=replace(p7,phase_index=index,phase_name='approach')
    commands=[]
    C.c10.adapter.base_pose_action=lambda target,gripper,stiffness,speed_limit=None:commands.append(target) or np.zeros(3)
    C.c10.solve(packet,c,p7,world,None)
    assert C.c10.last_actuator=='base_assist' and np.allclose(commands[-1],target)
    arrived=replace(world,base_pose_world=target)
    C.c10.solve(packet,c,p7,arrived,None)
    assert C.c10.last_actuator=='arm'


def test_door_stance_keeps_front_clearance_and_faces_handle(C,world):
    c=C.c12.expand(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}))
    target=C.c6.recipes.prepare(c.fields['base_at_door'],c,world)
    target=world.entities['microwave'].pose_world@target
    reference=world.entities['microwave_interior'].pose_world
    assert target[1,3]<=reference[1,3]-C.c10.config['base']['standoff_m']
    direction=world.entities['handle'].pose_world[:2,3]-target[:2,3]
    assert np.allclose(target[:2,0],direction/np.linalg.norm(direction))
    assert abs(target[0,3]-world.base_pose_world[0,3])<=.2
    assert [p.name for p in c.phases].index('withdraw')<[p.name for p in c.phases].index('base_to_door')<[p.name for p in c.phases].index('around_door')


def test_handle_push_roll_is_explicit_up_and_independent_of_last_grasp(C,world):
    c=C.c12.expand(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}))
    signals={'surface_normals':{'handle':np.array([-1.,0.,0.])}}
    a=replace(world,signals=signals)
    b=replace(a,eef_pose_world=pose(world.eef_pose_world[:3,3],Rotation.from_euler('xyz',[1.,2.,.5]).as_matrix()))
    field=c.fields['handle_pose'];handle=world.entities['handle'].pose_world
    first=handle@C.c6.recipes.prepare(field,c,a);second=handle@C.c6.recipes.prepare(field,c,b)
    assert np.allclose(first,second)
    assert np.allclose(first[:3,0],[0,0,1]) and np.allclose(first[:3,2],[1,0,0])


def test_hinge_command_tracks_prepared_current_door_normal(C,world):
    signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}}
    world=replace(world,signals=signals)
    c,p6,p7,prop=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name=='close'),phase_name='close')
    C.c10.config['base']['assist_during_door']=False
    C.c10.solve(packet,c,p7,world,None)
    assert np.allclose(C.c10.last_target[:3,:3],packet.params['handle_pose'].value[:3,:3])


def test_moving_door_reprepares_only_allowed_stance_and_contact_fields(C,world):
    from five_chains.chains.c4_vision import chain4_vision
    signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}}
    world=replace(world,signals=signals)
    c,p6,p7,prop=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),world,C)
    entities=dict(world.entities);changed=entities['handle'].pose_world.copy();changed[:2,3]+=[.1,-.5]
    entities['handle']=replace(entities['handle'],pose_world=changed)
    moved=replace(world,entities=entities,stamp=world.stamp+1,changed_keys=frozenset({'handle.pose'}))
    after,update=chain4_vision(c,p6,p7,moved,C)
    assert set(update.updates)=={'base_at_door','handle_pose'}
    assert after.fields['base_at_door'].stamp==moved.stamp
    assert update.updates['base_at_door'].value[1,3]<=changed[1,3]-.3
    for name in ('withdraw_pose','door_clearance_position','torso_height'):
        assert after.fields[name] is p6.fields[name]


def test_pregrasp_can_handoff_only_with_strict_endpoint_gate(C,call,world):
    c,p6,p7,prop=chain1_prep(call,world,C);packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    target=world.base_pose_world.copy();target[0,3]+=.05
    packet=replace(packet,params={**packet.params,'base_at_object':replace(packet.params['base_at_object'],value=target)})
    index=next(i for i,p in enumerate(c.phases) if p.name=='approach');p7=replace(p7,phase_index=index,phase_name='approach')
    C.c10.adapter.base_pose_action=lambda *args,**kwargs:np.zeros(3)
    C.c10.adapter.pose_reachable=lambda *args:False
    C.c10.solve(packet,c,p7,world,None);assert C.c10.last_actuator=='base_assist'
    C.c10.adapter.pose_reachable=lambda *args:True
    C.c10.solve(packet,c,p7,world,None);assert C.c10.last_actuator=='arm'
    too_far=replace(world,base_pose_world=pose([-.1,0,0]))
    C.c10.solve(packet,c,p7,too_far,None);assert C.c10.last_actuator=='base_assist'


def test_door_clearance_position_leaves_attitude_free_until_contact(C,world):
    signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}}
    world=replace(world,signals=signals,eef_pose_world=pose([.2,0,1.],Rotation.from_euler('x',.6).as_matrix()))
    c,p6,p7,prop=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    assert packet.params['door_clearance_position'].value.shape==(3,)
    index=next(i for i,p in enumerate(c.phases) if p.name=='around_door');p7=replace(p7,phase_index=index,phase_name='around_door')
    C.c10.config['base']['assist_during_door']=False
    C.c10.solve(packet,c,p7,world,None)
    assert np.allclose(C.c10.last_target[:3,:3],world.eef_pose_world[:3,:3])
    assert not np.allclose(packet.params['handle_pose'].value[:3,:3],world.eef_pose_world[:3,:3])


def test_contact_release_is_prepared_at_event_and_frozen_in_world(C,world):
    from five_chains.chains.c3_feedback import chain3b_full
    from five_chains.types import FeedbackDelta,ChainId
    signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':1.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}}
    world=replace(world,signals=signals)
    c,p6,p7,prop=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),world,C)
    p7=replace(p7,phase_index=next(i for i,p in enumerate(c.phases) if p.name=='settle_door'),phase_name='settle_door')
    entities=dict(world.entities);entities['handle']=replace(entities['handle'],pose_world=pose([.7,.3,1.]))
    moved=replace(world,entities=entities,stamp=world.stamp+1)
    p6,p7,update=chain3b_full(c,p6,p7,moved,FeedbackDelta(moved.stamp,('door_closed_settled',),{}),C)
    release=update.updates['release_pose'].value
    assert p7.phase_name=='release_contact' and np.isclose(release[0,3],.7-.06)
    entities['handle']=replace(entities['handle'],pose_world=pose([.9,.3,1.]))
    later=replace(moved,entities=entities,stamp=moved.stamp+1)
    output=C.c8.readout(c,p6,p7,later,frozenset({'release_pose'}),ChainId.FB_FULL)
    assert np.array_equal(output['release_pose'].value,release)


def test_object_stance_uses_actual_support_front_instead_of_robot_approach_line(C,call,world):
    entities=dict(world.entities)
    entities['counter']=replace(entities['bowl'],name='counter',pose_world=pose([.3,0,.4],Rotation.from_euler('z',np.pi/2).as_matrix()))
    world=replace(world,entities=entities,signals={'object_support_frames':{'bowl':'counter'}})
    c,p6,p7,update=chain1_prep(call,world,C)
    stance=update.updates['base_at_target'].value;center=entities['bowl'].pose_world[:2,3]
    assert np.allclose(stance[:2,3],center+[C.c10.config['base']['standoff_m'],0.])
    assert np.allclose(stance[:2,0],[-1.,0.])


def test_support_frame_motion_only_updates_dependent_base_field(C,call):
    from tests.conftest import observation
    from five_chains.chains.c4_vision import chain4_vision
    obs=observation();obs['state']['entities']['counter']={'pose_world':pose([.3,0,.4],Rotation.from_euler('z',np.pi/2).as_matrix()),'extent':[1.,.3,.4],'joints':{}}
    obs['state']['signals']['object_support_frames']={'bowl':'counter'}
    world=C.c4.update(obs);c,p6,p7,_=chain1_prep(call,world,C)
    obs['state']['entities']['counter']['pose_world']=pose([.3,0,.4],Rotation.from_euler('z',np.pi).as_matrix())
    moved=C.c4.update(obs);assert 'bowl.support' in moved.changed_keys
    after,update=chain4_vision(c,p6,p7,moved,C)
    assert set(update.updates)=={'base_at_target'}
    for name in p6.fields:
        if name!='base_at_target':assert after.fields[name] is p6.fields[name]
    unchanged=C.c4.update(obs);assert 'bowl.support' not in unchanged.changed_keys
    obs['state']['signals']['object_support_frames']={}
    assert 'bowl.support' in C.c4.update(obs).changed_keys


def test_torso_reference_persists_during_arm_motion_and_changes_only_on_torso_phase(C,world):
    world=replace(world,signals={'torso':{'position_m':.1,'origin_world':[0,0,.8],'range_m':[0.,.34]}})
    calls=[];C.c10.adapter.hold_torso=lambda action,target:calls.append(target) or action
    local=SkillCall('local',1,'local_pose_servo',{'reference':'world'})
    c,p6,p7,prop=chain1_prep(local,world,C);packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    C.c10.solve(packet,c,p7,world,None);assert calls[-1]==.1
    c2,_,p72,prop2=chain1_prep(SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'}),world,C)
    packet2,_=C.c10.arbitrate(None,[prop2],c2,C.c12)
    packet2=replace(packet2,params={**packet2.params,'torso_height':replace(packet2.params['torso_height'],value=np.asarray(.25))})
    index=next(i for i,p in enumerate(c2.phases) if p.name=='raise_torso');p72=replace(p72,phase_index=index,phase_name='raise_torso')
    C.c10.adapter.torso_action=lambda *args:np.zeros(3)
    C.c10.solve(packet2,c2,p72,world,None)
    C.c10.solve(packet,c,p7,world,None);assert calls[-1]==.25


def test_native_torso_hold_changes_only_declared_action_segment():
    from types import SimpleNamespace as N
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=object.__new__(RoboCasaAdapter)
    adapter.composite=N(_action_split_indexes={'torso':(2,3)})
    adapter.env=N(action_spec=(np.full(5,-1.),np.full(5,1.)))
    adapter._torso_input=lambda target:np.array([target])
    action=np.array([.1,.2,0.,-.3,1.]);saved=action.copy()
    combined=adapter.hold_torso(action,.4)
    assert np.array_equal(action,saved) and combined[2]==.4
    assert np.array_equal(combined[[0,1,3,4]],saved[[0,1,3,4]])


def test_reflex_hold_never_becomes_the_termination_goal_or_rewrites_torso_reference(C,world):
    world=replace(world,signals={'torso':{'position_m':.1}})
    c,p6,p7,prop=chain1_prep(SkillCall('local',1,'local_pose_servo',{'reference':'bowl'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    commands=[];C.c10.adapter.hold_torso=lambda action,target:commands.append(target) or action
    C.c10.torso_hold_target=.25
    C.c10.solve(packet,c,p7,world,ReflexOverride('hold',None,'test'))
    assert np.allclose(C.c10.last_target,packet.params['local_target'].value)
    assert not np.allclose(C.c10.last_target,world.eef_pose_world)
    assert commands[-1]==.1 and C.c10.torso_hold_target==.25
    C.c10.solve(packet,c,p7,world,None)
    assert commands[-1]==.25


def test_entry_alignment_compensates_final_base_translation_before_carry(C,world):
    entities=dict(world.entities)
    entities['microwave_interior']=replace(entities['microwave_interior'],pose_world=pose([1.,1.,1.5]),extent=np.array([.25,.2,.15]))
    entities['bowl']=replace(entities['bowl'],pose_world=pose([.6,-.2,1.]),extent=np.array([.1,.08,.05]))
    world=replace(world,entities=entities,base_pose_world=pose([1.,-.3,.7],Rotation.from_euler('z',np.pi/2).as_matrix()),
                  signals={'fixture_front_entities':['microwave_interior'],'cavity_entities':['microwave_interior'], 'object_bottom_offsets':{'bowl':[0,0,-.05]}})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})
    contract=C.c12.expand(call)
    recipes=C.c6.recipes;frame=entities['microwave_interior'].pose_world
    clearance=frame@recipes.prepare(contract.fields['entry_clearance_pose'],contract,world)
    final_base=frame@recipes.prepare(contract.fields['base_at_target'],contract,world)
    entrance=frame@recipes.prepare(contract.fields['place_pose'],contract,world)
    after_base=clearance[:3,3]+final_base[:3,3]-world.base_pose_world[:3,3]
    assert np.allclose(after_base[:2],entrance[:2,3])
    assert np.isclose(after_base[2],entrance[2,3]+C.c10.config['grasp']['transfer_height_margin_m'])
    assert clearance[1,3] < entrance[1,3]
    assert np.allclose(clearance[:3,:3],entities['bowl'].pose_world[:3,:3])


def test_rim_lift_reference_has_separate_slow_speed_cap(C,world):
    world=replace(world,signals={'grasp_modes':{'bowl':'rim'},'object_top_offsets':{'bowl':[0,0,.03]}})
    c,p6,p7,prop=chain1_prep(SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    index=next(i for i,p in enumerate(c.phases) if p.name=='lift')
    p7=replace(p7,phase_index=index,phase_name='lift')
    target=packet.params['lift_pose'].value.copy();target[:3,3]=world.eef_pose_world[:3,3]+[0,0,.2]
    packet=replace(packet,params={**packet.params,'lift_pose':replace(packet.params['lift_pose'],value=target)})
    C.c10.solve(packet,c,p7,world,None)
    assert np.isclose(np.linalg.norm(C.c10.reference[:3,3]-world.eef_pose_world[:3,3]),
                      C.c10.config['grasp']['lift_speed_m_s']/C.c10.adapter.control_freq)


def test_base_reference_retains_achieved_stance_and_reflex_is_temporary(C,world):
    commands=[];C.c10.adapter.hold_base=lambda action,target:commands.append(target.copy()) or action
    c,p6,p7,prop=chain1_prep(SkillCall('local',1,'local_pose_servo',{'reference':'world'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    C.c10.solve(packet,c,p7,world,None)
    anchor=world.base_pose_world.copy();moved=replace(world,base_pose_world=pose([.04,0,0]))
    C.c10.solve(packet,c,p7,moved,None);assert np.array_equal(commands[-1],anchor)
    C.c10.solve(packet,c,p7,moved,ReflexOverride('stop',None,'test'))
    assert np.array_equal(commands[-1],moved.base_pose_world) and np.array_equal(C.c10.base_hold_target,anchor)
    C.c10.last_actuator='base'
    C.c10.solve(packet,c,p7,moved,None);assert np.array_equal(commands[-1],moved.base_pose_world)


def test_native_base_hold_changes_only_live_base_segment():
    from types import SimpleNamespace as N
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=object.__new__(RoboCasaAdapter)
    adapter.config={'base':{'hold_max_speed_m_s':.03}}
    adapter.composite=N(_action_split_indexes={'base':(1,4)})
    adapter.env=N(action_spec=(np.full(6,-1.),np.full(6,1.)))
    adapter._base_input=lambda target,speed_limit:np.array([.1,.2,.3])
    action=np.array([.9,0,0,0,-.4,-1.]);saved=action.copy()
    combined=adapter.hold_base(action,np.eye(4))
    assert np.array_equal(action,saved)
    assert np.allclose(combined[1:4],[.1,.2,.3])
    assert np.array_equal(combined[[0,4,5]],saved[[0,4,5]])


def test_direct_cavity_placement_prepares_outside_before_interior_motion(C,world):
    entities=dict(world.entities)
    entities['microwave_interior']=replace(entities['microwave_interior'],pose_world=pose([1.,1.,1.5]),extent=np.array([.25,.2,.15]))
    world=replace(world,entities=entities,base_pose_world=pose([1.,-.3,.7]),signals={
        'fixture_front_entities':['microwave_interior'],'cavity_entities':['microwave_interior'],
        'object_bottom_offsets':{'bowl':[0,0,-.03]}})
    call=SkillCall('direct',3,'place_object_in_container',{'object':'bowl','target':'microwave_interior'})
    c=C.c12.initialize_entry(C.c12.expand(call),world)
    assert c.call is call and c.followup['entry_variant']=='selected_cavity_placement'
    recipes=C.c6.recipes;frame=entities['microwave_interior'].pose_world
    before=frame@recipes.prepare(c.fields['entry_clearance_pose'],c,world)
    base=frame@recipes.prepare(c.fields['base_at_target'],c,world)
    after=before[:3,3]+base[:3,3]-world.base_pose_world[:3,3]
    assert np.isclose(after[1],1.-.2-C.c10.config['grasp']['entrance_clearance_m'])
    interior=frame@recipes.prepare(c.fields['place_pose'],c,world)
    assert interior[1,3]>after[1]


def test_entry_center_does_not_inherit_lateral_coarse_stance_error(C,world):
    entities=dict(world.entities)
    entities['microwave_interior']=replace(entities['microwave_interior'],pose_world=pose([1.,1.,1.5]),extent=np.array([.25,.2,.15]))
    world=replace(world,entities=entities,base_pose_world=pose([.92,-.3,.7]),signals={
        'fixture_front_entities':['microwave_interior'],'cavity_entities':['microwave_interior'],
        'object_bottom_offsets':{'bowl':[0,0,-.03]}})
    c=C.c12.expand(SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'}))
    recipes=C.c6.recipes;frame=entities['microwave_interior'].pose_world
    before=frame@recipes.prepare(c.fields['entry_clearance_pose'],c,world)
    final_base=frame@recipes.prepare(c.fields['base_at_target'],c,world)
    entrance=frame@recipes.prepare(c.fields['place_pose'],c,world)
    assert np.isclose(before[0,3],entrance[0,3])  # Door-side clearance stays centered.
    assert np.isclose(before[1,3]+final_base[1,3]-world.base_pose_world[1,3],entrance[1,3])


def test_clearance_uses_open_panel_front_and_actual_gripper_envelope(C,world):
    entities=dict(world.entities)
    entities['microwave_interior']=replace(entities['microwave_interior'],pose_world=pose([1.,1.,1.5]),extent=np.array([.25,.2,.15]))
    entities['door']=replace(entities['microwave_interior'],name='door',pose_world=pose([.8,.4,1.5]),extent=np.array([.02,.4,.2]))
    entities['bowl']=replace(entities['bowl'],pose_world=pose([.6,0.,1.]),extent=np.array([.1,.08,.04]))
    points=np.array([[.9,0.,1.1],[.8,.1,1.2]])
    w=replace(world,entities=entities,base_pose_world=pose([0,0,.7]),signals={
        'fixture_front_entities':['microwave_interior'],'cavity_entities':['microwave_interior'],
        'cavity_obstacles':{'microwave_interior':['door']},'gripper_collision_points_world':points,
        'object_bottom_offsets':{'bowl':[0,0,-.04]}})
    c=C.c12.expand(SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'}))
    stance=entities['microwave_interior'].pose_world@C.c6.recipes.prepare(c.fields['base_at_clearance'],c,w)
    delta=stance[:3,:3]@w.base_pose_world[:3,:3].T
    carried=(points-w.base_pose_world[:3,3])@delta.T+stance[:3,3]
    door_front=entities['door'].pose_world[1,3]-entities['door'].extent[1]
    assert np.max(carried[:,1])<=door_front-C.c10.config['base']['payload_clearance_margin_m']+1e-10
    phases=[p.name for p in c.phases]
    assert phases.index('base_to_clearance')<phases.index('align_payload_outside')<phases.index('raise_torso')
    prepared=entities['microwave_interior'].pose_world@C.c6.recipes.prepare(c.fields['payload_alignment_pose'],c,w)
    assert np.isclose(prepared[2,3],entities['bowl'].pose_world[2,3])


def test_door_approach_uses_scene_path_but_contact_push_and_egress_do_not(C,world):
    C.c10.config['control']['posture_ik']['path_planning']['enabled']=True
    C.c10.config['base']['assist_during_door']=False
    world=replace(world,signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},
        'microwave_hinge':{'angle':1.,'axis_world':[0,0,1],'anchor_world':[.6,.2,1.]}})
    c,_,p7,prop=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12);calls=[]
    C.c10.adapter.prepare_motion_path=lambda target,*args:calls.append(target.copy()) or target.copy()
    for phase_name,expected in (('approach',1),('close',1),('release_contact',1)):
        index=next(i for i,p in enumerate(c.phases) if p.name==phase_name)
        phase=replace(p7,phase_index=index,phase_name=phase_name)
        C.c10.solve(packet,c,phase,world,None)
        assert len(calls)==expected


def test_door_contact_holds_base_and_preloads_inward(C,world):
    signals={'surface_normals':{'handle':np.array([-1.,0.,0.])},'microwave_hinge':{'angle':0.,'axis_world':[0.,0.,1.],'anchor_world':[.6,.2,1.]}}
    world=replace(world,signals=signals)
    c,p6,p7,prop=chain1_prep(SkillCall('door',3,'close_hinged_door',{'appliance':'microwave','handle':'handle'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    # A changing visual stance must never interrupt an established door push.
    stance=world.base_pose_world.copy();stance[0,3]+=.3
    packet=replace(packet,params={**packet.params,'base_at_door':replace(packet.params['base_at_door'],value=stance)})
    C.c10.adapter.base_pose_action=lambda *args,**kwargs:(_ for _ in ()).throw(AssertionError('contact moved base'))
    normal=packet.params['handle_pose'].value[:3,2]
    for phase in ('close','settle_door'):
        index=next(i for i,p in enumerate(c.phases) if p.name==phase)
        state=replace(p7,phase_index=index,phase_name=phase)
        C.c10.solve(packet,c,state,world,None)
        assert C.c10.last_actuator=='arm'
        assert np.allclose(C.c10.last_target[:3,3],world.entities['handle'].pose_world[:3,3]+.005*normal)
        assert np.allclose(C.c10.last_target[:3,:3],packet.params['handle_pose'].value[:3,:3])


def test_contact_release_freezes_measured_posture_once_per_phase():
    from types import SimpleNamespace as N
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=RoboCasaAdapter.__new__(RoboCasaAdapter)
    adapter.posture_solver=N(qpos=np.array([1,3]))
    adapter.controller=N(initial_joint=np.zeros(2))
    world=N(stamp=1,signals={'robot_kinematic_qpos':np.array([0.,.2,0.,.5])})
    adapter.prepare_contact_posture(world,('door',7))
    assert np.allclose(adapter.controller.initial_joint,[.2,.5])
    world.signals['robot_kinematic_qpos'][1]=.3
    adapter.prepare_contact_posture(world,('door',7))
    assert np.allclose(adapter.controller.initial_joint,[.2,.5])
    adapter.prepare_contact_posture(world,('button',2))
    assert np.allclose(adapter.controller.initial_joint,[.3,.5])


def test_button_approach_compares_bounded_attitudes_for_nearby_joint_branch(C,world):
    C.c10.config['control']['posture_ik']['path_planning']['enabled']=True
    world=replace(world,signals={'surface_normals':{'start':np.array([-1.,0.,0.])}})
    c,_,p7,prop=chain1_prep(SkillCall('button',3,'approach_control',{'appliance':'microwave','control':'start'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12);calls=[]
    C.c10.adapter.prepare_motion_path=lambda target,*args:calls.append(args[-1]) or target.copy()
    C.c10.solve(packet,c,p7,world,None)
    assert calls==[True]


def test_button_press_keeps_admitted_approach_attitude_with_nominal_goal(C,world):
    world=replace(world,signals={'surface_normals':{'start':np.array([-1.,0.,0.])}})
    c,_,p7,prop=chain1_prep(SkillCall('press',3,'activate_control',{'appliance':'microwave','control':'start'}),world,C)
    packet,_=C.c10.arbitrate(None,[prop],c,C.c12)
    nominal=packet.params['press_pose'].value
    attained=nominal.copy();attained[:3,:3]=Rotation.from_euler('z',.12).as_matrix()@nominal[:3,:3]
    world=replace(world,eef_pose_world=attained)
    index=next(i for i,p in enumerate(c.phases) if p.name=='press');p7=replace(p7,phase_index=index,phase_name='press')
    commands=[]
    C.c10.adapter.pose_action=lambda target,*args:commands.append(target.copy()) or np.zeros(3)
    C.c10.solve(packet,c,p7,world,None)
    assert np.allclose(commands[-1][:3,:3],attained[:3,:3])
    assert np.allclose(C.c10.last_target,nominal)
    # Contact drift cannot repeatedly re-anchor and accumulate a larger angle.
    drifted=attained.copy();drifted[:3,:3]=Rotation.from_euler('z',.1).as_matrix()@attained[:3,:3]
    C.c10.solve(packet,c,p7,replace(world,eef_pose_world=drifted),None)
    assert np.allclose(commands[-1][:3,:3],attained[:3,:3])


def test_button_roll_is_explicit_and_independent_of_previous_wrist_pose(C,world):
    world=replace(world,signals={'surface_normals':{'start':np.array([-1.,0.,0.])}})
    c=C.c12.expand(SkillCall('button',3,'activate_control',{'appliance':'microwave','control':'start'}))
    other=replace(world,eef_pose_world=pose(world.eef_pose_world[:3,3],Rotation.from_euler('xyz',[.2,.3,.4]).as_matrix()))
    a=world.entities['start'].pose_world@C.c6.recipes.prepare(c.fields['button_pose'],c,world)
    b=world.entities['start'].pose_world@C.c6.recipes.prepare(c.fields['button_pose'],c,other)
    press=world.entities['start'].pose_world@C.c6.recipes.prepare(c.fields['press_pose'],c,world)
    assert np.allclose(a,b) and np.allclose(a[:3,:3],press[:3,:3])
    assert np.allclose(a[:3,2],[1,0,0])
    assert np.allclose(a[:3,0],[0,-2**-.5,-2**-.5])


def test_already_reached_button_goal_holds_without_new_joint_path(cfg):
    from types import SimpleNamespace as N
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    adapter=RoboCasaAdapter.__new__(RoboCasaAdapter);adapter.config=cfg
    adapter.posture_solver=N(qpos=np.array([1,3]));adapter.controller=N(initial_joint=np.zeros(2))
    world=N(stamp=2,eef_pose_world=np.eye(4),signals={'robot_kinematic_qpos':np.zeros(4)})
    target=pose([.005,0,0],Rotation.from_euler('z',.1).as_matrix())
    got=adapter.prepare_motion_path(target,world,('button',0),None,None,None,False,True)
    assert np.allclose(got,world.eef_pose_world)
    assert adapter.posture_diagnostic['path_status']=='already_reached'
