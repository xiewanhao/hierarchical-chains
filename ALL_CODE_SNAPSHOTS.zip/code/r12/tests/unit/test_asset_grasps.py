from dataclasses import replace
from pathlib import Path
import hashlib,json
import numpy as np
import pytest
from five_chains.geometry import pose
from five_chains.skills.asset_grasps import AssetGraspProvider
from five_chains.skills.recipes import GeometricGraspProvider
from five_chains.types import ReadoutError


def setup_cache(cfg,world,tmp_path):
    t=pose([.1,0,.02],np.diag([1.,-1.,-1.]))
    path=tmp_path/'candidates.npz'
    np.savez_compressed(path,T_O_actual_TCP=np.stack([t,t]),confidence=np.array([.9,.1]),gripper_points_object=np.tile(np.array([[0.,0.,0.],[0.,-.2,.2]]),(2,1,1)))
    meta={'shape_sha256':'0'*64,'gripper_sha256':'1'*64,'T_actual_gripper_root_TCP':np.eye(4).tolist(),
          'candidate_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'provider':'test_proposals','mount_shift_m':.006}
    (tmp_path/'candidates.json').write_text(json.dumps(meta))
    cfg['grasp']['asset_candidates']['directory']=str(tmp_path)
    world=replace(world,entities={**world.entities,'bowl':replace(world.entities['bowl'],extent=np.array([.13,.13,.04]))},
        signals={'grasp_modes':{'bowl':'rim'},'object_top_offsets':{'bowl':[0,0,.04]},
                 'grasp_signatures':{'objects':{'bowl':'0'*64},'gripper':'1'*64,'T_actual_gripper_root_TCP':np.eye(4)}})
    return AssetGraspProvider(cfg,GeometricGraspProvider(cfg)),world,path


def test_valid_asset_proposal_has_jaw_symmetry_and_auditable_origin(cfg,world,tmp_path):
    provider,world,_=setup_cache(cfg,world,tmp_path)
    poses=provider.candidates('bowl',world)
    assert len(poses)==2  # Low-confidence contact is excluded; one jaw symmetry remains.
    assert np.array_equal(poses[0][:3,3],poses[1][:3,3])
    assert np.allclose(poses[0][:3,:3]@np.diag([-1,-1,1]),poses[1][:3,:3])
    origin=provider.describe(poses[1])
    assert origin['candidate_index']==0 and origin['confidence']==.9
    assert origin['physical_success_verified'] is False


@pytest.mark.parametrize('mismatch',['object','gripper','tcp'])
def test_asset_or_calibration_mismatch_is_rejected_without_geometric_fallback(cfg,world,tmp_path,mismatch):
    provider,world,_=setup_cache(cfg,world,tmp_path)
    signatures=dict(world.signals['grasp_signatures'])
    if mismatch=='object':signatures['objects']={'bowl':'2'*64}
    elif mismatch=='gripper':signatures['gripper']='2'*64
    else:signatures['T_actual_gripper_root_TCP']=pose([0,0,.01])
    world=replace(world,signals={**world.signals,'grasp_signatures':signatures})
    with pytest.raises(ReadoutError):provider.candidates('bowl',world)


def test_tampered_proposal_file_is_rejected(cfg,world,tmp_path):
    _,world,path=setup_cache(cfg,world,tmp_path)
    path.write_bytes(path.read_bytes()+b'changed')
    with pytest.raises(ValueError,match='checksum'):AssetGraspProvider(cfg,GeometricGraspProvider(cfg))


def test_followup_fit_checks_walls_and_keeps_front_exterior_open(cfg,world,tmp_path):
    provider,world,_=setup_cache(cfg,world,tmp_path)
    cavity=replace(world.entities['microwave_interior'],pose_world=np.eye(4),extent=np.array([.2,.1,.1]))
    world=replace(world,entities={**world.entities,'microwave_interior':cavity})
    candidate=(provider.candidates('bowl',world)[0],)
    # The second point lies above the cavity but in front of its open mouth.
    assert provider.filter_for_followup('bowl',world,candidate,'microwave_interior',np.eye(4))
    assert not provider.filter_for_followup('bowl',world,candidate,'microwave_interior',pose([0,0,.2]))
    assert not provider.filter_for_followup('bowl',world,candidate,'microwave_interior',pose([.3,0,0]))
    cfg['grasp']['asset_candidates']['require_future_geometry']=True
    provider.gripper_points=None
    with pytest.raises(ReadoutError,match='requires cached'):provider.filter_for_followup('bowl',world,candidate,'microwave_interior',np.eye(4))


def test_future_fit_does_not_treat_space_in_front_of_open_door_as_empty(cfg,world,tmp_path):
    provider,world,_=setup_cache(cfg,world,tmp_path)
    cavity=replace(world.entities['microwave_interior'],pose_world=np.eye(4),extent=np.array([.2,.1,.1]))
    door=replace(cavity,name='door',pose_world=pose([0.,-.2,.2]),extent=np.array([.01,.01,.01]))
    world=replace(world,entities={**world.entities,'microwave_interior':cavity,'door':door},signals={**world.signals,'cavity_obstacles':{'microwave_interior':['door']}})
    candidate=(provider.candidates('bowl',world)[0],)
    assert not provider.filter_for_followup('bowl',world,candidate,'microwave_interior',np.eye(4))
    entities={**world.entities,'door':replace(door,pose_world=pose([.4,-.2,.2]))}
    assert provider.filter_for_followup('bowl',replace(world,entities=entities),candidate,'microwave_interior',np.eye(4))


def test_gravity_relative_jaw_tilt_is_distinct_from_approach_tilt(cfg,world,tmp_path):
    from scipy.spatial.transform import Rotation
    provider,world,_=setup_cache(cfg,world,tmp_path)
    cfg['grasp']['asset_candidates']['max_approach_tilt_rad']=.85
    cfg['grasp']['asset_candidates']['max_jaw_tilt_rad']=.50
    original=provider.poses[0].copy()
    provider.poses[0][:3,:3]=Rotation.from_euler('y',.6).as_matrix()@original[:3,:3]
    assert not provider.candidates('bowl',world)
    # Approach is still tilted, but the actual opening axis is horizontal after
    # a local jaw roll. Apply the live axis rather than assuming approach tilt.
    world=replace(world,signals={**world.signals,'gripper_opening_axis_eef':[0.,1.,0.]})
    assert len(provider.candidates('bowl',world))==2


def test_future_fit_uses_candidate_aperture_points_even_when_live_gripper_is_open(cfg,world,tmp_path):
    provider,world,_=setup_cache(cfg,world,tmp_path)
    cavity=replace(world.entities['microwave_interior'],pose_world=np.eye(4),extent=np.array([.1,.1,.1]))
    world=replace(world,entities={**world.entities,'microwave_interior':cavity},signals={**world.signals,
        'gripper_collision_points_world':np.array([[2.,0.,0.]])})
    unknown=(pose([.03,.02,.01]),)
    assert not provider.filter_for_followup('bowl',world,unknown,'microwave_interior',np.eye(4))
    assert provider.filter_for_followup('bowl',world,unknown,'microwave_interior',np.eye(4),
        candidate_points_object=(np.array([[0.,0.,0.],[.02,.02,.02]]),))
    assert not provider.filter_for_followup('bowl',world,unknown,'microwave_interior',np.eye(4),
        candidate_points_object=(np.array([[0.,0.,.3]]),))
