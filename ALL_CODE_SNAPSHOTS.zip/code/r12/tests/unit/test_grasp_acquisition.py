from types import SimpleNamespace as N
import numpy as np
from five_chains.envs.robocasa_adapter import RoboCasaAdapter
from five_chains.geometry import pose


def test_grasp_measurement_starts_after_settling_and_still_rejects_later_slip(cfg):
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg;adapter.arm='right'
    position=np.array([.1,0,1.]);data=N(time=0.,get_body_xpos=lambda name:position.copy(),get_body_xmat=lambda name:np.eye(3))
    adapter.env=N(_check_grasp=lambda *a:True,check_contact=lambda *a:True,sim=N(data=data))
    adapter.robot=N(gripper={'right':N(important_geoms={'left_finger':['l'],'right_finger':['r']})})
    adapter.grasp_transforms={};adapter.grasp_origins={};adapter.grasp_contact_counts={};adapter.grasp_gap_counts={};adapter.grasp_evidence_times={}
    adapter.gripper_command='close';adapter.context_key=None;adapter.context_time=None;adapter.phase_ticks=0
    adapter.context=(N(contract_id='c'),N(phase_name='grasp',phase_index=0),np.eye(4),0.)
    item=N(root_body='bowl',contact_geoms=['bowl_geom']);settle=cfg['grasp']['close_settle_ticks']
    # Geometry settles by > retention bound during closure, before acquisition.
    for i in range(settle):
        data.time=i*.05;position[0]=.1+.04*i/settle
        adapter._update_phase_clock(data.time)
        held,_=adapter._estimate_grasp('bowl',item,pose([0,0,1]))
        assert not held and 'bowl' not in adapter.grasp_transforms
        before=adapter.phase_ticks;adapter._update_phase_clock(data.time)
        assert adapter.phase_ticks==before  # Re-reading a frame cannot satisfy dwell.
    data.time=settle*.05;position[0]=.14;adapter._update_phase_clock(data.time)
    held,evidence=adapter._estimate_grasp('bowl',item,pose([0,0,1]))
    assert held and evidence['relation_translation_error_m'] is None
    assert np.isclose(adapter.grasp_transforms['bowl'][0,3],.14)
    data.time+=.05;position[0]+=.03;adapter._update_phase_clock(data.time)
    held,evidence=adapter._estimate_grasp('bowl',item,pose([0,0,1]))
    assert not held and evidence['relation_translation_error_m']>cfg['feedback']['grasp_retention_translation_m']


def test_door_settling_counts_physical_frames_and_rejects_rebound(cfg):
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg
    cfg['grasp']['door_closed_settle_ticks']=3
    adapter.context=(N(),N(phase_name='settle_door'),np.eye(4),0.)
    adapter.door_evidence_time=None;adapter.door_closed_counts=0
    assert not adapter._door_settled(0.,True,0.)
    assert not adapter._door_settled(0.,True,0.) and adapter.door_closed_counts==1
    assert not adapter._door_settled(.05,True,.1) and adapter.door_closed_counts==0
    assert not adapter._door_settled(.1,True,0.)
    assert not adapter._door_settled(.15,True,0.)
    assert adapter._door_settled(.2,True,0.)
    assert not adapter._door_settled(.25,False,0.) and adapter.door_closed_counts==0


def test_native_contact_tracks_slow_drift_but_retains_acquisition_and_rejects_detachment(cfg):
    from scipy.spatial.transform import Rotation
    adapter=object.__new__(RoboCasaAdapter);adapter.config=cfg;adapter.arm='right'
    state={'rotation':np.eye(3),'contact':True};position=np.array([.1,0,1.])
    data=N(time=0.,get_body_xpos=lambda name:position.copy(),get_body_xmat=lambda name:state['rotation'])
    adapter.env=N(_check_grasp=lambda *a:state['contact'],check_contact=lambda *a:state['contact'],sim=N(data=data))
    adapter.robot=N(gripper={'right':N(important_geoms={'left_finger':['l'],'right_finger':['r']})})
    for name in ('grasp_transforms','grasp_origins','grasp_contact_counts','grasp_gap_counts','grasp_evidence_times'):setattr(adapter,name,{})
    adapter.gripper_command='close';adapter.phase_ticks=30
    adapter.context=(N(),N(phase_name='grasp'),np.eye(4),0.)
    item=N(root_body='cup',contact_geoms=['cup_geom'])
    for i in range(cfg['feedback']['grasp_confirm_steps']):
        data.time+=.05;held,_=adapter._estimate_grasp('cup',item,np.eye(4))
    assert held
    original=adapter.grasp_acquisition_relations['cup'].copy()
    for i in range(1,9):
        state['rotation']=Rotation.from_rotvec([0.,0.,.05*i]).as_matrix();data.time+=.05
        held,diag=adapter._estimate_grasp('cup',item,np.eye(4));assert held
    assert diag['cumulative_rotation_since_acquisition_rad']>.35
    assert diag['relation_rotation_error_rad']<.06
    assert np.array_equal(original,adapter.grasp_acquisition_relations['cup'])
    state['contact']=False
    for _ in range(cfg['feedback']['grasp_contact_grace_steps']+1):
        data.time+=.05;held,_=adapter._estimate_grasp('cup',item,np.eye(4))
    assert not held  # No-contact frames cannot keep rebasing or relatch.
