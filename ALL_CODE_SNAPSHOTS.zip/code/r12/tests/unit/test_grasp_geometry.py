from dataclasses import replace
import numpy as np
from five_chains.skills.recipes import GeometricGraspProvider
from five_chains.geometry import pose


def test_rim_candidates_use_half_extents_and_preserve_input_axis(cfg,world):
    bowl=replace(world.entities['bowl'],pose_world=pose([0,0,1]),extent=np.array([.13,.13,.04]))
    axis=np.array([0.,1.,0.])
    world=replace(world,entities={**world.entities,'bowl':bowl},signals={'grasp_modes':{'bowl':'rim'},
        'object_top_offsets':{'bowl':np.array([0.,0.,.04])},'gripper_opening_axis_eef':axis})
    candidates=GeometricGraspProvider(cfg).candidates('bowl',world)
    assert len(candidates)==8
    assert np.array_equal(axis,[0,1,0])
    for t in candidates:
        assert np.linalg.norm(t[:2,3]) < .13
        assert np.isclose(t[2,2],-np.cos(cfg['grasp']['rim_approach_tilt_rad']))
        assert np.dot(t[:2,2],t[:2,3]) < 0
        assert np.isclose(np.linalg.det(t[:3,:3]),1.)
    assert np.array_equal(candidates[0][:3,3],candidates[1][:3,3])


def test_followup_azimuth_does_not_choose_far_rim_when_target_is_higher(cfg,world):
    from five_chains.skills.recipes import RecipeRegistry
    from five_chains.types import SkillCall
    from five_chains.components.c12_contract import ContractDispatcher
    entities={**world.entities,
        'bowl':replace(world.entities['bowl'],pose_world=pose([0,0,1]),extent=np.array([.13,.13,.04])),
        'microwave_interior':replace(world.entities['microwave_interior'],pose_world=pose([1,.1,2]))}
    world=replace(world,entities=entities,base_pose_world=pose([0,-1,1]),eef_pose_world=pose([0,-.2,1.3]),
        signals={'grasp_modes':{'bowl':'rim'},'object_top_offsets':{'bowl':np.array([0,0,.04])}})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'},
        next_call=SkillCall('enter',1,'local_pose_servo',{'reference':'microwave_interior'}))
    contract=ContractDispatcher().expand(call)
    registry=RecipeRegistry(config=cfg)
    chosen=registry.prepare(contract.fields['grasp_pose'],contract,world)
    assert chosen[1,3] < 0  # The near member of the equally aligned rim pair.
    lower=replace(world,entities={**entities,'microwave_interior':replace(entities['microwave_interior'],pose_world=pose([1,.1,.8]))})
    assert np.allclose(chosen,registry.prepare(contract.fields['grasp_pose'],contract,lower))


def test_object_stance_faces_bound_target(cfg,world):
    from five_chains.skills.recipes import RecipeRegistry
    from five_chains.types import SkillCall
    from five_chains.components.c12_contract import ContractDispatcher
    call=SkillCall('move',3,'place_object_in_container',{'object':'vegetable','target':'bowl'})
    contract=ContractDispatcher().expand(call)
    world=replace(world,base_pose_world=pose([1,-1,0]))
    relative=RecipeRegistry(config=cfg).prepare(contract.fields['base_at_target'],contract,world)
    target=world.entities['bowl'].pose_world@relative
    toward=world.entities['bowl'].pose_world[:2,3]-target[:2,3]
    assert np.allclose(target[:2,0],toward/np.linalg.norm(toward))
    assert np.isclose(np.linalg.norm(toward),cfg['base']['standoff_m'])


def test_pregrasp_world_up_is_reprepared_after_parent_tilts(C,call,world):
    from scipy.spatial.transform import Rotation
    from five_chains.chains.c1_prep import chain1_prep
    from five_chains.types import ChainId
    contract,p6,_,_=chain1_prep(call,world,C)
    spec=contract.fields['pregrasp_pose'];old=p6.fields[spec.name]
    item=world.entities['vegetable'];moved=item.pose_world.copy();moved[:3,:3]=Rotation.from_euler('x',.12).as_matrix()
    world=replace(world,entities={**world.entities,'vegetable':replace(item,pose_world=moved)})
    assert not C.c6.recipes.valid(spec,old,contract,world)
    new=C.c6.prepare(contract,world,p6,frozenset({spec.name}),ChainId.VISION).fields[spec.name]
    contact=np.asarray(new.provenance['contact_pose_object'])
    actual=moved@new.value;grasp=moved@contact
    assert np.allclose(actual[:3,3]-grasp[:3,3],[0,0,spec.arguments['clearance_m']])
