import json
import numpy as np
from five_chains.types import SkillCall,ChainId,P7
from five_chains.components.c12_contract import ContractDispatcher


def test_same_named_fixed_interval_limits_physical_target(C,world,tmp_path):
    primary={'skill':'servo','layer':1,'roles':[],
        'fields':{'target':{'kind':'pose','unit':'m','frame_entity':'world','writable_by':['c1_prep'],'default':np.eye(4).tolist()},
                  'speed_limit':{'kind':'scalar','unit':'m/s','writable_by':['c1_prep'],'value_range':[0,.2],'recipe':'normalized','arguments':{'value':1.}}},
        'phases':[{'name':'track','target_field':'target','enter_when':'always','fields':['target','speed_limit']}],
        'termination':{'success_when':'reached','fail_when':None,'timeout_steps':20}}
    limit={'skill':'limit','layer':2,'roles':[],
        'fields':{'speed_limit':{'kind':'interval','unit':'m/s','writable_by':[],'default':[.03,.08]}},'phases':[],
        'termination':{'success_when':'never','fail_when':None,'timeout_steps':20}}
    for name,data in [('servo',primary),('limit',limit)]:
        (tmp_path/(name+'.yaml')).write_text(json.dumps(data))
    dispatch=ContractDispatcher(tmp_path)
    call=SkillCall('composed',1,'servo',{},(SkillCall('bound',2,'limit',{}),))
    contract=dispatch.expand(call)
    p6=C.c6.prepare(contract,world,None,None,ChainId.PREP)
    values=C.c8.readout(contract,p6,P7.initial(contract),world,None,ChainId.PREP)
    assert np.isclose(values['speed_limit'].value,.08)
    assert np.array_equal(values['speed_limit__constraint'].value,[.03,.08])
    assert not dispatch.may_write(contract,'speed_limit__constraint',ChainId.PREP)
