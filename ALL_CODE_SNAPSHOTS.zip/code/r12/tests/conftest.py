from __future__ import annotations
import numpy as np
import pytest
from five_chains.config import load_config
from five_chains.geometry import pose
from five_chains.build import build_components
from five_chains.components.c11_selector import ScriptedSelector
from five_chains.types import SkillCall


@pytest.fixture
def cfg() -> dict:
    return load_config()


def observation() -> dict:
    entities = {name: dict(pose_world=pose(pos), extent=[.03, .03, .03], joints={})
                for name, pos in {"vegetable": [.2, 0, .8], "bowl": [.4, 0, .8],
                                  "microwave": [.6, .2, 1.], "microwave_interior": [.6, .2, 1.],
                                  "handle": [.5, .2, 1.], "start": [.65, .2, 1.]}.items()}
    return {"state": dict(entities=entities, eef_pose_world=pose([.2, 0, 1.]), base_pose_world=np.eye(4),
                           gripper_width=.08, signals={"predicates": {}, "continuous": {}})}


class Adapter:
    control_freq = 20.

    def pose_action(self, target: np.ndarray, gripper: str, stiffness: float) -> np.ndarray:
        return target[:3, 3].copy()


@pytest.fixture
def C(cfg: dict) -> object:
    return build_components(Adapter(), ScriptedSelector([]), cfg)


@pytest.fixture
def call() -> SkillCall:
    return SkillCall("pick_1", 3, "place_object_in_container", {"object": "vegetable", "target": "bowl"})


@pytest.fixture
def world(C: object) -> object:
    return C.c4.update(observation())
