"""Independent runtime components."""
