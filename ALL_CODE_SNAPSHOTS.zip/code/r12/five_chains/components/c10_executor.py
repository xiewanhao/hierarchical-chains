from __future__ import annotations
from typing import Any
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import rigid, limited, motion_target
from five_chains.types import (ChainId, Contract, FieldKind, P7, WorldState, ParamPacket,
    Proposal, PhysParam, ReflexOverride, RejectedWrite)
from five_chains.components.c12_contract import ContractDispatcher
from five_chains.components.c04_state import StateGeometry


PRIORITY = {ChainId.PREP: 0, ChainId.FB_FULL: 1, ChainId.VISION: 2, ChainId.FB_FAST: 3}


class Executor:
    def __init__(self, adapter: Any, config: dict) -> None:
        self.adapter = adapter
        self.config = config
        self.executions = 0
        self.failure_reason: str | None = None
        self.reference: np.ndarray | None = None
        self.reference_key: tuple | None = None
        self.last_target: np.ndarray | None = None
        self.last_gripper = "open"
        self.last_error = 0.0
        self.last_actuator = "arm"
        self.base_hold_target: np.ndarray | None = None
        self.base_override_target: np.ndarray | None = None
        self.torso_hold_target: float | None = None
        self.torso_override_target: float | None = None

    def arbitrate(self, packet: ParamPacket | None, proposals: list[Proposal], contract: Contract,
                  c12: ContractDispatcher) -> tuple[ParamPacket, list[RejectedWrite]]:
        if packet and packet.contract_id != contract.contract_id:
            raise ValueError("packet belongs to a different contract")
        params = dict(packet.params) if packet else {}
        version = packet.version if packet else 0
        bounds = packet.bounds if packet else None
        rejected = []
        # Fixed physical defaults are initialized from the contract, not written by a chain.
        if packet is None:
            for name, spec in contract.fields.items():
                if not spec.writable_by:
                    params[name] = PhysParam(name, spec.kind, np.asarray(spec.default).copy(), spec.unit,
                                             spec.frame_entity, ChainId.PREP, -1)
        for proposal in sorted(proposals, key=lambda p: PRIORITY[p.chain]):
            accepted = False
            for name, parameter in proposal.updates.items():
                if not c12.may_write(contract, name, proposal.chain):
                    # Initialization of immutable defaults already happened above.
                    if not (packet is None and proposal.chain == ChainId.PREP and name in params and not contract.fields[name].writable_by):
                        rejected.append(RejectedWrite(name, proposal.chain, "permission_denied"))
                    continue
                spec = contract.fields[name]
                if (parameter.name != name or parameter.kind != spec.kind or parameter.unit != spec.unit
                        or parameter.frame_entity != spec.frame_entity or parameter.source_chain != proposal.chain):
                    rejected.append(RejectedWrite(name, proposal.chain, "metadata_mismatch"))
                    continue
                params[name] = parameter
                version += 1
                accepted = True
            if proposal.bounds is not None and (accepted or packet is None):
                bounds = proposal.bounds
        if bounds is None:
            raise ValueError("initial packet lacks reflex bounds")
        missing = [n for n, s in contract.fields.items() if s.required and n not in params]
        if missing:
            raise ValueError("incomplete parameter packet: " + ",".join(missing))
        return ParamPacket(contract.contract_id, params, version, bounds), rejected

    def solve(self, packet: ParamPacket, contract: Contract, p7: P7, world: WorldState,
              override: ReflexOverride | None) -> np.ndarray:
        self.failure_reason=None
        if self.base_hold_target is None or self.last_actuator in ('base','base_assist'):
            self.base_hold_target=world.base_pose_world.copy()
        self.base_override_target=world.base_pose_world.copy() if override is not None and override.kind in ('hold','stop') else None
        if self.torso_hold_target is None and 'torso' in world.signals:
            self.torso_hold_target=self._measured_torso_reference(world)
        self.torso_override_target=(self._measured_torso_reference(world) if override is not None and override.kind in ('hold','stop') and 'torso' in world.signals else None)
        phase = contract.phases[p7.phase_index]
        target_param = packet.params[phase.target_field]
        actuator = contract.fields[phase.target_field].arguments.get("actuator", "arm")
        if actuator == 'torso':
            if phase.gripper != 'keep':self.last_gripper=phase.gripper
            current_height=float(world.signals['torso']['position_m'])
            nominal_height=float(target_param.value)
            target_height=current_height if override is not None else nominal_height
            self.torso_hold_target=nominal_height
            self.last_target=np.asarray(nominal_height)
            self.last_error=abs(nominal_height-current_height)
            self.last_actuator='torso';self.reference_key=None
            stiffness=float(packet.params['stiffness_scale'].value) if 'stiffness_scale' in packet.params else 1.
            return self._hold_base(self.adapter.torso_action(target_height,self.last_gripper,stiffness))
        current = world.base_pose_world if actuator == "base" else world.eef_pose_world
        target = motion_target(target_param,StateGeometry.frame(target_param.frame_entity,world),current)
        if contract.fields[phase.target_field].arguments.get("motion_model") == "hinge_arc":
            hinge = world.signals.get("microwave_hinge")
            handle_name = contract.call.bindings.get("handle")
            if hinge is not None and handle_name is not None and handle_name in world.entities:
                angle = float(hinge["angle"])
                step = self.config["grasp"]["hinge_rate_rad_s"] / self.adapter.control_freq
                delta = np.clip(-angle,-step,step)
                anchor = np.asarray(hinge["anchor_world"])
                axis = np.asarray(hinge["axis_world"])
                handle = world.entities[handle_name].pose_world[:3,3]
                target[:3,3] = anchor+Rotation.from_rotvec(axis*delta).as_matrix()@(handle-anchor)
                # Contact normal follows the measured rotating door; roll is
                # prepared by C6 rather than accumulated from prior commands.
                contact = packet.params.get('handle_pose')
                target[:3,:3] = (StateGeometry.frame(contact.frame_entity,world)@rigid(contact.value))[:3,:3] if contact is not None else current[:3,:3]
                # A bounded inward reference supplies contact force at the closed
                # hinge stop. Native closure/settling predicates remain unchanged.
                preload=float(contract.fields[phase.target_field].arguments.get('contact_preload_m',0.))
                target[:3,3]+=target[:3,2]*preload
        relation=None
        max_tilt=None
        # Fixed L2 tilt envelope is enforced in the command target as well as monitored.
        if "tilt_limit" in packet.params and actuator == "arm":
            bounds = packet.params["tilt_limit"].value
            object_name = contract.fields["tilt_limit"].arguments.get("entity", contract.call.bindings.get("object"))
            relation = world.signals.get("grasp_transforms", {}).get(object_name)
            if relation is None and phase.name=='grasp' and 'preload_pose' in packet.params and object_name in world.entities:
                from five_chains.geometry import inverse
                relation=inverse(world.eef_pose_world)@world.entities[object_name].pose_world
            if relation is not None:
                object_goal = target @ relation
                up = object_goal[:3, 2]
                tilt = float(np.arccos(np.clip(up[2], -1, 1)))
                max_tilt = max(abs(float(bounds[0])), abs(float(bounds[1])))
                safe_tilt=max(0.,max_tilt-self.config['control']['constraint_tilt_margin_rad'])
                if tilt > safe_tilt:
                    axis = np.cross(up, np.array([0.,0.,1.]))
                    if np.linalg.norm(axis) < 1e-8:
                        axis = object_goal[:3,0].copy()
                    axis /= np.linalg.norm(axis)
                    correction = Rotation.from_rotvec(axis*(tilt-safe_tilt)).as_matrix()
                    object_goal[:3,:3] = correction @ object_goal[:3,:3]
                from five_chains.geometry import inverse
                target = object_goal @ inverse(relation)
        nominal_target=target.copy()
        if actuator=='arm' and phase.name=='press':
            # Retain the admitted approach attitude during contact; re-solving
            # a nominal wrist roll here can switch to a distant joint branch.
            contact_key=(contract.contract_id,p7.phase_index)
            if getattr(self,'contact_attitude_key',None)!=contact_key:
                from five_chains.geometry import rotation_distance
                attitude=current[:3,:3]
                self.contact_attitude=(attitude.copy() if rotation_distance(attitude,nominal_target[:3,:3])<=self.config['control']['reached_rad'] else nominal_target[:3,:3].copy())
                self.contact_attitude_key=contact_key
            target[:3,:3]=self.contact_attitude
        if phase.name=='grasp' and 'preload_pose' in packet.params and p7.steps_in_phase<=self.config['grasp']['close_settle_ticks']:
            target[2,3]-=self.config['grasp']['loaded_acquisition']['preload_height_m']
        if override:
            if override.kind in ("hold", "stop"):
                target = current.copy()
            elif override.delta_pose is not None:
                correction = rigid(override.delta_pose)
                if (np.linalg.norm(correction[:3, 3]) > packet.bounds.max_pos_correction_m + 1e-12
                        or np.linalg.norm(Rotation.from_matrix(correction[:3, :3]).as_rotvec()) > packet.bounds.max_rot_correction_rad + 1e-12):
                    raise ValueError("reflex exceeds authorized bounds")
                target = current.copy()
                target[:3, 3] += correction[:3, 3]
                target[:3, :3] = correction[:3, :3] @ current[:3, :3]
        speed = float(packet.params["speed_limit"].value) if "speed_limit" in packet.params else self.config["control"]["reference_speed_m_s"]
        if (actuator == "arm" and phase.name in ("approach", "descend", "grasp")
                and world.signals.get("grasp_modes", {}).get(contract.call.bindings.get("object")) == "rim"):
            speed = min(speed,self.config["grasp"]["approach_speed_m_s"])
        if (actuator == 'arm' and phase.name == 'lift'
                and world.signals.get('grasp_modes',{}).get(contract.call.bindings.get('object')) == 'rim'):
            speed=min(speed,self.config['grasp']['lift_speed_m_s'])
        if phase.name=='grasp' and 'preload_pose' in packet.params:
            speed=min(speed,self.config['grasp']['loaded_acquisition']['speed_m_s'])
        if phase.gripper != "keep":
            self.last_gripper = phase.gripper
        stiffness = float(packet.params["stiffness_scale"].value) if "stiffness_scale" in packet.params else 1.0
        stance_name=None
        precise_stance=False
        if 'base_at_door' in packet.params and phase.name in ('around_door','approach') and self.config['base']['assist_during_door']:
            stance_name='base_at_door';precise_stance=True
        elif phase.name=='carry' and self.config['base']['assist_during_carry']:
            stance_name='base_at_target'
        elif phase.name in ('approach','descend') and self.config['base']['assist_during_approach']:
            stance_name='base_at_object';precise_stance=True
        if not override and actuator=='arm' and stance_name is not None and stance_name in packet.params:
            stance=packet.params[stance_name]
            base_target=StateGeometry.frame(stance.frame_entity,world)@rigid(stance.value)
            base_position_error=np.linalg.norm(base_target[:2,3]-world.base_pose_world[:2,3])
            base_angle_error=np.linalg.norm(Rotation.from_matrix(base_target[:3,:3]@world.base_pose_world[:3,:3].T).as_rotvec())
            threshold=self.config['base']['reached_m'] if precise_stance else self.config['base']['stance_reached_m']
            needs_base=base_position_error>threshold or base_angle_error>self.config['base']['reached_rad']
            if (needs_base and stance_name=='base_at_object' and self.config['base']['assist_until_pose_reachable']
                    and base_position_error<=self.config['base']['stance_reached_m']
                    and base_angle_error<=self.config['base']['reached_rad'] and hasattr(self.adapter,'pose_reachable')):
                # Coarse stance is already valid. Do not insist on millimetres of
                # base motion when the requested arm pose is strictly reachable.
                needs_base=not self.adapter.pose_reachable(target,world)
            if needs_base:
                self.reference_key=None;self.last_target=target.copy();self.last_error=0.;self.last_actuator='base_assist'
                return self._hold_torso(self.adapter.base_pose_action(base_target,self.last_gripper,stiffness,speed_limit=speed))
        key = (contract.contract_id, p7.phase_index)
        planning=self.config['control']['posture_ik']['path_planning']
        free_phase=phase.name in planning['phases']
        if actuator=='arm' and phase.name in ('release_contact','press','close','settle_door') and override is None:
            # Contact egress reverses the prepared normal at fixed world pose.
            # Keep the achieved posture; a free-space plan cannot start at the
            # intended compressive contact used by the preceding push/press.
            if hasattr(self.adapter,'prepare_contact_posture'):
                self.adapter.prepare_contact_posture(world,key)
        elif actuator=='arm' and override is None and planning['enabled'] and free_phase and hasattr(self.adapter,'prepare_motion_path'):
            target=self.adapter.prepare_motion_path(target,world,key,relation,max_tilt,contract.call.bindings.get('object'),target_param.kind==FieldKind.POSITION,contract.call.skill in ('approach_control','activate_control'))
            if planning['fail_fast'] and getattr(self.adapter,'motion_failure',None):
                self.failure_reason='motion_path:'+self.adapter.motion_failure
        elif actuator=='arm' and override is None and hasattr(self.adapter,'prepare_posture'):
            proposed=self.adapter.prepare_posture(target,world,key,relation,max_tilt)
            if proposed is not None:
                from five_chains.envs.pose_ik import orientation_command
                allowed=orientation_command(nominal_target,proposed,self.config['control']['reached_rad'],relation,max_tilt)
                if allowed is not None:target=allowed
        if key != self.reference_key:
            self.reference = current.copy()
            self.reference_key = key
        assert self.reference is not None
        dt = 1.0 / self.adapter.control_freq
        self.reference[:3, 3] += limited(target[:3, 3] - self.reference[:3, 3], speed * dt)
        lead = self.config["control"]["max_tracking_lead_m"]
        self.reference[:3, 3] = current[:3, 3] + limited(self.reference[:3, 3] - current[:3, 3], lead)
        rot = limited(Rotation.from_matrix(target[:3, :3] @ self.reference[:3, :3].T).as_rotvec(), self.config["control"]["reference_rotation_rad_s"] * dt)
        self.reference[:3, :3] = Rotation.from_rotvec(rot).as_matrix() @ self.reference[:3, :3]
        if override:
            self.reference = target.copy()
        self.last_target = nominal_target
        self.last_error = float(np.linalg.norm(self.reference[:3, 3] - current[:3, 3]))
        self.last_actuator = actuator
        if actuator == "base":
            return self._hold_torso(self.adapter.base_pose_action(self.reference.copy(), self.last_gripper, stiffness, speed_limit=speed))
        return self._hold_base(self._hold_torso(self.adapter.pose_action(self.reference.copy(), self.last_gripper, stiffness)))

    def _hold_base(self, action: np.ndarray) -> np.ndarray:
        if self.config['base']['hold_pose_during_arm'] and self.base_hold_target is not None and hasattr(self.adapter,'hold_base'):
            return self.adapter.hold_base(action,self.base_override_target if self.base_override_target is not None else self.base_hold_target)
        return action

    def _measured_torso_reference(self, world: WorldState) -> float:
        support=world.signals['torso'];measured=float(support['position_m'])
        low,high=support.get('range_m',(0.,.34))
        excess=max(low-measured,measured-high,0.)
        if not np.isfinite(measured) or excess>self.config['torso'].get('measurement_limit_tolerance_m',.001):
            raise ValueError('measured torso exceeds native limits beyond reset tolerance')
        return float(np.clip(measured,low,high))

    def _hold_torso(self, action: np.ndarray) -> np.ndarray:
        if self.torso_hold_target is not None and hasattr(self.adapter,'hold_torso'):
            return self.adapter.hold_torso(action,self.torso_override_target if self.torso_override_target is not None else self.torso_hold_target)
        return action

    def execute(self, env: Any, action: np.ndarray) -> tuple[dict, bool]:
        # The sole env.step call site across this package.
        outcome = env.step(action)
        self.executions += 1
        obs, reward, done, info = outcome
        # RoboCasa horizon 'done' is not task success. Use the actual task predicate.
        normalized = self.adapter.observe(obs)
        normalized["environment_done"] = bool(done)
        return normalized, bool(self.adapter.success())
