from __future__ import annotations
import numpy as np
from five_chains.types import FeedbackDelta, WorldState


class FeedbackEncoder:
    def __init__(self) -> None:
        self.previous: dict[str, bool] = {}
        self.reported_relations: dict[str,np.ndarray] = {}

    def encode(self, obs: dict, world: WorldState, prev: WorldState | None,
               reflex_event: str | None) -> FeedbackDelta:
        flags = dict(world.signals.get("predicates", {}))
        # Explicit rising edges, including the negative grasp transition.
        grasp = bool(flags.get("grasp_established", False))
        if self.previous.get("grasp_established", False) and not grasp:
            flags["grasp_lost"] = True
        events = [key for key, value in flags.items() if value and not self.previous.get(key, False)]
        self.previous = {key: bool(value) for key, value in flags.items()}
        from five_chains.geometry import rotation_distance
        live_relations=world.signals.get('grasp_transforms',{})
        for name,relation in live_relations.items():
            old=self.reported_relations.get(name)
            if old is not None and (np.linalg.norm(relation[:3,3]-old[:3,3])>.002 or
                                    rotation_distance(relation[:3,:3],old[:3,:3])>.03):
                events.append('grasp_relation_changed');self.reported_relations[name]=relation.copy()
            elif old is None:self.reported_relations[name]=relation.copy()
        for name in set(self.reported_relations)-set(live_relations):self.reported_relations.pop(name)
        if reflex_event:
            events.append(reflex_event)
        continuous = {key: float(value) for key, value in world.signals.get("continuous", {}).items()}
        if not all(np.isfinite(v) for v in continuous.values()):
            raise ValueError("nonfinite feedback signal")
        return FeedbackDelta(world.stamp, tuple(dict.fromkeys(events)), continuous)
