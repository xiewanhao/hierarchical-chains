from __future__ import annotations
import numpy as np
from five_chains.geometry import limited
from five_chains.types import ReflexBounds, ReflexOverride


class ReflexLayer:
    def __init__(self, enabled: bool = False) -> None:
        self.enabled = enabled

    def step(self, bounds: ReflexBounds, obs: dict) -> ReflexOverride | None:
        if not self.enabled:
            return None
        signals = obs.get("state", {}).get("signals", obs)
        if bounds.stop_on_unexpected_contact and signals.get("unexpected_contact", False):
            return ReflexOverride("stop", None, "reflex_contact_stop")
        force = signals.get("force_world")
        if force is not None and bounds.max_force_n is not None:
            force = np.asarray(force, float)
            if force.shape != (3,) or not np.isfinite(force).all():
                raise ValueError("invalid force measurement")
            if np.linalg.norm(force) > bounds.max_force_n:
                t = np.eye(4)
                t[:3, 3] = limited(-force, bounds.max_pos_correction_m)
                return ReflexOverride("bounded_correction", t, "reflex_force_correction")
        return None
