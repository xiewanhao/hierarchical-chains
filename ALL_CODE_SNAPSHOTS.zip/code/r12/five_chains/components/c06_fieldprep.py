from __future__ import annotations
from copy import deepcopy
from five_chains.types import ChainId, Contract, FieldPrep, P6, WorldState
from five_chains.skills.recipes import RecipeRegistry
from five_chains.preparation import encode_preparation


class FieldPreparer:
    def __init__(self, recipes: RecipeRegistry | None = None) -> None:
        self.recipes = recipes or RecipeRegistry()
        self.recipe_calls = 0

    def prepare(self, contract: Contract, world: WorldState, prev: P6 | None,
                fields: frozenset[str] | None, chain: ChainId) -> P6:
        if prev and prev.contract_id != contract.contract_id:
            raise ValueError("P6 belongs to another contract")
        result = dict(prev.fields) if prev else {}
        selected = contract.fields.keys() if fields is None else fields
        for name in selected:
            spec = contract.fields[name]
            old = result.get(name)
            if chain == ChainId.VISION and old and self.recipes.valid(spec, old, contract, world):
                continue
            if spec.default is not None:
                result[name] = FieldPrep(name, None, "bound", chain, world.stamp, {"binding":"contract.default"})
            else:
                self.recipe_calls += 1
                value = self.recipes.prepare(spec, contract, world)
                reference=self.recipes.config['preparation']['translation_reference_m']
                provenance={**self.recipes.provenance(spec,value,world,contract),'preparation_unit':'1','translation_reference_m':reference}
                result[name] = FieldPrep(name, encode_preparation(spec,value,reference), "ready" if value is not None else "missing", chain, world.stamp, provenance)
        return P6(contract.contract_id, result)
