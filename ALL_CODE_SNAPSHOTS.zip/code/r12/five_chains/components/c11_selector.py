from __future__ import annotations
from importlib import import_module
from typing import Any, Callable, Protocol
import json
import sys
from pathlib import Path
from five_chains.types import SkillCall, SelectorOutputError


class Selector(Protocol):
    def select(self, task: str, obs: dict, history: list[SkillCall]) -> SkillCall: ...


def parse_call(raw: Any) -> SkillCall:
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except json.JSONDecodeError as error:
            raise SelectorOutputError("invalid JSON") from error
    if not isinstance(raw, dict):
        raise SelectorOutputError("selector must return an object")
    legacy = {"invocation_id", "primary", "level", "bindings", "auxiliary", "goal_window"}
    modern = {"call_id", "layer", "skill", "bindings", "combined_with", "next_call"}
    if set(raw) == legacy:
        if raw["level"] not in ("L1", "L2", "L3", "L4") or not isinstance(raw["auxiliary"], list):
            raise SelectorOutputError("invalid legacy call")
        name = raw["primary"]
        call_id = raw["invocation_id"]
        bindings = raw["bindings"]
        auxiliary = tuple(SkillCall(call_id + f"/aux{i}", 2, skill, dict(bindings)) for i, skill in enumerate(raw["auxiliary"]))
        result = SkillCall(call_id, int(raw["level"][1]), name, bindings, auxiliary)
    elif {"call_id", "layer", "skill", "bindings"} <= set(raw) <= modern:
        result = SkillCall(raw["call_id"], raw["layer"], raw["skill"], raw["bindings"],
                           tuple(parse_call(x) for x in raw.get("combined_with", [])),
                           parse_call(raw["next_call"]) if raw.get("next_call") else None)
    else:
        raise SelectorOutputError("unexpected or missing call keys")
    if (not isinstance(result.call_id, str) or not result.call_id or type(result.layer) is not int
            or result.layer not in (1, 2, 3, 4) or not isinstance(result.skill, str)
            or not isinstance(result.bindings, dict) or not all(isinstance(k, str) and isinstance(v, str) and v for k, v in result.bindings.items())):
        raise SelectorOutputError("invalid call values")
    return result


class SelectorAdapter:
    def __init__(self, model: Any, sample_builder: Callable[[str, dict, list[SkillCall]], dict]) -> None:
        self.model = model
        self.sample_builder = sample_builder
        self.calls = 0

    def select(self, task: str, obs: dict, history: list[SkillCall]) -> SkillCall:
        sample = self.sample_builder(task, obs, history)
        if any(key in sample for key in ("label", "expected", "teacher_action", "offline_teacher")):
            raise SelectorOutputError("deployment input contains teacher information")
        self.calls += 1
        raw, _ = self.model.generate(sample)
        call = parse_call(raw)
        # Preserve the legacy finite candidate grammar; no fallback routing policy.
        if hasattr(self.model, "candidates") and raw not in self.model.candidates(sample):
            raise SelectorOutputError("model call is outside original registered candidates")
        return call

    @classmethod
    def from_legacy(cls, config: dict, builder: Callable) -> SelectorAdapter:
        root = Path(config["legacy_root"])
        sys.path.insert(0, str(root))
        model_class = getattr(import_module(config["module"]), config["class"])
        model = model_class(adapter=root / config["adapter"])
        return cls(model, builder)


class ScriptedSelector:
    def __init__(self, calls: list[SkillCall]) -> None:
        self.sequence = tuple(calls)
        self.calls = 0

    def select(self, task: str, obs: dict, history: list[SkillCall]) -> SkillCall:
        if self.calls >= len(self.sequence):
            raise SelectorOutputError("scripted sequence exhausted before environment success")
        call = self.sequence[self.calls]
        self.calls += 1
        return call


class SubprocessSelectorAdapter:
    """Load the unchanged legacy model with its original torch environment."""
    def __init__(self, config: dict, sample_builder: Callable, output: str | Path) -> None:
        self.config = config
        self.sample_builder = sample_builder
        self.output = Path(output)
        self.output.mkdir(parents=True, exist_ok=True)
        self.calls = 0

    def select(self, task: str, obs: dict, history: list[SkillCall]) -> SkillCall:
        import os
        import subprocess
        sample = self.sample_builder(task, obs, history)
        # Successful history length cannot identify a failed/retried invocation.
        sample['call_context']['decision_id']=f'live_{self.calls:03d}'
        prefix = self.output / f"decision_{self.calls:03d}"
        self.calls += 1
        input_path = prefix.with_suffix(".input.json")
        output_path = prefix.with_suffix(".output.json")
        config_path = prefix.with_suffix(".config.json")
        input_path.write_text(json.dumps(sample))
        config_path.write_text(json.dumps(self.config))
        root = Path(__file__).resolve().parents[2]
        env = dict(os.environ)
        for key in ("LD_PRELOAD", "LD_LIBRARY_PATH", "MUJOCO_GL", "PYOPENGL_PLATFORM"):
            env.pop(key, None)
        cache = self.output / "cache"
        cache.mkdir(exist_ok=True)
        env.update(PYTHONDONTWRITEBYTECODE="1", HF_HOME=str(cache / "hf"),
                   XDG_CACHE_HOME=str(cache), CUDA_CACHE_PATH=str(cache / "cuda"), TOKENIZERS_PARALLELISM="false")
        command = [str(Path(self.config["legacy_root"]) / ".venv/bin/python"), "-B",
                   str(root / "scripts/selector_worker.py"), "--input", str(input_path),
                   "--output", str(output_path), "--config", str(config_path)]
        import fcntl
        lockpath=Path(self.config.get('gpu_lock_path',root/'work/neural_gpu.lock'));lockpath.parent.mkdir(parents=True,exist_ok=True)
        with lockpath.open('a') as lock, prefix.with_suffix(".stdout.log").open("x") as log:
            fcntl.flock(lock,fcntl.LOCK_EX)
            result = subprocess.run(command, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=300)
        if result.returncode:
            raise SelectorOutputError("legacy model process failed; see " + str(prefix.with_suffix(".stdout.log")))
        result = json.loads(output_path.read_text())
        return parse_call(result["call"])


def apply_observed_effect_eligibility(model: Any, sample: dict) -> dict:
    """Restrict original grammar by already observed effects, never supply a plan.

    The original generation method and weights still select the output. Each
    rejected complete call is retained for audit; all surviving calls must be
    members of the unchanged original finite vocabulary.
    """
    original = model.candidates
    candidates = original(sample)
    effects = sample.get('measured_satisfied_effects', [])
    rejected=[];allowed=[]
    for call in candidates:
        bindings=call['bindings'];reason=None
        if call['primary'] in ('place_object_in_container','carry_container_to_region'):
            if any(e.get('effect')=='placement_satisfied' and
                   all(bindings.get(k)==e.get('bindings',{}).get(k) for k in ('object','target')) for e in effects):
                reason='native placement postcondition already satisfied'
        if reason:rejected.append({'call':call,'reason':reason})
        else:allowed.append(call)
    if not allowed:raise SelectorOutputError('no eligible original registered calls')
    model.candidates=lambda incoming: allowed if incoming is sample else original(incoming)
    return {'method':'observed-effect eligibility before original neural generation',
            'original_candidate_count':len(candidates),'eligible_candidate_count':len(allowed),
            'rejected':rejected,'original_candidates':candidates}
