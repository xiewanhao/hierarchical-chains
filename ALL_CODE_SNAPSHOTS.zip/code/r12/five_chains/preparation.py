"""Dimensionless preparation values; physical units enter at C8 readout."""
from __future__ import annotations
from copy import deepcopy
from typing import Any
import numpy as np
from five_chains.geometry import rigid
from five_chains.types import FieldKind,FieldSpec


def encode_preparation(spec: FieldSpec, value: Any, reference_m: float) -> Any:
    if value is None:return None
    if spec.kind==FieldKind.POSE:
        result=rigid(value);result[:3,3]/=reference_m;return result
    if spec.kind==FieldKind.POSITION:return np.asarray(value,dtype=float)/reference_m
    return deepcopy(value)


def decode_preparation(spec: FieldSpec, value: Any, reference_m: float) -> Any:
    if value is None:return None
    if spec.kind==FieldKind.POSE:
        result=rigid(value);result[:3,3]*=reference_m;return result
    if spec.kind==FieldKind.POSITION:return np.asarray(value,dtype=float)*reference_m
    return deepcopy(value)
