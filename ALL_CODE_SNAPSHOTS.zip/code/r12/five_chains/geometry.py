from __future__ import annotations
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.types import PhysParam,FieldKind


def rigid(value: object) -> np.ndarray:
    t = np.asarray(value, dtype=float)
    if (t.shape != (4, 4) or not np.isfinite(t).all()
            or not np.allclose(t[3], [0, 0, 0, 1])
            or not np.allclose(t[:3, :3].T @ t[:3, :3], np.eye(3), atol=1e-6)
            or not np.isclose(np.linalg.det(t[:3, :3]), 1, atol=1e-6)):
        raise ValueError("expected finite SE(3) matrix")
    return t.copy()


def inverse(value: np.ndarray) -> np.ndarray:
    t = rigid(value)
    out = np.eye(4)
    out[:3, :3] = t[:3, :3].T
    out[:3, 3] = -out[:3, :3] @ t[:3, 3]
    return out


def limited(value: np.ndarray, bound: float) -> np.ndarray:
    norm = np.linalg.norm(value)
    return value * min(1.0, bound / norm) if norm else value.copy()


def rotation_distance(a: np.ndarray, b: np.ndarray) -> float:
    return float(np.linalg.norm(Rotation.from_matrix(a @ b.T).as_rotvec()))


def pose(position: object, orientation: object | None = None) -> np.ndarray:
    t = np.eye(4)
    t[:3, 3] = np.asarray(position, dtype=float)
    if orientation is not None:
        t[:3, :3] = np.asarray(orientation, dtype=float)
    return rigid(t)


def motion_target(parameter: PhysParam, frame: np.ndarray, reference: np.ndarray) -> np.ndarray:
    if parameter.kind == FieldKind.POSE:
        return rigid(frame) @ rigid(parameter.value)
    if parameter.kind == FieldKind.POSITION:
        if parameter.value.shape != (3,):
            raise ValueError("position target must have three coordinates")
        target = rigid(reference)
        target[:3,3] = frame[:3,:3] @ parameter.value + frame[:3,3]
        return target
    raise ValueError("only a pose or position may be used as a motion target")
