"""Current-asset static pad preparation on a private native MuJoCo model.

Geometric proposals and static contact checks are not pretrained predictions or
physical success. They must pass normal IK, scene planning and live grasp checks.
"""
from __future__ import annotations
from copy import copy
from typing import Any
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose,inverse
from five_chains.envs.asset_geometry import collision_boxes_world


class CurrentAssetGrasps:
    def __init__(self, adapter: Any, config: dict, original: Any) -> None:
        self.adapter=adapter;self.config=config;self.original=original
        self.cache: dict[tuple,tuple[np.ndarray,...]]={};self.records: list[tuple[np.ndarray,dict]]=[]
        self.prepared_points: dict[tuple[str,bytes],np.ndarray]={}
        self.probes=0;self.rejected: list[dict[str,Any]]=[]
        self.inferred: list[tuple[np.ndarray,dict[str,Any]]]=[]

    def candidates(self, entity: str, world: Any) -> tuple[np.ndarray,...]:
        signatures=world.signals.get('grasp_signatures',{})
        if (world.signals.get('grasp_modes',{}).get(entity)=='rim' and
            signatures.get('objects',{}).get(entity)==getattr(self.original,'meta',{}).get('shape_sha256')):
            return self.original.candidates(entity,world)
        key=(entity,signatures.get('objects',{}).get(entity),signatures.get('gripper'),str(signatures.get('T_actual_gripper_root_TCP')))
        if key in self.cache:return self.cache[key]
        result=self._prepare(entity,world);self.cache[key]=result
        return result

    def _network_candidates(self, entity: str, world: Any) -> list[np.ndarray]:
        import hashlib,json,subprocess,fcntl
        from pathlib import Path
        from five_chains.envs.asset_geometry import collision_surface
        root=Path(__file__).resolve().parents[2]
        base=Path(self.config['grasp'].get('online_cache_directory',str(root/'work/graspgen_cache')))
        shape=world.signals['grasp_signatures']['objects'][entity];directory=base/shape
        directory.mkdir(parents=True,exist_ok=True)
        path=directory/'candidates.npz';metadata=directory/'candidates.json'
        if not metadata.exists():
            points=collision_surface(self.adapter.env,entity,4096,2710)
            tcp=world.signals['grasp_signatures']['T_actual_gripper_root_TCP']
            geometry=directory/'geometry.npz'
            np.savez_compressed(geometry,points_object_m=points,T_actual_gripper_root_TCP=np.asarray(tcp))
            asset=dict(entity=entity,shape_sha256=shape,gripper_sha256=world.signals['grasp_signatures']['gripper'],
                T_actual_gripper_root_TCP=tcp,geometry_sha256=hashlib.sha256(geometry.read_bytes()).hexdigest(),
                extent_m=world.entities[entity].extent.tolist(),scope='compiled collision mesh development input; no control steps')
            (directory/'asset.json').write_text(json.dumps(asset,indent=2))
            legacy=Path(self.config['selector']['legacy_root'])
            command=[str(legacy/'.graspgen-env/bin/python'),'-B',str(root/'scripts/infer_graspgen.py'),'--input',str(geometry),
                '--output',str(path),'--legacy-root',str(legacy),'--count','128','--seed','2711']
            lockpath=Path(self.config['selector'].get('gpu_lock_path',root/'work/neural_gpu.lock'));lockpath.parent.mkdir(exist_ok=True,parents=True)
            import os
            child_env=dict(os.environ)
            child_env['PYTHONPATH']=str(legacy/'third_party/graspgen_source')+os.pathsep+str(legacy)
            for key in ('LD_PRELOAD','LD_LIBRARY_PATH','MUJOCO_GL','PYOPENGL_PLATFORM'):child_env.pop(key,None)
            with lockpath.open('a') as lock:
                fcntl.flock(lock,fcntl.LOCK_EX)
                with (directory/('inference_'+str(len(list(directory.glob('inference*.log'))))+'.log')).open('x') as stream:
                    subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,env=child_env,check=True,timeout=300)
        info=json.loads(metadata.read_text())
        if (info['shape_sha256']!=shape or info['gripper_sha256']!=world.signals['grasp_signatures']['gripper'] or
            not np.allclose(info['T_actual_gripper_root_TCP'],world.signals['grasp_signatures']['T_actual_gripper_root_TCP'],atol=1e-6) or
            info['candidate_sha256']!=hashlib.sha256(path.read_bytes()).hexdigest()):raise ValueError('regenerated proposal signature mismatch')
        support=world.signals.get('object_support_frames',{}).get(entity)
        enclosed=support in world.signals.get('enclosed_support_entities',())
        with np.load(path,allow_pickle=False) as data:poses=np.array(data['T_O_actual_TCP']);scores=np.array(data['confidence'])
        result=[]
        for index in np.argsort(-scores)[:64]:
            if scores[index]<.5:continue
            target=poses[index];approach=(world.entities[entity].pose_world@target)[:3,2]
            if enclosed:
                if approach@world.entities[support].pose_world[:3,1]<.7:continue
            elif -approach[2]<np.cos(self.config['grasp']['max_top_approach_tilt_rad']):continue
            result.append(target.copy())
            self.inferred.append((target.copy(),dict(provider=info['provider'],confidence=float(scores[index]),
                source_candidate_index=int(index),candidate_sha256=info['candidate_sha256'],input_geometry_sha256=info['geometry_sha256'],
                checkpoint_sha256=info['checkpoint_sha256'],score_scope='raw pretrained proposal score; bounded contact edits are not rescored',
                inference_metadata=str(metadata))))
        return result

    def _prepare(self, entity: str, world: Any) -> tuple[np.ndarray,...]:
        import mujoco
        adapter=self.adapter;env=adapter.env;source=env.sim.model._model
        # Native plant/model arrays are never written. Only this private copy is repositioned.
        model=copy(source)
        if np.shares_memory(model.body_pos,source.body_pos) or np.shares_memory(model.geom_contype,source.geom_contype):
            raise RuntimeError('static grasp model must own independent mutable storage')
        data=mujoco.MjData(model);initial=np.asarray(env.sim.data.qpos).copy()
        data.qpos[:]=initial;mujoco.mj_forward(model,data)
        gripper=adapter.robot.gripper[adapter.arm];obj=env.objects[entity]
        gid=lambda name:int(mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,name))
        bid=lambda name:int(mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,name))
        target_ids={gid(n) for n in obj.contact_geoms};grip_ids=set(map(int,adapter.gripper_collision_ids))
        names={i:mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_GEOM,i) or '' for i in grip_ids}
        pads=[{i for i,n in names.items() if f'finger{side}_pad_collision' in n} for side in (1,2)]
        if any(len(p)!=1 for p in pads):raise ValueError('current-asset preparation requires two native pad collision geoms')
        nonpads=grip_ids-(pads[0]|pads[1])
        keep=np.array(sorted(target_ids|grip_ids),int)
        ct=model.geom_contype[keep].copy();ca=model.geom_conaffinity[keep].copy()
        model.geom_contype[:]=0;model.geom_conaffinity[:]=0
        model.geom_contype[keep]=ct;model.geom_conaffinity[keep]=ca
        # The reduced static query measures only own-object/pad geometry;
        # fixtures and arm are still checked by the full live scene planner.
        root=bid(gripper.root_body);parent=int(model.body_parentid[root])
        parent_pose=pose(data.xpos[parent],data.xmat[parent].reshape(3,3))
        root_pose=pose(data.xpos[root],data.xmat[root].reshape(3,3))
        tcp=adapter.current_pose();root_tcp=inverse(root_pose)@tcp
        object_pose=world.entities[entity].pose_world
        joint_ids=[int(mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,n)) for n in gripper.joints]
        if len(joint_ids)!=2 or any(model.jnt_type[j]!=2 for j in joint_ids):raise ValueError('unverified gripper joints')
        indices=[int(model.jnt_qposadr[j]) for j in joint_ids]
        opened=np.array([model.jnt_range[j][np.argmax(np.abs(model.jnt_range[j]))] for j in joint_ids])
        cfg=self.config['grasp']['contact_refinement']
        def probe(contact):
            target=object_pose@contact@inverse(root_tcp);local=inverse(parent_pose)@target
            model.body_pos[root]=local[:3,3]
            quat=Rotation.from_matrix(local[:3,:3]).as_quat();model.body_quat[root]=quat[[3,0,1,2]];model.body_sameframe[root]=0
            for fraction in np.linspace(1.,0.,int(cfg['apertures'])):
                self.probes+=1;data.qpos[:]=initial;data.qpos[indices]=opened*fraction;mujoco.mj_forward(model,data)
                sides=[[],[]];nonpad=0.
                for c in data.contact[:data.ncon]:
                    a,b=int(c.geom1),int(c.geom2)
                    if (a in nonpads and b in target_ids) or (b in nonpads and a in target_ids):nonpad=max(nonpad,-float(c.dist))
                    for side,group in enumerate(pads):
                        if a in group and b in target_ids:pad=a
                        elif b in group and a in target_ids:pad=b
                        else:continue
                        offset=data.geom_xmat[pad].reshape(3,3).T@(c.pos-data.geom_xpos[pad])
                        sides[side].append(dict(offset=float(offset[2]),margin=float(model.geom_size[pad,2]-abs(offset[2])),penetration=max(0.,-float(c.dist))))
                if all(sides):
                    contacts=[max(s,key=lambda p:p['margin']) for s in sides]
                    return dict(contacts=contacts,nonpad_penetration_m=nonpad,opening_fraction=float(fraction),
                        opening_axis_object=object_pose[:3,:3].T@data.xaxis[joint_ids[0]])
            return None
        item=world.entities[entity];support=world.signals.get('object_support_frames',{}).get(entity)
        enclosed=support in world.signals.get('enclosed_support_entities',())
        opening_local=np.asarray(world.signals.get('gripper_opening_axis_eef',[1.,0.,0.]),float).copy()
        opening_local[2]=0.;opening_local/=np.linalg.norm(opening_local)
        local_basis=np.column_stack([opening_local,np.cross([0.,0.,1.],opening_local),[0.,0.,1.]])
        raw=[]
        if enclosed:
            fixture=world.entities[support];approach=fixture.pose_world[:3,1].copy();approach[2]=0.;approach/=np.linalg.norm(approach)
            opening=np.cross(approach,[0.,0.,1.]);opening/=np.linalg.norm(opening)
            for sign in (1.,-1.):
                r=np.column_stack([opening*sign,np.cross(approach,opening*sign),approach])@local_basis.T
                for depth in (-.08,-.06,-.04,-.02,0.,.02):
                    for lateral in (0.,-.02,.02):
                        for height in (0.,-.015,.015):
                            center=object_pose[:3,3]+approach*depth+opening*lateral+[0,0,height]
                            raw.append(inverse(object_pose)@pose(center,r))
        else:
            from five_chains.skills.recipes import GeometricGraspProvider
            if world.signals.get('grasp_modes',{}).get(entity)=='rim':
                from copy import deepcopy
                for tilt in (0.,.3,.5):
                    cfg2=deepcopy(self.config);cfg2['grasp']['rim_approach_tilt_rad']=tilt
                    for t in GeometricGraspProvider(cfg2).candidates(entity,world):
                        for dz in (0.,-.015,.015):
                            extra=t.copy();extra[2,3]+=dz;raw.append(extra)
            else:
                raw=list(GeometricGraspProvider(self.config).candidates(entity,world))
                for t in tuple(raw):
                    for dz in (-.015,.015):
                            extra=t.copy();extra[2,3]+=dz;raw.append(extra)
        if self.config['grasp'].get('online_graspgen',False):raw=self._network_candidates(entity,world)+raw
        admitted=[]
        for original in raw:
            t=original.copy();record=None;reason='iteration_limit'
            for _ in range(int(cfg['iterations'])):
                record=probe(t)
                if record is None:reason='no_bilateral_pad_geometry';break
                left,right=record['contacts'];offsets=[left['offset'],right['offset']]
                if abs(offsets[0]-offsets[1])>cfg['max_depth_disagreement_m']:reason='opposite_pad_ends';break
                imbalance=left['penetration']-right['penetration']
                if (min(left['margin'],right['margin'])>=cfg['min_pad_margin_m'] and abs(imbalance)<=cfg['max_imbalance_m']
                    and max(left['penetration'],right['penetration'])<=cfg['max_penetration_m'] and record['nonpad_penetration_m']<=cfg['max_nonpad_penetration_m']):
                    admitted.append(t.copy())
                    points=collision_boxes_world(model,data,np.array(sorted(grip_ids),int))
                    self.prepared_points[(entity,t.tobytes())]=(points-object_pose[:3,3])@object_pose[:3,:3]
                    origin=next((meta.copy() for candidate,meta in self.inferred if np.allclose(candidate,original,atol=1e-7)),{})
                    if 'provider' in origin:origin['proposal_provider']=origin.pop('provider')
                    self.records.append((t.copy(),dict(provider='current-asset geometric proposal + private native pad check',
                        physical_success_verified=False,source_shape=world.signals['grasp_signatures']['objects'][entity],
                        contact_margins_m=[left['margin'],right['margin']],opening_fraction=record['opening_fraction'],
                        approach_policy='cabinet_front' if enclosed else 'top',scope='static own-object contact geometry, not scene path or holding validation',**origin)))
                    break
                depth=float(np.clip(np.mean(offsets),-cfg['max_depth_step_m'],cfg['max_depth_step_m']))
                shift=float(np.clip(imbalance/2,-cfg['max_lateral_step_m'],cfg['max_lateral_step_m']))
                t[:3,3]+=depth*t[:3,2]+shift*record['opening_axis_object']
                if np.linalg.norm(t[:3,3]-original[:3,3])>cfg['max_total_shift_m']:reason='shift_bound';break
            else:reason='iteration_limit'
            if not admitted or not np.allclose(admitted[-1],t,atol=1e-7):
                self.rejected.append(dict(reason=reason,contacts=None if record is None else record['contacts'],nonpad_penetration_m=None if record is None else record['nonpad_penetration_m']))
        return tuple(admitted)

    def filter_for_followup(self,entity,world,candidates,target,goal_object_world):
        keys=[(entity,t.tobytes()) for t in candidates]
        points=tuple(self.prepared_points[k] for k in keys) if all(k in self.prepared_points for k in keys) else None
        return self.original.filter_for_followup(entity,world,candidates,target,goal_object_world,candidate_points_object=points)

    def describe(self, matrix):
        for candidate,record in self.records:
            if np.allclose(candidate,matrix,atol=1e-7):return record
        return self.original.describe(matrix) if hasattr(self.original,'describe') else {'provider':'geometric'}
