"""Asset-bound pretrained proposals, guarded against stale geometry/TCP reuse."""
from __future__ import annotations
from pathlib import Path
from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from five_chains.skills.recipes import GraspProvider
import hashlib,json
import numpy as np
from five_chains.geometry import rigid,inverse
from five_chains.types import WorldState,ReadoutError


class AssetGraspProvider:
    def __init__(self, config: dict, fallback: GraspProvider) -> None:
        self.config=config;self.fallback=fallback
        directory=Path(config['grasp']['asset_candidates']['directory'])
        if not directory.is_absolute():directory=Path(__file__).resolve().parents[2]/directory
        self.meta=json.loads((directory/'candidates.json').read_text())
        path=directory/'candidates.npz'
        if hashlib.sha256(path.read_bytes()).hexdigest()!=self.meta['candidate_sha256']:
            raise ValueError('candidate cache checksum mismatch')
        with np.load(path,allow_pickle=False) as data:
            self.poses=np.array(data['T_O_actual_TCP'],copy=True);self.scores=np.array(data['confidence'],copy=True)
            self.gripper_points=np.array(data['gripper_points_object'],copy=True) if 'gripper_points_object' in data else None
            self.source_indices=np.array(data['source_index'],copy=True) if 'source_index' in data else np.arange(len(self.scores))
        if self.poses.shape!=(len(self.scores),4,4) or not np.isfinite(self.scores).all():raise ValueError('invalid proposal array')
        for target in self.poses:rigid(target)

    def candidates(self, entity: str, world: WorldState) -> tuple[np.ndarray,...]:
        if world.signals.get('grasp_modes',{}).get(entity)!='rim':
            return self.fallback.candidates(entity,world)
        sig=world.signals.get('grasp_signatures',{})
        if sig.get('objects',{}).get(entity)!=self.meta['shape_sha256']:
            raise ReadoutError('GraspGen cache does not match current object collision geometry')
        if sig.get('gripper')!=self.meta['gripper_sha256'] or not np.allclose(
                sig.get('T_actual_gripper_root_TCP',np.zeros((4,4))),self.meta['T_actual_gripper_root_TCP'],atol=1e-6):
            raise ReadoutError('GraspGen cache does not match gripper geometry/TCP calibration')
        cfg=self.config['grasp']['asset_candidates'];item=world.entities[entity]
        result=[]
        for index in np.argsort(-self.scores):
            if self.scores[index]<cfg['min_confidence']:continue
            t=self.poses[index].copy()
            approach=(item.pose_world@t)[:3,2]
            tilt=np.arccos(np.clip(-approach[2],-1,1))
            if tilt>cfg['max_approach_tilt_rad']:continue
            opening=np.asarray(world.signals.get('gripper_opening_axis_eef',[1.,0.,0.]),float)
            opening=opening/np.linalg.norm(opening)
            jaw_tilt=np.arcsin(np.clip(abs(float(((item.pose_world@t)[:3,:3]@opening)[2])),0.,1.))
            if jaw_tilt>cfg['max_jaw_tilt_rad']:continue
            top=np.asarray(world.signals['object_top_offsets'][entity])[2]
            if not top-cfg['max_depth_below_rim_m']<=t[2,3]<=top+cfg['max_above_rim_m']:continue
            if not cfg['min_radial_fraction']*float(np.min(item.extent[:2]))<=np.linalg.norm(t[:2,3])<=cfg['max_radial_fraction']*float(np.max(item.extent[:2])):continue
            result.append(t)
            # Parallel jaws admit this symmetry, without changing the contact point.
            alternate=t.copy();alternate[:3,:3]=t[:3,:3]@np.diag([-1.,-1.,1.]);result.append(alternate)
            if len(result)>=2*cfg['top_k']:break
        return tuple(result)

    def filter_for_followup(self, entity: str, world: WorldState, candidates: tuple[np.ndarray,...],
                            target: str, goal_object_world: np.ndarray,
                            candidate_points_object: tuple[np.ndarray,...] | None = None) -> tuple[np.ndarray,...]:
        cavity=world.entities[target];extent=cavity.extent
        goal_object_world=rigid(goal_object_world)
        transform=inverse(cavity.pose_world)@goal_object_world
        obstacles=[]
        for name in world.signals.get('cavity_obstacles',{}).get(target,()):
            if name not in world.entities:raise ReadoutError('missing predicted collision obstacle: '+name)
            obstacles.append(world.entities[name])
        margin=self.config['grasp']['asset_candidates']['future_geometry_margin_m']
        allowed=[]
        if candidate_points_object is not None and len(candidate_points_object)!=len(candidates):
            raise ReadoutError('candidate-specific geometry count mismatch')
        for candidate_index,t in enumerate(candidates):
            points=None;matched=False
            if candidate_points_object is not None:
                points=np.asarray(candidate_points_object[candidate_index],float)
                if points.ndim!=2 or points.shape[1]!=3 or not len(points) or not np.isfinite(points).all():
                    raise ReadoutError('invalid candidate-specific gripper geometry')
                matched=True
            for index,original in enumerate(self.poses):
                if matched:break
                if not (np.allclose(t,original,atol=1e-7) or (np.allclose(t[:3,3],original[:3,3],atol=1e-7) and np.allclose(t[:3,:3],original[:3,:3]@np.diag([-1.,-1.,1.]),atol=1e-7))):continue
                matched=True
                if self.gripper_points is None:
                    if self.config['grasp']['asset_candidates']['require_future_geometry']:
                        raise ReadoutError('future fit requires cached gripper collision points')
                    allowed.append(t);break
                rotation=t@inverse(original)
                points=self.gripper_points[index]@rotation[:3,:3].T+rotation[:3,3]
                break
            if not matched:
                # A geometric proposal is not an old asset-cache entry. Transform
                # the live, calibrated collision boxes via TCP into this proposal.
                live=np.asarray(world.signals.get('gripper_collision_points_world',[]),float)
                if live.ndim!=2 or live.shape[1]!=3 or not len(live) or not np.isfinite(live).all():continue
                tcp_points=(live-world.eef_pose_world[:3,3])@world.eef_pose_world[:3,:3]
                points=tcp_points@t[:3,:3].T+t[:3,3]
            if points is None:continue
            local=points@transform[:3,:3].T+transform[:3,3]
            inside=local[:,1]>=-extent[1]
            cavity_fit=(np.all(np.abs(local[inside,0])<=extent[0]-margin) and np.all(local[inside,1]<=extent[1]-margin) and np.all(np.abs(local[inside,2])<=extent[2]-margin))
            world_points=points@goal_object_world[:3,:3].T+goal_object_world[:3,3]
            obstacle_fit=True
            for obstacle in obstacles:
                obstacle_points=(world_points-obstacle.pose_world[:3,3])@obstacle.pose_world[:3,:3]
                if np.any(np.all(np.abs(obstacle_points)<=obstacle.extent+margin,axis=1)):
                    obstacle_fit=False;break
            if cavity_fit and obstacle_fit:allowed.append(t)
        return tuple(allowed)

    def describe(self, matrix: np.ndarray) -> dict:
        # The pregrasp waypoint is separately translated by the recipe; only the
        # selected contact pose is matched here for audit provenance.
        for index,target in enumerate(self.poses):
            if np.allclose(matrix,target,atol=1e-7) or (np.allclose(matrix[:3,3],target[:3,3],atol=1e-7)
                    and np.allclose(matrix[:3,:3],target[:3,:3]@np.diag([-1.,-1.,1.]),atol=1e-7)):
                return {'provider':self.meta['provider'],'candidate_index':index,'source_candidate_index':int(self.source_indices[index]),
                        'score_scope':self.meta.get('score_scope','raw source inference score; any geometric edits were not rescored'),
                        'static_contact_refinement':self.meta.get('refinement_reports',[None]*len(self.poses))[index], 'confidence':float(self.scores[index]),
                        'candidate_sha256':self.meta['candidate_sha256'],'shape_sha256':self.meta['shape_sha256'],
                        'mount_shift_m':self.meta['mount_shift_m'],'physical_success_verified':False}
        return {'provider':'geometric_or_pregrasp'}
