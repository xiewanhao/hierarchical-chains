"""Declarative skills and pure field recipes."""
