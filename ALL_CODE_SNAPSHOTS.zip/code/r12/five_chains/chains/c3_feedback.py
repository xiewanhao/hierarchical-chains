from __future__ import annotations
from five_chains.types import (ChainId, Contract, ParamPacket, FeedbackDelta, Components,
    Proposal, P6, P7, WorldState)


def chain3a_fast(contract: Contract, packet: ParamPacket, delta: FeedbackDelta,
                 C: Components, cfg: dict) -> Proposal | None:
    if not any(abs(delta.continuous.get(k, 0)) > th for k, th in cfg["fb_fast"]["thresholds"].items()):
        return None
    updates = C.c8.fast_adjust(contract, packet, delta)
    return Proposal(ChainId.FB_FAST, updates) if updates else None


def chain3b_full(contract: Contract, p6: P6, p7: P7, world: WorldState,
                 delta: FeedbackDelta, C: Components) -> tuple[P6, P7, Proposal | None]:
    new_p7 = C.c7.update(contract, p7, world, delta)
    # An unrelated edge must not re-anchor a relative motion goal to the
    # already moving object (e.g. repeated +lift-height targets).
    if new_p7.phase_index == p7.phase_index:
        if 'grasp_relation_changed' in delta.events:
            phase=contract.phases[new_p7.phase_index]
            obj=contract.call.bindings.get('object')
            # Destination-frame/world P6 remains fixed. Re-reading source-relative
            # lift offsets would repeatedly move the goal, so exclude those.
            fields=frozenset(n for n in phase.fields if C.c12.may_write(contract,n,ChainId.FB_FULL)
                and contract.fields[n].arguments.get('held_object_goal') and contract.fields[n].prep_frame!=obj)
            if fields:
                updates=C.c8.readout(contract,p6,new_p7,world,fields,ChainId.FB_FULL)
                return p6,new_p7,Proposal(ChainId.FB_FULL,updates,C.c8.bounds(contract,new_p7))
        return p6, new_p7, None
    phase = contract.phases[new_p7.phase_index]
    affected = frozenset(n for n in phase.fields if C.c12.may_write(contract, n, ChainId.FB_FULL))
    if not affected:
        return p6, new_p7, None
    p6 = C.c6.prepare(contract, world, p6, affected, ChainId.FB_FULL)
    updates = C.c8.readout(contract, p6, new_p7, world, affected, ChainId.FB_FULL)
    return p6, new_p7, Proposal(ChainId.FB_FULL, updates, C.c8.bounds(contract, new_p7))
