from __future__ import annotations
from five_chains.types import ParamPacket, Components, ReflexOverride


def chain2_reflex(packet: ParamPacket, obs: dict, C: Components) -> ReflexOverride | None:
    return C.c9.step(packet.bounds, obs)
