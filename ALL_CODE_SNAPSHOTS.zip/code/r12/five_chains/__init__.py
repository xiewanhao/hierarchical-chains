"""Selected skill -> authorized field computation -> one executor."""
