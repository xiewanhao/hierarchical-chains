"""Deterministic contract test fixture. NOT MuJoCo, contact physics, or a benchmark.

It tracks supplied TCP targets and supplies controllable event predicates so tests
can exhaust the complete five-decision/L4 call lifecycle and ablation switches.
Physical success must be evaluated separately with RoboCasaAdapter.
"""
from __future__ import annotations
from typing import Any
from copy import deepcopy
import numpy as np
from five_chains.geometry import pose, inverse, rotation_distance


class KinematicTestbed:
    def __init__(self, config: dict) -> None:
        self.config = config
        self.control_freq = 20.
        self.executions = 0
        self.phase_key: tuple | None = None
        self.phase_ticks = 0
        self.context: Any = None
        self.gripper = "open"
        self.actuator = "arm"
        self.state: dict = {}
        self.held: str | None = None
        self.relations: dict = {}
        self.completed = False
        self.reset(self)

    def reset(self, env: Any) -> dict:
        locations = {"vegetable": [.2, 0, .8], "bowl": [.4, 0, .8],
                     "microwave": [.6, .2, 1.], "microwave_interior": [.6, .2, 1.],
                     "handle": [.5, .2, 1.], "start": [.65, .2, 1.]}
        self.state = dict(entities={name: dict(pose_world=pose(pos), extent=[.03]*3, joints={}) for name,pos in locations.items()},
                          eef_pose_world=pose([.2,0,1.]), base_pose_world=np.eye(4), gripper_width=.08,
                          signals={"predicates": {}, "continuous": {}})
        self.executions = 0
        self.phase_key = None
        self.phase_ticks = 0
        self.context = None
        self.held = None
        self.relations.clear()
        self.completed = False
        self.torso_position=0.
        self.door_closed=False
        return self.observe({})

    def set_execution_context(self, contract: Any, p7: Any, target: np.ndarray, error: float) -> None:
        self.context = (contract,p7,target.copy(),error)

    def pose_action(self, target: np.ndarray, gripper: str, stiffness: float) -> np.ndarray:
        self.gripper = gripper
        self.actuator = "arm"
        return np.r_[target.reshape(-1), 1. if gripper == "close" else -1., stiffness]

    def base_pose_action(self, target: np.ndarray, gripper: str, stiffness: float, speed_limit: float | None = None) -> np.ndarray:
        action=self.pose_action(target,gripper,stiffness)
        self.actuator='base'
        return action

    def torso_action(self, target: float, gripper: str, stiffness: float) -> np.ndarray:
        action=self.pose_action(pose([0.,0.,target]),gripper,stiffness)
        self.actuator='torso'
        return action

    def step(self, action: np.ndarray) -> tuple[dict, float, bool, dict]:
        self.executions += 1
        next_pose=action[:16].reshape(4,4).copy()
        if self.actuator=='torso':
            delta=next_pose[2,3]-self.torso_position
            self.torso_position=float(next_pose[2,3]);self.state['eef_pose_world'][2,3]+=delta
        elif self.actuator=='base':
            delta=next_pose@inverse(self.state['base_pose_world'])
            self.state['base_pose_world']=next_pose
            self.state['eef_pose_world']=delta@self.state['eef_pose_world']
        else:
            self.state["eef_pose_world"] = next_pose
        contract,p7,target,error=self.context
        key=(contract.contract_id,p7.phase_index)
        self.phase_ticks=self.phase_ticks+1 if self.phase_key==key else 0
        self.phase_key=key
        obj=contract.call.bindings.get("object")
        if p7.phase_name=="grasp" and self.gripper=="close" and self.phase_ticks>=2:
            self.held=obj
            self.relations[obj]=inverse(self.state["eef_pose_world"])@self.state["entities"][obj]["pose_world"]
        if self.held and self.gripper=="open":
            self.relations.pop(self.held,None)
            self.held=None
        if self.held:
            self.state["entities"][self.held]["pose_world"]=self.state["eef_pose_world"]@self.relations[self.held]
        current=self.state['base_pose_world'] if self.actuator=='base' else self.state["eef_pose_world"]
        if self.actuator=='torso':
            target=pose([0.,0.,float(target)]);current=pose([0.,0.,self.torso_position])
        distance=float(np.linalg.norm(current[:3,3]-target[:3,3]))
        reached=(distance<self.config["control"]["reached_m"] and rotation_distance(current[:3,:3],target[:3,:3])<self.config["control"]["reached_rad"] and self.phase_ticks>=8)
        flags={"reached":reached,"grasp_established":self.held==obj and obj is not None,
               "released":self.held!=obj and self.phase_ticks>=8,"placed":p7.phase_name in ("release","retreat"),
               "local_complete":reached,"object_at_entrance":reached and p7.phase_name=="carry"}
        flags['placed_and_retreated']=flags['placed'] and reached and p7.phase_name=='retreat'
        flags['base_reached']=reached and self.actuator=='base'
        flags['torso_reached']=reached and self.actuator=='torso'
        flags['lift_complete']=reached and p7.phase_name=='lift' and self.held==obj
        if contract.call.skill=="close_hinged_door" and p7.phase_name=="close" and reached:
            self.door_closed=True
        if contract.call.skill=="activate_control" and p7.phase_name=="press" and reached:
            flags["button_pressed"]=True
            self.completed=True
        flags['door_closed']=self.door_closed
        flags['door_closed_settled']=bool(self.door_closed and p7.phase_name=='settle_door' and self.phase_ticks>=8)
        flags['door_closed_and_retreated']=bool(self.door_closed and p7.phase_name=='release_contact' and reached)
        flags['activated_and_retreated']=bool(self.completed and p7.phase_name=='release_contact' and reached)
        self.state["signals"]={"predicates":flags,"continuous":{"eef_track_err":error,"tilt_dev":0.},
                                "grasp_transforms":deepcopy(self.relations),"target_distance_m":distance}
        return {},0.,False,{}

    def observe(self, raw_obs: dict) -> dict:
        state=deepcopy(self.state)
        state['signals']['torso']={'position_m':self.torso_position,'range_m':[0.,.34],
            'origin_world':np.array([0.,0.,.7+self.torso_position])}
        state['signals']['microwave_hinge']={'axis_world':np.array([0.,0.,1.]),'anchor_world':np.array([.5,.2,1.]),'angle':0.}
        state['signals']['surface_normals']={'handle':np.array([0.,-1.,0.]),'start':np.array([0.,-1.,0.])}
        return {"state":state}

    def success(self) -> bool:
        return self.completed
