"""Immutable compiled-shape signatures and object-local surface export."""
from __future__ import annotations
import hashlib
import json
from typing import Any
import numpy as np
from five_chains.geometry import pose,inverse


def shape_digest(env: Any, geoms: list[str], root_body: str) -> str:
    model=env.sim.model._model
    root=env.sim.model.body_name2id(root_body)
    h=hashlib.sha256()
    for name in sorted(geoms):
        gid=env.sim.model.geom_name2id(name)
        h.update(name.encode())
        for values in (model.geom_type[gid:gid+1],model.geom_size[gid],model.geom_pos[gid],model.geom_quat[gid]):
            h.update(np.asarray(values).tobytes())
        body=int(model.geom_bodyid[gid])
        while body!=root:
            if body==0:raise ValueError('geometry is not attached to expected root')
            h.update(np.asarray(model.body_pos[body]).tobytes());h.update(np.asarray(model.body_quat[body]).tobytes())
            body=int(model.body_parentid[body])
        mesh=int(model.geom_dataid[gid])
        if int(model.geom_type[gid])==7 and mesh>=0:
            va=int(model.mesh_vertadr[mesh]);vn=int(model.mesh_vertnum[mesh])
            fa=int(model.mesh_faceadr[mesh]);fn=int(model.mesh_facenum[mesh])
            h.update(np.asarray(model.mesh_vert[va:va+vn]).tobytes())
            h.update(np.asarray(model.mesh_face[fa:fa+fn]).tobytes())
    return h.hexdigest()


def grasp_signatures(env: Any, arm: str) -> dict:
    gripper=env.robots[0].gripper[arm]
    groups=sorted(set(n for names in gripper.important_geoms.values() for n in names))
    # Some important_geoms entries are optional; only installed names are used.
    groups=[n for n in groups if n in env.sim.model.geom_names]
    grip=shape_digest(env,groups,gripper.root_body)
    root=pose(env.sim.data.get_body_xpos(gripper.root_body),env.sim.data.get_body_xmat(gripper.root_body))
    site=env.robots[0].eef_site_id[arm]
    tcp=pose(env.sim.data.site_xpos[site],env.sim.data.site_xmat[site].reshape(3,3))
    return {'objects':{name:shape_digest(env,list(item.contact_geoms),item.root_body) for name,item in env.objects.items()},
            'gripper':grip,'T_actual_gripper_root_TCP':(inverse(root)@tcp).tolist()}


def collision_surface(env: Any, entity: str, points: int, seed: int) -> np.ndarray:
    model=env.sim.model._model;item=env.objects[entity]
    body=pose(env.sim.data.get_body_xpos(item.root_body),env.sim.data.get_body_xmat(item.root_body))
    triangles=[]
    for name in item.contact_geoms:
        gid=env.sim.model.geom_name2id(name);mid=int(model.geom_dataid[gid])
        if int(model.geom_type[gid])!=7 or mid<0:raise ValueError('surface export requires mesh collision geometry')
        va=int(model.mesh_vertadr[mid]);vn=int(model.mesh_vertnum[mid]);fa=int(model.mesh_faceadr[mid]);fn=int(model.mesh_facenum[mid])
        vertices=np.asarray(model.mesh_vert[va:va+vn],dtype=float)
        faces=np.asarray(model.mesh_face[fa:fa+fn],dtype=int)
        if faces.max()>=vn:
            if faces.min()>=va and faces.max()<va+vn:faces=faces-va
            else:raise ValueError('unexpected mesh face indices')
        world=vertices@env.sim.data.geom_xmat[gid].reshape(3,3).T+env.sim.data.geom_xpos[gid]
        local=(world-body[:3,3])@body[:3,:3]
        triangles.append(local[faces])
    tri=np.concatenate(triangles)
    area=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2
    keep=area>1e-12;tri=tri[keep];area=area[keep]
    rng=np.random.default_rng(seed);tri=tri[rng.choice(len(tri),size=points,p=area/area.sum())]
    uv=rng.random((points,2));fold=uv.sum(1)>1;uv[fold]=1-uv[fold]
    return (tri[:,0]+uv[:,0,None]*(tri[:,1]-tri[:,0])+uv[:,1,None]*(tri[:,2]-tri[:,0])).astype(np.float32)


def collision_boxes_world(model: Any, data: Any, geom_ids: np.ndarray) -> np.ndarray:
    """Conservative native collision-AABB corners in world coordinates."""
    from itertools import product
    signs=np.array(list(product((-1.,1.),repeat=3)))
    result=[]
    for index in np.asarray(geom_ids,int):
        bounds=np.asarray(model.geom_aabb[index])
        local=bounds[:3]+signs*bounds[3:]
        rotation=np.asarray(data.geom_xmat[index]).reshape(3,3)
        result.append(local@rotation.T+np.asarray(data.geom_xpos[index]))
    return np.concatenate(result) if result else np.empty((0,3))
