"""Bounded joint-path search and static scene checks on private MuJoCo data.

This samples geometry; it is not continuous collision or dynamics certification.
No physics integration or environment command is issued here.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose


@dataclass(frozen=True)
class JointPlan:
    path: tuple[np.ndarray, ...]
    iterations: int
    nodes: int
    initial_clear: bool
    status: str


def plan_joint_path(start: np.ndarray, goals: tuple[np.ndarray, ...], lower: np.ndarray,
                    upper: np.ndarray, valid: Callable[[np.ndarray], bool], config: dict,
                    native_lower: np.ndarray | None = None, native_upper: np.ndarray | None = None) -> JointPlan:
    start=np.asarray(start,float).copy();lower=np.asarray(lower,float);upper=np.asarray(upper,float)
    if start.shape!=lower.shape or upper.shape!=lower.shape or np.any(lower>=upper):
        raise ValueError('invalid joint planning bounds')
    hard_lower=lower if native_lower is None else np.asarray(native_lower,float)
    hard_upper=upper if native_upper is None else np.asarray(native_upper,float)
    if hard_lower.shape!=lower.shape or hard_upper.shape!=upper.shape or np.any(hard_lower>lower) or np.any(hard_upper<upper):
        raise ValueError('planning margin must lie inside native limits')
    if not np.isfinite(start).all() or np.any(start<hard_lower) or np.any(start>hard_upper):
        return JointPlan((),0,0,False,'start_outside_limits')
    rng=np.random.default_rng(config['seed']);initial_clear=valid(start)
    def edge(a: np.ndarray,b: np.ndarray) -> bool:
        n=max(1,int(np.ceil(np.max(np.abs(b-a))/config['validation_step_rad'])))
        return all(valid(a+(b-a)*i/n) for i in range(1,n+1))
    def branch(nodes: list[np.ndarray], parents: list[int], i: int) -> list[np.ndarray]:
        out=[]
        while i>=0:out.append(nodes[i]);i=parents[i]
        return out[::-1]
    def extend(nodes: list[np.ndarray], parents: list[int], target: np.ndarray) -> int | None:
        i=int(np.argmin([np.linalg.norm(q-target) for q in nodes]));delta=target-nodes[i];length=np.linalg.norm(delta)
        if length<1e-12:return i
        q=target.copy() if length<=config['extension_rad'] else nodes[i]+delta*config['extension_rad']/length
        if not edge(nodes[i],q):return None
        nodes.append(q);parents.append(i);return len(nodes)-1
    admitted=[np.asarray(q,float).copy() for q in goals if q.shape==start.shape and np.isfinite(q).all()
              and np.all(q>=lower) and np.all(q<=upper) and valid(q)]
    if not admitted:return JointPlan((),0,0,initial_clear,'no_clear_goal')
    found: list[np.ndarray] | None=None;total_nodes=0;iterations=0
    for goal in sorted(admitted,key=lambda q:float(np.linalg.norm(q-start))):
        if edge(start,goal):found=[start,goal];break
        A=[start];Ap=[-1];B=[goal];Bp=[-1]
        for it in range(config['iterations']):
            iterations+=1;target=B[0] if rng.random()<config['goal_bias'] else rng.uniform(lower,upper)
            ia=extend(A,Ap,target)
            if ia is not None:
                for _ in range(config['connect_steps']):
                    ib=extend(B,Bp,A[ia])
                    if ib is None:break
                    if np.linalg.norm(B[ib]-A[ia])<1e-8:
                        found=branch(A,Ap,ia)+branch(B,Bp,ib)[-2::-1];break
                if found is not None:break
            A,B=B,A;Ap,Bp=Bp,Ap
        total_nodes+=len(A)+len(B)
        if found is not None:
            if np.linalg.norm(found[0]-start)>1e-8:found=found[::-1]
            break
    if found is None:return JointPlan((),iterations,total_nodes,initial_clear,'search_exhausted')
    for _ in range(config['shortcut_attempts']):
        if len(found)<3:break
        a,b=sorted(rng.choice(len(found),2,replace=False).tolist())
        if b>a+1 and edge(found[a],found[b]):found=found[:a+1]+found[b:]
    # Dense FK waypoints reduce the Cartesian chord error in the OSC follower.
    dense=[found[0].copy()]
    for a,b in zip(found,found[1:]):
        n=max(1,int(np.ceil(np.max(np.abs(b-a))/config['waypoint_step_rad'])))
        dense.extend(a+(b-a)*i/n for i in range(1,n+1))
    return JointPlan(tuple(dense),iterations,total_nodes,initial_clear,
                     'sampled_clear' if initial_clear else 'sampled_escape_from_initial_contact')


def sampled_joint_connection(start: np.ndarray, goal: np.ndarray, lower: np.ndarray,
                             upper: np.ndarray, valid: Callable[[np.ndarray], bool],
                             step_rad: float, native_lower: np.ndarray | None = None,
                             native_upper: np.ndarray | None = None) -> bool:
    """Validate a connection from attained joints, including both endpoints."""
    hard_lower=lower if native_lower is None else np.asarray(native_lower,float)
    hard_upper=upper if native_upper is None else np.asarray(native_upper,float)
    if not np.isfinite(start).all() or np.any(start<hard_lower) or np.any(start>hard_upper):return False
    if not np.isfinite(goal).all() or np.any(goal<lower) or np.any(goal>upper):return False
    count=max(1,int(np.ceil(np.max(np.abs(goal-start))/step_rad)))
    return all(valid(start+(goal-start)*i/count) for i in range(count+1))


class StaticScene:
    def __init__(self, model: Any, site: int, arm_qpos: np.ndarray) -> None:
        import mujoco
        self.mj=mujoco;self.model=model;self.data=mujoco.MjData(model);self.site=site
        self.arm_qpos=np.asarray(arm_qpos,int);self.qpos=np.asarray(model.qpos0).copy()
        self.held: dict[str,np.ndarray]={};self.object_joints: dict[str,int]={}
        self.contact_entity: str | None=None;self.relation: np.ndarray | None=None;self.max_tilt: float | None=None
        self.epsilon=1e-6;self.checks=0;self.payload=np.zeros(model.ngeom,dtype=bool)
        self.names=[mujoco.mj_id2name(model,mujoco.mjtObj.mjOBJ_GEOM,i) or '' for i in range(model.ngeom)]
        self.robot=np.array([n.startswith(('robot0_','gripper0_')) for n in self.names])

    def configure(self, qpos: np.ndarray, held: dict[str,np.ndarray], object_joints: dict[str,int],
                  contact_entity: str | None, relation: np.ndarray | None, max_tilt: float | None,
                  epsilon: float) -> None:
        self.qpos=np.asarray(qpos).copy();self.held={n:np.asarray(t).copy() for n,t in held.items()}
        self.object_joints=dict(object_joints);self.contact_entity=contact_entity
        self.relation=None if relation is None else relation.copy();self.max_tilt=max_tilt;self.epsilon=epsilon;self.checks=0
        self.payload=np.array([any(g.startswith(n+'_') for n in self.held) for g in self.names])

    def forward(self, joints: np.ndarray) -> np.ndarray:
        self.data.qpos[:]=self.qpos;self.data.qpos[self.arm_qpos]=joints
        self.mj.mj_kinematics(self.model,self.data)
        return pose(self.data.site_xpos[self.site],self.data.site_xmat[self.site].reshape(3,3))

    def valid(self, joints: np.ndarray) -> bool:
        return self._assess(joints,False)[0]

    def explain(self, joints: np.ndarray) -> dict:
        admitted,tilt,contacts=self._assess(joints,True)
        return {'admitted':admitted,'tilt_rad':tilt,'max_tilt_rad':self.max_tilt,'contacts':contacts}

    def _assess(self, joints: np.ndarray, detailed: bool) -> tuple[bool,float | None,list[dict]]:
        self.checks+=1;target=self.forward(joints);tilt=None;admitted=True;contacts=[]
        if self.relation is not None and self.max_tilt is not None:
            up=(target@self.relation)[:3,2];tilt=float(np.arccos(np.clip(up[2],-1.,1.)))
            admitted=tilt<=self.max_tilt+1e-10
            if not admitted and not detailed:return False,tilt,[]
        for name,relation in self.held.items():
            if name not in self.object_joints:raise ValueError('missing held-object joint')
            joint=self.object_joints[name]
            if self.model.jnt_type[joint]!=self.mj.mjtJoint.mjJNT_FREE:raise ValueError('held object requires free joint')
            adr=int(self.model.jnt_qposadr[joint]);body=target@relation
            self.data.qpos[adr:adr+3]=body[:3,3]
            quat=Rotation.from_matrix(body[:3,:3]).as_quat();self.data.qpos[adr+3:adr+7]=quat[[3,0,1,2]]
        self.data.qvel[:]=0.;self.mj.mj_forward(self.model,self.data)
        allowed=set(self.held)
        if self.contact_entity is not None:allowed.add(self.contact_entity)
        for ct in self.data.contact[:self.data.ncon]:
            a,b=int(ct.geom1),int(ct.geom2)
            if not(self.robot[a] or self.robot[b] or self.payload[a] or self.payload[b]) or ct.dist>=-self.epsilon:continue
            if self.payload[a] and self.payload[b]:continue
            first,second=self.names[a],self.names[b]
            # Opposing pads may meet when the commanded gripper forms a fist.
            # This internal jaw contact is independent of the arm path; retain
            # all other gripper, robot and scene contacts.
            if (first.startswith('gripper0_') and second.startswith('gripper0_')
                    and ((first.endswith('finger1_pad_collision') and second==first.replace('finger1_pad_collision','finger2_pad_collision'))
                         or (second.endswith('finger1_pad_collision') and first==second.replace('finger1_pad_collision','finger2_pad_collision')))):
                continue
            if any((first.startswith('gripper0_') and second.startswith(n+'_')) or
                   (second.startswith('gripper0_') and first.startswith(n+'_')) for n in allowed):continue
            admitted=False
            if not detailed:return False,tilt,[]
            contacts.append({'first':first,'second':second,'penetration_m':float(-ct.dist)})
        return admitted,tilt,contacts
