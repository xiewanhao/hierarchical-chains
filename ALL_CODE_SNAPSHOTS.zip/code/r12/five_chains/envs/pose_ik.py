"""Robot-only scratch IK for OSC nullspace posture; no collision/path claim.

Adapts the legacy v36 least-squares IK, with explicit proprioception input rather
than reading live plant data. The model is read-only; only private MjData changes.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation
from five_chains.geometry import rigid,pose,rotation_distance


@dataclass(frozen=True)
class IKResult:
    success: bool
    joints: tuple[float,...]
    position_error_m: float
    orientation_error_rad: float
    attempts: int
    collision_checked: bool = False
    orientation_constrained: bool = True


class RobotPoseIK:
    def __init__(self, model: Any, site: int, joint_ids: np.ndarray, qpos_ids: np.ndarray,
                 rest: np.ndarray, config: dict) -> None:
        import mujoco
        self.mj=mujoco;self.model=model;self.data=mujoco.MjData(model);self.site=site
        self.qpos=np.asarray(qpos_ids,int);self.joints=np.asarray(joint_ids,int);self.rest=np.asarray(rest,float).copy();self.config=config
        self.lower=model.jnt_range[self.joints,0]+config['joint_margin_rad'];self.upper=model.jnt_range[self.joints,1]-config['joint_margin_rad']
        body=int(model.site_bodyid[site]);indexes: list[int]=[]
        while body>0:
            for j in range(int(model.body_jntadr[body]),int(model.body_jntadr[body]+model.body_jntnum[body])):
                width=7 if model.jnt_type[j]==0 else 4 if model.jnt_type[j]==1 else 1
                indexes.extend(range(int(model.jnt_qposadr[j]),int(model.jnt_qposadr[j])+width))
            body=int(model.body_parentid[body])
        self.proprio=np.asarray(indexes,dtype=np.int64)

    def forward(self, qpos: np.ndarray, joints: tuple[float,...]) -> np.ndarray:
        self.data.qpos[:]=self.model.qpos0
        self.data.qpos[self.proprio]=np.asarray(qpos)[self.proprio]
        self.data.qpos[self.qpos]=np.asarray(joints)
        self.mj.mj_kinematics(self.model,self.data)
        return pose(self.data.site_xpos[self.site],self.data.site_xmat[self.site].reshape(3,3))

    def solve(self, target: np.ndarray, qpos: np.ndarray, position_only: bool = False) -> IKResult:
        target=rigid(target);self.data.qpos[:]=self.model.qpos0
        self.data.qpos[self.proprio]=np.asarray(qpos)[self.proprio]
        current=self.data.qpos[self.qpos].copy();rng=np.random.default_rng(self.config['seed'])
        seeds=[current,self.rest.copy(),(self.lower+self.upper)/2]
        while len(seeds)<self.config['attempts']:seeds.append(current+rng.normal(0,self.config['seed_std_rad'],len(current)))
        def residual(q: np.ndarray) -> np.ndarray:
            self.data.qpos[self.qpos]=q;self.mj.mj_kinematics(self.model,self.data)
            dp=(self.data.site_xpos[self.site]-target[:3,3])*self.config['position_weight']
            dr=Rotation.from_matrix(self.data.site_xmat[self.site].reshape(3,3)@target[:3,:3].T).as_rotvec()
            return np.r_[dp,np.zeros(3) if position_only else dr,(q-current)*self.config['posture_regularization']]
        best: IKResult | None=None
        for index,seed in enumerate(seeds[:self.config['attempts']]):
            result=least_squares(residual,np.clip(seed,self.lower+1e-7,self.upper-1e-7),bounds=(self.lower,self.upper),max_nfev=self.config['max_nfev'])
            error=residual(result.x);dp=float(np.linalg.norm(error[:3])/self.config['position_weight']);dr=rotation_distance(self.data.site_xmat[self.site].reshape(3,3),target[:3,:3])
            item=IKResult(dp<self.config['position_tolerance_m'] and (position_only or dr<self.config['rotation_tolerance_rad']),tuple(result.x.tolist()),dp,dr,index+1,False,not position_only)
            if best is None or dp+.1*dr<best.position_error_m+.1*best.orientation_error_rad:best=item
            if item.success:return item
        assert best is not None
        return best


def orientation_command(nominal: np.ndarray, proposal: np.ndarray, tolerance: float,
                        relation: np.ndarray | None = None, max_tilt: float | None = None) -> np.ndarray | None:
    nominal=rigid(nominal);proposal=rigid(proposal)
    if not np.allclose(nominal[:3,3],proposal[:3,3],atol=1e-10,rtol=0):return None
    if rotation_distance(nominal[:3,:3],proposal[:3,:3])>tolerance+1e-10:return None
    if relation is not None and max_tilt is not None:
        up=(proposal@rigid(relation))[:3,2]
        if np.arccos(np.clip(up[2],-1,1))>max_tilt+1e-10:return None
    return proposal


def forward_command(nominal: np.ndarray, forward: np.ndarray, position_tolerance: float,
                    orientation_tolerance: float, relation: np.ndarray | None = None,
                    max_tilt: float | None = None) -> np.ndarray | None:
    """Certify an FK orientation with strict position residual and original bounds.

    Command position and termination goal remain nominal. This does not certify
    collisions or reclassify a failed solve as successful.
    """
    nominal=rigid(nominal);forward=rigid(forward)
    if np.linalg.norm(forward[:3,3]-nominal[:3,3])>position_tolerance:return None
    candidate=nominal.copy();candidate[:3,:3]=forward[:3,:3]
    return orientation_command(nominal,candidate,orientation_tolerance,relation,max_tilt)


def bounded_pose_targets(target: np.ndarray, angle: float) -> tuple[np.ndarray,...]:
    """Nominal and six attitude probes; position remains exactly nominal."""
    target=rigid(target)
    if not np.isfinite(angle) or not 0<=angle<np.pi:raise ValueError('invalid attitude search radius')
    result=[target.copy()]
    for axis in np.eye(3):
        for sign in (-1.,1.):
            candidate=target.copy()
            candidate[:3,:3]=Rotation.from_rotvec(axis*angle*sign).as_matrix()@target[:3,:3]
            result.append(candidate)
    return tuple(result)
