"""Native task bindings for a frozen multi-task evaluation, no new robot skills.

The v68 adapter/core are retained byte-for-byte. Non-Steam observations reuse
its feedback/proprioception logic with native fixture and placement predicates.
Only binding domains are supplied to the unchanged trained selector; no plans,
next calls, task goals, demonstrations or desired skill labels are supplied.
"""
from __future__ import annotations
from typing import Any
from copy import deepcopy
from pathlib import Path
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose,inverse,rotation_distance
from five_chains.types import SkillCall
from five_chains.envs.robocasa_adapter import RoboCasaAdapter

TASKS=('SteamInMicrowave','HeatMug','PrepareCoffee','ArrangeBreadBasket','PanTransfer')


class MultiTaskAdapter(RoboCasaAdapter):
    def __init__(self, env: Any, config: dict) -> None:
        self.task_name=config['environment']['task']
        if self.task_name not in TASKS:raise ValueError('unsupported evaluation task')
        self.region_fixtures: dict[str,Any]={}
        self.native_targets: list[str]=[]
        super().__init__(env,config)

    def observe(self, raw_obs: dict) -> dict:
        if self.task_name=='SteamInMicrowave':return super().observe(raw_obs)
        from robocasa.utils import object_utils as OU
        env = self.env
        sim = env.sim
        self._update_phase_clock(float(sim.data.time))
        eef = self.current_pose()
        entities: dict[str, dict[str, Any]] = {}
        predicates: dict[str, bool] = {}
        held = []
        previously_held = set(self.grasp_transforms)
        grasp_modes = {}
        top_offsets = {}
        bottom_offsets = {}
        grasp_diagnostics = {}
        gripper = self.robot.gripper[self.arm]
        for name, item in env.objects.items():
            transform = pose(sim.data.get_body_xpos(item.root_body), sim.data.get_body_xmat(item.root_body))
            # RoboCasa horizontal_radius is the xy half-box diagonal, not either half-size.
            extent = np.asarray(item.size,dtype=float) / 2.
            entities[name] = dict(pose_world=transform, extent=extent, joints={})
            top_offsets[name] = np.asarray(item.top_offset).copy()
            bottom_offsets[name] = np.asarray(item.bottom_offset).copy()
            if env.get_obj_lang(name).lower() == "bowl":
                grasp_modes[name] = "rim"
            grasp,grasp_diagnostics[name] = self._estimate_grasp(name,item,eef)
            if grasp:
                held.append(name)
        native = self.native_scene(entities)
        normals=native['normals'];hinge=native['hinge'];support_frames=native['support_frames']
        support_entities=native['support_entities'];predicates.update(native['predicates'])
        distance = 0.0
        continuous = {"eef_track_err": 0.0, "tilt_dev": 0.0}
        if self.context:
            contract, phase, target, track = self.context
            obj = contract.call.bindings.get("object")
            if "tilt_limit" in contract.fields:
                obj = contract.fields["tilt_limit"].arguments.get("entity", obj)
            predicates["grasp_established"] = bool(obj in held and
                (phase.phase_name != "grasp" or self.phase_ticks >= self.config['grasp']['close_settle_ticks']))
            actuator=contract.fields[contract.phases[phase.phase_index].target_field].arguments.get('actuator','arm')
            base_phase = actuator == 'base'
            torso_phase = actuator == 'torso' 
            measured = (pose(raw_obs["robot0_base_pos"], Rotation.from_quat(raw_obs["robot0_base_quat"]).as_matrix())
                        if base_phase else eef)
            distance = 0. if torso_phase else float(np.linalg.norm(measured[:3, 3] - target[:3, 3]))
            orientation_error = 0. if torso_phase else rotation_distance(measured[:3, :3], target[:3, :3])
            limits = self.config["base"] if base_phase else self.config["control"]
            position_limit = (self.config['grasp']['reached_m'] if not base_phase and (grasp_modes.get(obj) == 'rim' or self.config['grasp'].get('precise_acquisition',False)) and phase.phase_name in ('descend','grasp')
                              else (self.config['base']['stance_reached_m'] if base_phase and contract.fields[contract.phases[phase.phase_index].target_field].recipe == 'base_stance' else limits['reached_m']))
            target_name=contract.call.bindings.get('target')
            if phase.phase_name == 'carry' and target_name is not None and grasp_modes.get(target_name) == 'rim':
                # Drop above a receptacle has a region tolerance; actual placement
                # and later clearance are still checked by the native predicates.
                position_limit=min(self.config['grasp']['container_drop_reached_m'],float(np.min(entities[target_name]['extent'][:2]))/4.)
            if torso_phase:
                part=self.composite.part_controllers['torso']
                distance=abs(float(sim.data.qpos[part.qpos_index[0]])-float(target))
                orientation_error=0.;position_limit=self.config['torso']['reached_m']
            reached = distance <= position_limit and orientation_error <= limits["reached_rad"]
            predicates["reached"] = bool(reached and self.phase_ticks >= self.config["control"]["phase_dwell_ticks"])
            predicates['door_closed_and_retreated']=bool(predicates['door_closed'] and predicates['reached'] and phase.phase_name=='release_contact' and contract.call.skill=='close_hinged_door')
            predicates['activated_and_retreated']=bool(predicates['button_pressed'] and predicates['reached'] and phase.phase_name=='release_contact' and contract.call.skill=='activate_control')
            predicates["base_reached"] = predicates["reached"] and base_phase
            predicates['torso_reached'] = predicates['reached'] and torso_phase
            origin=self.grasp_origins.get(obj) if obj is not None else None
            predicates['lift_complete']=bool(obj is not None and obj in held and origin is not None and predicates['reached']
                and phase.phase_name=='lift' and entities[obj]['pose_world'][2,3]-origin[2]>=self.config['feedback']['lift_retention_min_m'])
            predicates["released"] = bool(obj not in held and self.phase_ticks >= self.config["control"]["phase_dwell_ticks"])
            if phase.phase_name=='release' and obj is not None and obj in env.objects:
                predicates['released']=self._release_ready(obj,held,raw_obs)
            predicates["placed"] = self.placement_satisfied(obj, contract.call.bindings.get("target"))
            target_entity = contract.call.bindings.get("target")
            clear = False
            if target_entity is not None and target_entity in native["cavities"]:
                cavity = entities[target_entity]
                local_eef = inverse(cavity["pose_world"]) @ eef
                clear = bool(local_eef[1,3] < -cavity["extent"][1]-self.config["grasp"]["cavity_exit_clearance_m"])
            elif target_entity is not None and target_entity in env.objects:
                receiving = env.objects[target_entity]
                center = entities[target_entity]["pose_world"][:3,3]
                clear = (np.linalg.norm(eef[:3,3]-center) >= self.config["grasp"]["retreat_clearance_m"]
                         and not env.check_contact(gripper,receiving.contact_geoms))
            elif target_entity in self.region_fixtures:
                clear=bool(np.linalg.norm(eef[:3,3]-entities[target_entity]['pose_world'][:3,3])>=self.config['grasp']['retreat_clearance_m']
                    and not env.check_contact(gripper,self.region_fixtures[target_entity]))
            predicates["placed_and_retreated"] = bool(predicates["placed"] and clear and phase.phase_name == "retreat")
            predicates["unexpected_grasp_lost"] = bool(obj in previously_held and obj not in held
                and contract.phases[phase.phase_index].gripper == "close")
            predicates["object_at_entrance"] = predicates["reached"] and phase.phase_name == "carry"
            predicates["local_complete"] = predicates["reached"]
            continuous["eef_track_err"] = 0.0 if base_phase else float(track)
            if base_phase:
                continuous["base_track_err"] = float(track)
            if obj in entities and "tilt_limit" in contract.fields:
                up = entities[obj]["pose_world"][:3, 2]
                tilt = float(np.arccos(np.clip(up[2], -1, 1)))
                hi = contract.fields["tilt_limit"].default[1]
                continuous["tilt_dev"] = max(0., tilt - hi)
        predicates.setdefault("grasp_established", bool(held))
        base = pose(raw_obs["robot0_base_pos"], Rotation.from_quat(raw_obs["robot0_base_quat"]).as_matrix())
        finger_joint = sim.model.joint_name2id(gripper.joints[0])
        opening_axis = eef[:3,:3].T @ np.asarray(sim.data.xaxis[finger_joint])
        state: dict[str, Any] = dict(entities=entities, eef_pose_world=eef, base_pose_world=base,
                     gripper_width=float(np.sum(np.abs(raw_obs["robot0_gripper_qpos"]))),
                     signals={"predicates": predicates, "continuous": continuous,
                              "grasp_transforms": deepcopy(self.grasp_transforms), "target_distance_m": distance,
                              "microwave_hinge": hinge, "surface_normals": normals})
        torso=self.composite.part_controllers['torso']
        origin,_=self.composite.get_controller_base_pose(self.arm)
        state['signals']['torso']={'position_m':float(sim.data.qpos[torso.qpos_index[0]]),
            'origin_world':np.asarray(origin).copy(),'command_target_m':getattr(self,'torso_command_target',None),'range_m':sim.model._model.jnt_range[torso.joint_index[0]].copy()}
        state['signals']['base_hold_target']=deepcopy(getattr(self,'base_hold_command_target',None))
        state['signals']['enclosed_support_entities']=tuple(n for n in support_entities if n=='cab')
        state['signals']['stance_ik']=deepcopy(self.stance_diagnostic)
        from five_chains.envs.asset_geometry import collision_boxes_world
        state['signals']['gripper_collision_points_world']=collision_boxes_world(sim.model._model,sim.data,self.gripper_collision_ids)
        state['signals']['support_surface_regions']=tuple(n for n in self.region_fixtures if n not in native['cavities'])
        state['signals']['upright_entities']=tuple(n for n in env.objects if any(label in env.get_obj_lang(n).lower() for label in ('mug','cup','bowl','basket','pan','pot')))
        state["signals"].update(loaded_grasp_enabled=self.config["grasp"]["loaded_acquisition"]["enabled"],grasp_modes=grasp_modes, object_top_offsets=top_offsets,
                                object_bottom_offsets=bottom_offsets, cavity_entities=tuple(native["cavities"]),
                                cavity_obstacles=native["obstacles"],
                                fixture_front_entities=tuple(native["front_entities"]), object_support_frames=support_frames, grasp_signatures=self.grasp_signatures,
                                robot_kinematic_qpos=np.asarray(sim.data.qpos).copy(),posture_ik=deepcopy(self.posture_diagnostic),
                                gripper_opening_axis_eef=opening_axis, grasp_diagnostics=grasp_diagnostics)
        # Force/unsafe-contact channels are absent unless independently instrumented;
        # absence is not interpreted as a measured zero force.
        return {"state": state, "raw": raw_obs}

    def fixture_pose(self, fixture: Any) -> np.ndarray:
        sim=self.env.sim
        return pose(sim.data.get_body_xpos(fixture.root_body),sim.data.get_body_xmat(fixture.root_body))

    def native_scene(self, entities: dict) -> dict:
        from robocasa.utils import object_utils as OU
        env=self.env;sim=env.sim;normals={};hinge={};supports={};support_entities=[]
        predicates={'door_closed':False,'button_pressed':False,'vegetable_in_bowl':False,'bowl_in_microwave':False}
        self.region_fixtures={};cavities=[];obstacles={};front=[];seen=set()
        for role in ('counter','counter_small','sink','cab','dining_table','stove'):
            fixture=getattr(env,role,None)
            if fixture is None or id(fixture) in seen:continue
            seen.add(id(fixture));support_entities.append(role)
            entities[role]=dict(pose_world=self.fixture_pose(fixture),extent=np.asarray(fixture.size)/2.,joints={})
            for name,item in env.objects.items():
                if env.check_contact(item,fixture):supports[name]=role
        microwave=getattr(env,'microwave',None)
        if microwave is not None:
            t=self.fixture_pose(microwave)
            angle=float(sim.data.get_joint_qpos(microwave.door_joint_names[0]));jid=sim.model.joint_name2id(microwave.door_joint_names[0])
            hinge=dict(angle=angle,velocity_rad_s=float(sim.data.get_joint_qvel(microwave.door_joint_names[0])),
                axis_world=sim.data.xaxis[jid].copy(),anchor_world=sim.data.xanchor[jid].copy())
            entities['microwave']=dict(pose_world=t,extent=np.asarray(microwave.size)/2,joints={'door':angle})
            points=np.asarray(microwave.get_int_sites(relative=False)[microwave.get_reset_region_names()[0]])
            p0,px,py,pz=points;axes=np.column_stack([px-p0,py-p0,pz-p0])
            entities['microwave_interior']=dict(pose_world=pose(p0+axes.sum(axis=1)/2,t[:3,:3]),extent=np.linalg.norm(axes,axis=0)/2,joints={})
            panel=sim.model.geom_name2id(microwave.door_name+'_main')
            entities['microwave_door']=dict(pose_world=pose(sim.data.geom_xpos[panel],sim.data.geom_xmat[panel].reshape(3,3)),extent=np.asarray(sim.model.geom_size[panel]).copy(),joints={})
            for name,geom in (('handle',microwave.handle_name),('start',microwave.name+'_start_button')):
                i=sim.model.geom_name2id(geom)
                entities[name]=dict(pose_world=pose(sim.data.geom_xpos[i],sim.data.geom_xmat[i].reshape(3,3)),extent=sim.model.geom_size[i].copy(),joints={})
                normal=-t[:3,1]
                normals[name]=Rotation.from_rotvec(angle*hinge['axis_world']).as_matrix()@normal if name=='handle' else normal
            predicates.update(door_closed=bool(microwave.is_closed(env)),button_pressed=bool(microwave.get_state()['turned_on']),
                mug_in_microwave=bool(OU.obj_inside_of(env,'obj',microwave)))
            cavities=['microwave_interior'];obstacles={'microwave_interior':('microwave_door','handle')};front+=cavities
            self.region_fixtures['microwave_interior']=microwave
        coffee=getattr(env,'coffee_machine',None)
        if coffee is not None:
            t=self.fixture_pose(coffee);entities['coffee_machine']=dict(pose_world=t,extent=np.asarray(coffee.size)/2,joints={})
            site=sim.model.site_name2id(coffee.naming_prefix+'receptacle_place_site')
            entities['coffee_pouring']=dict(pose_world=pose(sim.data.site_xpos[site],t[:3,:3]),extent=np.array([.04,.04,.005]),joints={})
            self.region_fixtures['coffee_pouring']=coffee;front.append('coffee_pouring')
            button=coffee.naming_prefix+coffee._start_button_names[0];i=sim.model.geom_name2id(button)
            entities['start']=dict(pose_world=pose(sim.data.geom_xpos[i],sim.data.geom_xmat[i].reshape(3,3)),extent=sim.model.geom_size[i].copy(),joints={})
            normals['start']=-t[:3,1]
            predicates.update(button_pressed=bool(coffee.get_state()['turned_on']),mug_under_dispenser=bool(coffee.check_receptacle_placement_for_pouring(env,'obj')))
        if self.task_name=='ArrangeBreadBasket':
            table=env.dining_table;t=self.fixture_pose(table)
            # Read a fixed native counter top region without consuming RNG.
            regions=table.get_reset_regions(env=env,ref=None)
            region=regions[sorted(regions)[0]];center=t@np.r_[region['offset'],1.]
            entities['dining_table']=dict(pose_world=pose(center[:3],t[:3,:3]),extent=np.r_[np.asarray(region['size'])/2,.005],joints={})
            self.region_fixtures['dining_table']=table;front.append('dining_table')
            predicates.update(bread_in_basket=bool(OU.check_obj_in_receptacle(env,'bread','basket')),
                basket_on_dining_table=bool(OU.check_obj_fixture_contact(env,'basket',table)),cabinet_closed=bool(env.cab.is_closed(env)))
        if self.task_name=='PanTransfer':
            stove=env.stove;t=self.fixture_pose(stove)
            sites=sorted((name,data) for name,data in stove.burner_sites.items() if data is not None)
            if not sites:raise ValueError('no native stove burner site')
            i=sim.model.site_name2id(sites[0][1].get('name'))
            entities['stove']=dict(pose_world=pose(sim.data.site_xpos[i],t[:3,:3]),extent=np.array([.08,.08,.005]),joints={})
            self.region_fixtures['stove']=stove;front.append('stove')
            predicates.update(vegetable_on_plate=bool(OU.check_obj_in_receptacle(env,'vegetable','plate')),
                pan_on_burner=bool(env._check_obj_location_on_stove('vegetable_container') is not None),
                robot_touched_food=bool(env._robot_touched_food))
        predicates['door_closed_settled']=self._door_settled(float(sim.data.time),predicates['door_closed'],hinge.get('velocity_rad_s',0.))
        return dict(normals=normals,hinge=hinge,predicates=predicates,support_frames=supports,
            support_entities=support_entities,cavities=cavities,obstacles=obstacles,front_entities=front+support_entities)

    def placement_satisfied(self, obj: str | None, target: str | None) -> bool:
        from robocasa.utils import object_utils as OU
        if obj not in self.env.objects:return False
        if target in self.env.objects:return bool(OU.check_obj_in_receptacle(self.env,obj,target))
        if target=='microwave_interior':return bool(OU.obj_inside_of(self.env,obj,self.env.microwave))
        if target=='coffee_pouring':return bool(self.env.coffee_machine.check_receptacle_placement_for_pouring(self.env,obj))
        if target=='stove':return bool(self.env._check_obj_location_on_stove(obj) is not None)
        if target in self.region_fixtures:return bool(OU.check_obj_fixture_contact(self.env,obj,self.region_fixtures[target]))
        return False

    def selector_sample(self, task: str, obs: dict, history: list[SkillCall], image_path: Path) -> dict:
        if self.task_name=='SteamInMicrowave':return super().selector_sample(task,obs,history,image_path)
        from PIL import Image
        rgb=self.env.sim.render(width=256,height=256,camera_name=self.config['environment']['selector_camera'])[::-1].copy()
        Image.fromarray(rgb).save(image_path)
        entities=obs['state']['entities']
        # These are task entity bindings, not a skill sequence or task-goal graph.
        objects=[n for n in self.env.objects if not n.startswith(('distr','dstr'))]
        targets={'HeatMug':['microwave_interior'],'PrepareCoffee':['coffee_pouring'],
            'ArrangeBreadBasket':['basket','dining_table'],'PanTransfer':['plate','stove']}[self.task_name]
        fixed={'reference':targets[-1]}
        if self.task_name=='HeatMug':fixed.update(appliance='microwave',handle='handle',control='start')
        if self.task_name=='PrepareCoffee':fixed.update(appliance='coffee_machine',control='start')
        labels={n:self.env.get_obj_lang(n) for n in self.env.objects}
        containers=('bowl','basket','pan','plate','mug','cup','pot','container')
        types={n:(['container'] if any(s in labels[n].lower() for s in containers) else []) for n in self.env.objects}
        effects=[]
        for previous in history:
            if previous.skill in ('place_object_in_container','carry_container_to_region') and self.placement_satisfied(previous.bindings.get('object'),previous.bindings.get('target')):
                effects.append({'bindings':previous.bindings,'effect':'placement_satisfied','source':'native placement predicate'})
        return {'measured_satisfied_effects':effects,'image':str(image_path),'instruction':task,
            'observation':{'source':'simulator_ground_truth_development','entities':list(entities),
                'entity_labels':labels,'state':obs['state']['signals']['predicates'],
                'failure_feedback':obs['state']['signals'].get('failure_feedback',[])},
            'history':[{'primary':c.skill,'bindings':c.bindings,'status':'completed'} for c in history[-3:]],
            'call_context':{'decision_id':f'live_{len(history):03d}','bindings':fixed,
                'binding_options':{'object':objects,'target':targets},'entity_types':types,'goal_window':[]},
            'completed_goals':[]}
