"""Simulator-independent observation/action boundary."""
