from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Literal
import numpy as np


class ChainId(str, Enum):
    PREP = "c1_prep"
    REFLEX = "c2_reflex"
    FB_FAST = "c3a_fb_fast"
    FB_FULL = "c3b_fb_full"
    VISION = "c4_vision"
    REPLAN = "c5_replan"


class FieldKind(str, Enum):
    POSE = "pose"
    POSITION = "position"
    SCALAR = "scalar"
    INTERVAL = "interval"
    DISCRETE = "discrete"


class ContractError(ValueError):
    pass


class ContractConflict(ContractError):
    pass


class ReadoutError(ValueError):
    pass


class SelectorOutputError(ValueError):
    pass


@dataclass(frozen=True)
class SkillCall:
    call_id: str
    layer: int
    skill: str
    bindings: dict[str, str]
    combined_with: tuple[SkillCall, ...] = ()
    next_call: SkillCall | None = None


@dataclass(frozen=True)
class FieldSpec:
    name: str
    kind: FieldKind
    unit: str
    frame_entity: str | None
    writable_by: frozenset[ChainId]
    depends_on: frozenset[str]
    recipe: str | None = None
    value_range: tuple[float, float] | None = None
    options: tuple[str, ...] = ()
    default: Any = None
    required: bool = True
    prep_frame: str | None = None
    constraints: tuple[str, ...] = ()
    arguments: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class PhaseSpec:
    name: str
    target_field: str
    enter_when: str
    fields: frozenset[str]
    gripper: Literal["open", "close", "keep"] = "keep"


@dataclass(frozen=True)
class TerminationSpec:
    success_when: str
    fail_when: str | None
    timeout_steps: int
    phase_timeouts: dict[str, int] = field(default_factory=dict)


@dataclass(frozen=True)
class Contract:
    contract_id: str
    call: SkillCall
    fields: dict[str, FieldSpec]
    phases: tuple[PhaseSpec, ...]
    termination: TerminationSpec
    followup: dict[str, Any]
    sub_calls: tuple[SkillCall, ...] = ()

    @property
    def dep_keys(self) -> frozenset[str]:
        return frozenset().union(*(s.depends_on for s in self.fields.values()))


@dataclass(frozen=True)
class EntityState:
    name: str
    pose_world: np.ndarray
    extent: np.ndarray
    joints: dict[str, float]
    stamp: int


@dataclass(frozen=True)
class WorldState:
    stamp: int
    entities: dict[str, EntityState]
    eef_pose_world: np.ndarray
    base_pose_world: np.ndarray
    gripper_width: float
    changed_keys: frozenset[str]
    signals: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FeedbackDelta:
    stamp: int
    events: tuple[str, ...]
    continuous: dict[str, float]


@dataclass(frozen=True)
class FieldPrep:
    name: str
    value: Any
    status: Literal["bound", "ready", "stale", "missing"]
    source_chain: ChainId
    stamp: int
    provenance: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class P6:
    contract_id: str
    fields: dict[str, FieldPrep]


@dataclass(frozen=True)
class P7:
    contract_id: str
    phase_index: int
    phase_name: str
    progress: float
    steps_in_phase: int
    entry_distance: float = 0.0

    @staticmethod
    def initial(contract: Contract) -> P7:
        return P7(contract.contract_id, 0, contract.phases[0].name, 0.0, 0)


@dataclass(frozen=True)
class PhysParam:
    name: str
    kind: FieldKind
    value: np.ndarray
    unit: str
    frame_entity: str | None
    source_chain: ChainId
    stamp: int


@dataclass(frozen=True)
class ReflexBounds:
    max_pos_correction_m: float
    max_rot_correction_rad: float
    max_force_n: float | None
    stop_on_unexpected_contact: bool


@dataclass(frozen=True)
class ParamPacket:
    contract_id: str
    params: dict[str, PhysParam]
    version: int
    bounds: ReflexBounds


@dataclass(frozen=True)
class Proposal:
    chain: ChainId
    updates: dict[str, PhysParam]
    bounds: ReflexBounds | None = None


@dataclass(frozen=True)
class ReflexOverride:
    kind: Literal["hold", "stop", "bounded_correction"]
    delta_pose: np.ndarray | None
    event: str


@dataclass(frozen=True)
class RejectedWrite:
    name: str
    chain: ChainId
    reason: str


@dataclass(frozen=True)
class EpisodeResult:
    success: bool
    ticks: int
    reason: str
    selector_calls: int
    prep_calls: int


@dataclass
class RuntimeContext:
    contract: Contract | None = None
    p6: P6 | None = None
    p7: P7 | None = None
    packet: ParamPacket | None = None
    history: list[SkillCall] = field(default_factory=list)
    sub_queue: list[SkillCall] = field(default_factory=list)
    reflex_event: str | None = None
    steps: int = 0
    selector_calls: int = 0
    prep_calls: int = 0
    executed_actuator: str = "arm"


@dataclass
class Components:
    adapter: Any
    c4: Any
    c5: Any
    c6: Any
    c7: Any
    c8: Any
    c9: Any
    c10: Any
    c11: Any
    c12: Any
