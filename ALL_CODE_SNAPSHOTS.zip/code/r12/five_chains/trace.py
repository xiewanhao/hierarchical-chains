from __future__ import annotations
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import asdict, is_dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Iterator
import json
import time
import numpy as np


def serial(value: Any) -> Any:
    if is_dataclass(value) and not isinstance(value, type):
        return {k: serial(v) for k, v in asdict(value).items()}
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, dict):
        return {k: serial(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, set, frozenset)):
        return [serial(v) for v in value]
    return value


class Tracer:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.file = self.path.open("x")
        self.costs: dict[str, dict[str, float]] = defaultdict(lambda: {"calls": 0, "seconds": 0.0})
        self.tick_costs: dict[str, float] = defaultdict(float)
        self.rows = 0

    @contextmanager
    def measure(self, component: str) -> Iterator[None]:
        start = time.perf_counter()
        try:
            yield
        finally:
            duration = time.perf_counter() - start
            self.costs[component]["calls"] += 1
            self.costs[component]["seconds"] += duration
            self.tick_costs[component] += duration

    def write(self, record: dict) -> None:
        self.file.write(json.dumps(serial(record), ensure_ascii=False, allow_nan=False) + "\n")
        self.file.flush()

    def log_failure(self, contract_id: str, reason: str) -> None:
        self.write({"kind": "failure", "contract_id": contract_id, "reason": reason})

    def log_tick(self, tick: int, ctx: Any, world: Any, delta: Any,
                 proposals: list, rejected: list, override: Any, action: np.ndarray,
                 triggers: list[str]) -> None:
        self.write({"kind": "tick", "tick": tick, "call_id": ctx.contract.call.call_id,
                    "phase": ctx.p7.phase_name, "triggers": triggers,
                    "executed_actuator": ctx.executed_actuator,
                    "writes": [{"name": n, "chain": p.chain, "stamp": v.stamp} for p in proposals for n, v in p.updates.items()
                               if ctx.packet.params.get(n) is v],
                    "proposals": [{"chain": p.chain, "fields": list(p.updates)} for p in proposals],
                    "rejected": rejected, "reflex": override, "events": delta.events,
                    "continuous": delta.continuous, "predicates":world.signals.get("predicates",{}), "changed_keys": world.changed_keys,
                    "bound_object_pose": (world.entities[ctx.contract.call.bindings['object']].pose_world if ctx.contract.call.bindings.get('object') in world.entities else None),
                    "grasp_transforms":world.signals.get('grasp_transforms',{}),"gripper_width_m":world.gripper_width,
                    "eef_pose_world": world.eef_pose_world, "base_pose_world": world.base_pose_world, "base_hold_target":world.signals.get("base_hold_target"),
                    "phase_progress": ctx.p7.progress, "steps_in_phase": ctx.p7.steps_in_phase,
                    "preparation_provenance": {n: {'stamp':p.stamp,'source_chain':p.source_chain,'method':p.provenance} for n,p in ctx.p6.fields.items()},
                    "posture_ik":world.signals.get("posture_ik",{}),
                    "torso":world.signals.get("torso",{}),
                    "microwave_hinge":world.signals.get("microwave_hinge",{}),
                    "stance_ik":world.signals.get("stance_ik",{}),
                    "object_support_frames":world.signals.get("object_support_frames",{}),
                    "grasp_diagnostics": world.signals.get("grasp_diagnostics", {}),
                    "version": ctx.packet.version, "parameters": ctx.packet.params,
                    "action": action, "component_seconds": dict(self.tick_costs)})
        self.rows += 1
        self.tick_costs.clear()

    def close(self, result: Any) -> None:
        self.write({"kind": "summary", "result": result, "costs": dict(self.costs), "tick_rows": self.rows})
        self.file.close()
