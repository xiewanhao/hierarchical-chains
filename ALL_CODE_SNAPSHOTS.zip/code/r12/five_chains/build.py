from __future__ import annotations
from typing import Any
from five_chains.types import Components
from five_chains.components.c04_state import StateGeometry
from five_chains.components.c05_feedback import FeedbackEncoder
from five_chains.components.c06_fieldprep import FieldPreparer
from five_chains.components.c07_phase import PhaseTracker
from five_chains.components.c08_readout import ParamReadout
from five_chains.components.c09_reflex import ReflexLayer
from five_chains.components.c10_executor import Executor
from five_chains.components.c12_contract import ContractDispatcher


def build_components(adapter: Any, selector: Any, config: dict, tracer: Any | None = None) -> Components:
    c4 = StateGeometry(config["state"])
    from five_chains.skills.recipes import RecipeRegistry
    recipes=RecipeRegistry(config=config)
    if config['grasp'].get('current_asset_contacts',False):
        from five_chains.skills.live_grasps import CurrentAssetGrasps
        recipes.grasp_provider=CurrentAssetGrasps(adapter,config,recipes.grasp_provider)
    result = Components(adapter, c4, FeedbackEncoder(), FieldPreparer(recipes), PhaseTracker(),
                        ParamReadout(c4, config), ReflexLayer(config["reflex"]["enabled"]),
                        Executor(adapter, config), selector, ContractDispatcher())
    if tracer:
        for name in ("c4", "c5", "c6", "c7", "c8", "c9", "c10", "c11", "c12"):
            setattr(result, name, TimedComponent(getattr(result, name), name, tracer))
    return result


class TimedComponent:
    def __init__(self, wrapped: Any, name: str, tracer: Any) -> None:
        self._wrapped = wrapped
        self._name = name
        self._tracer = tracer

    def __getattr__(self, name: str) -> Any:
        value = getattr(self._wrapped, name)
        if not callable(value):
            return value
        def timed(*args: Any, **kwargs: Any) -> Any:
            with self._tracer.measure(self._name + "." + name):
                return value(*args, **kwargs)
        return timed
