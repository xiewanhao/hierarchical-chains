from __future__ import annotations
import argparse,json,hashlib,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.config import load_config
from five_chains.envs.robocasa_adapter import make_environment,RoboCasaAdapter
from five_chains.envs.asset_geometry import grasp_signatures,collision_surface


def main() -> None:
    p=argparse.ArgumentParser();p.add_argument('--output',required=True);p.add_argument('--entity',default='bowl');a=p.parse_args()
    out=Path(a.output);out.mkdir(parents=True,exist_ok=False)
    cfg=load_config();env=make_environment(cfg)
    try:
        adapter=RoboCasaAdapter(env,cfg)
        signatures=grasp_signatures(env,adapter.arm)
        points=collision_surface(env,a.entity,4096,2700)
        np.savez_compressed(out/'geometry.npz',points_object_m=points,
            T_actual_gripper_root_TCP=np.asarray(signatures['T_actual_gripper_root_TCP']))
        meta={'entity':a.entity,'shape_sha256':signatures['objects'][a.entity],
              'gripper_sha256':signatures['gripper'],'T_actual_gripper_root_TCP':signatures['T_actual_gripper_root_TCP'],
              'geometry_sha256':hashlib.sha256((out/'geometry.npz').read_bytes()).hexdigest(),
              'extent_m':(np.asarray(env.objects[a.entity].size)/2).tolist(),
              'scope':'compiled collision-surface geometry, privileged development input; zero control steps',
              'ep_meta':env.get_ep_meta()}
        (out/'asset.json').write_text(json.dumps(meta,indent=2));print(json.dumps({k:v for k,v in meta.items() if k!='ep_meta'}))
    finally:env.close()


if __name__=='__main__':main()
