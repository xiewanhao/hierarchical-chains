"""Pre-batch observation/schema checks, disjoint seed, no policy or env.step."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.config import load_config
from five_chains.envs.robocasa_adapter import make_environment
from five_chains.envs.multitask_adapter import MultiTaskAdapter
from five_chains.trace import serial

root=Path(__file__).resolve().parents[1];protocol=json.loads((root/'protocol.json').read_text());rows=[]
for task in protocol['tasks']:
 for layout in protocol['layouts']:
    cfg=load_config(root/'configs/steam_graspgen_fine.yaml');cfg['environment'].update(task=task,seed=1999,layout_and_style_ids=[[layout,34]],render=False)
    env=None
    try:
        env=make_environment(cfg)
        def forbidden(*args: object,**kwargs: object) -> None:raise AssertionError('schema validation may not step')
        env.step=forbidden
        adapter=MultiTaskAdapter(env,cfg);before=json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str)
        obs=adapter.observe(adapter._initial_obs);after=json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str)
        assert before==after,'adapter consumed RNG'
        assert adapter.success() is False,'initial task already solved'
        rows.append({'task':task,'layout':layout,'passed':True,'rng_unchanged':True,'entities':list(obs['state']['entities'])})
    except Exception as error:rows.append({'task':task,'layout':layout,'passed':False,'error':repr(error)})
    finally:
        if env is not None:env.close()
    print(json.dumps(rows[-1]),flush=True)
core={name:hashlib.sha256((root/name).read_bytes()).hexdigest()==expected for name,expected in protocol['baseline_v68_core_sha256'].items()}
legacy=Path('/root/autodl-tmp/adaptive_semantics_20261031')
weights={name:hashlib.sha256((legacy/name).read_bytes()).hexdigest()==expected for name,expected in protocol['legacy_source_weights_sha256'].items()}
report={'schema_rows':rows,'v68_core_unchanged':core,'original_selector_and_weights_unchanged':weights,
    'passed':all(r['passed'] for r in rows) and all(core.values()) and all(weights.values())}
(root/'scene_validation.json').write_text(json.dumps(report,indent=2))
if not report['passed']:raise SystemExit(1)
