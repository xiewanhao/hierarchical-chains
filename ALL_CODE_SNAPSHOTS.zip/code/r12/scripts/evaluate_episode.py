"""One fresh native episode, unchanged v68 skills/controller and legacy model."""
from __future__ import annotations
import argparse,gzip,hashlib,inspect,json,sys,time,traceback
from collections import defaultdict
from dataclasses import asdict
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.config import load_config
from five_chains.envs.robocasa_adapter import make_environment
from five_chains.envs.multitask_adapter import MultiTaskAdapter,TASKS
from five_chains.components.c11_selector import SubprocessSelectorAdapter
from five_chains.types import SelectorOutputError
from five_chains.build import build_components
from five_chains.runtime import run_episode
from five_chains.trace import Tracer,serial


class EvalTrace(Tracer):
    def __init__(self, directory: Path) -> None:
        self.path=directory/'ticks.jsonl.gz';self.directory=directory
        self.file=gzip.open(self.path,'xt',compresslevel=3)
        self.costs=defaultdict(lambda:{'calls':0,'seconds':0.});self.tick_costs=defaultdict(float);self.rows=0
        self.last_tick: dict={}

    def log_tick(self,*args: object,**kwargs: object) -> None:
        super().log_tick(*args,**kwargs)
        tick,ctx=args[:2]
        self.last_tick={'tick':tick,'phase':ctx.p7.phase_name,'call_id':ctx.contract.contract_id,
            'skill':ctx.contract.call.skill,'bindings':ctx.contract.call.bindings,'selector_calls':ctx.selector_calls,
            'prep_calls':ctx.prep_calls,'executions':self.rows}
        if self.rows%100==0:
            temp=self.directory/'progress.tmp';temp.write_text(json.dumps(self.last_tick));temp.replace(self.directory/'progress.json')


class InspectPreparer:
    """Read-only logging around C6; returned P6 is unchanged."""
    def __init__(self, wrapped: object, tracer: EvalTrace) -> None:
        self.wrapped=wrapped;self.tracer=tracer;self.missing: list[dict]=[]
    def __getattr__(self,name: str) -> object:return getattr(self.wrapped,name)
    def prepare(self,*args: object,**kwargs: object) -> object:
        prepared=self.wrapped.prepare(*args,**kwargs)
        missing={name:serial(field) for name,field in prepared.fields.items() if field.status=='missing'}
        if missing:
            record={'kind':'missing_preparation','contract_id':prepared.contract_id,'fields':missing}
            self.missing.append(record);self.tracer.write(record)
        return prepared


class BudgetSelector:
    def __init__(self, wrapped: object, limit: int) -> None:
        self.wrapped=wrapped;self.limit=limit;self.calls=0
    def select(self,*args: object) -> object:
        if self.calls>=self.limit:raise SelectorOutputError('evaluation_decision_budget')
        self.calls+=1
        return self.wrapped.select(*args)


def sources(root: Path) -> dict[str,str]:
    paths=list((root/'five_chains').rglob('*.py'))+list((root/'five_chains').rglob('*.yaml'))
    paths+=list((root/'scripts').glob('*.py'))+list((root/'scripts').glob('*.sh'))+list((root/'configs').glob('*.yaml'))
    paths+=[p for p in (root/'data/graspgen').rglob('*') if p.is_file() and p.suffix in ('.json','.npz')]
    if (root/'protocol.json').exists():paths.append(root/'protocol.json')
    return {str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}


def category(reason: str) -> str:
    low=reason.lower()
    if 'cache' in low and ('geometry' in low or 'does not match' in low):return 'asset_cache_coverage'
    if 'selector' in low or 'evaluation_decision_budget' in low:return 'selection_failure'
    if 'motion_path' in low:return 'motion_planning_failure'
    if 'grasp_lost' in low:return 'grasp_retention_failure'
    if 'missing required preparation' in low:return 'parameter_preparation_failure'
    if 'environment_terminated_without_success' in low:return 'horizon_termination'
    if 'contracterror' in low:return 'skill_precondition_or_contract'
    if 'timeout' in low:return 'execution_timeout'
    return 'runtime_error'


def main() -> None:
    ap=argparse.ArgumentParser();ap.add_argument('--task',choices=TASKS,required=True);ap.add_argument('--seed',type=int,required=True)
    ap.add_argument('--layout',type=int,required=True);ap.add_argument('--style',type=int,default=34)
    ap.add_argument('--output',required=True);ap.add_argument('--smoke',action='store_true');args=ap.parse_args()
    output=Path(args.output);output.mkdir(parents=True,exist_ok=False)
    root=Path(__file__).resolve().parents[1];cfg=load_config(root/'configs/steam_graspgen_fine.yaml')
    cfg['environment'].update(task=args.task,seed=args.seed,layout_and_style_ids=[[args.layout,args.style]],render=True)
    cfg['selector']['kind']='model'
    if cfg['grasp'].get('online_graspgen',False):cfg['grasp']['online_cache_directory']=str(output.resolve()/'asset_cache')
    if args.smoke:cfg['control']['max_ticks']=20
    (output/'effective_config.json').write_text(json.dumps(cfg,indent=2))
    hashes=sources(root);tracer=EvalTrace(output);started=time.time();env=None;adapter=None;C=None;steps=0;selector=None
    result={'task':args.task,'seed':args.seed,'layout':args.layout,'style':args.style,'smoke':args.smoke,
        'success':False,'env_initialized':False,'status':'initializing','reason':'not_started','source_sha256':hashes}
    try:
        env=make_environment(cfg);adapter=MultiTaskAdapter(env,cfg)
        # Validate observation mapping before starting; no reset or physics step.
        import numpy as np
        before_rng=json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str)
        initial=adapter.observe(adapter._initial_obs)
        after_rng=json.dumps(env.rng.bit_generator.state,sort_keys=True,default=str)
        if before_rng!=after_rng:raise ValueError('observation adapter consumed environment RNG')
        np.savez_compressed(output/'initial_physical_state.npz',qpos=np.asarray(env.sim.data.qpos),qvel=np.asarray(env.sim.data.qvel))
        (output/'initial_ep_meta.json').write_text(json.dumps(serial(env.get_ep_meta()),default=str,indent=2))
        result['observation_rng_unchanged']=True
        result.update(env_initialized=True,initial_signature=adapter.initial_signature(),initial_native_success=bool(adapter.success()),
            initial_entities=list(initial['state']['entities']),initial_predicates=initial['state']['signals']['predicates'])
        native_file=Path(inspect.getfile(type(env)))
        result['native_task_source_file']=str(native_file);result['native_task_source_sha256']=hashlib.sha256(native_file.read_bytes()).hexdigest()
        (output/'native_success.py.txt').write_text(inspect.getsource(type(env)._check_success))
        if result['initial_native_success']:raise ValueError('invalid initial state: native task already successful')
        (output/'ready.json').write_text(json.dumps({'env_initialized':True,'initial_native_success':False}))
        raw_step=env.step
        def audit_step(action: object) -> tuple:
            nonlocal steps
            caller=sys._getframe(1)
            if caller.f_code.co_name!='execute' or caller.f_globals.get('__name__')!='five_chains.components.c10_executor':
                raise RuntimeError('env.step outside Executor.execute')
            steps+=1;return raw_step(action)
        env.step=audit_step
        def builder(task: str,obs: dict,history: list) -> dict:
            return adapter.selector_sample(task,obs,history,output.resolve()/f'camera_{0 if selector is None else selector.calls:03d}.png')
        selector=BudgetSelector(SubprocessSelectorAdapter(cfg['selector'],builder,output.resolve()/'selector'),10)
        C=build_components(adapter,selector,cfg,tracer)
        C.c6=InspectPreparer(C.c6,tracer)
        episode=asdict(run_episode(env,adapter.instruction(),C,cfg,tracer));result.update(episode,status='completed')
        result['outcome_category']='success' if episode['success'] else category(episode['reason'])
    except Exception as error:
        result.update(status='error',reason=repr(error),traceback=traceback.format_exc(),outcome_category=category(repr(error)))
        if not result['env_initialized']:result['outcome_category']='initialization_or_adapter_error'
    finally:
        result.update(audited_env_steps=steps,executions=0 if C is None else C.c10.executions,
            actual_model_calls=0 if selector is None else selector.calls,last_tick=tracer.last_tick,elapsed_seconds=time.time()-started)
        if adapter is not None:
            try:
                final=adapter.observe(env._get_observations(force_update=True))
                result['terminal_predicates']=serial(final['state']['signals']['predicates']);result['native_success_at_end']=bool(adapter.success())
                result['metadata']=adapter.metadata();result['terminal_eef_pose_world']=serial(final['state']['eef_pose_world'])
                result['terminal_object_poses_world']={n:serial(e['pose_world']) for n,e in final['state']['entities'].items() if n in env.objects}
                from PIL import Image
                Image.fromarray(env.sim.render(width=768,height=768,camera_name=cfg['environment']['selector_camera'])[::-1].copy()).save(output/'terminal_camera.png')
                np.savez_compressed(output/'terminal_physical_state.npz',qpos=np.asarray(env.sim.data.qpos),qvel=np.asarray(env.sim.data.qvel))
            except Exception as error:result.update(terminal_observation_error=repr(error),success=False,outcome_category='terminal_observation_error')
        result['success']=bool(result['success'] and result.get('native_success_at_end') and not result.get('initial_native_success',True))
        if C is not None:result['missing_preparations']=C.c6.missing
        current=sources(root);result['changed_code_during_run']=[name for name,digest in hashes.items() if current.get(name)!=digest]
        if result['changed_code_during_run']:result.update(success=False,outcome_category='source_changed')
        if steps!=result['executions']:result.update(success=False,outcome_category='step_audit_failure')
        tracer.close(result);(output/'result.json').write_text(json.dumps(serial(result),indent=2))
        if env is not None:env.close()
    print(json.dumps({k:result.get(k) for k in ('task','seed','layout','success','reason','outcome_category','audited_env_steps','actual_model_calls')}),flush=True)


if __name__=='__main__':main()
