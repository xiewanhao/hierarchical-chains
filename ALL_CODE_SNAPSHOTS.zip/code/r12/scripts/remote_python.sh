#!/usr/bin/env bash
set -euo pipefail
LEGACY_ROOT=/root/autodl-tmp/adaptive_semantics_20261031
RUNTIME_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$RUNTIME_ROOT/.cache" "$RUNTIME_ROOT/work/tmp"
export XDG_CACHE_HOME="$RUNTIME_ROOT/.cache"
export NUMBA_CACHE_DIR="$RUNTIME_ROOT/.cache/numba"
export TMPDIR="$RUNTIME_ROOT/work/tmp"
export MUJOCO_GL=osmesa
export PYOPENGL_PLATFORM=osmesa
export LD_PRELOAD=/usr/lib/x86_64-linux-gnu/libstdc++.so.6
export LD_LIBRARY_PATH="$LEGACY_ROOT/.runtime/robocasa_gl:$LEGACY_ROOT/.runtime/libs/usr/lib/x86_64-linux-gnu${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONHASHSEED=2000
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
exec "$LEGACY_ROOT/.robocasa-env/bin/python" -B "$@"
