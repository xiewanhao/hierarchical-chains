"""Read-only native-scene contact preparation diagnostic, no robot episode."""
import argparse,json,sys,time,contextlib
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.config import load_config
from five_chains.envs.robocasa_adapter import make_environment
from five_chains.envs.multitask_adapter import MultiTaskAdapter
from five_chains.skills.asset_grasps import AssetGraspProvider
from five_chains.skills.recipes import GeometricGraspProvider
from five_chains.skills.live_grasps import CurrentAssetGrasps
from five_chains.components.c04_state import StateGeometry

def main():
    p=argparse.ArgumentParser();p.add_argument('--task',required=True);p.add_argument('--entity',required=True);p.add_argument('--layout',type=int,default=8);p.add_argument('--seed',type=int,default=2000);a=p.parse_args()
    cfg=load_config('configs/steam_graspgen_fine.yaml');cfg['environment'].update(task=a.task,seed=a.seed,layout_and_style_ids=[[a.layout,34]],render=False)
    with contextlib.redirect_stdout(sys.stderr):env=make_environment(cfg)
    try:
        adapter=MultiTaskAdapter(env,cfg);world=StateGeometry(cfg['state']).update(adapter.observe(adapter._initial_obs))
        qpos=np.array(env.sim.data.qpos);qvel=np.array(env.sim.data.qvel);rng=json.dumps(env.rng.bit_generator.state,sort_keys=True)
        original=AssetGraspProvider(cfg,GeometricGraspProvider(cfg));provider=CurrentAssetGrasps(adapter,cfg,original)
        started=time.time();candidates=provider.candidates(a.entity,world)
        assert np.array_equal(qpos,env.sim.data.qpos) and np.array_equal(qvel,env.sim.data.qvel)
        assert rng==json.dumps(env.rng.bit_generator.state,sort_keys=True)
        print(json.dumps(dict(task=a.task,entity=a.entity,candidates=len(candidates),seconds=time.time()-started,static_probes=provider.probes,
            plant_qpos_qvel_rng_unchanged=True,poses=[c.tolist() for c in candidates],records=[provider.describe(c) for c in candidates],rejected=provider.rejected),indent=2))
    finally:env.close()

if __name__=='__main__':main()
