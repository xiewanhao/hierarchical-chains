"""Frozen, prespecified native task-rate evaluation, two owned child processes."""
from __future__ import annotations
import argparse,concurrent.futures,hashlib,json,math,os,signal,subprocess,time
from collections import Counter
from pathlib import Path
from evaluate_episode import sources


def wilson(k: int,n: int) -> list[float] | None:
    if not n:return None
    z=1.959963984540054;p=k/n;d=1+z*z/n
    center=(p+z*z/(2*n))/d;radius=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return [max(0.,center-radius),min(1.,center+radius)]


def summarize(rows: list[dict], protocol: dict) -> dict:
    out={'scope':'Native end-to-end development rates; no official benchmark or paired-gain claim',
        'formal_planned':protocol['total_episodes'],'completed':len(rows),'by_task':{}}
    for task in protocol['tasks']:
        records=[r for r in rows if r['task']==task]
        valid=[r for r in records if r.get('env_initialized') and not r.get('initial_native_success',False)]
        wins=sum(bool(r.get('success')) for r in valid)
        out['by_task'][task]={'completed':len(records),'planned':protocol['episodes_per_task'],'initialized_valid':len(valid),
            'successes':wins,'native_rate':wins/len(valid) if valid else None,'native_wilson95':wilson(wins,len(valid)),
            'attempt_completion_rate':wins/len(records) if records else None,
            'failure_categories':dict(Counter(r.get('outcome_category','unknown') for r in records if not r.get('success'))),
            'total_physics_steps':sum(r.get('audited_env_steps',0) for r in records)}
    return out


def main() -> None:
    parser=argparse.ArgumentParser();parser.add_argument('--smoke',action='store_true');args=parser.parse_args()
    root=Path(__file__).resolve().parents[1];protocol=json.loads((root/'protocol.json').read_text())
    directory=root/'evidence'/('smoke' if args.smoke else 'formal');directory.mkdir(parents=True,exist_ok=False)
    frozen=sources(root);suite_hash=hashlib.sha256(json.dumps(frozen,sort_keys=True).encode()).hexdigest()
    (directory/'freeze.json').write_text(json.dumps({'sha256':frozen,'suite_sha256':suite_hash},indent=2))
    jobs=protocol['jobs']
    if args.smoke:jobs=[dict(task=t,seed=1999,layout=l,style=34,episode_id=f'{t}_L{l}_smoke') for l in protocol['layouts'] for t in protocol['tasks']]
    def run(job: dict) -> dict:
        path=directory/job['episode_id'];log=directory/(job['episode_id']+'.log')
        cmd=['bash',str(root/'scripts/remote_python.sh'),str(root/'scripts/evaluate_episode.py'),
            '--task',job['task'],'--seed',str(job['seed']),'--layout',str(job['layout']),'--style',str(job['style']),'--output',str(path)]
        if args.smoke:cmd.append('--smoke')
        start=time.time()
        with log.open('x') as handle:
            child=subprocess.Popen(cmd,cwd=root,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
            stat=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()
            (directory/(job['episode_id']+'.process.json')).write_text(json.dumps({'pid':child.pid,'start_ticks':stat[19],'command':cmd}))
            timed_out=False
            try:child.wait(timeout=protocol['wall_budget_seconds'])
            except subprocess.TimeoutExpired:
                timed_out=True;os.killpg(child.pid,signal.SIGTERM)
                try:child.wait(timeout=10)
                except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
        result_path=path/'result.json'
        if result_path.exists():r=json.loads(result_path.read_text())
        else:
            r={**job,'status':'wall_timeout' if timed_out else 'process_error','reason':'evaluation_wall_budget' if timed_out else f'process_exit:{child.returncode}',
                'success':False,'env_initialized':(path/'ready.json').exists(),'initial_native_success':False,
                'outcome_category':'wall_budget' if timed_out else 'process_error','elapsed_seconds':time.time()-start}
            if (path/'progress.json').exists():r['last_tick']=json.loads((path/'progress.json').read_text());r['audited_env_steps']=r['last_tick'].get('executions',0)
            path.mkdir(exist_ok=True);result_path.write_text(json.dumps(r,indent=2))
        r['episode_id']=job['episode_id'];r['process_returncode']=child.returncode
        if r.get('source_sha256') and r['source_sha256']!=frozen:r.update(success=False,outcome_category='suite_source_mismatch')
        return r
    rows=[];started=time.time()
    with concurrent.futures.ThreadPoolExecutor(max_workers=protocol['parallel_workers']) as pool:
        pending={pool.submit(run,job):job for job in jobs}
        for completed in concurrent.futures.as_completed(pending):
            r=completed.result();rows.append(r)
            with (directory/'results.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
            summary=summarize(rows,protocol);summary.update(smoke=args.smoke,elapsed_seconds=time.time()-started,suite_sha256=suite_hash)
            temporary=directory/'summary.tmp';temporary.write_text(json.dumps(summary,indent=2));temporary.replace(directory/'summary.json')
            print(json.dumps({'completed':len(rows),'planned':len(jobs),'task':r['task'],'seed':r['seed'],'layout':r['layout'],
                'success':r['success'],'category':r.get('outcome_category'),'steps':r.get('audited_env_steps',0)},ensure_ascii=False),flush=True)
    changed=[n for n,d in frozen.items() if sources(root).get(n)!=d]
    (directory/'completed.json').write_text(json.dumps({'completed':len(rows),'planned':len(jobs),'changed_sources':changed,'elapsed_seconds':time.time()-started},indent=2))


if __name__=='__main__':main()
