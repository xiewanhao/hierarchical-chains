from __future__ import annotations
import argparse
from dataclasses import asdict
import hashlib
from pathlib import Path
import json
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from five_chains.components.c11_selector import SelectorAdapter, apply_observed_effect_eligibility
from five_chains.trace import serial


def main() -> None:
    p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--config',required=True);a=p.parse_args()
    config=json.loads(Path(a.config).read_text());sample=json.loads(Path(a.input).read_text())
    import torch
    torch.set_num_threads(2)
    adapter=SelectorAdapter.from_legacy(config,lambda task,obs,history:sample)
    eligibility=apply_observed_effect_eligibility(adapter.model,sample)
    call=adapter.select(sample['instruction'],{},[])
    model=adapter.model
    devices=sorted({str(p.device) for p in model.model.parameters()})
    root=Path(config['legacy_root'])
    files=['selector_vlm.py','research_shared_v38/native_selector_vlm.py','research_shared_v38/native_call_contract.py']
    files.append(config['adapter']+'/adapter_model.safetensors')
    report={'status':'selected','call':serial(call),'parameter_devices':devices,
            'source_sha256':{f:hashlib.sha256((root/f).read_bytes()).hexdigest() for f in files},
            'next_call_available':call.next_call is not None,'input_has_teacher':False,'eligibility':eligibility}
    Path(a.output).write_text(json.dumps(report,indent=2));print(json.dumps(report))


if __name__=='__main__':main()
