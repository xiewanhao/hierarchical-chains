"""External fixed-version validation driver; no source/config mutation."""
import argparse,concurrent.futures,json,os,signal,subprocess,time,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'scripts'))
from evaluate_episode import sources

def main():
 waiting=root/'validation_queue_status.json'
 receipts=[root/'dev_process.json',root.parent/'improve_20261113_r13/dev_process.json',root.parent/'improve_20261113_r10/dev_process.json']
 def live(receipt):
  if not receipt.exists():return False
  d=json.loads(receipt.read_text());p=Path('/proc')/str(d['pid'])/'stat'
  if not p.exists():return False
  parts=p.read_text().rsplit(')',1)[1].split()
  return parts[19]==d['start_ticks'] and parts[0]!='Z'
 while any(live(p) for p in receipts):
  waiting.write_text(json.dumps(dict(status='waiting_for_development_jobs',source_root=str(root),timestamp=time.time())))
  time.sleep(10)
 waiting.write_text(json.dumps(dict(status='running_isolated_validation',timestamp=time.time())))
 tasks=('SteamInMicrowave','HeatMug','PrepareCoffee','ArrangeBreadBasket','PanTransfer')
 cases=[(task,layout,seed) for task in tasks for layout in (8,11) for seed in (2012,2013)]
 out=root/'evidence/validation_2012_2013';out.mkdir(parents=True,exist_ok=False)
 frozen=sources(root);started=time.time()
 protocol=dict(purpose='independent-seed initial validation; no tuning within this batch',development_only=False,
  cases=cases,source_sha256=frozen,styles=[34],max_physics_steps=6000,max_selector_calls=10,wall_seconds_per_case=600,workers=2,
  success='unchanged native env._check_success() and final native success; all attempts retained in denominator',
  baseline='frozen original100episodes on seeds2000..2009; this is an unpaired initial comparison, not an official benchmark or matched causal study')
 (out/'protocol.json').write_text(json.dumps(protocol,indent=2))
 def run(case):
  task,layout,seed=case;name=f'{task}_L{layout}_S{seed}';directory=out/name
  cmd=['bash','scripts/remote_python.sh','scripts/evaluate_episode.py','--task',task,'--layout',str(layout),'--seed',str(seed),'--output',str(directory)]
  with (out/(name+'.log')).open('x') as log:
   child=subprocess.Popen(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   ticks=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
   (out/(name+'.process.json')).write_text(json.dumps(dict(pid=child.pid,start_ticks=ticks,command=cmd)))
   timeout=False
   try:child.wait(timeout=600)
   except subprocess.TimeoutExpired:
    timeout=True;os.killpg(child.pid,signal.SIGTERM)
    try:child.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
  if (directory/'result.json').exists():r=json.loads((directory/'result.json').read_text())
  else:r=dict(task=task,layout=layout,seed=seed,success=False,reason='wall_budget' if timeout else 'process_error')
  r.update(case_id=name,development_only=False,validation_batch='independent_2012_2013')
  return r
 results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  for future in concurrent.futures.as_completed([pool.submit(run,c) for c in cases]):
   r=future.result();results.append(r)
   (out/'results.json').write_text(json.dumps(results,indent=2))
   status=dict(completed=len(results),total=len(cases),successes=sum(bool(r['success']) for r in results),elapsed_seconds=time.time()-started)
   (out/'status.json').write_text(json.dumps(status))
   print(json.dumps({k:r.get(k) for k in ('case_id','success','reason','audited_env_steps','actual_model_calls')}),flush=True)
 changed=[n for n,h in frozen.items() if sources(root).get(n)!=h]
 (out/'completed.json').write_text(json.dumps(dict(completed=len(results),total=len(cases),source_changed=changed,elapsed_seconds=time.time()-started),indent=2))
 if changed:raise RuntimeError('validation source changed')
if __name__=='__main__':main()
