from __future__ import annotations
from copy import deepcopy
from pathlib import Path
from typing import Any
import math
import yaml


def merge(base: dict, update: dict) -> dict:
    out = deepcopy(base)
    for key, value in update.items():
        out[key] = merge(out[key], value) if isinstance(value, dict) and isinstance(out.get(key), dict) else deepcopy(value)
    return out


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    default = Path(__file__).resolve().parents[1] / "configs/default.yaml"
    if not default.is_file():
        default = Path(__file__).resolve().parent / "data/default.yaml"
    cfg = yaml.safe_load(default.read_text())
    if path:
        cfg = merge(cfg, yaml.safe_load(Path(path).read_text()) or {})
    validate_config(cfg)
    return cfg


def validate_config(cfg: dict) -> None:
    yaws = cfg['grasp']['cavity_yaw_repair_rad']
    if (not isinstance(yaws,list) or not yaws or yaws[0] != 0.
            or any(not math.isfinite(y) or abs(y)>math.pi for y in yaws)):
        raise ValueError('invalid free-yaw cavity preparation samples')
    repair = cfg['grasp']['parameter_repair']
    if (type(repair['max_attempts']) is not int or not 0 <= repair['max_attempts'] <= 3
            or not math.isfinite(repair['min_open_width_m']) or not 0 < repair['min_open_width_m'] <= .08):
        raise ValueError('invalid grasp parameter repair budget/opening')
    if 'current_asset_contacts' in cfg['grasp'] and not isinstance(cfg['grasp']['current_asset_contacts'],bool):
        raise ValueError('current-asset contact preparation requires a boolean setting')
    for group,key in (('base','cavity_standoff_m'),('grasp','cabinet_exit_clearance_m')):
        if key in cfg[group] and (not math.isfinite(cfg[group][key]) or cfg[group][key]<=0):
            raise ValueError('invalid geometry clearance: '+key)
    if not math.isfinite(cfg['preparation']['translation_reference_m']) or cfg['preparation']['translation_reference_m']<=0:
        raise ValueError('preparation reference length must be positive')
    if any(not math.isfinite(v) or v<=0 for v in cfg['torso'].values()):
        raise ValueError('invalid torso settings')
    ik=cfg['control']['posture_ik']
    if any(not math.isfinite(v) or v<=0 for k,v in ik.items() if k not in ('enabled','allow_approximate_reference','orientation_projection','path_planning')):
        raise ValueError('invalid posture IK setting')
    refinement=cfg['grasp']['contact_refinement']
    if any(not math.isfinite(v) or v<0 for v in refinement.values()) or refinement['iterations']<1 or refinement['apertures']<3:
        raise ValueError('invalid contact refinement settings')
    if cfg['grasp']['provider'] not in ('geometric','asset_cached'):
        raise ValueError('unknown grasp provider')
    proposals=cfg['grasp']['asset_candidates']
    if (not 0<=proposals['min_confidence']<=1 or proposals['top_k']<1 or
        not 0<=proposals['min_radial_fraction']<proposals['max_radial_fraction'] or
        not 0<=proposals['max_approach_tilt_rad']<math.pi/2):
        raise ValueError('invalid asset proposal filter')
    if not math.isfinite(cfg['base']['hold_max_speed_m_s']) or cfg['base']['hold_max_speed_m_s'] <= 0:
        raise ValueError('base hold speed must be positive')
    load=cfg['grasp']['loaded_acquisition']
    for key in ('preload_height_m','min_object_lift_m','stable_translation_m','stable_rotation_rad','speed_m_s'):
        if not math.isfinite(load[key]) or load[key]<=0:raise ValueError('invalid loaded acquisition setting: '+key)
    if load['min_object_lift_m']>=load['preload_height_m'] or load['stable_frames']<1:
        raise ValueError('invalid loaded acquisition sequence')
    if not 0<=cfg['control']['constraint_tilt_margin_rad']<.05:raise ValueError('invalid tilt interior margin')
    planner=cfg['control']['posture_ik']['path_planning']
    for key in ('iterations','goal_seeds','connect_steps','shortcut_attempts'):
        if not isinstance(planner[key],int) or planner[key]<1:raise ValueError('invalid path planning count: '+key)
    for key in ('extension_rad','validation_step_rad','waypoint_step_rad','joint_reached_rad','container_tilt_slack_rad'):
        if not math.isfinite(planner[key]) or planner[key]<=0:raise ValueError('invalid path planning scale: '+key)
    if not 0<planner['orientation_search_fraction']<1:raise ValueError('attitude search must stay inside the original goal region')
    if not 0<planner['goal_bias']<1 or not 0<=planner['penetration_epsilon_m']<=1e-5:
        raise ValueError('invalid path planning geometry setting')
    if cfg["control"]["max_ticks"] <= 0:
        raise ValueError("max_ticks must be positive")
    if cfg['feedback']['grasp_contact_mode'] not in ('native_pads','bilateral_fingers'):
        raise ValueError('unknown grasp contact mode')
    if cfg['feedback']['grasp_confirm_steps'] < 1 or cfg['feedback']['grasp_contact_grace_steps'] < 0:
        raise ValueError('invalid contact evidence window')
    for key in ('grasp_retention_translation_m','grasp_retention_rotation_rad','lift_retention_min_m'):
        if not math.isfinite(cfg['feedback'][key]) or cfg['feedback'][key] <= 0:
            raise ValueError('invalid grasp retention bound: '+key)
    for key in ('reached_m','approach_speed_m_s','lift_speed_m_s','rim_depth_m','container_drop_reached_m'):
        if not math.isfinite(cfg['grasp'][key]) or cfg['grasp'][key] <= 0:
            raise ValueError('invalid grasp setting: '+key)
    if not 0 <= cfg['grasp']['asset_candidates']['max_jaw_tilt_rad'] < math.pi/2:
        raise ValueError('jaw tilt must be measured from the horizontal plane')
    if not 0 <= cfg['grasp']['rim_approach_tilt_rad'] < math.pi/2:
        raise ValueError('rim approach must point downward')
    if not isinstance(cfg['grasp']['door_closed_settle_ticks'],int) or cfg['grasp']['door_closed_settle_ticks']<1:
        raise ValueError('door settling needs positive physical frame count')
    if not math.isfinite(cfg['grasp']['door_closed_max_velocity_rad_s']) or cfg['grasp']['door_closed_max_velocity_rad_s']<=0:
        raise ValueError('invalid door settling velocity')
    if cfg['grasp']['close_settle_ticks'] < 0:
        raise ValueError('negative grasp settle time')
    for name in ("eps_pos", "eps_rot", "eps_joint"):
        if cfg["state"][name] < 0:
            raise ValueError(name + " must be nonnegative")
    if cfg["state"]["backend"] not in ("ground_truth", "noisy"):
        raise ValueError("unknown state backend")
    if cfg["state"]["noise"]["update_every"] < 1:
        raise ValueError("update_every must be positive")
    for name in ("pos_std", "rot_std"):
        value = cfg["state"]["noise"][name]
        if not math.isfinite(value) or value < 0:
            raise ValueError("invalid noise scale: " + name)
    for group, names in {"control": ("reference_speed_m_s", "reference_rotation_rad_s", "max_tracking_lead_m", "reached_m", "reached_rad"),
                         "base": ("stance_reached_m", "standoff_m", "payload_clearance_margin_m", "door_lateral_standoff_m", "door_front_standoff_m", "door_fixture_standoff_m", "door_max_lateral_shift_m", "max_speed_m_s", "max_yaw_rad_s", "proportional_gain", "reached_m", "reached_rad")}.items():
        for name in names:
            value = cfg[group][name]
            if not math.isfinite(value) or value <= 0:
                raise ValueError("invalid positive control setting: " + group + "." + name)
    if any(not math.isfinite(value) or value < 0 for value in cfg["fb_fast"]["thresholds"].values()):
        raise ValueError("invalid feedback threshold")
    for name in ("max_pos_correction_m", "max_rot_correction_rad"):
        if cfg["reflex"]["bounds"][name] < 0:
            raise ValueError("negative reflex bound")
    valid = {"c1_prep", "c2_reflex", "c3a_fb_fast", "c3b_fb_full", "c4_vision"}
    if not set(cfg["ablation"]["disable_chains"]) <= valid:
        raise ValueError("unknown disabled chain")
    if "c1_prep" in cfg["ablation"]["disable_chains"]:
        raise ValueError("preparation is required to initialize a contract")
