from __future__ import annotations
from typing import Protocol
from dataclasses import replace
import numpy as np
from scipy.spatial.transform import Rotation
from five_chains.geometry import pose, inverse, rigid
from five_chains.preparation import decode_preparation
from five_chains.types import Contract, FieldPrep, FieldSpec, WorldState, ReadoutError


class GraspProvider(Protocol):
    def candidates(self, entity: str, world: WorldState) -> tuple[np.ndarray, ...]: ...


class GeometricGraspProvider:
    def __init__(self, config: dict | None = None) -> None:
        self.config = config

    def candidates(self, entity: str, world: WorldState) -> tuple[np.ndarray, ...]:
        item = world.entities[entity]
        opening_local = np.asarray(world.signals.get("gripper_opening_axis_eef", [1.,0.,0.]),float).copy()
        opening_local[2] = 0.
        opening_local /= np.linalg.norm(opening_local)
        zlocal=np.array([0.,0.,1.])
        local_basis=np.column_stack([opening_local,np.cross(zlocal,opening_local),zlocal])
        rim = world.signals.get("grasp_modes", {}).get(entity) == "rim"
        # Top approach in world, expressed in the current object reference.
        result = []
        for yaw in (0.0, np.pi / 2, np.pi, -np.pi / 2):
            opening_world=np.array([np.cos(yaw),np.sin(yaw),0.])
            zworld=np.array([0.,0.,-1.])
            radial=opening_world.copy()
            if rim:
                assert self.config is not None
                tilt=self.config["grasp"]["rim_approach_tilt_rad"]
                opening_world=np.cos(tilt)*radial-np.sin(tilt)*np.array([0.,0.,1.])
                zworld=-np.sin(tilt)*radial-np.cos(tilt)*np.array([0.,0.,1.])
            orientation=np.column_stack([opening_world,np.cross(zworld,opening_world),zworld])@local_basis.T
            center=item.pose_world[:3,3].copy()
            if rim:
                if self.config is None:
                    raise ValueError("rim grasp requires explicit geometry settings")
                top=np.asarray(world.signals["object_top_offsets"][entity])
                local_direction=item.pose_world[:3,:3].T@radial
                local_direction[2]=0.
                length=np.linalg.norm(local_direction)
                if length<1e-8:
                    continue
                local_direction/=length
                radius=1./np.sqrt(np.sum((local_direction[:2]/item.extent[:2])**2))
                local_point=top+local_direction*radius*self.config["grasp"]["rim_fraction"]
                local_point[2]-=self.config["grasp"]["rim_depth_m"]
                center=item.pose_world[:3,3]+item.pose_world[:3,:3]@local_point
            target = pose(center, orientation)
            result.append(inverse(item.pose_world) @ target)
            if rim:
                alternate = target.copy()
                alternate[:3,:3] = target[:3,:3] @ np.diag([-1.,-1.,1.])
                result.append(inverse(item.pose_world) @ alternate)
        return tuple(result)


class RecipeRegistry:
    def __init__(self, grasp_provider: GraspProvider | None = None, config: dict | None = None) -> None:
        if config is None:
            from five_chains.config import load_config
            config = load_config()
        self.config = config
        self.placement_diagnostics: dict[str, dict] = {}
        self.grasp_provider: GraspProvider = grasp_provider or GeometricGraspProvider(config)
        if grasp_provider is None and config['grasp']['provider']=='asset_cached':
            from five_chains.skills.asset_grasps import AssetGraspProvider
            self.grasp_provider=AssetGraspProvider(config,self.grasp_provider)

    def prepare(self, spec: FieldSpec, contract: Contract, world: WorldState,
                prepared_support: object | None = None) -> object | None:
        args = spec.arguments
        if spec.recipe == "normalized":
            return np.asarray(args["value"])
        if spec.recipe == "relative_pose":
            return rigid(args["matrix"]) if "matrix" in args else pose(args.get("offset", [0, 0, 0]), args.get("orientation"))
        if spec.recipe == "object_placement":
            assert spec.prep_frame is not None
            frame = world.entities[spec.prep_frame].pose_world
            item_pose = world.entities[contract.call.bindings["object"]].pose_world.copy()
            if contract.call.bindings['object'] in world.signals.get('upright_entities',()):
                up=item_pose[:3,2];axis=np.cross(up,[0.,0.,1.]);angle=float(np.arccos(np.clip(up[2],-1.,1.)))
                if angle>1e-8:
                    if np.linalg.norm(axis)<1e-8:axis=item_pose[:3,0].copy()
                    item_pose[:3,:3]=Rotation.from_rotvec(axis/np.linalg.norm(axis)*angle).as_matrix()@item_pose[:3,:3]
            # Containers permit orientation-free contents. Preserve the acquired
            # object attitude instead of imposing the receiving body's axes.
            offset = np.asarray(args["offset"],float).copy()
            target_name = contract.call.bindings["target"]
            if world.signals.get("grasp_modes", {}).get(target_name) == "rim":
                top = np.asarray(world.signals["object_top_offsets"][target_name])
                offset[2] = top[2]+self.config["grasp"]["container_drop_clearance_m"]
            if spec.prep_frame in world.signals.get('support_surface_regions',()):
                bottom=np.asarray(world.signals['object_bottom_offsets'][contract.call.bindings['object']])
                offset[2]=-(frame[:3,:3].T@item_pose[:3,:3]@bottom)[2]+self.config['grasp']['placement_clearance_m']
            if spec.prep_frame in world.signals.get("cavity_entities", ()):
                bottom = np.asarray(world.signals["object_bottom_offsets"][contract.call.bindings["object"]])
                bottom_local = frame[:3,:3].T @ item_pose[:3,:3] @ bottom
                extent = world.entities[spec.prep_frame].extent
                offset[2] = -extent[2]-bottom_local[2]+self.config["grasp"]["placement_clearance_m"]
                entrance = args.get("placement_mode") == "entrance"
                if entrance:
                    offset[1] = -extent[1]-self.config["grasp"]["entrance_clearance_m"]
                # The entrance uses the same future interior yaw choice, so a
                # required turn happens outside the cavity, not after insertion.
                # Release inside the cavity from the lowest height that fits
                # at least one checked hand aperture. The object then settles
                # through real physics after opening; native success remains
                # the only task-completion authority.
                payload_name=contract.call.bindings['object']
                held=payload_name in world.signals.get('grasp_transforms',{})
                candidates=((inverse(world.entities[payload_name].pose_world)@world.eef_pose_world,) if held else self.grasp_provider.candidates(payload_name,world))
                if candidates and hasattr(self.grasp_provider,'filter_for_followup'):
                    turn=np.eye(3) if held else self.preview_turn(contract,world,spec.prep_frame)
                    tested=0;choice=None
                    # Preserve the original yaw whenever ANY previously
                    # allowed height fits. Only then search other free yaws.
                    for yaw in self.config['grasp']['cavity_yaw_repair_rad']:
                        rotation=Rotation.from_euler('z',yaw).as_matrix()@item_pose[:3,:3]
                        for extra in np.arange(0.,.081,.01):
                            local=offset.copy();local[1]=0.;local[2]+=extra
                            goal=frame@pose(local,frame[:3,:3].T@turn@rotation)
                            tested+=1
                            if self.grasp_provider.filter_for_followup(payload_name,world,candidates,spec.prep_frame,goal):
                                choice=(yaw,float(extra),rotation);break
                        if choice is not None:break
                    key=contract.contract_id+'/'+spec.name+'/'+str(args.get('placement_mode','interior'))
                    self.placement_diagnostics[key]={'tested_goals':tested,'admitted':choice is not None,
                        'yaw_rad':None if choice is None else choice[0],
                        'extra_height_m':None if choice is None else choice[1],
                        'scope':'candidate hand-aperture geometry only; native path, contact and success still required'}
                    if choice is not None:
                        chosen_yaw,chosen_extra,chosen_rotation=choice
                        item_pose[:3,:3]=chosen_rotation
                        if not entrance or abs(chosen_yaw)>1e-10:offset[2]+=chosen_extra
            return pose(offset, frame[:3,:3].T @ item_pose[:3,:3])
        if spec.recipe == "held_local_entry":
            obj = contract.call.bindings.get("object")
            if "tilt_limit" in contract.fields:
                obj = contract.fields["tilt_limit"].arguments.get("entity", obj)
            if obj is None:
                return pose(args.get("offset",[0,0,0]))
            assert spec.prep_frame is not None
            frame = world.entities[spec.prep_frame].pose_world
            item_pose = world.entities[obj].pose_world
            offset = np.asarray(args.get("offset",[0,0,0]),float).copy()
            if spec.prep_frame in world.signals.get("cavity_entities", ()):
                bottom = np.asarray(world.signals["object_bottom_offsets"][obj])
                bottom_local = frame[:3,:3].T @ item_pose[:3,:3] @ bottom
                offset[2] = -world.entities[spec.prep_frame].extent[2]-bottom_local[2]+self.config["grasp"]["placement_clearance_m"]
            return pose(offset,frame[:3,:3].T @ item_pose[:3,:3])
        if spec.recipe == "eef_attitude_pose":
            target_name = contract.call.bindings["target"]
            target = world.eef_pose_world.copy()
            if target_name in world.signals.get("cavity_entities", ()):
                frame = world.entities[target_name].pose_world
                local = inverse(frame) @ target
                local[1,3] = -world.entities[target_name].extent[1]-self.config["grasp"]["entrance_clearance_m"]
                return frame @ local
            if target_name in world.signals.get('fixture_front_entities', ()):
                # Withdraw horizontally from a fixture before raising the arm.
                # Raising next to an upper-cabinet door can trap the forearm.
                outward=-world.entities[target_name].pose_world[:3,1].copy();outward[2]=0.
                norm=np.linalg.norm(outward)
                if norm<1e-8:raise ReadoutError('fixture retreat needs a horizontal front normal')
                target[:3,3]+=outward/norm*max(.18,self.config['grasp']['retreat_clearance_m']+.04)
                return target
            toward_base = world.base_pose_world[:2,3]-target[:2,3]
            distance = np.linalg.norm(toward_base)
            if distance > 1e-8:
                target[:2,3] += toward_base/distance*self.config["grasp"]["retreat_back_m"]
            target[2,3] += self.config["grasp"]["retreat_up_m"]
            return target
        if spec.recipe == 'grasp_preload':
            target=world.eef_pose_world.copy()
            target[2,3]+=self.config['grasp']['loaded_acquisition']['preload_height_m']
            return target
        if spec.recipe == "current_reference":
            return world.eef_pose_world.copy()
        if spec.recipe == 'extract_object':
            entity=contract.call.bindings['object'];item=world.entities[entity]
            support=args.get('source_fixture',world.signals.get('object_support_frames',{}).get(entity))
            if support not in world.entities:return item.pose_world.copy()
            fixture=world.entities[support];local=inverse(fixture.pose_world)@item.pose_world
            outward=-fixture.pose_world[:3,1]
            extraction_distance=max(0.,float(local[1,3]+fixture.extent[1]+self.config['grasp'].get('cabinet_exit_clearance_m',.15)))
            goal=item.pose_world.copy();goal[:3,3]+=outward*extraction_distance
            return goal
        if spec.recipe == "payload_entry_clearance":
            # Align outside the opening before base mode carries the whole arm
            # forward. Height alone leaves lateral acquisition offsets intact.
            entry_placement=contract.fields['place_pose']
            if entry_placement.prep_frame in world.signals.get('cavity_entities',()):
                entry_placement=replace(entry_placement,arguments={**entry_placement.arguments,'placement_mode':'entrance'})
            stance=contract.fields['base_at_target']
            assert entry_placement.prep_frame is not None and stance.prep_frame is not None and spec.prep_frame is not None
            goal=world.entities[entry_placement.prep_frame].pose_world@rigid(self.prepare(entry_placement,contract,world))
            base_goal=world.entities[stance.prep_frame].pose_world@rigid(self.prepare(stance,contract,world))
            axis=world.entities[entry_placement.prep_frame].pose_world[:3,1].copy();axis[2]=0.
            axis/=np.linalg.norm(axis)
            # Keep the payload centered laterally before approaching an open
            # side-hinged door. Compensate only the forthcoming forward travel.
            delta=world.base_pose_world[:3,3]-base_goal[:3,3]
            goal[:3,3]+=axis*float(axis@delta)
            if args.get('preserve_height'):
                goal[2,3]=world.entities[contract.call.bindings['object']].pose_world[2,3]
            else:goal[2,3]+=self.config['grasp']['transfer_height_margin_m']
            return inverse(world.entities[spec.prep_frame].pose_world)@goal
        if spec.recipe == "lift_object":
            item = world.entities[contract.call.bindings["object"]]
            # Lift is world-up even when the grasped object's body frame is tilted.
            lift = float(args["clearance_m"])
            placement = contract.fields.get("place_pose")
            if args.get("include_target_height",True) and placement and placement.recipe == "object_placement" and placement.prep_frame is not None:
                prepared = self.prepare(placement,contract,world)
                if prepared is not None:
                    goal = world.entities[placement.prep_frame].pose_world @ rigid(prepared)
                    lift = max(lift,goal[2,3]+self.config["grasp"]["transfer_height_margin_m"]-item.pose_world[2,3])
            offset = item.pose_world[:3, :3].T @ np.array([0., 0., lift])
            return pose(offset)
        if spec.recipe == "torso_support":
            placement=contract.fields[args.get('support_target','place_pose')]
            assert placement.prep_frame is not None and spec.value_range is not None
            prepared=(prepared_support if prepared_support is not None
                      else self.prepare(placement,contract,world))
            if prepared is None:return None
            body_goal=world.entities[placement.prep_frame].pose_world@rigid(prepared)
            relation=world.signals.get('grasp_transforms',{}).get(contract.call.bindings.get('object'))
            eef_height=((body_goal@inverse(relation))[2,3] if relation is not None and not args.get('source_is_eef') else body_goal[2,3])
            # Native proprioception supplies mount position, lift position and limits.
            support=world.signals.get('torso',{'position_m':0.,'origin_world':world.base_pose_world[:3,3],'range_m':[0.,.34]})
            low,high=spec.value_range
            live_low,live_high=support['range_m']
            wanted=support['position_m']+eef_height+self.config['grasp']['transfer_height_margin_m']-support['origin_world'][2]-self.config['torso']['preferred_eef_above_mount_m']
            physical=float(np.clip(wanted,max(low,live_low),min(high,live_high)))
            return (physical-low)/(high-low)
        if spec.recipe == "base_stance":
            assert spec.prep_frame is not None
            item = world.entities[spec.prep_frame]
            delta = world.base_pose_world[:2, 3] - item.pose_world[:2, 3]
            distance = np.linalg.norm(delta)
            if distance < 1e-8:
                return None
            target = world.base_pose_world.copy()
            front_name=item.name if item.name in world.signals.get('fixture_front_entities',()) else world.signals.get('object_support_frames',{}).get(item.name)
            if front_name is not None and front_name in world.entities:
                outward = -world.entities[front_name].pose_world[:3,1].copy()
                outward[2] = 0.
                norm = np.linalg.norm(outward)
                if norm < 1e-8:
                    return None
                outward /= norm
                standoff=(self.config['base'].get('cavity_standoff_m',self.config['base']['standoff_m']) if item.name in world.signals.get('cavity_entities',()) and not args.get('payload_clearance') else self.config['base']['standoff_m'])
                if args.get('payload_clearance'):
                    payload=world.entities[contract.call.bindings['object']]
                    # Base mode rotates the held geometry with the base yaw.
                    yaw=np.arctan2(-outward[1],-outward[0])
                    planned=Rotation.from_euler('z',yaw).as_matrix()
                    delta_rotation=planned@world.base_pose_world[:3,:3].T
                    relative=delta_rotation@(payload.pose_world[:3,3]-world.base_pose_world[:3,3])
                    projected_radius=float(np.abs(outward@(delta_rotation@payload.pose_world[:3,:3]))@payload.extent)
                    forward=-float(outward@relative)
                    front=float(item.extent[1])
                    for name in world.signals.get('cavity_obstacles',{}).get(item.name,()):
                        if name not in world.entities:raise ReadoutError('missing clearance obstacle: '+name)
                        obstacle=world.entities[name]
                        front=max(front,float(outward@(obstacle.pose_world[:3,3]-item.pose_world[:3,3]))+
                            float(np.abs(outward@obstacle.pose_world[:3,:3])@obstacle.extent))
                    reach=forward+projected_radius
                    points=np.asarray(world.signals.get('gripper_collision_points_world',[]),float)
                    if points.size:
                        if points.ndim!=2 or points.shape[1]!=3:raise ReadoutError('invalid gripper geometry points')
                        rotated=(points-world.base_pose_world[:3,3])@delta_rotation.T
                        reach=max(reach,float(np.max(-rotated@outward)))
                    standoff=max(standoff,front+reach+self.config['base']['payload_clearance_margin_m'])
                target[:2,3] = item.pose_world[:2,3]+outward[:2]*standoff
                if self.config["base"]["face_fixture"]:
                    yaw = np.arctan2(-outward[1],-outward[0])
                    target[:3,:3] = Rotation.from_euler('z',yaw).as_matrix()
            elif distance > self.config["base"]["standoff_m"]:
                target[:2, 3] = item.pose_world[:2, 3] + delta / distance * self.config["base"]["standoff_m"]
            if self.config["base"]["face_object"] and item.name not in world.signals.get("fixture_front_entities", ()):
                direction=item.pose_world[:2,3]-target[:2,3]
                yaw=np.arctan2(direction[1],direction[0])
                target[:3,:3]=Rotation.from_euler('z',yaw).as_matrix()
            return inverse(item.pose_world) @ target
        if spec.recipe in ("grasp_candidates_for_followup", "pregrasp"):
            name = contract.call.bindings["object"]
            candidates = self.grasp_provider.candidates(name, world)
            rejected = world.signals.get('grasp_candidate_rejections', {})
            if rejected.get('contract_id') == contract.contract_id:
                candidates = tuple(t for t in candidates if not any(
                    np.allclose(t, old, atol=1e-6, rtol=0)
                    for old in rejected.get('contacts_object', ())))
            if not candidates:
                return None
            # Preview the selected placement itself, or an explicitly supplied
            # subsequent call. Never invent a future selector output.
            followup_target = self.preview_target(contract,world)
            candidates=self.filter_followup(contract,world,name,candidates)
            if not candidates:return None
            def motion_cost(t: np.ndarray) -> tuple[float, float]:
                candidate = world.entities[name].pose_world @ t
                base_distance = np.linalg.norm(candidate[:2,3]-world.base_pose_world[:2,3])
                hand_distance = np.linalg.norm(candidate[:3,3]-world.eef_pose_world[:3,3])
                angle = np.linalg.norm(Rotation.from_matrix(candidate[:3,:3]@world.eef_pose_world[:3,:3].T).as_rotvec())
                cost = (self.config["grasp"]["base_reach_cost_weight"]*base_distance
                        + self.config["grasp"]["hand_motion_cost_weight"]*hand_distance)
                return float(cost),float(angle)
            if followup_target in world.entities:
                turn=self.preview_turn(contract,world,followup_target)
                direction=(world.entities[followup_target].pose_world[:3,1] if followup_target in world.signals.get('cavity_entities',())
                    else world.entities[followup_target].pose_world[:3,3]-world.entities[name].pose_world[:3,3])
                def score(t: np.ndarray) -> tuple[float, float, float]:
                    opening = turn @ (world.entities[name].pose_world @ t)[:3, :3] @ np.asarray(world.signals.get("gripper_opening_axis_eef", [1.,0.,0.]))
                    cost,angle = motion_cost(t)
                    # Rim slope contributes a vertical opening component. Insertion
                    # azimuth must be independent of receiving-surface height.
                    opening_xy=opening[:2]
                    alignment = abs(opening_xy @ direction[:2]) / max(float(np.linalg.norm(opening_xy)*np.linalg.norm(direction[:2])),1e-8)
                    return cost+self.config["grasp"]["orientation_distance_weight_m_rad"]*angle+self.config["grasp"]["future_alignment_weight_m"]*float(alignment), cost, angle
                chosen = min(candidates, key=score)
            else:
                # Minimize initial orientation change for an unconditioned grasp.
                def score(t: np.ndarray) -> tuple[float, float, float]:
                    cost,angle = motion_cost(t)
                    return cost+self.config["grasp"]["orientation_distance_weight_m_rad"]*angle, cost, angle
                chosen = min(candidates, key=score)
            chosen = chosen.copy()
            if spec.recipe == "pregrasp":
                chosen[:3, 3] += self.approach_offset(chosen,world,name,args['clearance_m'])
            return chosen
        if spec.recipe == "hinge_step":
            # A local contact target attached to the hinge geometry; joint advancement is feedback-driven.
            return pose(args.get("offset", [0, 0, 0]))
        if spec.recipe == 'contact_release':
            source=contract.fields[args['source_field']]
            local=rigid(self.prepare(source,contract,world))
            if source.prep_frame is None:raise ReadoutError('contact release source needs a physical frame')
            target=local if source.prep_frame=='world' else world.entities[source.prep_frame].pose_world@local
            if source.recipe=='button_approach':
                control=contract.call.bindings['control'];normal=np.asarray(world.signals['surface_normals'][control],float)
                target[:3,3]=world.entities[control].pose_world[:3,3]+normal/np.linalg.norm(normal)*max(.30,self.config['grasp']['button_approach_m'])
            return target
        if spec.recipe == 'door_work_stance':
            appliance_pose=world.entities[contract.call.bindings['appliance']].pose_world
            local=inverse(appliance_pose)@world.base_pose_world
            handle_local=inverse(appliance_pose)@world.entities[contract.call.bindings['handle']].pose_world
            side=1. if local[0,3]>=handle_local[0,3] else -1.
            desired=handle_local[0,3]+side*self.config['base']['door_lateral_standoff_m']
            shift=np.clip(desired-local[0,3],-self.config['base']['door_max_lateral_shift_m'],self.config['base']['door_max_lateral_shift_m'])
            local[0,3]+=shift
            reference_name=args.get('clearance_reference')
            if reference_name is None or reference_name not in world.entities:
                raise ReadoutError('door stance needs an explicit fixture clearance reference')
            reference_local=inverse(appliance_pose)@world.entities[reference_name].pose_world
            safe_front=reference_local[1,3]-self.config['base']['door_fixture_standoff_m']
            local[1,3]=min(handle_local[1,3]-self.config['base']['door_front_standoff_m'],safe_front)
            target_world=appliance_pose@local
            direction=world.entities[contract.call.bindings['handle']].pose_world[:2,3]-target_world[:2,3]
            target_world[:3,:3]=Rotation.from_euler('z',np.arctan2(direction[1],direction[0])).as_matrix()
            return inverse(appliance_pose)@target_world
        if spec.recipe == 'door_clearance':
            appliance_pose=world.entities[contract.call.bindings['appliance']].pose_world
            handle=world.entities[contract.call.bindings['handle']].pose_world
            if args['around_edge']:
                target=handle@rigid(self.prepare(contract.fields['handle_pose'],contract,world))
            else:target=world.eef_pose_world.copy()
            local=inverse(appliance_pose)@target
            handle_local=inverse(appliance_pose)@handle
            # Route around the far edge of the open door before moving laterally.
            local[1,3]=min(local[1,3],handle_local[1,3]-self.config['grasp']['door_edge_clearance_m'])
            return local[:3,3].copy() if args.get('position_only') else local
        if spec.recipe == "closed_handle_pose":
            hinge = world.signals.get("microwave_hinge")
            if hinge is None:
                return None
            name = contract.call.bindings["handle"]
            appliance = contract.call.bindings["appliance"]
            handle = world.entities[name].pose_world.copy()
            axis = np.asarray(hinge["axis_world"], float)
            anchor = np.asarray(hinge["anchor_world"], float)
            rotation = Rotation.from_rotvec(-float(hinge["angle"]) * axis).as_matrix()
            target = pose(anchor + rotation @ (handle[:3, 3] - anchor), world.eef_pose_world[:3, :3])
            return inverse(world.entities[appliance].pose_world) @ target
        if spec.recipe in ("button_approach", "button_press", "handle_approach"):
            role = "handle" if spec.recipe == "handle_approach" else "control"
            item = world.entities[contract.call.bindings[role]]
            normal = world.signals.get("surface_normals", {}).get(item.name)
            if normal is None:
                return None
            normal = np.asarray(normal, float)
            z = -normal / np.linalg.norm(normal)
            roll_reference = args.get('roll_reference','current_eef')
            if roll_reference not in ('world_up','current_eef'):
                raise ReadoutError('unknown contact roll reference')
            tangent = np.array([0.,0.,1.]) if roll_reference=='world_up' else world.eef_pose_world[:3,0]
            x = tangent-z*np.dot(tangent,z)
            if np.linalg.norm(x) < 1e-8:
                tangent=world.eef_pose_world[:3,0]
                x=tangent-z*np.dot(tangent,z)
            if np.linalg.norm(x) < 1e-8:
                x = world.eef_pose_world[:3, 1] - z * np.dot(world.eef_pose_world[:3, 1], z)
            x = x / np.linalg.norm(x)
            orientation = np.column_stack([x, np.cross(z, x), z])
            orientation=orientation@Rotation.from_rotvec([0.,0.,float(args.get('contact_roll_rad',0.))]).as_matrix()
            distance = (-self.config["grasp"]["button_press_m"] if spec.recipe == "button_press"
                        else self.config["grasp"]["button_approach_m"])
            target = pose(item.pose_world[:3, 3] + normal * distance, orientation)
            return inverse(item.pose_world) @ target
        return None

    def preview_target(self, contract: Contract, world: WorldState) -> str | None:
        target=contract.call.bindings.get('target')
        obj=contract.call.bindings.get('object')
        if (contract.call.skill=='place_object_in_container' and target in world.signals.get('cavity_entities',())
                and obj not in world.signals.get('grasp_transforms',{})):
            return target
        hint=contract.followup.get('target')
        return hint if isinstance(hint,str) else None

    def preview_turn(self, contract: Contract, world: WorldState, target: str) -> np.ndarray:
        start=world.base_pose_world.copy();finish=world.base_pose_world.copy()
        for name in ('base_at_object','base_at_target'):
            spec=contract.fields.get(name)
            if spec is None or spec.prep_frame is None:continue
            if name=='base_at_target' and spec.prep_frame!=target:spec=replace(spec,prep_frame=target)
            assert spec.prep_frame is not None
            local=self.prepare(spec,contract,world)
            if local is None:continue
            frame=np.eye(4) if spec.prep_frame=='world' else world.entities[spec.prep_frame].pose_world
            stance=frame@rigid(local)
            if name=='base_at_object':start=stance
            else:finish=stance
        return finish[:3,:3]@start[:3,:3].T

    def filter_followup(self, contract: Contract, world: WorldState, entity: str,
                        candidates: tuple[np.ndarray,...]) -> tuple[np.ndarray,...]:
        target=self.preview_target(contract,world)
        if (not isinstance(target,str) or target not in world.signals.get('cavity_entities',()) or 'place_pose' not in contract.fields
                or not hasattr(self.grasp_provider,'filter_for_followup')):
            return candidates
        placement=contract.fields['place_pose']
        if placement.prep_frame!=target:raise ReadoutError('future fit requires an explicit placement frame')
        goal_spec=replace(placement,arguments={**placement.arguments,'placement_mode':'interior'})
        goal_local=self.prepare(goal_spec,contract,world)
        goal_world=world.entities[target].pose_world@rigid(goal_local)
        goal_world[:3,:3]=self.preview_turn(contract,world,target)@goal_world[:3,:3]
        return self.grasp_provider.filter_for_followup(entity,world,candidates,target,goal_world)

    def provenance(self, spec: FieldSpec, value: object, world: WorldState, contract: Contract | None = None) -> dict:
        if spec.recipe=='pregrasp' and value is not None:
            assert spec.prep_frame is not None
            contact=rigid(value)
            offset=self.approach_offset(contact,world,spec.prep_frame,spec.arguments['clearance_m'])
            contact[:3,3]-=offset
            info={'recipe':spec.recipe,'contact_pose_object':contact.tolist(),'approach_offset_object':offset.tolist()}
        elif spec.recipe=='grasp_candidates_for_followup' and hasattr(self.grasp_provider,'describe') and value is not None:
            info=self.grasp_provider.describe(rigid(value))
        else:
            info={'recipe':spec.recipe,'provider':type(self.grasp_provider).__name__ if spec.recipe=='pregrasp' else None}
        if contract is not None and spec.recipe=='object_placement':
            key=contract.contract_id+'/'+spec.name+'/'+str(spec.arguments.get('placement_mode','interior'))
            if key in self.placement_diagnostics:info['cavity_yaw_preview']=self.placement_diagnostics[key].copy()
        if contract is not None and spec.recipe in ('pregrasp','grasp_candidates_for_followup'):
            obj=contract.call.bindings.get('object')
            if obj is not None and obj in world.entities:info['source_extent']=world.entities[obj].extent.tolist()
            target=self.preview_target(contract,world)
            if target is not None:
                info['preview']={'target':target,'base_turn_world':self.preview_turn(contract,world,target).tolist(),
                    'obstacles':list(world.signals.get('cavity_obstacles',{}).get(target,()))}
        return info

    def valid(self, spec: FieldSpec, previous: FieldPrep, contract: Contract, world: WorldState) -> bool:
        if previous.status not in ("ready", "bound"):
            return False
        if previous.status=='ready':
            reference=previous.provenance.get('translation_reference_m',self.config['preparation']['translation_reference_m'])
            previous=replace(previous,value=decode_preparation(spec,previous.value,reference))
        if spec.recipe in ("base_stance","door_work_stance"):
            return False  # stance depends on the current target/base geometry
        if spec.recipe in ("grasp_candidates_for_followup", "pregrasp"):
            invalid = world.signals.get("invalid_grasp_fields", ())
            if spec.name in invalid:
                return False
            entity=contract.call.bindings["object"]
            item = world.entities[entity]
            source_extent=previous.provenance.get('source_extent')
            if source_extent is not None and not np.allclose(source_extent,item.extent,atol=self.config['state']['eps_pos'],rtol=0):return False
            contact=rigid(previous.value)
            if spec.recipe=='pregrasp':
                stored=previous.provenance.get('contact_pose_object')
                if stored is None:return False
                contact=rigid(stored)
                expected=contact[:3,3]+self.approach_offset(contact,world,entity,spec.arguments['clearance_m'])
                if np.linalg.norm(rigid(previous.value)[:3,3]-expected)>self.config['state']['eps_pos']:
                    return False
            if entity not in world.signals.get('grasp_transforms',{}) and not self.filter_followup(contract,world,entity,(contact,)):
                return False
            approach = (item.pose_world @ rigid(previous.value))[:3, 2]
            tilt = np.arccos(np.clip(-approach[2], -1, 1))
            rim = world.signals.get("grasp_modes", {}).get(item.name) == "rim"
            limit = (self.config["grasp"]["rim_approach_tilt_rad"] + self.config["grasp"]["max_top_approach_tilt_rad"]
                     if rim else self.config["grasp"]["max_top_approach_tilt_rad"])
            if world.signals.get('object_support_frames',{}).get(entity) in world.signals.get('enclosed_support_entities',()):
                limit=np.pi/2+self.config['grasp']['max_top_approach_tilt_rad']
            if tilt > limit:
                return False
        # Local rigid references remain valid across movement of their parent frame.
        return True

    def approach_offset(self, contact: np.ndarray, world: WorldState, entity: str, clearance: float) -> np.ndarray:
        support=world.signals.get('object_support_frames',{}).get(entity)
        if self.config['grasp'].get('current_asset_contacts',False) or support in world.signals.get('enclosed_support_entities',()):return -contact[:3,2]*clearance
        return world.entities[entity].pose_world[:3,:3].T@np.array([0.,0.,clearance])
