from __future__ import annotations
from typing import Any
from dataclasses import replace
import numpy as np
from five_chains.geometry import motion_target
from five_chains.types import Components, RuntimeContext, SkillCall, EpisodeResult, Proposal, Contract, SelectorOutputError, ReadoutError, ContractError
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.c2_reflex import chain2_reflex
from five_chains.chains.c3_feedback import chain3a_fast, chain3b_full
from five_chains.chains.c4_vision import chain4_vision
from five_chains.chains.c5_replan import chain5_replan
from five_chains.chains.grasp_repair import repair_world, retry_grasp


def next_call(ctx: RuntimeContext, C: Components, task: str, obs: dict) -> SkillCall:
    if ctx.sub_queue:
        return ctx.sub_queue.pop(0)
    ctx.selector_calls += 1
    call = C.c11.select(task, obs, ctx.history)
    expanded = C.c12.expand(call)
    if expanded.sub_calls:
        ctx.sub_queue.extend(expanded.sub_calls)
        return ctx.sub_queue.pop(0)
    return call


def run_episode(env: Any, task: str, C: Components, cfg: dict, tracer: Any,
                perturb: Any | None = None) -> EpisodeResult:
    obs = C.adapter.reset(env)
    ctx = RuntimeContext()
    previous = None
    last_contract: Contract | None = None
    disabled = set(cfg["ablation"]["disable_chains"])
    replans=0;failures=[]
    def recover(contract: Contract, world: Any, reason: str) -> bool:
        nonlocal replans, obs
        chain5_replan(contract,world,reason,tracer)
        if replans>=cfg.get('replan',{}).get('max_reselections',0):return False
        replans+=1
        failures.append({'primary':contract.call.skill,'bindings':dict(contract.call.bindings),
                         'status':'failed','reason':reason,'stamp':world.stamp})
        # This observation is the same physical plant state. No env.step/reset.
        obs['state']['signals']['failure_feedback']=failures[-3:]
        tracer.write({'kind':'reselection_requested','attempt':replans,'failed_call':contract.call,
                      'reason':reason,'stamp':world.stamp,'pending_children_discarded':len(ctx.sub_queue)})
        ctx.contract=None;ctx.p6=None;ctx.p7=None;ctx.packet=None;ctx.steps=0;ctx.sub_queue.clear()
        ctx.grasp_rejections.clear()
        return True
    for tick in range(cfg["control"]["max_ticks"]):
        if perturb:
            obs = perturb(tick, obs, ctx, C)
        with tracer.measure("c04_state"):
            world = C.c4.update(obs)
        world = repair_world(world, ctx)
        with tracer.measure("c05_feedback"):
            delta = C.c5.encode(obs, world, previous, ctx.reflex_event)
        proposals = []
        proposal: Proposal | None = None
        triggers = []
        if ctx.contract:
            assert ctx.p7 is not None
            status = C.c12.check_termination(ctx.contract, world, delta, ctx.p7, ctx.steps)
            if status == "failure":
                from five_chains.components.c12_contract import predicate
                failed_predicate = ctx.contract.termination.fail_when
                if failed_predicate and predicate(failed_predicate,world,delta):
                    reason = failed_predicate
                elif ctx.steps >= ctx.contract.termination.timeout_steps:
                    reason = "contract_timeout"
                else:
                    reason = "phase_timeout:" + ctx.p7.phase_name
                if recover(ctx.contract,world,reason):
                    previous=world
                    continue
                return EpisodeResult(False, tick, "contract_failure:" + reason, ctx.selector_calls, ctx.prep_calls)
            if status == "success":
                last_contract=ctx.contract
                ctx.history.append(ctx.contract.call)
                ctx.contract = None
        if ctx.contract is None:
            ctx.grasp_rejections.clear()
            try:
                with tracer.measure("c11_selector_boundary"):
                    call = next_call(ctx, C, task, obs)
            except SelectorOutputError as error:
                reason='selector_failure:'+str(error)
                if last_contract is not None:chain5_replan(last_contract,world,reason,tracer)
                else:tracer.log_failure('selector',reason)
                return EpisodeResult(False,tick,reason,ctx.selector_calls,ctx.prep_calls)
            try:
                with tracer.measure("c1_prep"):
                    ctx.contract, ctx.p6, ctx.p7, proposal = chain1_prep(call, world, C)
            except (ReadoutError,ContractError) as error:
                reason='preparation_failure:'+str(error)
                failed_contract=C.c12.expand(call)
                if recover(failed_contract,world,reason):
                    previous=world
                    continue
                return EpisodeResult(False,tick,reason,ctx.selector_calls,ctx.prep_calls)
            ctx.packet, ctx.steps = None, 0
            ctx.prep_calls += 1
            proposals.append(proposal)
            triggers.append("c1_prep")
        else:
            assert ctx.p6 is not None and ctx.p7 is not None and ctx.packet is not None
            freeze = cfg["ablation"]["freeze_after_prep"]
            if delta.events and "c3b_fb_full" not in disabled:
                with tracer.measure("c3b_fb_full"):
                    p6, p7, proposal = chain3b_full(ctx.contract, ctx.p6, ctx.p7, world, delta, C)
                ctx.p7 = p7
                # Freeze baseline still tracks stages, but preserves all parameters and P6.
                if not freeze:
                    ctx.p6 = p6
                    if proposal:
                        proposals.append(proposal)
                triggers.append("c3b_phase_only" if freeze else "c3b_fb_full")
            if not freeze and "c3a_fb_fast" not in disabled:
                with tracer.measure("c3a_fb_fast"):
                    proposal = chain3a_fast(ctx.contract, ctx.packet, delta, C, cfg)
                if proposal:
                    proposals.append(proposal)
                    triggers.append("c3a_fb_fast")
            if not freeze and "c4_vision" not in disabled and world.changed_keys & ctx.contract.dep_keys:
                with tracer.measure("c4_vision"):
                    ctx.p6, proposal = chain4_vision(ctx.contract, ctx.p6, ctx.p7, world, C, cfg["ablation"]["vision_full_recompute"])
                if proposal:
                    proposals.append(proposal)
                    triggers.append("c4_vision")
        with tracer.measure("c10_arbitrate"):
            ctx.packet, rejected = C.c10.arbitrate(ctx.packet, proposals, ctx.contract, C.c12)
        assert ctx.p7 is not None and ctx.packet is not None
        # Clock/progress bookkeeping does not advance the phase or run component 7.
        # Phase transitions remain exclusively owned by feedback chain 3b.
        from five_chains.components.c04_state import StateGeometry
        phase_target = ctx.packet.params[ctx.contract.phases[ctx.p7.phase_index].target_field]
        base_target = ctx.contract.fields[phase_target.name].arguments.get("actuator") == "base"
        reference_pose = world.base_pose_world if base_target else world.eef_pose_world
        if ctx.contract.fields[phase_target.name].arguments.get('actuator') == 'torso':
            remaining=abs(float(phase_target.value)-float(world.signals['torso']['position_m']))
        else:
            target_world = motion_target(phase_target,StateGeometry.frame(phase_target.frame_entity,world),reference_pose)
            current_position = world.base_pose_world[:3, 3] if base_target else world.eef_pose_world[:3, 3]
            remaining = float(np.linalg.norm(target_world[:3, 3] - current_position))
        entry = ctx.p7.entry_distance or max(remaining, np.finfo(float).eps)
        ctx.p7 = replace(ctx.p7, entry_distance=entry, steps_in_phase=ctx.p7.steps_in_phase+1,
                         progress=float(np.clip(1.0-remaining/entry, 0, 1)))
        with tracer.measure("c09_reflex"):
            override = chain2_reflex(ctx.packet, obs, C) if "c2_reflex" not in disabled else None
        if override:
            triggers.append("c2_reflex")
        with tracer.measure("c10_solve"):
            action = C.c10.solve(ctx.packet, ctx.contract, ctx.p7, world, override)
        controller_failure=getattr(C.c10,'failure_reason',None)
        if controller_failure:
            tracer.write({'kind':'controller_failure','tick':tick,'contract':ctx.contract,'p7':ctx.p7,
                'parameters':ctx.packet.params,'world':world,'posture_ik':getattr(C.adapter,'posture_diagnostic',{})})
            if override is None and retry_grasp(ctx,C,world,controller_failure,cfg,tracer):
                triggers.append('c3b_grasp_repair')
                assert ctx.p7 is not None and ctx.packet is not None
                # Execute the new C7 entry through the ordinary C10 path this tick.
                action = C.c10.solve(ctx.packet, ctx.contract, ctx.p7, world, None)
                controller_failure = getattr(C.c10,'failure_reason',None)
        if controller_failure:
            if recover(ctx.contract,world,controller_failure):
                previous=world
                continue
            return EpisodeResult(False,tick,'controller_failure:'+controller_failure,ctx.selector_calls,ctx.prep_calls)
        ctx.executed_actuator = C.c10.last_actuator
        C.adapter.set_execution_context(ctx.contract, ctx.p7, C.c10.last_target, C.c10.last_error)
        with tracer.measure("c10_execute"):
            obs, success = C.c10.execute(env, action)
        ctx.reflex_event = override.event if override else None
        ctx.steps += 1
        tracer.log_tick(tick, ctx, world, delta, proposals, rejected, override, action, triggers)
        previous = world
        if success:
            return EpisodeResult(True, tick + 1, "environment_success", ctx.selector_calls, ctx.prep_calls)
        if obs.get("environment_done", False):
            chain5_replan(ctx.contract, world, "environment_terminated_without_success", tracer)
            return EpisodeResult(False, tick + 1, "environment_terminated_without_success", ctx.selector_calls, ctx.prep_calls)
    if ctx.contract:
        chain5_replan(ctx.contract, world, "episode_timeout", tracer)
    return EpisodeResult(False, cfg["control"]["max_ticks"], "episode_timeout", ctx.selector_calls, ctx.prep_calls)
