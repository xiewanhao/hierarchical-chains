from __future__ import annotations
from five_chains.types import (ChainId, Contract, ParamPacket, FeedbackDelta, Components,
    Proposal, P6, P7, WorldState, ReadoutError)


def chain3a_fast(contract: Contract, packet: ParamPacket, delta: FeedbackDelta,
                 C: Components, cfg: dict) -> Proposal | None:
    if not any(abs(delta.continuous.get(k, 0)) > th for k, th in cfg["fb_fast"]["thresholds"].items()):
        return None
    updates = C.c8.fast_adjust(contract, packet, delta)
    return Proposal(ChainId.FB_FAST, updates) if updates else None


def chain3b_full(contract: Contract, p6: P6, p7: P7, world: WorldState,
                 delta: FeedbackDelta, C: Components) -> tuple[P6, P7, Proposal | None]:
    new_p7 = C.c7.update(contract, p7, world, delta)
    if 'grasp_candidate_rejected' in delta.events:
        acquisition = frozenset(('grasp_pose', 'pregrasp_pose', 'torso_at_object'))
        if any(n not in contract.fields or not C.c12.may_write(contract, n, ChainId.FB_FULL)
               for n in acquisition):
            raise ReadoutError('contract does not allow grasp parameter repair')
        refreshed = C.c6.prepare(contract, world, p6, acquisition, ChainId.FB_FULL)
        if any(refreshed.fields[n].status != 'ready' for n in acquisition):
            raise ReadoutError('no remaining prepared grasp candidate')
        # Keep destination P6 fixed, but re-read goals that predicted the old grasp.
        affected = acquisition | frozenset(n for n, spec in contract.fields.items()
            if spec.arguments.get('held_object_goal') and C.c12.may_write(contract, n, ChainId.FB_FULL))
        updates = C.c8.readout(contract, refreshed, new_p7, world, affected, ChainId.FB_FULL)
        if not affected <= updates.keys():
            raise ReadoutError('incomplete grasp repair readout')
        return refreshed, new_p7, Proposal(ChainId.FB_FULL, updates, C.c8.bounds(contract, new_p7))
    # An unrelated edge must not re-anchor a relative motion goal to the
    # already moving object (e.g. repeated +lift-height targets).
    if new_p7.phase_index == p7.phase_index:
        if 'grasp_relation_changed' in delta.events:
            phase=contract.phases[new_p7.phase_index]
            obj=contract.call.bindings.get('object')
            # Destination-frame/world P6 remains fixed. Re-reading source-relative
            # lift offsets would repeatedly move the goal, so exclude those.
            fields=frozenset(n for n in phase.fields if C.c12.may_write(contract,n,ChainId.FB_FULL)
                and contract.fields[n].arguments.get('held_object_goal') and contract.fields[n].prep_frame!=obj)
            if fields:
                updates=C.c8.readout(contract,p6,new_p7,world,fields,ChainId.FB_FULL)
                return p6,new_p7,Proposal(ChainId.FB_FULL,updates,C.c8.bounds(contract,new_p7))
        return p6, new_p7, None
    phase = contract.phases[new_p7.phase_index]
    affected = frozenset(n for n in phase.fields if C.c12.may_write(contract, n, ChainId.FB_FULL))
    if not affected:
        return p6, new_p7, None
    p6 = C.c6.prepare(contract, world, p6, affected, ChainId.FB_FULL)
    updates = C.c8.readout(contract, p6, new_p7, world, affected, ChainId.FB_FULL)
    return p6, new_p7, Proposal(ChainId.FB_FULL, updates, C.c8.bounds(contract, new_p7))
