from __future__ import annotations
from dataclasses import replace
import numpy as np
from five_chains.types import Contract, P7, WorldState, FeedbackDelta
from five_chains.components.c12_contract import predicate


class PhaseTracker:
    def reset(self, contract: Contract, world: WorldState) -> P7:
        return P7.initial(contract)

    def update(self, contract: Contract, p7: P7, world: WorldState, delta: FeedbackDelta) -> P7:
        if p7.contract_id != contract.contract_id:
            raise ValueError("P7 contract mismatch")
        if 'grasp_candidate_rejected' in delta.events:
            phase = contract.phases[p7.phase_index]
            if (phase.name not in ('approach', 'descend') or phase.gripper != 'open'
                    or world.signals.get('grasp_transforms')):
                raise ValueError('grasp repair requires an unheld open-hand acquisition phase')
            for index, entry_phase in enumerate(contract.phases):
                if entry_phase.name == 'raise_for_grasp' and entry_phase.gripper == 'open':
                    return P7(contract.contract_id, index, entry_phase.name, 0., 0)
            raise ValueError('contract has no grasp repair entry')
        index = p7.phase_index
        if index + 1 < len(contract.phases) and predicate(contract.phases[index + 1].enter_when, world, delta):
            index += 1
            return P7(contract.contract_id, index, contract.phases[index].name, 0.0, 0)
        remaining = float(world.signals.get("target_distance_m", p7.entry_distance))
        entry = p7.entry_distance or max(remaining, np.finfo(float).eps)
        progress = float(np.clip(1.0 - remaining / entry, 0, 1))
        return replace(p7, progress=progress, entry_distance=entry)
