from dataclasses import replace
import numpy as np
import pytest
from five_chains.chains.c1_prep import chain1_prep
from five_chains.chains.grasp_repair import retry_grasp, repair_world
from five_chains.geometry import pose
from five_chains.preparation import decode_preparation
from five_chains.types import RuntimeContext, ChainId


class Log:
    def __init__(self): self.rows=[]
    def write(self, row): self.rows.append(row)


def setup_repair(C, call, world):
    class Provider:
        def candidates(self, entity, world): return (pose([0,0,.03]),pose([.02,0,.03]))
    C.c6.recipes.grasp_provider=Provider()
    c,p6,p7,proposal=chain1_prep(call,world,C)
    packet,_=C.c10.arbitrate(None,[proposal],c,C.c12)
    i=next(i for i,p in enumerate(c.phases) if p.name=='approach')
    ctx=RuntimeContext(contract=c,p6=p6,p7=replace(p7,phase_index=i,phase_name='approach'),packet=packet,selector_calls=1,steps=17)
    world=replace(world,signals={**world.signals,'grasp_diagnostics':{'vegetable':{}}})
    return ctx,world


def test_retry_changes_consistent_candidate_and_preserves_contract_budget(C,call,world,cfg):
    ctx,w=setup_repair(C,call,world); log=Log(); old=ctx.packet; old_p6=ctx.p6
    assert retry_grasp(ctx,C,w,'motion_path:no_clear_goal',cfg,log)
    assert ctx.selector_calls==1 and ctx.steps==17 and C.c10.executions==0
    assert ctx.p7.phase_name=='raise_for_grasp' and ctx.p7.steps_in_phase==0
    assert ctx.packet.contract_id==old.contract_id
    assert not np.allclose(ctx.packet.params['grasp_pose'].value,old.params['grasp_pose'].value)
    assert ctx.p6.fields['place_pose'] is old_p6.fields['place_pose']
    contact=decode_preparation(ctx.contract.fields['grasp_pose'],ctx.p6.fields['grasp_pose'].value,1.)
    pre=decode_preparation(ctx.contract.fields['pregrasp_pose'],ctx.p6.fields['pregrasp_pose'].value,1.)
    pre[:3,3]-=C.c6.recipes.approach_offset(pre,w,'vegetable',.1)
    assert np.allclose(contact,pre)
    assert ctx.packet.params['grasp_pose'].source_chain==ChainId.FB_FULL
    assert ctx.packet.params['speed_limit'] is old.params['speed_limit']
    assert log.rows[-1]['kind']=='grasp_parameter_repaired'


def test_exhausted_candidates_never_commit_stale_parameters(C,call,world,cfg):
    ctx,w=setup_repair(C,call,world);log=Log()
    assert retry_grasp(ctx,C,w,'motion_path:no_clear_goal',cfg,log)
    before=(ctx.p6,ctx.p7,ctx.packet)
    i=next(i for i,p in enumerate(ctx.contract.phases) if p.name=='descend')
    ctx.p7=replace(ctx.p7,phase_index=i,phase_name='descend')
    assert not retry_grasp(ctx,C,w,'motion_path:no_clear_goal',cfg,log)
    assert ctx.p6 is before[0] and ctx.packet is before[2]
    assert log.rows[-1]['kind']=='grasp_repair_exhausted'
    assert C.c10.executions==0


@pytest.mark.parametrize('case',['held','touching','closed','joint_limit','budget','freeze','disabled'])
def test_guarded_cases_do_not_retry(C,call,world,cfg,case):
    ctx,w=setup_repair(C,call,world);log=Log();reason='motion_path:no_clear_goal'
    if case=='held':w=replace(w,signals={**w.signals,'grasp_transforms':{'vegetable':np.eye(4)}})
    if case=='touching':w.signals['grasp_diagnostics']['vegetable']['left_finger_contact']=True
    if case=='closed':w=replace(w,gripper_width=.04)
    if case=='joint_limit':reason='motion_path:start_outside_limits'
    if case=='budget':cfg['grasp']['parameter_repair']['max_attempts']=0
    if case=='freeze':cfg['ablation']['freeze_after_prep']=True
    if case=='disabled':cfg['ablation']['disable_chains']=['c3b_fb_full']
    old=ctx.packet
    assert not retry_grasp(ctx,C,w,reason,cfg,log)
    assert ctx.packet is old and not ctx.grasp_rejections and not log.rows


def test_rejections_are_scoped_to_contract(C,call,world,cfg):
    ctx,w=setup_repair(C,call,world);log=Log()
    assert retry_grasp(ctx,C,w,'motion_path:no_clear_goal',cfg,log)
    scoped=repair_world(w,ctx)
    spec=ctx.contract.fields['grasp_pose']
    alternative=C.c6.recipes.prepare(spec,ctx.contract,scoped)
    other=replace(ctx.contract,contract_id='other')
    original=C.c6.recipes.prepare(spec,other,scoped)
    assert not np.allclose(alternative,original)
