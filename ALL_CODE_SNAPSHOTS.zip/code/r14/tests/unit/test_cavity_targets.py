from dataclasses import replace
import numpy as np
from five_chains.types import SkillCall
from five_chains.geometry import pose,inverse
from five_chains.chains.c1_prep import chain1_prep


def held_world(world):
    return replace(world,signals={'grasp_transforms':{'bowl':pose([.03,0,.04])},
        'cavity_entities':['microwave_interior'],'object_bottom_offsets':{'bowl':np.array([0.,0.,-.02])}})


def test_cavity_goal_respects_floor_and_body_to_tcp(C,world):
    world=held_world(world)
    call=SkillCall('place',3,'place_object_in_container',{'object':'bowl','target':'microwave_interior'})
    c,p6,p7,prop=chain1_prep(call,world,C)
    goal_body=prop.updates['place_pose'].value@world.signals['grasp_transforms']['bowl']
    bottom=goal_body@np.array([0,0,-.02,1])
    cavity=world.entities['microwave_interior']
    floor=cavity.pose_world[2,3]-cavity.extent[2]
    assert np.isclose(bottom[2]-floor,.01)


def test_entrance_goal_is_outside_opening(C,world):
    world=held_world(world)
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'})
    c,p6,p7,prop=chain1_prep(call,world,C)
    body=prop.updates['place_pose'].value@world.signals['grasp_transforms']['bowl']
    cavity=world.entities['microwave_interior']
    local=inverse(cavity.pose_world)@body
    assert np.isclose(local[1,3],-cavity.extent[1]-.08)


def test_l1_entry_reuses_grasp_and_withdrawal_keeps_height(C,world):
    world=held_world(world)
    aux=SkillCall('attitude',2,'maintain_container_attitude',{'object':'bowl'})
    call=SkillCall('entry',1,'local_pose_servo',{'reference':'microwave_interior'},(aux,))
    c,p6,p7,prop=chain1_prep(call,world,C)
    goal_body=prop.updates['local_target'].value@world.signals['grasp_transforms']['bowl']
    bottom=goal_body@np.array([0,0,-.02,1])
    cavity=world.entities['microwave_interior']
    assert np.isclose(bottom[2],cavity.pose_world[2,3]-cavity.extent[2]+.01)
    place=SkillCall('release',3,'place_object_in_container',{'object':'bowl','target':'microwave_interior'})
    c,p6,p7,prop=chain1_prep(place,world,C)
    assert np.isclose(prop.updates['retreat_pose'].value[2,3],world.eef_pose_world[2,3])


def test_selected_direct_cavity_place_expands_transport_without_new_selection(C,world):
    world=replace(world,signals={'cavity_entities':['microwave_interior'],'object_bottom_offsets':{'bowl':np.array([0.,0.,-.02])}})
    call=SkillCall('direct',3,'place_object_in_container',{'object':'bowl','target':'microwave_interior'})
    c,p6,p7,prop=chain1_prep(call,world,C)
    assert c.call is call and call.next_call is None and c.followup.get('target') is None
    assert c.followup['entry_variant']=='selected_cavity_placement'
    phases=[p.name for p in c.phases]
    assert phases==['base_to_object','raise_for_grasp','approach','descend','grasp','lift','base_to_clearance','align_payload_outside','raise_torso','raise_to_entry','base_to_target','carry','release','retreat']
    assert c.fields['lift_pose'].arguments['include_target_height'] is False
    assert c.fields['place_pose'].arguments.get('placement_mode')!='entrance'
    assert {'microwave_interior.pose','microwave_interior.extent'}<=c.fields['grasp_pose'].depends_on
    assert C.c6.recipes.preview_target(c,world)=='microwave_interior'
    assert p7.phase_index==0 and set(prop.updates)==set(c.fields)
    # Existing held-object release entry still avoids unnecessary reacquisition.
    held=replace(world,signals={**world.signals,'grasp_transforms':{'bowl':np.eye(4)}})
    release=C.c12.initialize_entry(C.c12.expand(call),held)
    assert release.phases[0].name=='base_to_target'


def test_grasp_preview_includes_planned_base_turn_and_obstacle_dependencies(C,world):
    from scipy.spatial.transform import Rotation
    from five_chains.skills.recipes import GeometricGraspProvider
    seen=[]
    class Recorder(GeometricGraspProvider):
        def filter_for_followup(self,entity,world,candidates,target,goal):
            seen.append(goal.copy());return candidates
    C.c6.recipes.grasp_provider=Recorder(C.c10.config)
    door=replace(world.entities['handle'],name='door')
    world=replace(world,entities={**world.entities,'door':door},signals={'cavity_entities':['microwave_interior'],'fixture_front_entities':['microwave_interior'],
        'object_bottom_offsets':{'bowl':np.array([0.,0.,-.02])},'cavity_obstacles':{'microwave_interior':['door']}})
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'},next_call=SkillCall('insert',1,'local_pose_servo',{'reference':'microwave_interior'}))
    c,p6,p7,prop=chain1_prep(call,world,C)
    expected=Rotation.from_euler('z',np.pi/2).as_matrix()
    assert np.allclose(seen[-1][:3,:3],expected)
    assert np.allclose(p6.fields['grasp_pose'].provenance['preview']['base_turn_world'],expected)
    assert {'door.pose','door.extent'}<=c.fields['grasp_pose'].depends_on


def test_cavity_release_height_is_bounded_by_candidate_geometry_and_uses_measured_held_aperture(C,world,call):
    from dataclasses import replace
    from five_chains.geometry import pose
    from five_chains.skills.recipes import RecipeRegistry
    import numpy as np
    obj=call.bindings['object'];target='microwave_interior';seen=[]
    class Provider:
        def candidates(self,entity,world):return (pose([0.,0.,.01]),)
        def filter_for_followup(self,entity,world,candidates,target,goal):
            seen.append(candidates[0].copy())
            floor=world.entities[target].pose_world[2,3]-world.entities[target].extent[2]
            return candidates if goal[2,3]>=floor+.08-1e-8 else ()
    r=RecipeRegistry(Provider(),C.c6.recipes.config)
    c=C.c12.expand(replace(call,bindings={'object':obj,'target':target}))
    world=replace(world,signals={'cavity_entities':[target],'object_bottom_offsets':{obj:[0.,0.,-.02]}})
    local=r.prepare(c.fields['place_pose'],c,world)
    assert np.isclose(local[2,3],-world.entities[target].extent[2]+.08)
    assert len(seen)>1
    held=replace(world,signals={**world.signals,'grasp_transforms':{obj:pose([0.,0.,.03])}})
    seen.clear();r.prepare(c.fields['place_pose'],c,held)
    assert not np.allclose(seen[0],pose([0.,0.,.01]))
