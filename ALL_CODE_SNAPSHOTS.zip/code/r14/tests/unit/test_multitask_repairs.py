from dataclasses import replace
import numpy as np
import pytest
from five_chains.geometry import pose
from five_chains.skills.asset_grasps import AssetGraspProvider
from five_chains.skills.recipes import GeometricGraspProvider
from five_chains.chains.c1_prep import chain1_prep
from test_asset_grasps import setup_cache


def test_unknown_geometric_pose_uses_measured_gripper_tcp_for_future_fit(cfg,world,tmp_path):
    provider,world,_=setup_cache(cfg,world,tmp_path)
    cavity=replace(world.entities['microwave_interior'],pose_world=np.eye(4),extent=np.array([.3,.3,.3]))
    world=replace(world,eef_pose_world=pose([10,20,30]),entities={**world.entities,'microwave_interior':cavity},
        signals={**world.signals,'gripper_collision_points_world':np.array([[10.,20.,30.],[10.02,20.,30.]])})
    candidate=pose([0.,0.,0.])
    assert provider.filter_for_followup('vegetable',world,(candidate,),'microwave_interior',np.eye(4))
    assert not provider.filter_for_followup('vegetable',world,(candidate,),'microwave_interior',pose([1.,0.,0.]))
    missing=replace(world,signals={k:v for k,v in world.signals.items() if k!='gripper_collision_points_world'})
    assert not provider.filter_for_followup('vegetable',missing,(candidate,),'microwave_interior',np.eye(4))


def test_high_source_requires_torso_before_pregrasp(C,call,world):
    world=replace(world,entities={**world.entities,'vegetable':replace(world.entities['vegetable'],pose_world=pose([.2,0,1.45]))},
        signals={'torso':{'position_m':0.,'origin_world':[0,0,.7],'range_m':[0,.34]}})
    c,p6,p7,prop=chain1_prep(call,world,C)
    height=float(prop.updates['torso_at_object'].value)
    assert .2<height<=.34
    phases=[p.name for p in c.phases]
    assert phases.index('base_to_object')<phases.index('raise_for_grasp')<phases.index('approach')


def test_only_small_measured_reset_overshoot_is_projected_to_joint_boundary(C,world):
    def state(q):return replace(world,signals={'torso':{'position_m':q,'range_m':[0.,.34]}})
    assert C.c10._measured_torso_reference(state(-1e-8))==0.
    assert C.c10._measured_torso_reference(state(.34000001))==.34
    with pytest.raises(ValueError,match='beyond reset tolerance'):C.c10._measured_torso_reference(state(-.01))


def test_fixture_retreat_uses_measured_front_without_raising_near_upper_cabinet(C,world,call):
    from dataclasses import replace
    import numpy as np
    from five_chains.geometry import pose
    contract=C.c12.expand(call)
    target=call.bindings['target']
    world=replace(world,eef_pose_world=pose([.4,0.,.8]),signals={**world.signals,'fixture_front_entities':[target]})
    spec=contract.fields['retreat_pose']
    retreat=C.c6.recipes.prepare(spec,contract,world)
    assert np.isclose(retreat[2,3],.8)
    delta=retreat[:3,3]-world.eef_pose_world[:3,3]
    assert np.allclose(delta,[0.,-.18,0.])


def test_release_requires_physical_dwell_opening_and_no_remaining_contact(cfg):
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    from types import SimpleNamespace as N
    a=object.__new__(RoboCasaAdapter);a.arm='right';a.phase_ticks=24
    touching=[True]
    a.env=N(objects={'cup':N(contact_geoms=['cup'])},check_contact=lambda *args:touching[0])
    a.robot=N(gripper={'right':N()})
    raw={'robot0_gripper_qpos':[.04,-.04]}
    assert not a._release_ready('cup',[],raw)
    a.phase_ticks=25
    assert not a._release_ready('cup',[],raw)
    touching[0]=False
    assert not a._release_ready('cup',[],{'robot0_gripper_qpos':[.025,-.025]})
    assert a._release_ready('cup',[],raw)
    assert not a._release_ready('cup',['cup'],raw)


def test_native_support_surface_uses_object_bottom_and_upright_attitude(C,world,call):
    import numpy as np
    from dataclasses import replace
    from scipy.spatial.transform import Rotation
    from five_chains.geometry import pose
    obj=call.bindings['object'];target=call.bindings['target']
    world=replace(world,entities={**world.entities,obj:replace(world.entities[obj],pose_world=pose([.2,0.,.8],Rotation.from_euler('x',.4).as_matrix()))},
        signals={'support_surface_regions':[target],'upright_entities':[obj],'object_bottom_offsets':{obj:[0.,0.,-.043]}})
    c=C.c12.expand(call);local=C.c6.recipes.prepare(c.fields['place_pose'],c,world)
    body=world.entities[target].pose_world@local
    assert np.allclose(body[:3,2],[0.,0.,1.])
    assert np.isclose(local[2,3],.043+C.c6.recipes.config['grasp']['placement_clearance_m'])


def test_control_release_exceeds_native_button_clearance(C,world):
    from five_chains.types import SkillCall
    from dataclasses import replace
    import numpy as np
    world=replace(world,signals={**world.signals,'surface_normals':{'start':[0.,-1.,0.]}})
    c=C.c12.expand(SkillCall('press',3,'activate_control',{'appliance':'microwave','control':'start'}))
    target=C.c6.recipes.prepare(c.fields['release_pose'],c,world)
    assert np.allclose(target[:3,3]-world.entities['start'].pose_world[:3,3],[0.,-.30,0.])


def test_supported_open_release_requires_native_placement_and_distinct_stable_frames():
    from five_chains.envs.robocasa_adapter import RoboCasaAdapter
    from types import SimpleNamespace as N
    from five_chains.geometry import pose
    import numpy as np
    a=object.__new__(RoboCasaAdapter);a.arm='right';a.phase_ticks=30
    item=N(contact_geoms=['cup'],root_body='cup');fixture=object();position=np.array([0.,0.,1.]);supported=[True]
    data=N(time=0.,get_body_xpos=lambda n:position.copy(),get_body_xmat=lambda n:np.eye(3))
    a.env=N(objects={'cup':item},sim=N(data=data),check_contact=lambda x,y:supported[0] if y is fixture else True)
    a.robot=N(gripper={'right':N()});a.region_fixtures={'tray':fixture}
    a.context=(N(contract_id='place',call=N(bindings={'target':'tray'})),N(phase_index=2),pose([0.,0.,0.]),0.)
    raw={'robot0_gripper_qpos':[.04,-.04]}
    for i in range(11):
        data.time=i*.05
        assert a._release_ready('cup',[],raw,True)==(i==10)
        before=a.release_support_evidence[('place',2,'cup')]['stable_frames']
        a._release_ready('cup',[],raw,True)
        assert a.release_support_evidence[('place',2,'cup')]['stable_frames']==before
    assert not a._release_ready('cup',[],raw,False)
    supported[0]=False
    assert not a._release_ready('cup',[],raw,True)
    supported[0]=True;position[0]+=.003;data.time+=.05
    assert not a._release_ready('cup',[],raw,True)
