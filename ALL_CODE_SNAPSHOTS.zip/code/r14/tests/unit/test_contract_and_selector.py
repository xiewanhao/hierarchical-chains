from dataclasses import replace
import pytest
from five_chains.types import ChainId, ContractError, ContractConflict, SelectorOutputError
from five_chains.components.c11_selector import parse_call, ScriptedSelector, SelectorAdapter


def test_contract_requires_bindings_and_layer(C, call):
    with pytest.raises(ContractError):
        C.c12.expand(replace(call, bindings={}))
    with pytest.raises(ContractError):
        C.c12.expand(replace(call, layer=1))
    c = C.c12.expand(call)
    assert c.fields["grasp_pose"].depends_on == {"vegetable.pose","vegetable.extent"}
    assert not C.c12.may_write(c, "speed_limit", ChainId.VISION)


def test_duplicate_writable_ownership_rejected(C, call):
    with pytest.raises(ContractConflict):
        C.c12.expand(replace(call, combined_with=(call,)))


def test_fixed_auxiliary_preserved(C, call):
    aux = replace(call, skill="maintain_container_attitude", layer=2)
    c = C.c12.expand(replace(call, combined_with=(aux,)))
    assert c.fields["tilt_limit"].default == [-.15, .15]
    assert not c.fields["tilt_limit"].writable_by


def test_strict_legacy_adapter(call):
    raw = dict(invocation_id="d1", primary=call.skill, level="L3", bindings=call.bindings, auxiliary=[], goal_window=[])
    assert parse_call(raw).skill == call.skill
    with pytest.raises(SelectorOutputError):
        parse_call({"primary": call.skill})
    with pytest.raises(SelectorOutputError):
        parse_call(dict(raw, guessed_pose=[1,2,3]))
    class Model:
        def generate(self, sample): return raw, {}
        def candidates(self, sample): return [raw]
    adapter = SelectorAdapter(Model(), lambda task, obs, history: {})
    assert adapter.select("task", {}, []).call_id == "d1"
    assert adapter.calls == 1


def test_scripted_exhaustion_is_failure(call):
    s = ScriptedSelector([call])
    assert s.select("", {}, []) == call
    with pytest.raises(SelectorOutputError):
        s.select("", {}, [])


def test_posture_primary_requires_physical_coupling(C,call,world):
    c=C.c12.expand(replace(call,skill='maintain_container_attitude',layer=2))
    with pytest.raises(ContractError):
        C.c12.initialize_entry(c,world)


def test_malformed_template_has_explicit_contract_error(tmp_path):
    from five_chains.components.c12_contract import ContractDispatcher
    from five_chains.types import SkillCall
    (tmp_path/'broken.yaml').write_text('skill: broken\nlayer: 1\n')
    with pytest.raises(ContractError):
        ContractDispatcher(tmp_path).expand(SkillCall('bad',1,'broken',{}))


def test_explicit_followup_geometry_is_a_grasp_dependency():
    from five_chains.types import SkillCall
    from five_chains.components.c12_contract import ContractDispatcher
    call=SkillCall('carry',3,'carry_container_to_region',{'object':'bowl','target':'microwave_interior'},
        next_call=SkillCall('enter',1,'local_pose_servo',{'reference':'microwave_interior'}))
    contract=ContractDispatcher().expand(call)
    for name in ('grasp_pose','pregrasp_pose'):
        assert {'microwave_interior.pose','microwave_interior.extent'}<=contract.fields[name].depends_on


def test_measured_effect_filter_does_not_choose_the_next_call():
    from five_chains.components.c11_selector import apply_observed_effect_eligibility
    from types import SimpleNamespace
    calls=[dict(primary='place_object_in_container',bindings={'object':'cup','target':'tray'}),
           dict(primary='carry_container_to_region',bindings={'object':'cup','target':'other'}),
           dict(primary='activate_control',bindings={'control':'button'})]
    model=SimpleNamespace(candidates=lambda sample:calls)
    sample={'measured_satisfied_effects':[dict(effect='placement_satisfied',bindings={'object':'cup','target':'tray'})]}
    report=apply_observed_effect_eligibility(model,sample)
    assert model.candidates(sample)==calls[1:]
    assert report['rejected'][0]['call']==calls[0]
    assert len(model.candidates({}))==3  # Scope is this live observation only.


def test_c5_same_state_infeasibility_excludes_failed_effect_without_a_task_plan():
    from five_chains.components.c11_selector import apply_observed_effect_eligibility
    from types import SimpleNamespace
    candidates=[dict(primary=name,bindings={'object':obj,'target':target}) for name,obj,target in (
        ('place_object_in_container','bowl','cavity'),('carry_container_to_region','bowl','cavity'),
        ('place_object_in_container','food','bowl'))]
    model=SimpleNamespace(candidates=lambda sample:candidates)
    sample={'current_failure_feedback':[dict(primary='place_object_in_container',bindings={'object':'bowl','target':'cavity'},reason='preparation_failure:missing grasp')]}
    report=apply_observed_effect_eligibility(model,sample)
    assert model.candidates(sample)==candidates[2:]
    assert len(report['rejected'])==2
    assert model.candidates({})==candidates
